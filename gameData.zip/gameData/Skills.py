from Utility import *
from gameData.Statuses import *

##------------CONST------------##

DAMAGE = "Damage"
MULTI = "MultiHit"
def HITS(num1: int, num2: int):
    return lambda: random.randint(num1, num2)
HEAL = "Healing"
STATUS = "Status"
PASSIVE = "Passive"
SPECIAL = "Special"

##------------Player Class Skills------------##

##--Lancer--##
def ready_stance_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    phys=0
    mags=0
    for skill in target.skills:
        if "Damage" in skill.type_ and "magic" == skill.statsUsed[0]:
            mags += 1
        elif "Damage" in skill.type_ and "strength" == skill.statsUsed[0]:
            phys += 1

    if phys > mags:
        StanceP.inflict(user)
    else:
        StanceM.inflict(user)
        
    self.onCooldown = True
    self.usable = False
lancer_ready_stance = PlayerSkill("Ready Stance", [STATUS], 4, 2, 
                f"Depending on opposer, gain Stance. M or Stance. P.",
                customEffect=ready_stance_effect, weight=8)

def morstalis_thrust_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth *  0.65):
        damage = round(damage * 1.5)
        
    stance = next((status for status in user.statusList if status.name in ["Stance. M", "Stance. P"]), None)
    if stance:
        stance.duration = 0
        say(f"{Color['green']}{stance.name}s Duration Was Set To 0!{Color['reset']}")
        
        if user.health <= round(user.maxHealth * 0.65):
            Steadfast.inflict(user)
    return damage
lancer_morstalis_thrust = PlayerSkill("Morstalis Thrust", [DAMAGE, [MULTI, 2]], 6, 3, 
                f"Strength vs. Defense x 2. If health is below 65%, increase damage (1.5x!). If Stance. M or Stance. P is present, reset the duration of the status. If both conditions are met, gain Steadfast. Will inflict Bleed/Puncture)",
                hit=100, critical=135, element="physical", status=[Bleed, Puncture], willStatus=True, statsUsed=["strength", "defense", 2], conditional=morstalis_thrust_conditional, weight=18)

def defensive_whirl_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name in ["Stance. M", "Stance. P"] for s in user.statusList):
        BoostII.inflict(user)
        damage = round(damage * 1.5)
    
    difference = target.defense - user.defense
    percent = 0
    if difference >= 5:
        GuardU.inflict(user)
        for i in range(difference):
            percent += 0.02
            if percent >= 0.44:
                percent = 0.44
                break
        
        if percent:
            damage += round(damage * percent)
    return damage
lancer_defensive_whirl = PlayerSkill("Defensive Whirl", [DAMAGE, [MULTI, HITS(1,5)]], 7, 3,
                f"Strength vs. Defense x 1-5. If Stance. M/Stance. P are present, gain Boost II and increase damage (1.5x!). If Defense is lower than opposers by 5 points, gain Guard. U and increase damage (2% per Defense stat diffrence, max 44%). Chance to inflict Break/Gash.",
                hit=80, critical=90, element="wind", status=[Break, Gash], statsUsed=["strength", "defense", 1.5], conditional=defensive_whirl_conditional, weight=16)

##--Magi--##
# Never Used Directly
fire_weather_ball = PlayerSkill("Weather Ball", [DAMAGE, [MULTI, HITS(1,2)]], 0, 0, None,
                                hit=80, critical=75, element="fire", statsUsed=["magic", "resistance", 1.6], status=[Burn], stacks=2, weight=0)
ice_weather_ball = PlayerSkill("Weather Ball", [DAMAGE, [MULTI, HITS(1,2)]], 0, 0, None,
                                hit=80, critical=75, element="ice", statsUsed=["magic", "resistance", 1.6], status=[Freeze], willStatus=True, weight=0)
thunder_weather_ball = PlayerSkill("Weather Ball", [DAMAGE, [MULTI, HITS(1,2)]], 0, 0, None,
                                hit=80, critical=75, element="thunder", statsUsed=["magic", "resistance", 1.6], status=[Shock], statusTarget="user", weight=0)
wind_weather_ball = PlayerSkill("Weather Ball", [DAMAGE, [MULTI, HITS(1,2)]], 0, 0, None,
                                hit=90, critical=140, element="wind", statsUsed=["magic", "resistance", 1.8], weight=0)

##---##

def weather_ball_effect(self, user: Player, target: Enemy, actions=1):
    fire_weather_ball.usable = True
    ice_weather_ball.usable = True
    thunder_weather_ball.usable = True
    wind_weather_ball.usable = True

    self.onCooldown = True
    self.usable = False
    self.cooldownProgress = 0
    
    element = ["fire", "thunder", "ice", "wind"]
    for e in element:
        if getattr(target, e) in ["Weak", "Super Weak"]:
            affinity = e
            break
    
    else:
        affinity = "fire"
    
    result = None
    if affinity == "fire":
        result = fire_weather_ball.effect(user, target, actions)

    elif affinity == "ice":
        result = ice_weather_ball.effect(user, target, actions)

    elif affinity == "thunder":
        result = thunder_weather_ball.effect(user, target, actions)

    elif affinity == "wind":
        result = wind_weather_ball.effect(user, target, actions)

    if user.lastAction == "Miss":
        self.cooldownProgress += 1
        
    return result
magi_weather_ball = PlayerSkill("Weather Ball", [SPECIAL], 7, 2, 
                                "Magic vs. Resistance x 1-2. Default element is Fire. Changes element to match an affinity the opposer is Weak to. If Fire, chance to inflict 2 stacks of Burn. If Ice, will inflict Freeze. If Thunger, chance to gain Shock. If Wind, higher chance to critical.",
                                hit=80, critical=75,
                                customEffect=weather_ball_effect, weight=17)

def thunger_alter_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Shock" == s.family for s in target.statusList):
        damage *= 2
        Shock.inflict(user)
    return damage
magi_thunger_alter = PlayerSkill("Thunger Alter", [DAMAGE, [MULTI, HITS(1,3)]], 8, 3,
                                 "Magic vs. Resistance x 1-3. If any Shock statuses are present on the opposer, gain Shock and increase damage (2x!). Chance to inflict 3 stacks of Spark/Burn/Static.",
                                 hit=80, critical=55, element="thunder", status=[Spark, Burn, Static], stacks=3, statsUsed=["magic", "resistance", 1.6],
                                 conditional=thunger_alter_conditional, weight=15)

def mana_rupture_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    ManaRegen.inflict(user)
    if user.resistance > target.resistance:
        damage *= 2
    return damage
magi_mana_rupture = PlayerSkill("Mana Rupture", [DAMAGE, [MULTI, HITS(2,4)]], 10, 4,
                                 "Magic vs. Resistance x 2-4. If Resistance is greater than opposers Resistance, increase damage (2x!). Gain Mana Regen. Will inflict Frail II/Cripple I.",
                                 hit=90, critical=80, element="mighty", status=[FrailII, CrippleI], willStatus=True, statsUsed=["magic", "resistance", 2],
                                 conditional=mana_rupture_conditional, weight=17)

def attune_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.actions <= 1:
        self.attune = None

    if (user.lastAction == "Skill" and "Damage" in user.lastSkill.type_ and user.lastSkill.element in ["fire", "ice", "thunder", "wind"]):
        if self.attune:
            if self.attune == "fire" and user.lastSkill.element == self.attune:
                statuses = [Heated, Scorch]
                for status in statuses:
                    if random.randint(1, 100) >= 45:
                        status.inflict(enemy)
            elif self.attune == "ice" and user.lastSkill.element == self.attune:
                if random.randint(1, 100) >= 75:
                    DeepFreeze.inflict(enemy)
            elif self.attune == "thunder" and user.lastSkill.element == self.attune:
                if any("Shock" == s.name and s.stacks < s.maxStack for s in user.statusList) or not any("Shock" == s.name for s in user.statusList):
                    Shock.inflict(user)
                else:
                    Overload.inflict(user)
            elif self.attune == "wind" and user.lastSkill.element == self.attune:
                Keen.inflict(user, 2)

        if self.attune != user.lastSkill.element or not self.attune:
            say(f"{Color['yellow']}Attunement Is Now {user.lastSkill.element.capitalize()}!{Color['reset']}")
            self.attune = user.lastSkill.element
passive_attune = PlayerSkill("Elemental Attune", [PASSIVE], 0, 0,
                             "Start battle with no Attunement. When using damaging skills, change Attunement to the current skills element. When using a skill that matches the current Attunement, activate effects; If Fire, chance to inflict Heated/Scorch. If Ice, chance to inflict Deep Freeze. If Thunger, gain Shock/Overload (If Shock is at max stacks). If Wind, gain 2 stacks of Keen. Attunement can only be Fire, Ice, Thunger, or Wind.", weight=0)
passive_attune.passive = types.MethodType(attune_passive, passive_attune)
passive_attune.attune = None

##--Ferkin--##
ferkin_munch = PlayerSkill("Munch", [DAMAGE, [MULTI, HITS(1,2)]], 4, 2,
                f"Strength vs. Defense x 1-2. Restore Health (45% of dealt damage). Chance to inflict Bleed.",
                hit=80, critical=80, element="physical", status=[Bleed], statsUsed=["strength", "defense", 1.5], damHeal=0.45, meter="health", weight=18)

def beast_swipe_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
        if sum(1 for s in target.statusList if s.family == "Bleed") >= 2:
            BoostII.inflict(user)
        missingPercent = (target.maxHealth - target.health) / target.maxHealth
        bonus = 1 + (0.05 * int(missingPercent / 0.05))
        return round(damage * bonus)
ferkin_beast_swipe = PlayerSkill("Beast Swipe", [DAMAGE], 7, 3,
                f"Strength vs. Defense. Increase damage (5%!) for every 5% the opposer is missing. If opposer has 2+ Bleed statuses, gain Boost II. Chance to inflict Bleed/Gash.",
                hit=80, critical=85, element="mighty", status=[Bleed, Gash], statsUsed=["strength", "defense", 2],
                conditional=beast_swipe_conditional, weight=15)

def familial_instinct_healCondition(damage, user, target):
    hasBleed = any(status.name == "Bleed" for status in target.statusList)
    hasGash = any(status.name == "Gash" for status in target.statusList)

    if hasBleed and hasGash:
        return True
    return False
ferkin_familial_instinct = PlayerSkill("Familial Instinct", [DAMAGE, [MULTI, HITS(2,5)]], 10, 3, 
                f"Strength vs. Defense x 2-5. Chance to inflict 3 stacks of Hemorrhage/Gash/Sear. If the enemy has Bleed and Gash, restore Health (75% of damage dealt). Take recoil (40% of damage).",
                hit=65, critical=80, element="fire", status=[Hemorrhage, Gash, Sear], stacks=3, statsUsed=["strength", "defense", 2.5], recoil=[True, 40], damHeal=0.75, meter="health",
                healCondition=familial_instinct_healCondition, weight=12)

##--Accursed--##
def malfira_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.speedMeter += 15
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
    return damage
accursed_malfira = PlayerSkill("Malfira", [DAMAGE, [MULTI, HITS(1,2)]], 5, 2,
                                   "Magic vs. Resistance x 1-2. Raise Speed Meter by 15. If any Bleed statuses are present on the opposer, inflict Sear. Chance to inflict Burn/Scorch.",
                                    hit=80, critical=60, element="fire", status=[[Sear, "Bleed"], Burn, Scorch], onlyStatusCondition=True, statsUsed=["magic", "resistance", 2], conditional=malfira_conditional, weight=16)

def malwind_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if sum(1 for status in target.statusList if status.align == "Negative") >= 4:
        Venom.inflict(target)
        Plague.inflict(target)

    for status in target.statusList:
        if status.family in ["Burn", "Bleed", "Poison"]:
            status.duration -= 1
            if status.duration < 0:
                status.duration = 0
            say(f"{Color['green']}{status.name}s Duration Was Extended By 1!{Color['reset']}")

            if hasattr(status, "count"):
                status.count += 1
                say(f"{Color['green']}{target.name} Gained 1 Count Of {self.name}!{Color['reset']}")
            
    return damage
accursed_malwind = PlayerSkill("Malwind", [DAMAGE, [MULTI, HITS(1,4)]], 9, 3,
                 "Magic vs. Resistance x 1-4. If 4+ Negative statuses are present on the opposer, inflict Venom/Plague. If any Burn/Bleed/Poison statuses are present on the opposer, extend/add their duration by 1. Chance to inflict Ill/Poison.",
                 hit=70, critical=80, element="wind", status=[Ill, Poison], statsUsed=["magic", "resistance", 1.5], conditional=malwind_conditional, weight=13)

def malremolio_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    # Hit Check
    if (self.hit + (user.hit * 0.5)) >= random.randint(1, 100):
        damage = sum(round(target.maxHealth * 0.02 + user.magic * 0.25) for s in target.statusList if s.align == "Negative")
        
        if damage > 0:
            if sum(1 for s in target.statusList if s.align == "Negative") >= 3:
                heal = round(user.maxHealth * 0.03) * 2
                user.health = min(user.maxHealth, user.health + heal)
                say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
                
                heal = round(user.maxMana * 0.03) * 2
                user.mana = min(user.maxMana, user.mana + heal)
                say(f"{Color['green']}{user.name}s Mana Was Restored By {heal}!{Color['reset']}")
            
            if sum(1 for s in target.statusList if s.align == "Negative") >= 5:
                Weak.inflict(target)
                damage *= 2
            say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}!{Color['reset']}")
            target.health -= damage
        else:
            say("Nothing Happened!")
    else:
        say(f"It Missed!")
        self.cooldownProgress += 1

    self.onCooldown = True
    self.usable = False
accursed_malremolio = PlayerSkill("Malremolio", [SPECIAL], 12, 4,
                 "For each Negative status on the opposer, deal damage (2% of opposers Max Health + 25% of Magic). If 3+ Negative statuses are present on the opposer, restore health/mana (3% of Max Health/Mana x 2). if 5+ Negative statuses are present on the opposer, inflict Weak and increase damage (2x!).",
                 hit=75, customEffect=malremolio_effect, weight=10)

##--Scout--##
def tri_blade_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.hit > target.hit:
        damage = round(damage * 1.5)
        Haze.inflict(user)
    return damage
scout_tri_blade = PlayerSkill("Tri-Blade", [DAMAGE, [MULTI, 3]], 4, 6,
                              f"Speed vs. Defense x 3. If Hit is greater than opposers Hit, gain Haze and increase damage (1.5x!). Chance to inflict Gash.",
                              hit=100, critical=65, element="thunder", status=[Gash], statsUsed=["speed", "defense", 1],
                              conditional=tri_blade_conditional, weight=18)

def quick_glance_conditional(self, user: Player, target: Enemy, actions=1):
    if target.health < target.maxHealth * 0.35:
        Shock.inflict(user)
        Keen.inflict(user)
scout_quick_glance = PlayerSkill("Quick Glance", [STATUS], 4, 5,
                                 f"Gain 3 stacks of Keen. If opposers Health is less than 35%, gain Shock and 1 stack of Keen.",
                                 status=[Keen], stacks=3, statusTarget="user", 
                                 conditional=quick_glance_conditional, weight=10)

def myriad_rush_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.luck > target.luck and user.hit > target.hit:
        if random.randint(1,100) > 80:
            BoostII.inflict(user)
    return damage
scout_myriad_rush = PlayerSkill("Myriad Rush", [DAMAGE, [MULTI, HITS(2, 4)]], 5, 9,
                                f"Speed vs. Defense x 2-4. If Hit and Luck are greater than opposers, chance to gain Boost II. Chance to inflict Slow I/Frail I.",
                                hit=125, critical=75, element="physical", status=[SlowI, FrailI], statsUsed=["speed", "defense", 1],
                                conditional=myriad_rush_conditional, weight=19)

##--Monk--##
def chi_palm_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.hit > 100:
        Keen.inflict(user)
        user.sanity += 3
    for status in user.statusList[:]:
        if status.name == "Peace" and status.stacks >= 5:
            status.remove(user, 3)
            damage *= 2
    if user.sanity <= -5:
        damage = round(damage * 0.5)
    return damage
monk_chi_palm = PlayerSkill("Chi-Palm", [DAMAGE, [MULTI, 2]], 5, 2,
                            f"Magic vs. Defense x 2. If Hit is greater than 100, gain 1 stack of Keen and 3 sanity. If Peace is at 5+ stacks, lose 3 stacks and increase damage (2x!). If sanity is lower than -5, decrease damage (50%!).",
                             hit=75, critical=30, element="mighty", statsUsed=["magic", "defense", 2],
                             conditional=chi_palm_conditional, weight=14)

def soul_search_conditional(self, user: Player, target: Enemy, actions=1):
    amount = 0
    removeList = []
    user.sanity += 3
    for status in user.statusList[:]:
        if status.align == "Negative" and amount <= 1:
            user.sanity += 1
            amount += 1
            removeList.append(status)

        if status.name == "Peace":
            if status.stacks >= 4:
                for s in removeList:
                    user.sanity += 4
                    s.remove(user, full=True)

            if status.stacks >= 5 and user.sanity >= 14:
                damage = 10 + status.stacks * 2 + user.sanity
                target.health -= damage
                say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}!{Color['reset']}")
monk_soul_search = PlayerSkill("Soul Search", [STATUS], 7, 2,
                               f"Gain 3 stack of Peace and 3 sanity. If Peace is at 4+ stacks, gain 4 sanity and try to remove 2 Negative statuses (gain 1 sanity per removed status). If sanity is at 14+ and Peace is at 5+ stacks, deal damage (10 + (stacks of Peace x 2) + sanity).",
                               status=[Peace], stacks=3, statusTarget="user", conditional=soul_search_conditional, weight=12)

def chi_blast_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity >= 15:
        damage *= 2
        user.sanity -= 5

    if any("Peace" == s.name and s.stacks >= 8 for s in user.statusList):
        next(s for s in user.statusList if s.name == "Peace").remove(user, 4)
        ManaRegen.inflict(user)
        Regen.inflict(user)
        dam = round((user.strength * 0.5 + user.magic * 0.5) * (user.sanity / 2))
        if dam > 0:
            target.health -= dam
            say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")  

    return damage
monk_chi_blast = PlayerSkill("Chi-Blast", [DAMAGE, [MULTI, 2]], 9, 3,
                             f"Magic vs. Resistance x 2. If sanity is at 15+, lose 5 sanity and increase damage (2x!). If Peace is at max stacks, lose 4 stacks, gain Mana Regen/Regen, and deal damage ((50% of Strength + 50% of Magic) * (sanity / 2)). Chance to inflict 2 stacks of Burn/Heated.",
                             hit=80, critical=30, element="fire", status=[Burn, Heated], stacks=2, statsUsed=["magic", "resistance", 2],
                             conditional=chi_blast_conditional, weight=16)

##--Forlorn--##

def dwell_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")

    hp = round(user.maxHealth * 0.12)
    mp = round(user.maxMana * 0.1)
    user.health = min(user.maxHealth, user.health + hp)
    user.mana = min(user.maxMana, user.mana + mp)
    say(f"{Color['green']}{user.name}s Health Was Restored By {hp}!{Color['reset']}")
    say(f"{Color['green']}{user.name}s Mana Was Restored By {mp}!{Color['reset']}")

    Fear.inflict(user)

    user.sanity -= 3

    if user.sanity <= -5:
        count = 0
        for status in user.statusList[:]:
            if status.align == "Negative" and status.name != "Fear":
                status.remove(user, full=True)
                count += 1

            if count >= 2:
                break

    if user.sanity <= -10:
        Fear.inflict(user, 2)
        Protection.inflict(user, 2)

        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")

    self.onCooldown = True
    self.usable = False
forlorn_dwell = PlayerSkill("Dwell", [SPECIAL], 5, 2,
                            "Restore health/mana (12% of Max Health/10% of Max Mana). Gain 1 stack of Fear. Lose 3 sanity. If sanity is below -5, chance to remove 2 Negative statuses. If sanity is below -10, gain 2 stacks of Fear/Protection and raise Speed Meter by 25.",
                            customEffect=dwell_effect, weight=13)

def panic_attack_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Fear" and s.stacks >= 4 for s in user.statusList):
        Fragile.inflict(target, 2)
        if random.randint(1, 100) + user.luck >= target.luck + 50:
            FrailII.inflict(target)
    return damage
forlorn_panic_attack = PlayerSkill("Panic Attack", [DAMAGE, [MULTI, HITS(2,4)]], 9, 3,
                                   "Strength vs. Defense x 2-4. If Fear is present and at 4+ stacks, inflict 2 stacks of Fragile and chance to inflict Frail II. Chance to inflict Cripple I/Down/Bleed.",
                                   hit=90, critical=40, element="physical", status=[CrippleI, Down, Bleed], statsUsed=["strength", "defense", 1.8], sanLean="Negative",
                                   conditional=panic_attack_conditional, weight=16)

def trauma_break_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity <= -18:
        user.speedMeter += 15
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
        damage *= 2

        if random.randint(1, 100) + user.luck >= target.luck + 50:
            Slug.inflict(target)

    if any(s.name == "Fear" and s.stacks >= 5 for s in user.statusList) and user.sanity <= -15:
        Sinking.inflict(target)
        Gloom.inflict(target)
    return damage
forlorn_trauma_break = PlayerSkill("Trauma Break", [DAMAGE, [MULTI, 3]], 12, 4,
                                   "Strength vs. Defense x 3. If sanity is below -18, raise Speed Meter by 15 and increase damage (2x!) and chance to inflict Slug. If Fear is present and at 5+ stacks and sanity is below -15, inflict Sinking/Gloom. Chance to inflict 2 stacks of Down/Fragile.",
                                   hit=100, critical=20, element="mighty", status=[Down, Fragile], stacks=2, statsUsed=["strength", "defense", 2.2], sanLean="Negative",
                                   conditional=trauma_break_conditional, weight=15)

def experience_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.sanity <= -10:
        for status in user.statusList[:]:
            if status.family == "Mental" and status.align == "Negative" and status.name not in ["Fear", "Mania"]:
                if random.randint(1,100) >= 25:
                    status.remove(user, full=True)
passive_experience  = PlayerSkill("Experience", [PASSIVE], 00, 00,
                                  "If sanity is below -10, for every Negative Mental status present (excluding Fear/Mania), chance to remove it.")
passive_experience.passive = types.MethodType(experience_passive, passive_experience)

##--Equinox--##
# Never Used Directly
def emission_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Equilibrium.inflict(user)
    return damage
neutral_emission = PlayerSkill("Emission", [DAMAGE], 0, 0, "",
                               hit=80, critical=80, element="mighty", statsUsed=["magic", "resistance", 3], conditional=emission_conditional, weight=0)
positive_emission = PlayerSkill("Emission", [DAMAGE], 0, 0, "",
                               hit=100, critical=80, element="fire", status=[Burn, FrailI], statsUsed=["magic", "resistance", 2.5], conditional=emission_conditional, weight=0)
negative_emission = PlayerSkill("Emission", [DAMAGE], 0, 0, "",
                               hit=80, critical=140, element="wind", status=[Bleed, BindI], statsUsed=["magic", "resistance", 2.5], conditional=emission_conditional, weight=0, sanLean="Negative")
##---##
def emission_effect(self, user: Player, target: Enemy, actions=1):
    self.onCooldown = True
    self.usable = False
    
    if user.sanity >= -4 and user.sanity <= 4:
        if random.randint(1, 100) >= 50:
            user.sanity -= 5
        else:
            user.sanity += 5
        
    if user.sanity >= 5:
        positive_emission.usable = True
        positive_emission.onCooldown = False
        return positive_emission.effect(user, target, actions)
    elif user.sanity <= -5:
        negative_emission.usable = True
        negative_emission.onCooldown = False
        return negative_emission.effect(user, target, actions)
    else:
        neutral_emission.usable = True
        neutral_emission.onCooldown = False
        return neutral_emission.effect(user, target, actions)
equinox_emission = PlayerSkill("Emission", [SPECIAL], 10, 2, 
                               "Magic vs. Resistance. If sanity is at 5+; element is Fire and chance to inflict Burn/Frail I. If sanity is below -5: element is Wind and chance to inflict Bleed/Bind I. If sanity is within the -4 to 4 range, either gain/loss 5 sanity. Gain Equilibrium.",
                               customEffect=emission_effect, weight=16)

def sarn_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    Equilibrium.inflict(user)
    
    if user.sanity == 0:
        user.sanity = random.randint(-5, 5)

    if user.sanity > 0:
        for status in [Burn, Sear]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target)
            
        damage = max(0, round(((user.magic * 1.5) - target.resistance) * 2))
        
        if any("Equilibrium" == s.name and s.stacks >= 4 for s in user.statusList):
            damage = round(damage * 1.5)
            Burn.inflict(target, 2)
            user.sanity += 5
            
        say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}!{Color['reset']}")
        target.health -= damage
            
    elif user.sanity < 0:
        ToughI.inflict(user)
        
        if any("Equilibrium" == s.name and s.stacks >= 4 for s in user.statusList):
            ToughI.inflict(user, ToughI.maxStack)
            BoostII.inflict(user)
            user.sanity -= 5
            
        if any("Tough I" == s.name and s.stacks == s.maxStack for s in user.statusList):
            GuardU.inflict(user)
        
    self.onCooldown = True
    self.usable = False
equinox_sarn = PlayerSkill("Sarn", [SPECIAL], 13, 3,
                           "If sanity is Positive; chance to inflict Burn/Sear and deal damage ((Magic x 1.5) - opposers Resistance) x 2. If sanity is Negative, gain Tough I/Guard. U (If tough I is at max stacks). If Equilibrium is at 4+ stacks; if sanity is Positive- increase damage (1.5x), inflict 2 stacks of Burn and gain 5 sanity- if sanity is Negative- gain max stacks of Tough I/Boost II and lose 5 sanity.",
                           customEffect=sarn_effect, weight=15)

def pendulum_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    Equilibrium.inflict(user, 2) 
    
    positive = False
    negative = False
    
    if user.sanity > 0 and positive == False and negative == False:
        user.sanity = -user.sanity
        say(f"{Color['magenta']}{user.name}s Sanity Is Now Negative!{Color['reset']}")
        positive = True
    
    elif user.sanity < 0 and positive == False and negative == False:
        user.sanity = abs(user.sanity)
        say(f"{Color['yellow']}{user.name}s Sanity Is Now Positive!{Color['reset']}")
        negative = True
    else:
        say("Nothing Happened!")
    
    if positive:
        heal = round(user.maxHealth * 0.05 + random.randint(2,6))
        user.health += heal
        say(f"{Color['green']}{user.name} Restored {heal} Health!{Color['reset']}")
        Scorch.inflict(target)
    
    elif negative:
        for status in [SlowI, BindI]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target)
                
        count = 0        
        for status in user.statusList[:]:
            if status.family == "Mental" and status.align == "Negative" and random.randint(1, 100) >= 50:
                count += 1

                status.remove(user, full=True)
            
            if count >= 2:
                break
        
    self.onCooldown = True
    self.usable = False
equinox_pendulum = PlayerSkill("Pendulum", [SPECIAL], 16, 4,
                               "Change sanity from Positive/Negative to Negative/Positive. If sanity was Positive on use, restore health (5% of Max Health + 2-6) and inflict Scorch. If sanity was Negative on use, chance to; remove 2 Negative Mental statuses and inflict Slow I/Bind I. Gain 2 stacks of Equilibrium.",
                               customEffect=pendulum_effect, weight=11)

def metamorphosis_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.sanity >= 5 and not any("Shock" == s.name for s in user.statusList):
        Shock.inflict(user)
    if user.sanity >= 10 and not any("Equilibrium" == s.name for s in user.statusList):
        Equilibrium.inflict(user)
    if user.sanity >= 23 and not any("Keen" == s.name for s in user.statusList):
        Keen.inflict(user)
        
    if user.sanity <= -5 and not any("Tough I" == s.name for s in user.statusList):
        ToughI.inflict(user)
    if user.sanity <= -10 and not any("Equilibrium" == s.name for s in user.statusList):
        Equilibrium.inflict(user)
    if user.sanity <= -23 and not any("Tough II" == s.name for s in user.statusList):
        ToughII.inflict(user)
passive_metamorphosis = PlayerSkill("Metamorphosis", [PASSIVE], 0, 0,
                                    "If sanity is at 5+/10+/23+, gain Shock/Equilibrium/Keen (if status is not already present). If sanity is below -5/-10/-23, gain Tough I/Equilibrium/Tough II (if status is not already present).", weight=0)
passive_metamorphosis.passive = types.MethodType(metamorphosis_passive, passive_metamorphosis)

##--Cleric--##
def sutura_conditional(self, heal: int, user: Player, target: Enemy):
    user.sanity += 3
    
    if user.sanity >= 15:
        damage = round(user.resistance * 0.5 + user.magic * 0.2)
        target.health -= damage
        say(f"{Color['red']}{target.name} Took {damage} Health Damage!{Color['reset']}")
        
    if random.randint(1,100) >= 50: Regen.inflict(user)
    else: ManaRegen.inflict(user)
        
    return heal
cleric_sutura = PlayerSkill("Sutura", [HEAL], 12, 3,
                            "Restore health (100% of Resistance + 50% of Magic). If sanity is at 15+, deal damage (50% of Resistance + 20% of Magic). Gain 3 sanity. Gain Regen or Mana Regen.",
                            statsUsed=[[("resistance", 150), ("magic", 50)], "health"], 
                            conditional=sutura_conditional, weight=13)

def divine_protection_conditional(self, user: Player, target: Enemy, actions=1):
    if user.sanity >= 10:
        Protection.inflict(user)
    
    count = 0
    num = random.randint(1,2)
    for status in user.statusList[:]:
        if random.randint(1,100) > 60 and status.align == "Negative" and status.family in ["Burn", "Bleed", "Chill"]:
            status.remove(user, full=True)
            count += 1

        if count >= num:
            break
cleric_divine_protection = PlayerSkill("Divine Protection", [STATUS], 9, 3,
                                       "Gain 1 stack of Tough I. If sanity is at 10+, gain 1 stack of Protection. Chance to remove 1-2 Burn/Bleed/Chill statuses.",
                                       status=[ToughI], statusTarget="user", conditional=divine_protection_conditional, weight=10)

def smite_effect(self, user: Player, target: Enemy, actions=1):
    if self.useCheck(user, target):
        user.sanity += 3
                
        if user.sanity >= 20:
            damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
            user.sanity -= 10
            damage = self.bonusChecks(user, target, actions, damage)
            reflect, absorb = False, False 
        else:
            damage, reflect, absorb = self.calculateDamage(user, target, "player", actions)

        if any(getattr(target, s) in ["Resist", "Absorb", "Reflect"] for s in ["mighty", "thunder"]):
            damage += round(damage * 0.5)
            user.sanity -= 2
            Fragile.inflict(target, 2)
        return self.applyDamage(user, target, damage, reflect, absorb)
cleric_smite = PlayerSkill("Smite", [DAMAGE], 6, 3,
                           "Resistance vs. Resistance. If sanity is at 20+, lose 10 sanity and ignore Defensive stats. If opposer is Resist/Absorb/Reflect to Mighty/Thunder, lose 2 sanity, inflict 2 stacks of Fragile, and increase damage (50%!). Gain 3 sanity. Chance to inflict Burn/Heated/Bind I.",
                           hit=75, critical=110, element=None, status=[Burn, Heated, BindI], statsUsed=["resistance", "resistance", 2],
                           customEffect=smite_effect, weight=15)

def confessions_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.actions == 1:
        self.total = 0
        
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Healing" in user.lastSkill.type_ and isinstance(self.total, int):
        user.sanity += 2
        self.total += damage
        if self.total > 1111:
            self.total = 1111
    
    if user.lastAction and user.lastAction == "Wait" and user.sanity >= 15:
        user.sanity -= 5
        if not any(s.name == "Protection" for s in user.statusList):
            Protection.inflict(user, 2)
            
        heal = round(self.total * 0.1)
        if heal > 0:
            say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
            user.health += min(heal, user.maxHealth - user.health)
            
    if user.lastAction and user.lastAction == "Attack" and user.sanity >= 10:
        user.sanity -= 5
        damage = round(user.resistance * 0.25 + user.luck * 0.25 + self.total * 0.1)
        enemy.health -= damage
        say(f"{Color['red']}{enemy.name} Took {damage} Health Damage!{Color['reset']}")
passive_confessions = PlayerSkill("The Confessions", [PASSIVE], 00, 00,
                                  "Track total amount of healing done using skills (max 1111). If a healing skill is used, gain 2 sanity. If wait is used and sanity is at 15+, lose 5 sanity, gain 2 stacks of Protection (if not present), and restore health (10% of tracked total). If attack is used and sanity is at 10+, lose 5 sanity and deal damage (25% of Resistance + 25% of Luck + 10% of tracked total).")
passive_confessions.passive = types.MethodType(confessions_passive, passive_confessions); passive_confessions.total = 0

##--Daredevil--##
def test_run_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Risk.inflict(user, 2)

    if user.sanity <= -10:
        Keen.inflict(user, 2)
        damage *= 2

    percent = 0
    risk = next((s for s in user.statusList if s.name == "Risk" and s.stacks > 0), None)
    if risk:
        for i in range(0, risk.stacks, 1):
            percent += 0.05

        if percent:
            damage += round(damage * percent)
    return damage
daredevil_test_run = PlayerSkill("Test Run", [DAMAGE], 6, 2,
                                 "Strength vs. Defense. If sanity is below -10, gain 2 stacks of Keen and increase damage (2x!). For each stack of Risk present, increase damage (5%!). Gain 2 stacks of Risk. Chance to inflict Break/Burn/Bleed.",
                                 hit=65, critical=65, element="fire", status=[Break, Burn, Bleed], statsUsed=["strength", "defense", 1.5],
                                 conditional=test_run_conditional, weight=13, sanLean="Negative")

def freestyle_danger_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    keen = next((s for s in user.statusList if s.name == "Keen" and s.stacks >= 5), None)
    if keen:
        damage += round(user.strength * 0.35 + user.hit * 0.35)

    if any(s.name == "Risk" for s in user.statusList):
        Risk.inflict(user, 3)
        Keen.inflict(user, 3)
    return damage
daredevil_freestyle_danger = PlayerSkill("Freestyle Danger", [DAMAGE, [MULTI, HITS(1,3)]], 7, 3,
                                         "Strength vs. Defense x 1-3. If Keen is present and at 5+ stacks, increase damage (35% of Strength + 35% of Hit). If Risk is present, gain 3 stacks of Risk/Keen. Take recoil (30% of damage dealt). Chance to inflict Break/Muddy/Cripple I.",
                                         hit=75, critical=90, element="physical", status=[Break, Muddy, CrippleI], statsUsed=["strength", "defense", 2], recoil=[True, 30],
                                         conditional=freestyle_danger_conditional, weight=18, sanLean="Negative")

def triple_axel_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if "Precision" in strikes:
        damage *= 2

    if user.sanity <= -20:
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
        user.sanity += 5
        Risk.inflict(user, 3)
        damage = round(damage * 1.5)

    if any(s.name == "Risk" and s.stacks >= 8 for s in user.statusList):
        Fragile.inflict(target, 3)
        Burnout.inflict(target)
        next(s for s in user.statusList if s.name == "Risk").remove(user, 4)
    return damage
daredevil_triple_axel = PlayerSkill("Triple Axel", [DAMAGE, [MULTI, 3]], 9, 4,
                                    "Strength vs. Defense x 3. If skill lands a Precision, increase damage (2x!). If sanity is below -20, raise Speed Meter by 25, gain 5 sanity, gain 3 stacks of Risk, and increase damage (1.5x!). Chance to inflict Gash/Ice Veins/Slow I.",
                                    hit=65, critical=125, element="ice", status=[Gash, IceVeins, SlowI], statsUsed=["strength", "defense", 1.5],
                                    conditional=triple_axel_conditional, weight=16, sanLean="Negative")

def fearless_passive(self, user: Player, enemy: Enemy, damage=0):
    speed = 0
    heal = 0
    for status in user.statusList[:]:
        if status.align == "Negative":
            speed += 10

        if speed >= 30:
            speed = 30

        if status.name == "Risk" and status.stacks > 0:
            heal = round((user.maxHealth * 0.02) * status.stacks)

    if speed:
        user.speedMeter +=speed
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By {speed}!{Color['reset']}")

    if user.health <= round(user.maxHealth * 0.75):
        user.speedMeter += 10
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 10!{Color['reset']}")

        enemy.sanity -= 3
        enemy.speedMeter -= 10
        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Lowered By 10!{Color['reset']}")

        if user.lastAction and user.lastAction == "Attack":
            Fragile.inflict(enemy, 2)

    if heal:
        say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
        user.health += min(heal, user.maxHealth - user.health)
passive_fearless = PlayerSkill("Fearless", [PASSIVE], 00, 00,
                            "For each Negative status present, raise Speed Meter by 10 (max 30). If health is below 75%, raise Speed Meter by 10, lower opposers sanity by 3, lower opposers Speed Meter by 10, and if attack is used, inflict 2 stacks of Fragile. For each stack of Risk present, restore health (2% of Max Health).")
passive_fearless.passive = types.MethodType(fearless_passive, passive_fearless)

##--Tamer--##
def whistle_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    if user.buddy:
        missing = 150 - user.buddy.buddyMeter
        if missing > 0:
            user.buddy.buddyMeter += missing
            say(f"{Color['cyan']}{user.buddy.name} Gained {missing} Buddy Meter!{Color['reset']}")
        
        if user.buddy.level >= 8:
            user.buddy.buddyMeter += 60
            say(f"{Color['cyan']}{user.buddy.name} Gained 60 Buddy Meter!{Color['reset']}")
            HealthShield.inflict(user, 2)
    else:
        say("Nothing Happened!")
tamer_whistle = PlayerSkill("Whistle", [SPECIAL], 15, 5,
                            "If a Buddy is equipped, Buddy gains missing Buddy Meter and if Buddy is at level 8+, Buddy gains 60 Buddy Meter and gain 2 stacks of Health Shield.",
                            customEffect=whistle_effect, weight=13)

def buddy_trick_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    if user.buddy:
        affinity = user.buddy.affinity 
        
        if user.buddy.level >= 5:
            Bond.inflict(user)
            Protection.inflict(user)
                    
        if affinity == "Force":
            damage = round(user.buddy.attack + (user.strength if user.strength >= user.magic else user.magic) * 0.5)
            target.health -= damage
            say(f"{Color['red']}{target.name} Took {damage} Health Damage!{Color['reset']}")
            return damage
        
        elif affinity == "Support":
            heal = round(user.buddy.talent + user.maxHealth * 0.1)
            user.health = min(user.maxHealth, user.health + heal)
            say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
            return heal
        
        elif affinity == "Utility":
            user.buddy.buddyMeter += 15
            say(f"{Color['cyan']}{user.buddy.name} Gained 15 Buddy Meter!{Color['reset']}")
            
            num = random.randint(1, 2)
            count = 0
            cop = copy.deepcopy(target.statusList)
            random.shuffle(cop)
            for status in cop:
                if status.align == "Negative" and "Damage" in status.type_:
                    if "Special" not in status.type_:
                        status.simple(target)
                    else:
                        status.special(target, 0)
                    count += 1
                if count >= num:
                    break
            
            if count <= 0:
                say("Nothing Happened!")
            
            return None
    else:
        say("Nothing Happened!")
tamer_buddy_trick = PlayerSkill("Buddy Trick", [SPECIAL], 12, 3,
                                "If a Force Buddy is equipped, deal damage (Buddy’s Attack + 50% of strongest offensive stat). If a Support Buddy is equipped, restore health (Buddy’s Talent + 10% of Max Health). If a Utility Buddy is equipped, retrigger 1-2 damaging Negative statuses and Buddy gains 15 Buddy Meter. If Buddy is at level 5+, gain 1 stack of Bond/Protection.",
                                customEffect=buddy_trick_effect, weight=15)

def tackle_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if not user.buddy:
        Down.inflict(target, 2)
        Fragile.inflict(target, 2)
        
        damage += round(damage * 0.3)
    
    else:
        user.buddy.buddyMeter += 15
        say(f"{Color['cyan']}{user.buddy.name} Gained 15 Buddy Meter!{Color['reset']}")
    return damage
tamer_tackle = PlayerSkill("Tackle", [DAMAGE], 9, 2,
                           "Strength vs. Defense. If no Buddy is equipped, inflict 2 stacks of Down/Fragile and increase damage (30%!). If a Buddy is equipped, Buddy gains 15 Buddy Meter. Chance to inflict Weak.",
                           hit=85, critical=60, element="physical", status=[Weak], statsUsed=["strength", "defense", 2.2],
                           conditional=tackle_conditional, weight=17)

def kindred_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.buddy:
        user.buddy.levelValue += 3 + 3 * user.level

        if user.actions % 3 == 0 and user.actions != 0:
            affinity = user.buddy.affinity 
            
            if affinity == "Force":
                Power.inflict(user)
                
                if user.buddy.level >= 5:
                    FullPower.inflict(user)
            
            elif affinity == "Support":
                Rejuvenate.inflict(user, 2)
                
                if user.buddy.level >= 5:
                    for status in user.statusList[:]:
                        if status.align == "Negative":
                            status.remove(user, full=True)
                            break
            
            elif affinity == "Utility":
                Keen.inflict(user)
                
                if user.buddy.level >= 5:
                    Poise.inflict(user)
passive_kindred = PlayerSkill("Kindred Spirit", [PASSIVE], 0, 0,
                              "Over the course of the battle, equipped Buddy will gain 3 + 3 per user level EXP per user action. Every 3 user actions, depending on equipped Buddy's affinity, trigger an 1 of the effects listed. if a Force Buddy is equipped, gain 1 stack of Power and if Buddy is at level 5+, gain Full Power. If a Support Buddy is equipped, gain 2 stacks of Rejuvenate and if Buddy is at level 5+, remove 1 Negative status. If a Utility Buddy is equipped, gain 1 stack of Keen, if Buddy is at level 5+, gain 1 stack of Poise.")
passive_kindred.passive = types.MethodType(kindred_passive, passive_kindred)

##--Theif--##

def coin_shot_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    percent = 0
    for i in range(0, user.coins, 100):
        percent += 0.05
        if percent >= 2:
            break
    
    if percent:
        damage += round(damage * percent)
    
    if user.luck >= 175:
        Might.inflict(user, 2)
        Haste.inflict(user, 2)
    
    Boon.inflict(user)
    
    for status in target.statusList[:]:
        if status.align == "Positive":
            status.remove(target)
    
    return damage
thief_coin_shot = PlayerSkill("Coin Shot", [DAMAGE], 11, 4,
                              "Strength vs. Defense. For every 100 Coins owned, increase damage (5% per 100 Coins, max 200%). If Luck is at 175+, gain 2 stacks of Might/Haste. Gain 1 stack of Boon. Remove 1 Positive status present on the opposer.",
                              hit=80, critical=100, element="mighty", statsUsed=["strength", "defense", 2],
                              conditional=coin_shot_conditional, weight=18)

def swipe_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.health <= round(target.maxHealth * 0.5):
        StolenGoods.inflict(user)
        Power.inflict(user, 3)
    
    chance = 0.15 + (user.luck // 10) * 0.03
    if chance >= random.random():
        items = [Item.allItems["Red S.Valens Potion"], Item.allItems["Blue S.Valens Potion"], Item.allItems["Cleanse S. Potion"], Item.allItems["Pocket Watch"], Item.allItems["Iron S. Potion"]]
        item = random.choice(items)
        item.tracker(1, "Add", user)
        say(f"{Color['yellow']}{user.name} Gained 1 {item.name}!{Color['reset']}")

    if not any("Damage" in i.type_ for i in user.items):
        item = random.choice([i for i in Item.allItems.values() if "Damage" in i.type_])
        item.tracker(1, "Add", user)
        say(f"{Color['yellow']}{user.name} Gained 1 {item.name}!{Color['reset']}")
    return damage
thief_swipe = PlayerSkill("Swipe", [DAMAGE, [MULTI, HITS(1,2)]], 8, 3,
                          "Speed vs. Defense x 1-2. If opposers health is below 50%, gain 1/3 stacks of Stolen Goods/Power. At a chance of 15% + 3% per 10 points of Luck, gain 1 random item (from a pool). If no damaging items are present, gain 1 damaging item. Chance to inflict Muddy/Bleed.",
                          hit=90, critical=85, element="physical", status=[Muddy, Bleed], statsUsed=["speed", "defense", 1.2],
                          conditional=swipe_conditional, weight=18)

def sleight_hand_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    pItems = []
    for i in user.items:
        if any(t in i.type_ for t in ["Heal", "Cleanse", "StatusI", "Damage"]):
            pItems.append(i)

            if "Damage" in i.type_:
                pItems.extend([i] * 3)

    if len(pItems) > 0:
        use = random.choice(pItems)
        result = use.use(user, target, actions)
        use.tracker(1, "Add", user)

        if user.luck >= 160:
            use.tracker(1, "Add", user)
            say(f"{Color['yellow']}{user.name} Gained 1 {use.name}!{Color['reset']}")

            if "Damage" in use.type_:
                damage += result
        
        user.lastAction = "Item"
    return damage
thief_sleight_hand = PlayerSkill("Sleight of Hand", [DAMAGE], 15, 5,
                                 "Strength vs. Defense. Upon use, treat action as if an item was used. Use 1 item without consuming it (prioritize damaging items). If Luck is at 160+, gain 1 of the item used and if damaging item was used, increase damage by items damage. Chance to inflict Weak/Fragile/Clouded I.",
                                 hit=85, critical=80, element="mighty", status=[Weak, Fragile, CloudedI], statsUsed=["strength", "defense", 1.7],
                                 conditional=sleight_hand_conditional, weight=16)

def sticky_fingers_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.lastAction == "Item":
        chance = 0.1 + (user.luck // 10) * 0.05
        if chance >= random.random():
            user.lastItem.tracker(1, "Add", user)
            say(f"{Color['yellow']}{user.name} Gained 1 {user.lastItem.name}!{Color['reset']}")
            if user.level >= 8 and "Damage" in user.lastItem.type_:
                cop = copy.deepcopy(user.lastItem)
                cop.damage = list(cop.damage)
                cop.damage[0] += 35
                number = 0
                for i in range(0, len(cop.damage[2])):
                    cop.damage[2][number][1] += 0.1
                    number += 1
                cop.use(user, enemy)
passive_sticy_fingers = PlayerSkill("Sticky Fingers", [PASSIVE], 0, 0,
                                    "If an item is used, at a chance of 10% + 5% per 10 points of Luck, do not consume the item and at level 8+, if a damaging item is used, trigger the item's effect again (+35 Base Damage/10% More Stat Scaling).")
passive_sticy_fingers.passive = types.MethodType(sticky_fingers_passive, passive_sticy_fingers)

##------------Player Skills------------##

skill_clean_piercer = PlayerSkill("Clean Piercer", [DAMAGE], 5, 2,
                       f"Strength vs. Defense. Chance to inflict Bleed.",
                       hit=110, critical=50, element="physical", status=[Bleed], statsUsed=["strength", "defense", 2], weight=14)

skill_dirty_blow = PlayerSkill("Dirty Blow", [DAMAGE], 6, 2,
                               "Strength vs. Defense. Chance to inflict Clouded I/Fragile.",
                               hit=85, critical=75, element="physical", status=[CloudedI, Fragile], statsUsed=["strength", "defense", 2], sanLean="Negative", weight=13)

def wallop_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Tough" in s.name for s in user.statusList):
        increase = 0.05 * next(s for s in user.statusList if "Tough" in s.name).stacks
        damage += round(damage * increase)
    Shell.inflict(user, 2)
    return damage
skill_wallop = PlayerSkill("Wallop", [DAMAGE, [MULTI, HITS(1,2)]], 9, 3,
                           "Defense vs. Defense x 1-2. If any Tough status is present, increase damage (5% per stack). Gain 2 stacks of Shell.",
                           hit=80, critical=75, element="mighty", status=[Shell], stacks=2, statusTarget=["user"], statsUsed=["defense", "defense", 1.3],
                           conditional=wallop_conditional, weight=13)

def double_down_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.sanity -= 3
    return damage
skill_double_down = PlayerSkill("Double Down", [DAMAGE, [MULTI, 2]], 7, 2,
                               "Strength vs. Defense x 2. Lower opposers sanity by 3. Chance to inflict 2 stacks of Down/Hemorrhage.",
                               hit=85, critical=75, element="physical", status=[Down, Hemorrhage], stacks=2, statsUsed=["strength", "defense", 2], sanLean="Negative", conditional=double_down_conditional, weight=15)

def drag_down_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.sanity -=4
    return damage
skill_drag_down = PlayerSkill("Drag Down", [DAMAGE], 10, 3,
                              "Strength vs. Defense. Lower opposers sanity by 4. Will inflict Burn/Sinking/Engulfed (if Deluge is present).",
                              hit=90, critical=80, element="fire", status=[Burn, Sinking,[Engulfed, Deluge]], onlyStatusCondition=True, willStatus=True, statsUsed=["strength", "defense", 2], sanLean="Negative", conditional=drag_down_conditional, weight=16)

skill_bliz = PlayerSkill("Bliz", [DAMAGE], 5, 2,
                       f"Magic vs. Resistance. Chance to inflict Freeze.",
                       hit=65, critical=40, element="ice", status=[Freeze], statsUsed=["magic", "resistance", 2], weight=10)

skill_blizga = PlayerSkill("Blizga", [DAMAGE, [MULTI, 2]], 9, 3,
                       f"Magic vs. Resistance x 2. Chance to inflict Deep Freeze/Absolute Zero.",
                       hit=70, critical=30, element="ice", status=[[DeepFreeze, Freeze], AbsoluteZero], statsUsed=["magic", "resistance", 1.8], weight=13)

skill_fira = PlayerSkill("Fira", [DAMAGE], 5, 2,
                       f"Magic vs. Resistance. Chance to inflict Burn.",
                       hit=70, critical=30, element="fire", status=[Burn], statsUsed=["magic", "resistance", 2], weight=10)

skill_firaga = PlayerSkill("Firaga", [DAMAGE], 8, 3,
                       f"Magic vs. Resistance. Chance to inflict 2 stacks of Heated/Sear.",
                       hit=75, critical=30, element="fire", status=[Sear, Heated], stacks=2, statsUsed=["magic", "resistance", 2.5], weight=12)

skill_thunger = PlayerSkill("Thunger", [DAMAGE, [MULTI, 2]], 6, 3,
                       f"Magic vs. Resistance x 2. Chance to gain Shock.",
                       hit=70, critical=40, element="thunder", status=[Shock], statusTarget="user", statsUsed=["magic", "resistance", 1.6], weight=11)

skill_thungerga= PlayerSkill("Thungerga", [DAMAGE, [MULTI, HITS(2,4)]], 9, 3,
                       f"Magic vs. Resistance x 2-4. Chance to inflict 2 stacks of Spark/Static.",
                       hit=75, critical=30, element="thunder", status=[Spark, [Static, Spark]], stacks=2, statsUsed=["magic", "resistance", 2], weight=13)

skill_wind = PlayerSkill("Wind", [DAMAGE, [MULTI, HITS(1,2)]], 6, 3,
                       f"Magic vs. Resistance x 1-2.",
                       hit=75, critical=70, element="wind", statsUsed=["magic", "resistance", 1.6], weight=10)

skill_windga = PlayerSkill("Windga", [DAMAGE, [MULTI, HITS(2, 4)]], 9, 3,
                       f"Magic vs. Resistance x 2-4.",
                       hit=85, critical=100, element="wind", statsUsed=["magic", "resistance", 1.8], weight=13)
PlayerSkill.allScrolls[skill_windga.name].coinCost = 65
PlayerSkill.allScrolls[skill_windga.name].gpCost = 630

def cure_conditional(self, heal: int, user: Player, target: Enemy):
    for status in user.statusList[:]:
        if random.randint(1,100) > 60 and status.align == "Negative":
            status.remove(user, full=True)
            heal += round(user.maxHealth * 0.05)
            break
    return heal
skill_cure = PlayerSkill("Cure", [HEAL], 8, 4,
                       "Restore health (10% of Max Health + 50% of Magic). Increased healing (5% of Max Health) if any Negative statuses are removed on use. Chance to remove 1 Negative status.",
                       statsUsed=[[("maxHealth", 10), ("magic", 50)], "health"], conditional=cure_conditional, weight=12)

def curega_conditional(self, heal: int, user: Player, target: Enemy):
    amount = 0
    for status in user.statusList[:]:
        if status.align == "Negative":
            status.remove(user, full=True)
            heal += round(user.maxHealth * 0.05)
            amount += 1        

        if amount >= 2:
            break

    if amount:
        Regen.inflict(user)
    return heal
skill_curega = PlayerSkill("Curega", [HEAL], 13, 5,
                       f"Restore health (15% of Max Health + 75% of Magic). If any Negative statuses are removed on use, increase healing (5% of Max Health) and gain Regen. Remove 2 Negative status.",
                       statsUsed=[[("maxHealth", 15), ("magic", 75)], "health"], status=[Regen], statusTarget="user", conditional=curega_conditional, weight=14)

def patch_up_conditional(self, heal: int, user: Player, target: Enemy):
    if any("Bleed" == s.family for s in user.statusList):
        heal += round(user.maxHealth * 0.07)
    return heal
skill_patch_up = PlayerSkill("Patch-Up", [HEAL], 13, 5,
                       "Restore health (25% of Max Health). Increased healing (7% of Max Health!) if any Bleed statuses are present on user.",
                       statsUsed=[[("maxHealth", 25)], "health"], conditional=patch_up_conditional, weight=13)

def resolve_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    happen = False
    if user.sanity > 0:
        user.sanity -= 5
        say(f"{Color['magenta']}{user.name} Lost 2 Sanity!{Color['reset']}")
        happen = True
    elif user.sanity < 0:
        user.sanity += 5
        say(f"{Color['yellow']}{user.name} Gained 2 Sanity!{Color['reset']}")
        happen = True

    for status in user.statusList[:]:
        if status.align == "Negative" and random.randint(1,100) >= 50:
            status.remove(user, full=True)
            happen = True
            break
    
    if not happen:
        say("Nothing Happened")
    self.onCooldown = True
    self.usable = False
skill_resolve = PlayerSkill("Resolve", [SPECIAL], 10, 2, 
                            "Gain/Lose 5 sanity if sanity is Negative/Positive. Chance to remove 1 Negative status.",
                            customEffect=resolve_effect, weight=6)

def thungerabolt_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    keen = next((s for s in user.statusList if s.name == "Keen"), None)
    if charge and charge.stacks >= 5:
        charge.remove(user, 5)
        user.speedMeter += 15
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
        Fragile.inflict(target, 3)

    if keen and keen.stacks >= 6:
        keen.remove(user, 6)
        Power.inflict(user, 3)
    return damage
skill_thungerabolt = PlayerSkill("Thungerabolt", [DAMAGE], 14, 4,
                                 "Strength vs. Resistance. If Charge is present and at 5+ stacks, lose 5 stacks of Charge, raise Speed Meter by 15, and inflict 3 stacks of Fragile. If Keen is present and at 6+ stacks, lose 6 stacks of Keen and gain 3 stacks of Power. Chance to inflict 2 stacks Burn/Weak.",
                                 hit=85, critical=95, element="thunder", status=[Burn, Weak], stacks=2, statsUsed=["strength", "resistance", 2],
                                 conditional=thungerabolt_conditional, weight=16)

def sword_dance_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.hit >= 80:
        BindI.inflict(target)
    return damage
skill_sword_dance = PlayerSkill("Sword Dance", [DAMAGE, [MULTI, HITS(1,3)]], 9, 3,
                       f"Strength vs. Defense x 1-3. If Hit is 80+, inflict Bind I. Chance to inflict Bleed.",
                       hit=70, critical=125, element="physical", status=[Bleed], statsUsed=["strength", "defense", 1.8], conditional=sword_dance_conditional, weight=15)

def bloodboon_rite_conditional(self, user: Player, target: Enemy, actions=1):
    if user.sanity <= -5:
        CrippleII.inflict(target)

    if any(s.name == "Formless Mother’s Follower" for s in user.skills):
        BloodGeyser.inflict(target, 2)
        Fragile.inflict(target, 2)
        Power.inflict(user, 2)
        Protection.inflict(user, 2)
skill_bloodboon_rite = PlayerSkill("Bloodboon Rite", [STATUS], 14, 4,
                                   "Inflict 5 stacks of Blood Geyser. If sanity is below –5, inflict Cripple II. If the passive Formless Mother’s Follower is equipped, inflict 2 stacks of Blood Geyser/Fragile and gain 2 stacks of Power/Protection.",
                                   status=[BloodGeyser], stacks=5, conditional=bloodboon_rite_conditional, weight=00)

skill_zeta_I = PlayerSkill("Zeta I", [DAMAGE], 15, 6,
                       f"Magic vs. Resistance. Will inflict Sear/Gash.",
                       hit=80, critical=80, element="mighty", status=[Sear, Gash], willStatus=True, statsUsed=["magic", "resistance", 3.5], weight=13)

def hellfire_press_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Willow Wisp" and s.stacks >= 20 for s in target.statusList):
        FireProne.inflict(target)
    
    Shell.inflict(user, 3)
    return damage
skill_hellfire_press = PlayerSkill("Hellfire Press", [DAMAGE, [MULTI, HITS(1,3)]], 14, 4,
                                   "Defense vs. Defense x 1-3. If Willow Wisp is present on the opposer and at 20+ stacks, inflict Fire Prone. Gain 3 stacks of Shell. Chance to inflict 2 stacks of Willow Wisp/Hemorrhage/Slug. Take recoil (40% of damage).",
                                   hit=65, critical=125, element="fire", status=[WillowWisp, Hemorrhage, Slug], stacks=2, statsUsed=["defense", "defense", 1.5], recoil=[True, 40], conditional=hellfire_press_conditional, weight=18)

def defensive_blow_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.defense >= 17:
        if random.randint(1, 100) >= 55:
            GuardP.inflict(user)
        damage += round(damage * 0.5)
    return damage
skill_defensive_blow = PlayerSkill("Defensive Blow", [DAMAGE], 6, 2,
                                   f"Strength vs. Defense. If Defense is 17+, gain Guard. P and increase damage (50%!). Chance to gain 1 stack of Tough I.",
                                   hit=85, critical=60, element="physical", status=[ToughI], statusTarget="user", statsUsed=["strength", "defense", 1.5], conditional=defensive_blow_conditional, weight=14)

def limit_break_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    amount = 0
    for status in user.statusList[:]:
        if status.align == "Negative":
            status.remove(user, full=True)
            amount += 1

        if amount >= 2:
            break
        
    if user.sanity >= 15:
        BoostIII.inflict(user)
        user.sanity -= 25

    elif user.sanity >= 10:
        BoostII.inflict(user)
        user.sanity -= 15

    elif user.sanity >= 5:
        BoostI.inflict(user)
        user.sanity -= 5

    else:
        say("Nothing Happend!")
    self.onCooldown = True
    self.usable = False
skill_limit_break = PlayerSkill("Limit Break", [SPECIAL], 10, 6,
                                f"Remove 1-2 Negative statuses. Gain Boost I/Boost II/Boost III if sanity is at 5+/10+/15+. Lose 5/15/20 sanity.",
                                customEffect=limit_break_effect, weight=9)

def seeth_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    if user.sanity <= -10:
        Keen.inflict(user, 2)
        Protection.inflict(user, 2)
        if user.sanity <= -20:
            Power.inflict(user, 2)
            Charge.inflict(user, 2)
            user.sanity += 10
    else:
        say("Nothing Happend!")
    self.onCooldown = True
    self.usable = False
skill_seethe = PlayerSkill("Seethe", [SPECIAL], 9, 3,
                           f"If sanity is below -10, gain 2 stacks of Keen/Protection. If sanity is below -20, gain 2 stacks of Power/Charge and gain 10 sanity.",
                           customEffect=seeth_effect, weight=11)

def thunderstone_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.fire in ["Super Weak", "Weak"]:
        WillowWisp.inflict(target, 10)
        Charge.inflict(user, 2)
        damage += round(damage * 0.25)
    Charge.inflict(user, 2)
    return damage
skill_thunderstone = PlayerSkill("Thunderstone", [DAMAGE], 16, 3,
                                  "Strength vs. Defense. If opposer is Super Weak/Weak to Fire, inflict 10 stacks of Willow Wisp, gain 2 stacks of Charge, and increase damage (25%!). Gain 2 stacks of Charge. Chance to inflict 3 stacks of Burn/Static.",
                                  hit=90, critical=105, element="thunder", status=[Burn, Static], stacks=3, statsUsed=["strength", "defense", 1.7], conditional=thunderstone_conditional, weight=17)

def wither_storm_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Weak" == s.name for s in target.statusList):
        damage = round(damage * 2)
    return damage
skill_wither_storm = PlayerSkill("Wither Storm", [DAMAGE, [MULTI, HITS(1,3)]], 11, 3,
                       f"Magic vs. Resistance x 1-3. If opposer has Weak, increase damage (2x!). Chance to inflict Weak/Frail I.",
                       hit=65, critical=35, element="mighty", status=[Weak, FrailI], statsUsed=["magic", "resistance", 1.5],
                       conditional=wither_storm_conditional, weight=15)

def drill_in_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Break" == s.name for s in target.statusList):
        damage *= 2
    return damage
skill_drill_in = PlayerSkill("Drill-In", [DAMAGE, [MULTI, HITS(2,4)]], 12, 3,
                             f"Strength vs. Defense x 2-4. If opposer has Break, increase damage (2x!). Chance to inflict Wound/Break. Take recoil (25% of damage).",
                             hit=75, critical=70, element="physical", status=[Wound, Break], statsUsed=["strength", "defense", 1.5], recoil=[True, 25],
                             conditional=drill_in_conditional, weight=15)

def ice_crash_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.health <= round(target.maxHealth * 0.5):
        Protection.inflict(user, 2)
        if random.randint(1, 100) >= 55: IceProne.inflict(user)
    return damage
skill_ice_crash = PlayerSkill("Ice Crash", [DAMAGE], 15, 4,
                          "Resistance vs. Resistance. If opposers health is below 50%, gain 2 stacks of Protection and chance to inflict Ice Prone. Chance to inflict 2 stacks of Frigid/Frostbite. Take recoil (30% of damage).",
                          hit=75, critical=95, element="ice", status=[Frigid, Frostbite], stacks=2, statsUsed=["resistance", "resistance", 2], recoil=[True, 30], conditional=ice_crash_conditional, weight=18)

def lightning_charge_conditional(self, user: Player, target: Enemy, actions=1):
    for status in user.statusList[:]:
        if "Overload" == status.name:
            if status.stacks >= status.maxStack:
                Shock.inflict(user)
            
            if status.stacks >= 2:
                Regen.inflict(user)
skill_lightning_charge = PlayerSkill("Lightning Charge", [STATUS], 7, 2,
                                f"Gain 1 stack of Overload. If Overload is at 2+ stacks, gain Regen. If Overload is at max stacks, gain 1 stack of Shock.",
                                status=[Overload], statusTarget="user", conditional=lightning_charge_conditional, weight=9)

def mana_bomb_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    ManaRegen.inflict(user)
    return damage
skill_mana_bomb = PlayerSkill("Mana Bomb", [DAMAGE, [MULTI, HITS(2,4)]], 14, 3,
                             f"Magic vs. Defense x 2-4. Gain Mana Regen. Chance to inflict 2 stacks of Burn/Break.",
                             hit=70, critical=80, element="mighty", status=[Burn, Break], stacks=2, statsUsed=["magic", "defense", 1.4], 
                             conditional=mana_bomb_conditional, weight=13)

def ill_wind_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    triggered = False
    for status in target.statusList[:]:
        if status.family in ["Poison", "Mental"] and status.align == "Negative":
            triggered = True
            if "Special" not in status.type_:
                status.simple(target)
            else:
                status.special(target)
    
    if not triggered:
        say("Nothing Happened!")
    
    if random.randint(1, 100) + user.luck >= target.luck + 35:
        Ill.inflict(target)
    self.onCooldown = True
    self.usable = False
skill_ill_wind = PlayerSkill("Ill Wind", [SPECIAL], 12, 4,
                             "Retrigger all Poison/Mental statuses on the opposer. Chance to inflict Ill.",
                             customEffect=ill_wind_effect, weight=8)

def guard_conditional(self, user: Player, target: Enemy, actions=1):
    if user.level < 10:
        self.status = [ToughI]
    else:
        self.status = [ToughII]
    
    if user.health <= round(user.maxHealth * 0.5):
        Shell.inflict(user, 5)
skill_guard = PlayerSkill("Guard", [STATUS], 10, 3,
                       f"Gain 1 stack of Tough I. If level is at 10+, gain 1 stack of Tough II instead. if health is below 50%, gain 5 stacks of Shell.",
                       status=[], statusTarget="user", conditional=guard_conditional, weight=12)

def stance_conditional(self, user: Player, target: Enemy, actions=1):
    if user.health > round(user.maxHealth * 0.5):
        self.status = [Counter]
    else: self.status = [Rejuvenate, SuperCounter]
skill_stance = PlayerSkill("Stance", [STATUS], 12, 2,
                       f"Gain Counter. If health is below 50%, gain 5 stacks of Rejuvenate/Super Counter instead.",
                       status=[], stacks=5, statusTarget="user", conditional=stance_conditional, weight=10)

def stripping_lash_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    for status in target.statusList:
            if status.align == "Positive":
                if random.randint(1, 100) > 60:
                    status.remove(target, full=True)
                damage += round(damage * 0.05)

    return damage
skill_stripping_lash = PlayerSkill("Stripping Lash", [DAMAGE], 9, 3,
                       "Strength vs. Defense. Increased damage (5%) for each Positive status the opposer has. Chance to remove Positive statuses from opposer.",
                       hit=80, critical=100, element="physical", statsUsed=["strength", "defense", 2], conditional=stripping_lash_conditional, weight=11)

def ionic_storm_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Stun" == s.name for s in target.statusList):
        damage *= 2

    if target.thunder in ["Super Weak", "Weak"]:
        if random.randint(1,100) >= 45:
            Stun.inflict(target)
    return damage
skill_ionic_storm = PlayerSkill("Ionic Storm", [DAMAGE, [MULTI, HITS(2,6)]], 12, 4,
                       f"Magic vs. Resistance x 2-6. Increased damage (2x!) if Stun is present on the opposer. If opposer is Weak to Thunder, chance to inflict Stun.",
                       hit=85, critical=25, element="thunder", statsUsed=["magic", "resistance", 2],
                       conditional=ionic_storm_conditional, weight=15)

skill_rasenshuriken = PlayerSkill("Rasenshuriken", [DAMAGE, [MULTI, 4]], 10, 4,
                       f"Magic vs. Defense x 4. Chance to inflict Bleed/Wound/Break.",
                       hit=70, critical=125, element="wind", status=[Bleed, Wound, Break], statsUsed=["magic", "defense", 2], weight=13)

def mantra_burst_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    for sigil in user.sigils:
        if sigil.name == "Asura Sigil":
            damage *= 4
            FrailII.inflict(user)
    return damage
skill_mantra_burst = PlayerSkill("Mantra Burst", [DAMAGE, [MULTI, 3]], 15, 3, 
                       f"Magic vs. Resistance x 3. If Asura Sigil is equipped, increase damage (4x!) and gain Frail II.",
                       hit=100, critical=150, element="mighty", statsUsed=["magic", "resistance", 2],
                       conditional=mantra_burst_conditional, weight=12)

skill_wind_shift = PlayerSkill("Wind Shift", [STATUS], 15, 5,
                       f"Will inflict Wind Shift.",
                       status=[WindShift], weight=6)

skill_thunder_shift = PlayerSkill("Thunder Shift", [STATUS], 15, 5,
                       f"Will inflict Thunder Shift.",
                       status=[ThunderShift], weight=6)

skill_fire_shift = PlayerSkill("Fire Shift", [STATUS], 15, 5,
                       f"Will inflict Fire Shift.",
                       status=[FireShift], weight=6)

skill_ice_shift = PlayerSkill("Ice Shift", [STATUS], 15, 5,
                       f"Will inflict Ice Shift.",
                       status=[IceShift], weight=6)

skill_mighty_shift = PlayerSkill("Mighty Shift", [STATUS], 15, 5,
                       f"Will inflict Mighty Shift.",
                       status=[MightyShift], weight=6)

skill_physical_shift = PlayerSkill("Physical Shift", [STATUS], 15, 5,
                       f"Will inflict Physical Shift.",
                       status=[PhysicalShift], weight=6)

def truth_seeking_orb_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.magic > target.magic:
        damage *= 2
    return damage
skill_truth_seeking_orb = PlayerSkill("Truth-Seeking Orb", [DAMAGE, [MULTI, HITS(3,6)]], 12, 4, 
                       f"Magic vs. Magic x 3-6. if Magic is greater than opposers Magic, increased damage (2x!). Chance to inflict Weak/Cripple II.",
                       hit=65, critical=80, element="mighty", status=[Weak, CrippleII], statsUsed=["magic", "magic", 2],
                       conditional=truth_seeking_orb_conditional, weight=17)

skill_primary_lotus = PlayerSkill("Primary Lotus", [DAMAGE], 12, 4,
                       f"Strength vs. Defense. Chance to inflict Bind I/Cripple I/Break.",
                       hit=90, critical=50, element="physical", status=[BindI, Break], statsUsed=["strength", "defense", 2], weight=15)

skill_bacteri_hand = PlayerSkill("Bacteri Hand", [DAMAGE], 9, 3, 
                       f"Strength vs. Defense. Chance to inflict Plague/Poison/Venom.",
                       hit=80, critical=35, element="mighty", status=[Plague, Poison, Venom], statsUsed=["strength", "defense", 2], weight=11)

skill_snow_haul = PlayerSkill("Snow Haul", [DAMAGE, [MULTI, HITS(2, 4)]], 12, 4, 
                       f"Strength vs. Defense x 2-4. Chance to inflict Freeze/Absolute Zero.",
                       hit=65, critical=75, element="ice", status=[Freeze, AbsoluteZero], statsUsed=["strength", "defense", 1.5], weight=14)

def kai_split_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity += 2

    if user.sanity >= 10:
        user.sanity -= 5
        Rejuvenate.inflict(user, 10)

        
        user.speedMeter += 10
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 10!{Color['reset']}")

    Vestige.inflict(user, 2)
    Keen.inflict(user, 2)

    return damage
skill_kai_split = PlayerSkill("Kai Split Cut", [DAMAGE], 15, 4,
                              "Magic vs. Defense x 2. If sanity is at 10+, lose 5 sanity, gain 10 stacks of Rejuvenate, and raise Speed Meter by 10. Gain 2 stacks of Vestige/Keen. Gain 2 sanity. Chance to inflict Split/Break/Bleed.",
                              hit=90, critical=90, element="mighty", status=[Split, Break, Bleed], statsUsed=["magic", "defense", 2], conditional=kai_split_conditional, weight=16)

def passion_impact_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity += 2
    if user.sanity >= 8:
        damage *= 2
    return damage
skill_passion_impact = PlayerSkill("Passion Impact", [DAMAGE], 8, 3,
                                   f"Strength vs. Defense. If sanity is at 8+, increase damage (2x!). Gain 2 sanity. Chance to inflict Break/Heated.",
                                   hit=75, critical=70, element="fire", status=[Break, Heated], statsUsed=["strength", "defense", 2], conditional=passion_impact_conditional, weight=13)

def psi_I_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity -= 10
    return damage
skill_psi_I = PlayerSkill("Psi I", [DAMAGE, [MULTI, 3]], 16, 6,
                          f"Magic vs. Resistance x 3. Lose 5 sanity. Take recoil (15% of damage). Will inflict Freeze/Ice Veins/Clouded I.",
                          hit=80, critical=85, element="ice", status=[Freeze, IceVeins, CloudedI], statsUsed=["magic", "resistance", 2.5], recoil=[True, 15], conditional=psi_I_conditional, weight=11, sanLean="Negative")

def coward_blade_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    bleed = False
    bleedAmount = 0
    poison = False
    poisonAmount = 0
    focus = random.randint(1,2)
    for status in target.statusList:
        if status.family in ("Bleed", "Poison") and (status.name != "Bleed" or status.name != "Poison"):
            if status.family == "Bleed" and not bleed:
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target)
                bleedAmount += 1
                if bleedAmount >= focus:
                    bleed = True

            if status.family == "Poison" and not poison:
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target)
                poisonAmount += 1
                if poisonAmount >= focus:
                    poison = True
    return damage
skill_cowards_blade = PlayerSkill("Cowards Blade", [DAMAGE], 6, 4, 
                                  f"Strength vs. Defense. Retrigger 1-2 present Posion/Bleed status (excluding Poison/Bleed). Chance to inflict Poison/Bleed.",
                                  hit=80, critical=100, element="physical", status=[Poison, Bleed], statsUsed=["strength", "defense", 1], conditional=coward_blade_conditional, weight=10)

def swift_pierce_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.luck >= 90:
        Weak.inflict(target)
        FrailII.inflict(target)
    return damage
skill_swift_pierce = PlayerSkill("Swift Pierce", [DAMAGE], 8, 3,
                                   f"Strength vs. Defense. If Luck is 90+, chance to inflict Weak/Frail II. Chance to inflict Gash/Puncture.",
                                   hit=90, critical=150, element="physical", status=[Gash, Puncture], statsUsed=["strength", "defense", 2], conditional=swift_pierce_conditional, weight=15)

def jagged_thrust_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity -= 5
    if user.sanity <= -10:
        Madness.inflict(target)
    return damage
skill_jagged_thrust = PlayerSkill("Jagged Thrust", [DAMAGE, [MULTI, HITS(1, 4)]], 10, 4, 
                                  "Strength vs. Defense x 1-4. If sanity is below -10, inflict Madness and restore health (25% of damage dealt). Lose 5 sanity. Chance to inflict 2 stacks of Madness/Puncture.",
                                  hit=85, critical=60, element="mighty", status=[Madness, Puncture], stacks=2, statsUsed=["strength", "defense", 2], damHeal=0.25, meter="health", conditional=jagged_thrust_conditional, weight=14, sanLean="Negative")

def imogi_kick_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.health <= round(target.maxHealth * 0.45) and not abs(target.defense - user.strength) <= 10:
        Stun.inflict(target)
    return damage
skill_imogi_kick = PlayerSkill("Imogi Kick", [DAMAGE], 11, 4,
                               "Strength vs. Defense. If opposers health is below 45% and their Defense is not within 10 points of users Strength, inflict Stun. Will inflict Bind II.",
                               hit=70, critical=100, element="physical", status=[BindII], statsUsed=["strength", "defense", 2.5], conditional=imogi_kick_conditional, weight=13)

def lament_dullahan_conditonal(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity -= 5
    for status in user.statusList[:]:
        if status.name == "Sinking":
            damage += round(damage * (0.10 * status.stacks))

    bonus = abs(user.sanity - 25  )  
    bonus = bonus * 0.02
    bonus = min(bonus, 0.20)
    damage = round(damage * (1 + bonus))

    if user.sanity > 0:
        damage = round(damage * 0.5)
        user.sanity -= 10
        CrippleII.inflict(user)
        say(f"{Color['magenta']}{user.name} Lost 10 Sanity!{Color['reset']}")
    return damage
skill_lament_dullahan = PlayerSkill("Lament, Mourn, and Despair", [DAMAGE, [MULTI, 5]], 14, 5,
                                    "Strength vs. Defense x 5. Increase damage (10% for stack of Sinking/2% for point away from 25 sanity, max 20%). If sanity is Positive, decrease damage (50%!), gain Cripple II and lose 10 sanity. Lose 5 sanity. Chance to inflict 2 stacks of Sinking/Hemorrhage/Clouded I.",
                                    hit=80, critical=70, element="mighty", status=[Sinking, Hemorrhage, CloudedI], stacks=2, statsUsed=["strength", "defense", 1.6], conditional=lament_dullahan_conditonal, weight=13, sanLean="Negative")

skill_steam_blast = PlayerSkill("Steam Blast", [DAMAGE, [MULTI, HITS(1,4)]], 8, 3,
                                "Magic vs. Defense x 1-4. Chance to inflict Scald/Burn.",
                                hit=70, critical=80, element="physical", status=[Scald, Burn], statsUsed=["magic", "defense", 1.6], weight=13)

def shell_shock_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.health < round(target.maxHealth * 0.75) and any("Slow" in status.name for status in target.statusList):
        Stun.inflict(target)
    return damage
skill_shell_shock = PlayerSkill("Shell Shock", [DAMAGE], 10, 4,
                                "Strength vs. Defense. If opposers health is below 75% and any Slow statuses are present on the opposer, inflict Stun. Chance to inflict Break/Slow II.",
                                hit=75, critical=120, element="thunder", status=[Break, SlowII], statsUsed=["strength", "defense", 2.5], conditional=shell_shock_conditional, weight=14)

def cruenta_saltatio_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name in ["Boost II", "Boost III"] for s in user.statusList):
        CrippleII.inflict(target)
        damage = round(damage * 1.5)
    return damage
skill_cruenta_saltatio = PlayerSkill("Cruenta Saltatio", [DAMAGE, [MULTI, HITS(1,3)]], 12, 4,
                                     "Strength vs. Defense x 1-3. If any Boost status (excluding Boost I) is present, inflict Cripple II and increase damage (1.5x!). Chance to inflict 2 stacks of Hemorrhage/Burn.",
                                     hit=70, critical=130, element="fire", status=[Hemorrhage, Burn], stacks=2, statsUsed=["strength", "defense", 2], conditional=cruenta_saltatio_conditional, weight=14)

skill_windga_razor = PlayerSkill("Windga Razor", [DAMAGE, [MULTI, 2]], 9, 2,
                                 "Strength vs. Resistance x 2. Chance to inflict 2 stacks of Hemorrhage/Wound.",
                                 hit=90, critical=150, element="wind", status=[Hemorrhage, Wound], stacks=2, statsUsed=["strength", "resistance", 1.5], weight=15)

def divergent_slashes_effect(self, user: Player, target: Enemy, actions=1):
    if self.useCheck(user, target):
        damage = round(max(0, getattr(user, self.statsUsed[0]) + random.randint(1, 5) - (getattr(target, self.statsUsed[1]) // 2)) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        self.applyStatus(user, target)
        BindII.inflict(user)
        return self.applyDamage(user, target, damage)
skill_divergent_slashes = PlayerSkill("Divergent Slashes", [DAMAGE, [MULTI, HITS(1,5)]], 15, 6,
                           "Strength vs. Defense (50%) x 1-5. Gain Bind II. Will inflict 5 stacks of Hemorrhage/Gash/Cripple II.", 
                           hit=120, critical=100, status=[Hemorrhage, Gash, CrippleII], stacks=5, willStatus=True, statsUsed=["strength", "defense", 1.5],
                           customEffect=divergent_slashes_effect, weight=16)

skill_energy_field = PlayerSkill("Energy Field", [DAMAGE, [MULTI, 6]], 15, 5,
                                 "Magic vs. Resistance x 6. Gain Guard. M.", 
                                 hit=95, critical=50, element="thunder", status=[GuardM], statusTarget="user", willStatus=True, statsUsed=["magic", "resistance", 1.5], weight=17)

def sunset_blade_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity >= 15 and user.health >= round(user.maxHealth * 0.8):
        Light.inflict(user)
        Power.inflict(user)

    
    if target.health >= round(target.maxHealth * 0.65):
        Fragile.inflict(target, 2)
        Heated.inflict(target, 2)
    return damage
skill_sunset_blade = PlayerSkill("Sunset Blade", [DAMAGE, [MULTI, HITS(1,3)]], 20, 4,
                                 "Strength vs. Defense x 1-3. If sanity is at 15+ and health is above 80%, gain 1 stack of Light/Power. If opposers health is above 65%, inflict 2 stacks of Fragile/Heated. Chance to inflict 2 stacks of Burn/Slug.", 
                                 hit=75, critical=80, element="fire", status=[Burn, Slug], stacks=2, willStatus=True, statsUsed=["strength", "defense", 1.8],
                                 conditional=sunset_blade_conditional, weight=15)

def weak_victimize_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.snaity >= 15:
        user.sanity -= 15

        Wax.inflict(user, 2)
        Protection.inflict(user, 2)

        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Burnout.inflict(target)
    return damage
skill_weak_victimize = PlayerSkill("Weak Victimze", [DAMAGE, [MULTI, HITS(2,3)]], 23, 5,
                                   "Magic vs. Resistance x 2-3. If sanity is at 15+, lose 15 sanity, gain 2 stacks of Wax/Protection, and chance to inflict Burnout. Chance to inflict Slug/Scorch.", 
                                   hit=90, critical=70, element="fire", status=[Slug, Scorch], statusTarget="user", statsUsed=["magic", "resistance", 1.8], sanLean="Negative",
                                   conditional=weak_victimize_conditional, weight=17)

def high_roller_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    percent = 0
    for i in range(0, user.sanity, 2):
        percent += 0.05
        if percent >= 0.5:
            percent = 0.5
            break
    if percent:
        damage += round(damage * percent)
        
    if user.sanity >= 15:
        Keen.inflict(user, 2)
    return damage
skill_high_roller = PlayerSkill("High Roller", [DAMAGE, [MULTI, HITS(1, 4)]], 15, 3,
                                "Strength vs. Defense x 1-4. Increase damage (5% per 2 sanity, max 50%). If sanity is at 15+, gain 2 stacks of Keen.",
                                hit=90, critical=145, element="physical", statsUsed=["strength", "defense", 1.8], conditional=high_roller_conditional, weight=14)

def caltera_cut_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.luck >= 80 and user.hit >= 80:
        damage *= 2
        if random.randint(1, 100) + user.luck >= target.luck + 50:
            Split.inflict(target)
    return damage
skill_caltera_cut = PlayerSkill("Caltera Cut", [DAMAGE], 13, 3,
                                "Strength vs. Defense. If Luck/Hit are at 80+, increase damage (2x!) and chance to inflict Split. Will inflict 2 stacks of Hemorrhage.",
                                hit=80, critical=135, element="mighty", status=[Hemorrhage], stacks=2, statsUsed=["strength", "defense", 2], 
                                conditional=caltera_cut_conditional, weight=15)

skill_disrupt = PlayerSkill("Disrupt", [DAMAGE, [MULTI, HITS(2,3)]], 15, 3,
                                "Magic vs. Resistance x 2-3. Chance to inflict 3 stacks of Spark/Short Circuit. Take recoil (30% of damage).",
                                hit=70, critical=95, element="thunder", status=[Spark, ShortCircuit], stacks=3, statsUsed=["magic", "resistance", 1.5], recoil=[True, 30], weight=11)

def vile_breath_effect(self, user: Player, target: Enemy, actions=1):
    if self.useCheck(user, target):
        damage = round(max(0, getattr(user, self.statsUsed[0]) + random.randint(1, 5) - (getattr(target, self.statsUsed[1]) // 2)) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        self.applyStatus(user, target)
        if user.luck > target.luck:
            Blight.inflict(target)
        return self.applyDamage(user, target, damage)
skill_vile_breath = PlayerSkill("Vile Breath", [DAMAGE, [MULTI, HITS(1,5)]], 15, 4,
                    "Magic vs. Resistance (50%) x 1-5. If Luck is greater than opposers Luck, inflict Blight. Chance to inflict Infection/Rot.", 
                    hit=65, critical=55, status=[Infection, Rot], statsUsed=["magic", "resistance", 1.5], 
                    customEffect=vile_breath_effect, weight=15)

skill_hael = PlayerSkill("Hael", [HEAL], 18, 6,
                         "Restore health (35% of Max Health + 25% of Magic). Gain 2 stacks of Tough I/Regen.",
                         statsUsed=[[("maxHealth", 35), ("magic", 25)], "health"], status=[Regen, ToughI], stacks=2, statusTarget="user", weight=15)

def ward_conditional(self, user: Player, target: Enemy, actions: int):
    if user.mana >= round (user.maxMana * 0.75):
        Shell.inflict(user, 10)
skill_ward = PlayerSkill("Ward", [STATUS], 18, 3,
                         "Gain Magic Shield. If mana is above 75%, gain 10 stacks of Shell.",
                         status=[MagicShield], conditional=ward_conditional, weight=12)

def lament_departed_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity <= -10:
        damage *= 2
    
    if any(s.name == "Deluge" for s in target.statusList):
        target.sanity -= 3
        Butterfly.inflict(target, 2)
    
    return damage
skill_lament_departed = PlayerSkill("Lament for the Departed", [DAMAGE, [MULTI, 2]], 11, 3,
                                    "Strength vs. Defense x 2. If sanity is below -10, increase damage (2x!). If Deluge is present on the opposer, opposer loses 3 sanity and inflict 2 stacks of Butterfly. If Sinking is present on the opposer, inflict Butterfly.",
                                    hit=75, critical=100, element="mighty", status=[[Butterfly, Sinking]], onlyStatusCondition=True, statsUsed=["strength", "defense", 2], 
                                    conditional=lament_departed_conditional, weight=14)

def jet_uppercut_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.speedMeter += 30
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 30!{Color['reset']}")
    return damage
skill_jet_uppercut = PlayerSkill("Jet Uppercut", [DAMAGE], 6, 2,
                                 "Strength vs. Defense. Raise Speed Meter by 30. Chance to inflict Break/Wind Shift.",
                                 hit=80, critical=115, element="wind", status=[Break, WindShift], statsUsed=["strength", "defense", 1.25], 
                                 conditional=jet_uppercut_conditional, weight=16)

def psi_II_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity -= 15
    
    if user.sanity <= -20:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            DeepFreeze.inflict(target)
    
    return damage
skill_psi_II = PlayerSkill("Psi II", [DAMAGE, [MULTI, 2]], 19, 6,
                          "Magic vs. Resistance x 2. If sanity is lower than -20, chance to inflict Deep Freeze. Lose 15 sanity. Take recoil (35% of damage). Will inflict 2 stacks of Frostbite/Clouded II.",
                           hit=75, critical=90, element="ice", status=[Frostbite, CloudedII], stacks=2, willStatus=True, statsUsed=["magic", "resistance", 3.5], recoil=[True, 35], 
                           conditional=psi_II_conditional, weight=10, sanLean="Negative")

def ice_breaker_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name in ["Stun", "Deep Freeze"] for s in target.statusList):
        Frigid.inflict(target, 2)
        target.ultimateMeter -= 30
        say(f"{Color['magenta']}{target.name}s Ultimate Meter Was Reduced By 30!{Color['reset']}")
    
    return damage
skill_ice_breaker = PlayerSkill("Ice Breaker", [DAMAGE], 8, 3,
                                "Strength vs. Defense. If Stun or Deep Freeze are present on the opposer, inflict 2 stacks of Frigid and lower Ultimate Meter by 30. Chance to inflict Frigid/Freeze.",
                                hit=85, critical=125, element="ice", status=[Frigid, Freeze], statsUsed=["strength", "defense", 2], conditional=ice_breaker_conditional, weight=14)

def dome_conditional(self, user: Player, target: Enemy, actions: int):
    if user.sanity < 10:
        self.status = [Protection]
        Shell.inflict(user, 5)
    else:
        self.status = [Vitality]
skill_dome = PlayerSkill("Dome", [STATUS], 20, 4,
                         "If sanity is below 10, gain 5/1 stacks of Shell/Protection. If sanity is at 10+, gain Vitality. Chance to remove 1-2 Negative statueses.",
                         statusTarget="user", conditional=dome_conditional, weight=11)

def affinity_rattle_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any("Shift" in s.name for s in target.statusList):
        dam = round(user.magic * 0.5 * random.randint(1,2))
        target.health -= dam
        say(f"{Color['red']}{user.name} Dealt {dam} To {target.name}s Health!{Color['reset']}")
            
        damage *= 2
    return damage
skill_affinity_rattle = PlayerSkill("Affinity Rattle", [DAMAGE, [MULTI, HITS(1,3)]], 10, 3,
                                    "Magic vs. Resistance x 1-3. If any Shift statuses are present on the opposer, deal damage (50% of Magic x 1-2) and increase damage (2x!).",
                                    hit=75, critical=110, element=None, statsUsed=["magic", "resistance", 1.5], conditional=affinity_rattle_conditional, weight=13)

def clean_through_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if self.hit + user.hit >= 250:
        Hemorrhage.inflict(target, 5)
        CrippleII.inflict(target)
        Keen.inflict(user, 3)
    return damage
skill_clean_through = PlayerSkill("Clean Through", [DAMAGE], 11, 3,
                                  "Strength vs. Defense. If Hit + skills Hit is greater than 250, inflict 5 stacks of Hemorrhage/Cripple II and gain 3 stacks of Keen.",
                                  hit=110, critical=135, element="wind", statsUsed=["strength", "defense", 2], conditional=clean_through_conditional, weight=14)

def zeta_flare_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Draken Bahamut Sigil" for s in user.sigils) and any(s.name == "Warden of Light Sigil" for s in user.sigils):
        Radiant.inflict(target)
        Molten.inflict(target)
    Husk.inflict(user)
    
    return damage
skill_zeta_flare = PlayerSkill("Zeta-Flare", [DAMAGE, [MULTI, HITS(2,4)]], 17, 5,
                                "Magic vs. Resistance x 2-4. If Draken Bahamut and Warden of Light Sigils are equipped, inflict Radiant/Molten. Gain Husk. Chance to inflict 3 stacks of Burn/Heated/Scorch.",
                                hit=70, critical=100, element="fire", status=[Burn, Heated, Scorch], stacks=3, statsUsed=["magic", "resistance", 2], conditional=zeta_flare_conditional, weight=13)

def frenzied_burst_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Frenzied Flames" for s in target.statusList) and any(s.name == "Madness" for s in target.statusList):
        Madness.inflict(target)
        madness = next((s for s in target.statusList if s.name == "Madness"), None)
        percent = 0
        for i in range(0, madness.stacks):
            percent += 0.25
            
        if percent:
            damage += round(damage * percent)
            
    return damage
skill_frenzied_burst = PlayerSkill("Frenzied Burst", [DAMAGE], 10, 3,
                                    "Magic vs. Resistance. If Frenzied Flames and Madness is present on the opposer, inflict Madness and increase damage (25% per stack of Madness on the opposer). Chance to inflict 2 stacks of Madness.",
                                    hit=75, critical=110, element="mighty", status=[Madness], stacks=2, statsUsed=["magic", "resistance", 2], conditional=frenzied_burst_conditional, weight=11, sanLean="Negative")

def burning_jealousy_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if sum(1 for s in target.statusList if s.align == "Positive") >= 3:
        for i in range (0, 3):
            next(s for s in target.statusList if s.align == "Positive").remove(target, full=True)
        
        for status in [Molten, Scorch]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target, self.stacks, self.count)
            
    return damage
skill_burning_jealousy = PlayerSkill("Burning Jealousy", [DAMAGE, [MULTI, HITS(1,4)]], 13, 4,
                                    "Magic vs. Resistance x 1-4. If opposer has 3+ Positive statuses, remove 3 of the opposers Positive statuses and chance to inflict Molten/Scorch. Chance to inflict 2 stacks of Burn/Heated.",
                                    hit=70, critical=100, element="fire", status=[Burn, Heated], stacks=2, statsUsed=["magic", "resistance", 1.5], conditional=burning_jealousy_conditional, weight=13, sanLean="Negative")

def moonlight_razor_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.sanity -= 4
    return damage
skill_moonlight_razor = PlayerSkill("Moonlight Razor", [DAMAGE, [MULTI, HITS(1,3)]], 13, 3,
                                    "Strength vs. Resistance x 1-3. If opposers sanity is below -15, restore health (25% of damage dealt). Lower opposers sanity by 4. Chance to inflict 2 stacks of Sinking/Hemorrhage/Bleed.",
                                    hit=80, critical=115, element="ice", status=[Sinking, Hemorrhage, Bleed], stacks=2, statsUsed=["strength", "resistance", 1.5], damHeal=0.25, meter="health",
                                    healCondition= lambda damage, user, target: target.sanity <= -15, weight=13)

def demanding_butterflies_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    user.sanity -= 7
    target.sanity -= 4
    if user.sanity <= -10:
        Butterfly.inflict(target, 2)
    
    if target.sanity <= -15:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Burnout.inflict(target)
            
    return damage
skill_demanding_butterflies = PlayerSkill("Demanding Butterflies", [DAMAGE, [MULTI, 2]], 13, 3,
                                    "Strength vs. Defense x 2. If sanity is below -10, inflict 2 stacks of Butterfly. If opposers sanity is below -15, chance to inflict Burnout. Lose 7 sanity. Lower opposers sanity by 4. Chance to inflict 2 stacks of Sinking.",
                                    hit=75, critical=105, element="mighty", status=[Sinking], stacks=2, statsUsed=["strength", "defense", 1.7], conditional=demanding_butterflies_conditional, weight=12, sanLean="Negative")

def thunderstrike_ripple_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    percent = 0
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    if rupture:
        for i in range(0, rupture.stacks):
            percent += 0.05
            if percent >= 0.5:
                break
    
        if percent:
            damage += round(damage * percent)
    return damage
skill_thunderstrike_ripple = PlayerSkill("Thunderstrike - Ripple", [DAMAGE], 14, 4,
                                    "Strength vs. Defense. For every stack of Rupture present on the opposer, increase damage (5% per stack of Rupture, max 50%). Will inflict 4 stacks of Rupture (with 3 count).",
                                    hit=80, critical=100, element="thunder", status=[Rupture], stacks=4, count=3, statsUsed=["strength", "defense", 2], conditional=thunderstrike_ripple_conditional, weight=11)

def draining_hold_effect(self, user: Player, target: Enemy, actions=1):
    if self.useCheck(user, target):
        self.applyStatus(user, target)
        damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        return self.applyDamage(user, target, damage)
skill_draining_hold = PlayerSkill("Draining Hold", [DAMAGE, [MULTI, HITS(1,5)]], 9, 3,
                                  "Magic vs. None x 1-5. Restore mana (50% of damage dealt).",
                                  hit=80, critical=75, statsUsed=["magic", None, 1], damHeal=0.50, meter="mana", customEffect=draining_hold_effect, weight=13)

def meditate_conditional(self, heal: int, user: Player, target: Enemy):
    if any(s.name in ["Blue Star Sigil", "Library Sigil"] for s in user.sigils):
        restore = round(user.magic * 0.5)
        user.mana += min(restore, user.maxMana - user.mana)
        say(f"{Color['green']}{user.name}s Mana Was Restored By {restore}!{Color['reset']}")
        
    if user.sanity > 0:
        user.sanity -= 5
    elif user.sanity < 0:
        user.sanity += 5
        
    return heal
skill_meditate = PlayerSkill("Meditate", [HEAL], 7, 2,
                              "Restore health (50% of Magic + 25% of Resistance). If Blue Star or Library Sigil is equipped, restore mana (50% of Magic). Gain/Lose 5 sanity if sanity is Negative/Positive.",
                              statsUsed=[[("magic", 50), ("resistance", 25)], "health"], conditional=meditate_conditional, weight=10)

def shack_off_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    if any(s.align == "Negative" and s.family == "Other" for s in user.statusList):
        num = random.randint(1,3)
        for i in range(0, num):
            
            if random.randint(1, 100) >= 45:
                status = next((s for s in user.statusList if s.family == "Other" and s.align == "Negative"), None)
                if status:
    
                    status.remove(user, full=True)
    else:
        say("Nothing Happened!")
        
    return None
skill_shack_off = PlayerSkill("Shack Off", [SPECIAL], 8, 3,
                              "Chance to remove 1-3 Negative Other statuses.",
                              customEffect=shack_off_effect, weight=8)

def deep_breath_conditional(self, heal: int, user: Player, target: Enemy):
    user.sanity += random.randint(3,5)
    
    if user.sanity >= 20:
        heal = round(heal * 1.5)
    
    return heal
skill_deep_breath = PlayerSkill("Deep Breath", [HEAL], 5, 2,
                                 "Restore mana (60% of Resistance). If sanity is at 20+, increase restore (1.5x!). Gain 3-5 sanity.",
                                 statsUsed=[[("resistance", 60)], "mana"], conditional=deep_breath_conditional, weight=9)

def linger_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    user.sanity -= random.randint(5,7)
    
    if user.sanity > -10:
        ToughI.inflict(user)
        
    else:
        ToughII.inflict(user, 2)
        BoostII.inflict(user)
        
    return None
skill_linger = PlayerSkill("Linger", [SPECIAL], 7, 3,
                           "Gain Tough I. Lose 5-7 sanity. If sanity is below -10, gain 2 stacks Tough II/Boost II.",
                           customEffect=linger_effect, weight=7)

def combusting_blade_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    percent = 0
    dam = 0
    for status in user.statusList[:]:
        if status.family == "Burn":
            percent += 0.05
            dam += round(user.magic * 0.25 + random.randint(1,10))
    
    if percent:
        damage += round(damage * percent)
        target.health -= dam
        say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")
    
    return damage
skill_combusting_blade = PlayerSkill("Combusting Blade", [DAMAGE, [MULTI, HITS(1,5)]], 12, 4,
                                     "Strength vs. Resistance x 1-5. For each Burn status present on the opposer, increase damage (5% per status, max 50%) and deal damage (25% of Magic + 1-10). Chance to inflict 2 stacks of Heated/Sear/Gash/Break.",
                                     hit=75, critical=70, element="fire", status=[Heated, Sear, Gash, Break], stacks=2, statsUsed=["strength", "resistance", 1.5],
                                     conditional=combusting_blade_conditional, weight=16)

skill_explode = PlayerSkill("Explode", [DAMAGE], 14, 4,
                            "Magic vs. Resistance. Will inflict 3 stacks of Heated/Scorch/Scald. Take recoil (80% of damage).",
                            hit=90, critical=100, element="fire", status=[Heated, Scorch, Scald], willStatus=True, stacks=3, statsUsed=["magic", "resistance", 4], recoil=[True, 80],
                            weight=10)

def mental_blast_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity > 0:
        BoostII.inflict(user)
        
        percent = 0
        for i in range(0, user.sanity, 3):
            percent += 0.15
            if percent > 0.90:
                percent = 0.90
                break
        
        if percent:
            damage += round(damage * percent)
    
    if user.sanity < 0:
        ToughII.inflict(user, 2)
        
        reduce = 0
        for i in range(0, user.sanity, -3):
            reduce += 6
        
            if reduce >= 30:
                reduce = 30
                break
        
        if reduce:
            target.ultimateMeter -= reduce
            target.speedMeter -= reduce 
            say(f"{Color['magenta']}{target.name}s Ultimate Meter Was Reduced By {reduce}!{Color['reset']}")
            say(f"{Color['magenta']}{target.name}s Speed Meter Was Reduced By {reduce}!{Color['reset']}")
            
    return damage
skill_mental_blast = PlayerSkill("Mental Blast", [DAMAGE, [MULTI, HITS(1,3)]], 12, 4,
                                 "Magic vs. Resistance x 1-3. If sanity is Positive, gain Boost II, and for every 3 sanity, increase damage (15% per 3 sanity, max 45%). If sanity is Negative, gain 2 stacks of Tough II, and for every -3 sanity, lower opposers Speed/Ultimate Meter by 6 (max 30). Chance to inflict Sinking/Cripple II.",
                                 hit=80, critical=75, element="mighty", status=[Sinking, CrippleII], statsUsed=["magic", "resistance", 1.5],
                                 conditional=mental_blast_conditional, weight=15)

def extreme_speed_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Keen.inflict(user)
    user.speedMeter += 35
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 35!{Color['reset']}")
    
    if user.hit >= 150:
        user.speedMeter += 30
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 30!{Color['reset']}")
    return damage
skill_extreme_speed = PlayerSkill("Extreme Speed", [DAMAGE], 6, 2,
                                  "Speed vs. Defense. Raise Speed Meter by 35. If Hit is at 150+, raise Speed Meter by 30. Gain 1 stack of Keen. Chance to inflict Slow I.",
                                  hit=90, critical=115, element="wind", status=[SlowI], statsUsed=["speed", "defense", 1.3],
                                  conditional=extreme_speed_conditional, weight=13)

def splitting_winds_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    rai = 0
    percent = 0
    
    for status in target.statusList:
        if status.name == "Rupture":
            rai = 5 * status.stacks
            percent = 0.05 * status.stacks
            break
    
    if rai and percent:
        damage += round(damage * percent)
        user.speedMeter += rai
    
    return damage
skill_splitting_winds = PlayerSkill("Splitting Winds", [DAMAGE, [MULTI, HITS(2,4)]], 10, 3,
                                    "Magic vs. Resistance x 2-4. For every stack of Rupture present on the opposer, raise Speed Meter by 5 and increase damage (5% per stack, max 50%). Chance to inflict 3 stacks of Rupture (with 3 count).",
                                    hit=80, critical=125, element="wind", status=[Rupture], stacks=3, count=3, statsUsed=["magic", "resistance", 1.5],
                                    conditional=splitting_winds_conditional, weight=13)

skill_arrow_barrage = PlayerSkill("Arrow Barrage", [DAMAGE, [MULTI, HITS(2,6)]], 13, 4,
                                  "Strength vs. Defense x 2-6. Chance to inflict Puncture/Venom/Infection/Cripple II.",
                                  hit=85, critical=60, element="physical", status=[Puncture, Venom, Infection, CrippleII], statsUsed=["strength", "defense", 1.3],
                                  weight=17)

def bang_bang_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    sinking = next((s for s in target.statusList if s.name == "Sinking"), 0)
    frigid = next((s for s in target.statusList if s.name == "Frigid"), 0)
    
    percent = 0.1
    percent *= (sinking.stacks if sinking else 0) + (frigid.stacks if frigid else 0)
    
    if percent:
        damage += round(damage * percent)
    return damage
skill_bang_bang = PlayerSkill("Bang, Bang", [DAMAGE, [MULTI, 2]], 13, 4,
                              "Magic vs. Resistance x 2. For every total stacks of Sinking and Frigid present on the opposer, increase damage (10% per stack, max 100%). Chance to inflict 2 stacks of Sinking/Frigid.",
                              hit=75, critical=90, element="ice", status=[Sinking, Frigid], stacks=2, statsUsed=["magic", "resistance", 1.5],
                              conditional=bang_bang_conditional, weight=13)

def hunter_lasso_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity < 10:
        user.sanity -= 20
        user.speedMeter -= 30
        say(f"{Color['magenta']}{user.name}s Speed Meter Was Reduced By 30!{Color['reset']}")
        damage //= 2
        return damage
    
    if user.sanity >= 10:
        damage *= 2
    
    if user.sanity >= 15:
        user.sanity -= 10
        rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
        percent = 0
        if rupture:
            for i in range (0, rupture.stacks, 5):
                percent += 0.1
                Rupture.inflict(target, 1, 2)
            
            if percent:
                if percent > 0.5:
                    percent = 0.5
                damage += round(damage * percent)
    
    return damage
skill_hunter_lasso = PlayerSkill("Rose Hunter Lasso", [DAMAGE, [MULTI, 3]], 17, 5,
                                 "Strength vs. Defense x 3. If sanity is below 10, lose 20 sanity, lower Speed Meter by 30, and decrease damage (50%!). If sanity is at 10+, increase damage (2x!). If sanity is at 15+, lose 10 sanity and for every 5 stacks of Rupture present on the opposer, inflict Rupture (with 2 count) and increase damage (10% per 5 stacks, max 50%). Will inflict 5 stacks of Hemorrhage/Rupture (with 7 count).",
                                 hit=80, critical=115, element="wind", status=[Hemorrhage, Rupture], stacks=5, count=7, statsUsed=["strength", "defense", 1.8], 
                                 conditional=hunter_lasso_conditional, weight=11)

def command_meltdown_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    burn = next((s for s in target.statusList if s.name == "Burn"), None)
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    
    user.sanity += 5
    
    if burn and rupture and burn.stacks >= 3 and rupture.stacks >= 3:
        damage *= 2
        
    if user.sanity >= 15:
        count = 1
        
        if rupture and rupture.count >= 10 and rupture.stacks >= 10:
            for i in range(0, max(rupture.count, rupture.stacks), 1):
                if rupture.stacks >= i and rupture.count >= i:
                    dam = round(user.magic * 0.25)
                    target.health -= dam
                    say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")
                    count += 1
                
                if count >= 15:
                    break
    return damage
skill_command_meltdown = PlayerSkill("Command: Meltdown", [DAMAGE, [MULTI, 2]], 22, 6,
                                    "Strength vs. Defense x 2. If the opposer has Burn and Rupture and both are at 3+ stacks, increase damage (2x!). If sanity is at 15+ and Rupture is present on the opposer and at 10+ stack/count, for every 1 stack + count of Rupture present on the opposer, deal damage (25% of Magic) (max 15 times). Gain 5 sanity. Restores health (20% of damage dealt). Chance to inflict 3 stacks of Rupture (with 3 count)/Scald.",
                                    hit=80, critical=125, element="fire", status=[Rupture, Scald], stacks=3, count=3, statsUsed=["strength", "defense", 1.8], damHeal=0.20, meter="health",
                                    conditional=command_meltdown_conditional, weight=17)

def remain_oneself_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Keen.inflict(user, 2)
    keen = next((s for s in user.statusList if s.name == "Keen"), None)
    percent = 0
    for i in range(0, keen.stacks, 2):
        percent += 0.05
        
        if percent >= 0.2:
            percent = 0.2
            break
    
    if percent:
        damage += round(damage * percent)
    
    if keen and keen.stacks >= keen.maxStack:
        Poise.inflict(user, 2)
        
    poise = next((s for s in user.statusList if s.name == "Poise"), None)
    if poise and poise.stacks >= 2 and "Super Precision" in strikes:
        percent = (poise.stacks + (keen.stacks if keen else 0)) / 100
        dam = round(user.magic * percent)
        target.health -= dam
        say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")
    return damage
skill_remain_oneself = PlayerSkill("To Remain Oneself", [DAMAGE, [MULTI, 3]], 11, 3,
                                    "Strength vs. Defense x 3. For every 2 stacks of Keen present, increase damage (5% per 2 stacks, max 20%). If Keen is at max stacks, gain 2 stacks of Poise. If Poise is present and at 2 stacks and skill lands a Super Precision, deal damage (stacks of Keen + stacks of Poise% of Magic). Gain 2 stacks of Keen. Chance to inflict Clouded II/Sinking/Rupture (with 6 count).",
                                    hit=120, critical=120, element="wind", status=[CloudedII, Sinking, Rupture], count=6, statsUsed=["strength", "defense", 1.7],
                                    conditional=remain_oneself_conditional, weight=14)

def mutilating_talons_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.5):
        Might.inflict(user, 2)
    
    if any(s.name == "Burn" and s.stacks >= 2 for s in user.statusList) and any(s.name == "Rupture" and s.stacks >= 6 for s in target.statusList):
        Burn.inflict(user)
        damage += round(damage * 0.35)
    
    Burn.inflict(user)
    Power.inflict(user)
    return damage
skill_mutilating_talons = PlayerSkill("Mutilating Talons", [DAMAGE, [MULTI, HITS(1,2)]], 19, 3,
                                      "Strength vs. Defense x 1-2. If health is below 50%, gain 2 stacks of Might. If Burn is present and at 2+ stacks and Rupture is present on the opposer and at 6+ stacks, gain 1 stack of Burn and increase damage (35%!). Gain 1 stack of Burn/Power. Will inflict 2 stacks of Burn/Rupture (with 4 count).",
                                      hit=75, critical=85, element="fire", status=[Burn, Rupture], stacks=2, count=4, willStatus=True, statsUsed=["strength", "defense", 1.8],
                                      conditional=mutilating_talons_conditional, weight=19)

def rampaging_blades_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    burn = next((s for s in user.statusList if s.name == "Burn"), None)
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    if burn and rupture:
        for i in range(0, burn.stacks + rupture.stacks):
            dam = round(user.strength * 0.05) * 10
            target.health -= dam
            say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")
    
    if rupture and rupture.stacks >= 6:
        DeathriteBlaze.inflict(target, 4)
        Might.inflict(user, 2)
    
    Burn.inflict(user, 2)
    return damage
skill_rampaging_blades = PlayerSkill("Rampaging Blades", [DAMAGE, [MULTI, 3]], 22, 5,
                                     "Strength vs. Defense x 3. If Burn is present and Rupture is present on the opposer, for every stack of Burn present + stacks of Rupture present on the opposer, deal damage (5% of Strength x 5). If Rupture is present on the opposer and at 6+ stacks, inflict 4 stacks of Deathrite-Blaze and gain 2 stacks of Might. Gain 2 stacks of Burn. Chance to inflict 2 stacks of Burn/Heated/Rupture (with 4 count). Take recoil (35% of damage).",
                                     hit=60, critical=100, element="fire", status=[Burn, Heated, Rupture], stacks=2, count=4, statsUsed=["strength", "defense", 2.4], recoil=[True, 35],
                                     conditional=rampaging_blades_conditional, weight=22)

def cloudsplitting_manifestation_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.speed > target.speed and any(s.name == "Rupture" for s in target.statusList):
        DeathriteFissure.inflict(target, 5)

        dam = (user.speed - target.speed) * next(s for s in target.statusList if s.name == "Rupture").count
        target.health -= dam
        say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")

    if user.speed >= 50:
        Keen.inflict(user, 3)
        Poise.inflict(user, 2)
    return damage
skill_cloudsplitting_manifestation = PlayerSkill("Cloudsplitting Manifestation", [DAMAGE], 18, 4,
                                                 "Strength vs. Defense. If Speed is greater than opposers and Rupture is present on the opposer, inflict 5 stacks of Deathrite-Fissure and deal damage (diffrence in Speed x Rupture count on the opposer). At 50+ Speed, gain 3 stacks of Keen/Poise. Chance to inflict 4 stacks of Spark/Rupture (with 4 count).",
                                                 hit=80, critical=100, element="physical", status=[Spark, Rupture], stacks=4, count=4, statsUsed=["strength", "defense", 2.5],
                                                 conditional=cloudsplitting_manifestation_conditional, weight=20)

def blinkstep_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.speed >= 45:
        Rupture.inflict(target, 3, 0)
    
    if any(s.name == "Rupture" and s.count >= 8 for s in target.statusList):
        Rupture.inflict(target, 4, 0)

    Haze.inflict(user)
    return damage
skill_blinkstep = PlayerSkill("Blinkstep", [DAMAGE, [MULTI, HITS(1,4)]], 23, 2,
                              "Strength vs. Defense x 1-4. If Speed is at 45+, inflict 3 stacks of Rupture (with 0 count). If Rupture is at 8+ count, inflict 4 stacks of Rupture (with 0 count). Gain Haze. Will inflict 2 stacks of Spark/Rupture (with 5 count).",
                              hit=85, critical=75, element="physical", status=[Spark, Rupture], stacks=2, count=5, willStatus=True, statsUsed=["strength", "defense", 1.5],
                              conditional=blinkstep_conditional, weight=19)

def coin_toss_conditional(self, user: Player, target: Enemy, actions=1):
    if user.luck >= 100:
        Boon.inflict(user, 2)
        
        if user.luck >= 135:
            Boon.inflict(user, 2)
skill_coin_toss = PlayerSkill("Coin Toss", [STATUS], 5, 2,
                              "Gain Haze. If Luck is at 100+/135+, gain 2/4 stacks of Boon.",
                               status=[Haze], statusTarget="user", 
                               conditional=coin_toss_conditional, weight=9)

def void_stare_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    target.speedMeter -= 20
    say(f"{Color['magenta']}{target.name}s Speed Meter Was Reduced By 20!{Color['reset']}")
    target.sanity -= 6
    
    poison = 0
    sinking = 0
    
    for status in target.statusList:
        if status.family == "Poison":
            poison += 1
        
        if status.name in ["Sinking", "Deluge", "Butterfly", "Gloom"]:
            sinking += 1
    
    if poison >= 4:
        Corruption.inflict(target)
    
    if sinking >= 2:
        Gloom.inflict(target)
skill_void_stare = PlayerSkill("Void Stare", [SPECIAL], 10, 3,
                               "Lower opposers Speed Meter by 20. Lower opposers sanity by 6. If 4+ Poison statuses are present on the opposer, inflict Corruption. If 2+ Sinking adjacent statuses are present on the opposer, inflict Gloom.",
                               customEffect=void_stare_effect, weight=13)

def full_life_conditional(self, heal: int, user: Player, target: Enemy):
    if user.health <= round (user.maxHealth * 0.25) and user.sanity >= 15:
        Phoenix.inflict(user)
    return heal
skill_full_life = PlayerSkill("Full Life", [HEAL], 24, 5,
                              "Restore health (Magic x 400). If health is below 25% and sanity is at 15+, gain Phoenix Blessing.",
                              statsUsed=[[("magic", 400)], "health"], conditional=full_life_conditional, weight=15)

skill_rejuvenate = PlayerSkill("Rejuvenate", [HEAL], 12, 3,
                               "Restore health (50% of Magic + 15% of Max Health). Gain Boost III.",
                               statsUsed=[[("magic", 50), ("maxHealth", 15)], "health"], status=[BoostIII], statusTarget="user",
                               weight=13)

def electric_screaming_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge and charge.stacks < 20 and user.sanity >= 15:
        user.sanity -= 15
        loss = 20 - charge.stacks

        for i in range(0, loss, 1):
            dam = round(user.maxHealth * 0.01)
            user.health -= dam
            say(f"{Color['red']}{user.name} Took {dam} Health Damage!{Color['reset']}")  
            Charge.inflict(user)
    return damage
skill_electric_screaming = PlayerSkill("Electrict Screaming", [DAMAGE, [MULTI, 10]], 14, 4,
                                       "Magic vs. Resistance x 10. If Charge is present and not at max stacks and sanity is at 15+, lose 15 sanity, and for every missing stack of Charge to max, lose health (1% of Max Health) and gain 1 stack of Charge. Chance to inflict 5 stacks of Spark/Static.",
                                       hit=75, critical=135, element="thunder", status=[Spark, Static], stacks=5, statsUsed=["magic", "resistance", 1.2], 
                                       conditional=electric_screaming_conditional, weight=14)

def love_hate_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Charge.inflict(user, 2)

    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge and charge.stacks >= 3:
        heal = round(user.maxHealth * 0.02 + (charge.stacks / 2)) * 20
        user.health += heal
        say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
        charge.remove(user)

    if user.luck >= 180:
        Rupture.inflict(target, 2, 2)
    return damage
skill_love_hate = PlayerSkill("In The Name of Love and Hate!", [DAMAGE, [MULTI, HITS(1,5)]], 16, 5,
                              "Magic vs. Resistance x 1-5. If Charge is present and at 3+ stacks, remove Charge and restore health (2% of Max Health + stacks of Charge / 2) x 20. If Luck is at 180+, inflict 2 stacks of Rupture (with 2 count). Gain 2 stacks of Charge. Chance to inflict 3 stacks of Burn/Heated/Rupture (with 6 count).",
                              hit=90, critical=150, element="thunder", status=[Burn, Heated, Rupture], stacks=3, count=6, statsUsed=["magic", "resistance", 1.7], 
                              conditional=love_hate_conditional, weight=17)

def with_love_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    love = next((s for s in user.statusList if s.name == "Love~Hate"), None)
    if love:
        increase = min(0.96, (0.12 * love.stacks))
        damage += round(damage * increase)
    LoveHate.inflict(user, 2)
    return damage
skill_with_love = PlayerSkill("With Love!", [DAMAGE, [MULTI, HITS(1,3)]], 21, 3,
                              "Magic vs. Resistance x 1-3. For every stack of Love~Hate present, increase damage (12%, max 96%). Gain 2 stacks of Love~Hate. Will inflict 4 stacks of Rupture (with 3 count).",
                              hit=85, critical=95, element="mighty", status=[Rupture], stacks=4, count=3, statsUsed=["magic", "resistance", 1.5],
                              conditional=with_love_conditional, weight=18)

def minor_arcana_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    love = next((s for s in user.statusList if s.name == "Love~Hate"), None)
    if love:
        increase = (love.stacks * 10) / 100
        damage += round(damage * increase)
        
        if love.stacks >= 3:
            love.remove(user, 2)
            Might.inflict(user, 2)
    return damage
skill_minor_arcana = PlayerSkill("Minor Arcana Slave!!", [DAMAGE, [MULTI, HITS(2,5)]], 26, 5,
                                 "Magic vs. Resistance x 2-5. If Love~Hate is present, increase damage ((stacks of Love~Hate x 10)%!) and if Love~Hate is at 3+ stacks, lose 2 stacks of Love~Hate and gain 2 stacks of Might. Chance to inflict 4 stacks of Spark/Rupture (with 6 count).",
                                 hit=75, critical=115, element="mighty", status=[Spark, Rupture], stacks=4, count=6, statsUsed=["magic", "resistance", 2.4],
                                 conditional=minor_arcana_conditional, weight=21)

def rapid_chant_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    love = next((s for s in user.statusList if s.name == "Love~Hate"), None)
    if love:
        if love.stacks >= 6:
            ToughII.inflict(user)
            
            charge = next((s for s in user.statusList if s.name == "Charge"), None)
            if charge:
                charge.inflict(user, love.stacks)
                lose = love.stacks // 2
                love.remove(user, lose)
        else:
            say("Nothing Happened!")
    else:
        say("Nothing Happened!")
skill_rapid_chant = PlayerSkill("Rapid Chant!", [SPECIAL], 18, 4,
                                "If Love~Hate is present and at 6+ stacks, gain 1 stack of Tough II. If Love~Hate and Charge are present, gain 1 stack of Charge per Love~Hate stack and lose half stacks of Love~Hate (remove if at 1 stack).",
                                customEffect=rapid_chant_effect, weight=16)

def energy_cycle_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge and charge.stacks >= 7:
        charge.remove(user, 2)
        Boon.inflict(user, 2)
        Shock.inflict(user, 2)

    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    if rupture and rupture.stacks >= 6 and rupture.count >= 6:
        Charge.inflict(user, 3)
    return damage
skill_energy_cycle = PlayerSkill("Energy Cycle", [DAMAGE, [MULTI, HITS(1,3)]], 12, 3,
                                 "Strength vs. Defense x 1-3. If Charge is present and at 7+ stacks, lose 2 stacks of Charge and gain 2 stacks of Boon/Shock. If Rupture is present on the opposer and at 6+ stacks/count, gain 3 stacks of Charge. Chance to inflict Bind II/Rupture (with 3 count).",
                                 hit=80, critical=135, element="thunder", status=[BindII, Rupture], count=3, statsUsed=["strength", "defense", 1.5], 
                                 conditional=energy_cycle_conditional, weight=14)

def aedd_conditional(self, user: Player, target: Enemy, actions=1):
    missing = ((user.maxHealth - user.health) / user.maxHealth) * 100
    if missing > 0:
        stacks = min(int(missing // 5), 5)
        Charge.inflict(user, stacks)

    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge and charge.stacks >= 15:
        charge.remove(user, 5)
        user.sanity -= 5
        skill = next((s for s in user.skills if s.element == "thunder" and s.usable), None)
        if skill:
            ogStrength, ogMagic = user.strength, user.magic
            user.strength, user.magic = ogStrength // 2, ogMagic // 2
            skill.effect(user, target, 0)
            user.strength, user.magic = ogStrength, ogMagic
            skill.usable = True
            skill.cooldownProgress = skill.cooldown
skill_aedd = PlayerSkill("AEDD", [STATUS], 7, 2,
                         "Gain 2 stacks of Overload/Boon. For every 5% of health missing, gain 1 stack of Charge (max 5). If Charge is present and at 15+ stacks, lose 5 stacks, lose 5 sanity, and use 1 Thunder element skill (if equipped and not on cooldown) at half strength.",
                         status=[Overload, Boon], stacks=2, statusTarget="user", 
                         conditional=aedd_conditional, weight=11)

def tidal_elegy_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity > -15:
        user.sanity += 20
        damage -= round(damage * 0.8)

    if user.sanity <= -15:
        sinking = next((s for s in target.statusList if s.name == "Sinking"), None)
        frigid = next((s for s in target.statusList if s.name == "Frigid"), None)

        chosen = frigid if frigid and frigid.stacks and (sinking and sinking.stacks and frigid.stacks >= sinking.stacks or not sinking) else sinking if sinking else None
        if chosen:
            percent = 0

            for i in range(0, chosen.stacks):
                percent += 0.05
            
            if percent:
                damage += round(damage * percent)

        if target.resistance <= 20:
            damage = round(damage * 1.5)

        if damage > round(target.maxHealth * 0.2):
            dam = round(user.magic * 0.5 + user.resistance * 0.25)
            target.health-= dam
            say(f"{Color['red']}{target.name} Took {dam} Health Damage!{Color['reset']}")  
    user.sanity -= 5
    return damage
skill_tidal_elegy = PlayerSkill("Tidal Elegy", [DAMAGE, [MULTI, HITS(1,2)]], 14, 4,
                                "Magic vs. Resistance x 1-2. If sanity is greater than -15, gain 20 sanity and decrease damage (80%!). -15 sanity is needed for all of the effects of this skill (besides basic status infliction). For every stack of Sinking or Frigid (whichever has the most stacks) present on the opposer, increase damage (5%!). If the opposers Resistance is below 20, increase damage (1.5x!). If damage is more than 20% of opposers Max Health, deal damage (50% of Magic + 25% of Resistance) x 1.5. Lose 5 sanity. Chance to inflict Clouded II/Sinking/Frigid.",
                                hit=65, critical=115, element="ice", status=[CloudedII, Sinking, Frigid], statsUsed=["magic", "resistance", 2], 
                                conditional=tidal_elegy_conditional, weight=11, sanLean="Negative")

def rime_shank_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if target.health >= round(target.maxHealth * 0.5):
        damage += round(damage * 0.3)

    sinking = next((s for s in target.statusList if s.name == "Sinking"), None)
    if target.sanity <= -15 and sinking:
        Frigid.inflict(target)
        Sinking.inflict(target)
    return damage
skill_rime_shank = PlayerSkill("Rime Shank", [DAMAGE, [MULTI, 3]], 9, 3,
                                "Strength vs. Resistance x 3. If opposers health is above 50%, increase damage (30%!). If opposers sanity is below -15 and Sinking is present on the opposer, inflcit 1 stack of Frigid/Sinking. Chance to inflict 2 stacks of Frigid/Sinking.",
                                hit=50, critical=135, element="ice", status=[Frigid, Sinking], stacks=2, statsUsed=["strength", "resistance", 1.5], sanLean="Negative",
                                conditional=rime_shank_conditional, weight=15)

def sunshower_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity > -20:
        user.sanity += 5
        Fragile.inflict(user, 2)

    sinking = next((s for s in target.statusList if s.name == "Sinking"), None)
    frigid = next((s for s in target.statusList if s.name == "Frigid"), None)

    if sinking and frigid:
        Frostbite.inflict(target, 2)
        Freeze.inflict(target)
        AbsoluteZero.inflict(target)
    return damage
skill_sunshower = PlayerSkill("Sunshower", [DAMAGE, [MULTI, HITS(3,7)]], 14, 3,
                              "Magic vs. Resistance x 3-7. If sanity is greater than -20, lose 5 sanity and gain 2 stacks of Fragile. If Sinking and Frigid are present on the opposer, inflict 2 stacks of Frostbite/Freeze/Absolute Zero. Chance to inflict Gloom.",
                              hit=55, critical=115, element="ice", status=[Gloom], stacks=2, statsUsed=["magic", "resistance", 1.2], 
                              conditional=sunshower_conditional, weight=18, sanLean="Negative")

def abyssal_dance_conditional(self, user: Player, target: Enemy, actions=1):
    user.sanity -= 5

    if user.sanity <= -15 and sum(1 for s in target.statusList if s.align == "Negative" and s.family == "Mental") >= 4:
        target.sanity -= 50
        say(f"{Color['magenta']}{target.name} Lost 50 Sanity!{Color['reset']}")
skill_abyssal_dance = PlayerSkill("Abyssal Dance", [STATUS], 11, 4,
                                  "Inflict Engulfed. Lose 5 sanity. If sanity is below -15 and opposer has 4+ Negative Mental statuses, lower opposers sanity by 50 sanity.",
                                  status=[Engulfed], 
                                  conditional=abyssal_dance_conditional, weight=15)

def fluid_slam_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.luck >= 150:
        target.sanity -= 25
        damage = round(damage * 1.5)

    sinking = next((s for s in target.statusList if s.name == "Sinking"), None)
    poison = next((s for s in target.statusList if s.name == "Deadly Poison"), None)
    if sinking and poison and sinking.stacks >= 5 and poison.stacks >= 5:
        target.speedMeter -= 35
        target.ultimateMeter -= 35
        say(f"{Color['magenta']}{target.name}s Speed Meter Was Reduced By 35!{Color['reset']}")
        say(f"{Color['magenta']}{target.name}s Ultimate Meter Was Reduced By 35!{Color['reset']}")
    return damage
skill_fluid_slam = PlayerSkill("Fluid Slam", [DAMAGE], 14, 3,
                                "Strength vs. Defense. If Luck is at 150+, lower opposers sanity by 25 and increase damage (1.5x!). If Sinking and Deadly Poison are present on the opposer and at 5+ stacks, lower opposers Speed/Ultimate Meter by 35. Chance to inflict 5 stacks of Deadly Poison/Poison/Venom/Break.",
                                hit=55, critical=150, element="physical", status=[DeadlyPoison, Poison, Venom, Break], stacks=5, statsUsed=["strength", "defense", 2], 
                                conditional=fluid_slam_conditional, weight=18)

def corroding_pearl_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.sanity -= 5
    if target.health <= round(target.maxHealth * 0.5):
        damage = round(damage * 1.5)

        if target.health <= round(target.maxHealth * 0.25):
            count = 0
            for status in target.statusList:
                if status.family == "Poison":
                    if "Special" not in status.type_:
                        status.simple(target)
                    else:
                        status.special(target, damage, user)
                    count += 1

                if count >= 2:
                    break
    return damage
skill_corroding_pearl = PlayerSkill("Corroding Pearl", [DAMAGE, [MULTI, 3]], 12, 4,
                                    "Magic vs. Resistance x 3. If opposers health is below 50%, increase damage (1.5x!). If opposers health is below 25%, chance to retrigger 1-2 Poison statuses and increase damage (2x!). Lower opposers sanity by 4. Chance to inflict 3 stacks of Deadly Poison/Corruption.",
                                    hit=65, critical=90, element="mighty", status=[DeadlyPoison, Corruption], stacks=3, statsUsed=["magic", "resistance", 1.5], 
                                    conditional=corroding_pearl_conditional, weight=15, sanLean="Negative")

def acid_splash_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.sanity -= 5
    if sum(1 for s in target.statusList if s.family == "Poison") >= 4 and target.sanity <= -10:
        Sinking.inflict(target, 1)
        Fragile.inflict(target, 2)
    return damage
skill_acid_splash = PlayerSkill("Acid Splash", [DAMAGE], 10, 3,
                                "Magic vs. Resistance. If 4+ Poison statuses are present on the opposer and their sanity is below -10, inflict 1 stack of Sinking and 2 stacks of Fragile. Lower opposers sanity by 5. Chance to inflict Venom/Plague/Frail II.",
                                hit=65, critical=120, element="physical", status=[Venom, Plague, FrailII], statsUsed=["magic", "resistance", 2], 
                                conditional=acid_splash_conditional, weight=15)

def ebony_stem_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name in ["Fragile", "Frail II", "Frail III"] for s in target.statusList):
        target.sanity -= 10
        damage *= 2
    return damage
skill_ebony_stem = PlayerSkill("Ebony Stem", [DAMAGE, [MULTI, HITS(1,4)]], 15, 4,
                                "Strength vs. Defense x 1-4. If Fragile or Frail II/III are present on the opposer, lower opposers sanity by 10 and increase damage (2x!). Chance to inflict 2 stacks of Maggots/Hemorrhage/Infection/Puncture.",
                                hit=70, critical=85, element="wind", status=[Maggots, Hemorrhage, Infection, Puncture], stacks=2, statsUsed=["strength", "defense", 1.7], 
                                conditional=ebony_stem_conditional, weight=17, sanLean="Negative")

def shimmer_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if getattr(target, "mighty") in ["Super Weak", "Weak"]:
        damage *= 2
    return damage
skill_shimmer = PlayerSkill("Shimmer", [DAMAGE], 16, 4, 
                            "Magic vs. Resistance. If opposer is Super Weak/Weak to Mighty, increase damage (2x!). Chance to inflict 2 stacks of Fragile/Frigid.",
                            hit=85, critical=85, element="ice", status=[Fragile, Frigid], stacks=2, statsUsed=["magic", "resistance", 2.3], 
                            conditional=shimmer_conditional, weight=15)

def bladeblitz_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)

    if rupture and rupture.count >= 5:
        rupture.remove(target, 0, 5)
        FullPower.inflict(user)
    return damage
skill_bladeblitz = PlayerSkill("Bladeblitz", [DAMAGE, [MULTI, 2]], 12, 3, 
                               "Strength vs. Defense x 2. If Rupture is present on the opposer and at 5+ count, opposer loses 5 count of Rupture and gain Full Power. Chance to inflict 3 stacks of Hemorrhage/Rupture (with 3 count).",
                                hit=110, critical=125, element="thunder", status=[Hemorrhage, Rupture], stacks=3, count=3, statsUsed=["strength", "defense", 1.6],
                                conditional=bladeblitz_conditional, weight=16)

def mineuchi_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    target.speedMeter -= 25
    say(f"{Color['magenta']}{target.name}s Speed Meter Was Lowered By 25!{Color['reset']}")

    if user.strength >= 45 and user.hit >= 115:
        for status in [Stun, Fragile]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target, 4)
    return damage
skill_mineuchi = PlayerSkill("Mineuchi", [DAMAGE], 13, 4, 
                             "Strength vs. Defense. If Strength is greater than 45 and Hit is greater than 115, chance to inflict 4 stacks of Fragile/Stun. Lower opposers Speed Meter by 25 . Chance to inflict 5 stacks of Rupture (with 6 count).",
                              hit=90, critical=95, element="wind", status=[Rupture], stacks=5, count=6, statsUsed=["strength", "defense", 2], 
                              conditional=mineuchi_conditional, weight=17)

def pentakinesis_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    count = 0
    for skill in user.skills:
        if "Damage" in skill.type_ and skill.statsUsed[0] in ["magic", "resistance"] and (skill.element == "fire" or skill.name == "Weather Ball"):
            count += 1

    if count:
        WillowWisp.inflict(target, count * 5)
        increase = 0.1 * count
        damage += round(damage * increase)

    if sum(1 for s in target.statusList if s.family == "Burn") >= 4:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Radiant.inflict(target)
    return damage
skill_pentakinesis = PlayerSkill("Pentakinesis", [DAMAGE], 18, 5, 
                                 "Magic vs. Resistance. For each Magic skill equipped, if the skill is the same element as this skill, inflict 5 stacks of Willow Wisp and increase damage (10%!). If 4+ Burn statuses are present on the opposer, chance to inflict Radiant. Chance to inflict 2 stacks of Heated/Willow Wisp/Weak.",
                                 hit=65, critical=125, element="fire", status=[Heated, WillowWisp, Weak], stacks=2, statsUsed=["magic", "resistance", 2.5], 
                                 conditional=pentakinesis_conditional, weight=16)

def doloris_flames_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    willow = next((s for s in target.statusList if s.name == "Willow Wisp"), None)
    increase = 0

    if willow and target.sanity <= -10:
        for i in range(0, willow.stacks, 10):
            increase += 0.1
            target.sanity -= 2

        if increase:
            damage += round(damage * increase)

        willow.remove(target, willow.stacks // 2)

    if user.sanity <= -15:
        Madness.inflict(target, 3)

    return damage
skill_doloris_flames = PlayerSkill("Doloris Flames", [DAMAGE, [MULTI, HITS(1,3)]], 15, 4, 
                                   "Magic vs. Resistance x 1-3. If Willow Wisp is present on the opposer and sanity is below -10, opposer loses half of Willow Wisps stacks, and for every 10 stacks of Willow Wisp, opposer loses 2 sanity, and increase damage (10%!). If sanity is below -15, inflict 3 stacks of Madness. Chance to inflict 5 stacks of Willow Wisp.",
                                   hit=70, critical=85, element="fire", status=[WillowWisp], stacks=5, statsUsed=["magic", "resistance", 1.8], sanLean="Negative",
                                   conditional=doloris_flames_conditional, weight=15)

def blood_branch_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity <= -15 and sum(1 for s in target.statusList if s.family == "Bleed") >= 2:
        Protection.inflict(user, 2)
        count = 0
        for status in target.statusList:
            if status.family == "Bleed":
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target)

                count += 1
            if count >= 2:
                break

        if user.health <= round(user.maxHealth * 0.35):
            Power.inflict(user, 3)
            if any(s.family == "Bleed" for s in target.statusList):
                random.choice([s for s in target.statusList if s.family == "Bleed"]).remove(target, full=True)

    return damage
skill_blood_branch = PlayerSkill("Blood Branch", [DAMAGE], 13, 4, 
                                 "Strength vs. Defense. If sanity is below -15 and 2+ Bleed statuses are present on the opposer, retrigger 2 Bleed statuses. If health is below 35%, gain 3 stacks of Power and remove 1 Bleed status from the opposer. Chance to inflict 2 stacks of Hemorrhage/Fragile/Weak.",
                                 hit=85, critical=95, element="wind", status=[Hemorrhage, Fragile, Weak], stacks=2, statsUsed=["strength", "defense", 2], 
                                 conditional=blood_branch_conditional, sanLean="Negative", weight=15)

def magic_heart_conditional(self, heal: int, user: Player, target: Enemy):
    if user.sanity >= 15:
        Protection.inflict(user, 2)
    return heal
skill_magic_heart = PlayerSkill("Magic Heart", [HEAL], 13, 3, 
                                "Restore health (5% of Max Health + 50% of Magic). If sanity is at 15+, gain 2 stacks Protection. Gain 5 stacks of Rejuvenate.",
                                statsUsed=[[("maxHealth", 5), ("magic", 50)], "health"], status=[Rejuvenate], stacks=5, statusTarget="user", conditional=magic_heart_conditional, weight=13)

def double_edge_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.45):
        FullPower.inflict(user)

    if user.health <= round(user.maxHealth * 0.30): 
        Fragile.inflict(target, 2)
    return damage
skill_double_edge = PlayerSkill("Double-Edge", [DAMAGE], 12, 4, 
                                "Strength vs. Defense. If health is below 45%, gain Full Power. If health is below 30%, inflict 2 stacks of Fragile. Will inflict Break. Take recoil (40% of damage).",
                                hit=55, critical=110, element="physical", status=[Break], willStatus=True, statsUsed=["strength", "defense", 3], recoil=[True, 40], 
                                conditional=double_edge_conditional, weight=13)

def wild_tempest_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    Charge.inflict(user, 3)
    return damage
skill_wild_tempest = PlayerSkill("Wild Tempest", [DAMAGE, [MULTI, HITS(1,4)]], 14, 4, 
                                 "Strength vs. Resistance x 1-4. Gain 3 stacks of Charge. Chance to inflict 3 stacks of Rupture (with 5 count)/Clot/Gash. Take recoil (55% of damage).",
                                 hit=60, critical=100, element="thunder", status=[Rupture, Clot, Gash], stacks=3, count=5, statsUsed=["strength", "defense", 1.7], recoil=[True, 55], 
                                 conditional=wild_tempest_conditional, weight=14)

def blind_shots_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if "Critical" in strikes:
        Charge.inflict(user, 2)
        Poise.inflict(user, 2)
    
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge and charge.stacks >= 10:
        charge.remove(user, 5)
        Poise.inflict(user, 3)
        
        Scorch.inflict(target)
        Static.inflict(target)
    
    if random.randint(1, 100) + user.luck >= target.luck + 35:
        Spark.inflict(target, 5)
    
    return damage
skill_blind_shots = PlayerSkill("Blind Shots", [DAMAGE, [MULTI, HITS(1,5)]], 20, 3,
                                "Luck vs. Defense x 1-5. If skill lands a Critical Strike, gain 2 stacks of Charge/Poise. If Charge is present and at 10+ stacks, lose 5 stacks of Charge, gain 3 stacks of Poise, and inflict Scorch/Static. Chance to inflict 5/3 stacks of Spark/Burn.",
                                hit=55, critical=150, element="fire", status=[Burn], stacks=3, statsUsed=["luck", "defense", 0.4],
                                conditional=blind_shots_conditional, weight=16)

def cache_effect(self, user: Player, target: Enemy, actions=1):
    say(f"{user.name} Used {self.name}!")
    self.onCooldown = True
    self.usable = False
    
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge:
        if charge.stacks >= 10:
            charge.remove(user, 5)
            Haste.inflict(user, 3)
                
        if charge.stacks > 0:
            count = 0
            for i in range(0, charge.stacks):
                charge.lose(user)
                Boon.inflict(user)
                count += 1
                if charge.stacks == 0 or count >= 6:
                    break
    else:
        say("Nothing Happened!")
skill_cache = PlayerSkill("Cache", [SPECIAL], 15, 3,
                          "If Charge is present and at 10+ stacks, lose 5 stacks and gain 3 stacks of Haste. For each stack of Charge, lose 1 stack of Charge, gain 1 stack of Boon (max 6).",
                           customEffect=cache_effect, weight=16)

def giga_break_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.5):
        Overflow.inflict(user)
        SuperBreak.inflict(target)

    Fragile.inflict(target, 2)
    return damage
skill_giga_break = PlayerSkill("Giga Break", [DAMAGE, [MULTI, HITS(1,3)]], 30, 5,
                               "Strength vs. Defense x 1-3. If health is below 50%, gain Overflow and inflict Super Break. Will inflict 2/6 stacks of Fragile/Spark. Take recoil (40% of damage).",
                               hit=70, critical=115, element="thunder", status=[Spark], stacks=6, statsUsed=["strength", "defense", 2.3], recoil=[True, 40], 
                               conditional=giga_break_conditional, weight=15)

def death_bound_press_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.75):
        Power.inflict(user)
        damage += round(damage * 0.25)

    if user.health <= round(user.maxHealth * 0.5):
        BoostII.inflict(user)
        damage += round(damage * 0.25)

    if target.health <= round(target.maxHealth * 0.5):
        Might.inflict(user)

    return damage
skill_death_bound_press = PlayerSkill("Death Bound Press", [DAMAGE], 24, 4,
                                      "Strength vs. Defense. If health is below 75%, gain 3 stacks of Power and increase damage (25%!). If health is below 50%, gain Boost II and increase damage (25%!). If opposers health is below 50%, gain 2 stacks of Might. Will inflict Cripple II/Weak. Take recoil (50% of damage).",
                                      hit=65, critical=105, element="mighty", status=[CrippleII, Weak], willStatus=True, statsUsed=["strength", "defense", 2.5], recoil=[True, 50], 
                                      conditional=death_bound_press_conditional, weight=15)

def star_plummet_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if getattr(target, "fire") in ["Super Weak", "Weak"]:
        damage = round(damage * 1.5)

    if any(s.name == "Rupture" for s in target.statusList):
        Rupture.inflict(target, 2, 4)
        Fragile.inflict(target, 2)
    return damage
skill_star_plummet = PlayerSkill("Star Plummet", [DAMAGE, [MULTI, HITS(1,5)]], 19, 4,
                                 "Strength vs. Defense x 1-5. If opposer is Super Weak/Weak to Fire, increase damage (1.5x!). If Rupture is present on the opposer, inflict 2 stacks of Fragile/Rupture (with 4 count). Chance to inflict 2 stacks of Burn/Rupture (with 5 count). Take recoil (38% of damage).",
                                 hit=60, critical=110, element="mighty", status=[Burn, Rupture], stacks=2, count=5, statsUsed=["strength", "defense", 1.8], recoil=[True, 38], 
                                 conditional=wild_tempest_conditional, weight=15)

def four_sided_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Deep Freeze" for s in target.statusList):
        Glint.inflict(target, 3)
        Frigid.inflict(target, 3)
    
    if target.sanity >= 10:
        target.sanity -= 5
        Glint.inflict(target, 2)
    
    user.sanity += 3
    
    return damage
skill_four_sided = PlayerSkill("Four-Sided Ice Cage", [DAMAGE, [MULTI, 4]], 20, 4,
                               "Magic vs. Resistance x 4. If Deep Freeze is present on the opposer, inflict 3 stacks of Glint/Frigid. If opposers sanity is at 10+, lower opposers sanity by 5 and inflict 2 stacks of Glint. Gain 3 sanity. Chance ot inflict 2 stacks of Glint/Bind II.",
                               hit=65, critical=85, element="ice", status=[Glint, BindII], stacks=2, statsUsed=["magic", "resistance", 1.8],
                               conditional=four_sided_conditional, weight=19)

def charged_strikes_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if any(s.name == "Electric Bridge" for s in target.statusList):
        Haste.inflict(user)
    
    if any(s.name == "Spark" and s.stacks >= 10 for s in target.statusList):
        Arc.inflict(user)
        
    return damage
skill_charged_strikes = PlayerSkill("Charged Strikes", [DAMAGE, [MULTI, HITS(2,3)]], 18, 4,
                                    "Strength vs. Defense x 2-3. If Electric Bridge is present on the opposer, gain 1 stack of Haste. If Spark is present on the opposer and at 10+ stacks, inflict Arc. Chance to inflict 2 stacks of Spark/Short Circuit/Slug.",
                                    hit=70, critical=105, element="thunder", status=[Spark, ShortCircuit, Slug], stacks=2, statsUsed=["strength", "defense", 2],
                                    conditional=charged_strikes_conditional, weight=17)

def floating_slash_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    madness = next((s for s in target.statusList if s.name == "Madness"), None)
    if madness and madness.stacks >= 5:
        target.sanity -= 3
        for status in [Fragile, FrenziedFlames]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target, self.stacks, self.count)

    user.sanity -= 3 
    target.sanity -= 3
    return damage
skill_floating_slash = PlayerSkill("Floating Slash", [DAMAGE, [MULTI, HITS(1,2)]], 18, 4,
                                   "Strength vs. Defense x 1-2. If Madness is present on the opposer and at 5+ stacks, lower opposers sanity by 3 and chance to inflict 2 stacks of Fragile/Frenzied Flames. Lose 3 sanity. Lower opposers sanity by 3. Chance to inflict 2 stacks of Madness/Burn/Split.",
                                   hit=100, critical=35, element="fire", status=[Madness, Burn, Split], stacks=2, statsUsed=["strength", "defense", 2], sanLean="Negative",
                                   conditional=floating_slash_conditional, weight=20)

def golden_crux_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity <= -10:
        user.sanity += 10
        Rejuvenate.inflict(user, 10)
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Slug.inflict(target)
        
    return damage
skill_golden_crux = PlayerSkill("Golden Crux", [DAMAGE, [MULTI, HITS(1,5)]], 21, 5,
                                "Magic vs. Resistance x 1-5. If sanity is below -10, gain 10 sanity, gain 10 stacks of Rejuvenate, and chance to inflict 1 stack of Slug. Will inflict 2 stacks of Madness/Down/Hemorrhage. Take recoil (30% of damage).",
                                hit=50, critical=130, element="mighty", status=[Madness, Down, Hemorrhage], willStatus=True, statsUsed=["magic", "resistance", 1.6], recoil=[True, 30], sanLean="Negative",
                                conditional=golden_crux_conditional, weight=18)

def confuse_ray_conditional(self, user: Player, target: Enemy, actions=1):
    if target.sanity <= -15 and any(s.name == "Gloom" for s in target.statusList):
        Burnout.inflict(target)
skill_confuse_ray = PlayerSkill("Confuse Ray", [STATUS], 17, 5,
                                "Inflict 2 stacks of Down/Slow. If opposers sanity is below -15 and Gloom is present on the opposer, inflict Burnout.",
                                status=[Down, SlowI], stacks=2, 
                                conditional=confuse_ray_conditional, weight=15)

def nightshade_conditional(self, damage: int, user: Player, target: Enemy, actions=1, strikes=[]):
    if user.sanity > 0:
        damage -= round(damage * 0.6)

    if actions >= 12 and user.sanity <= -15:
        for status in [Madness, Engulfed]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target, 2)
    return damage
skill_nightshade = PlayerSkill("Nightshade Flash Fire", [DAMAGE], 24, 5,
                               "Magic vs. Resistance. If sanity is Positive, decrease damage (60%!). If global actions is at 12+ and sanity is below -15, chance to inflict 2 stacks of Madness/Engulfed. Will inflict 2 stacks of Gloom/Sinking/Madness. Take recoil (28% of damage).",
                               hit=50, critical=120, element="fire", status=[Gloom, Sinking, Madness], stacks=2, willStatus=True, statsUsed=["magic", "resistance", 2.5], recoil=[True, 28], sanLean="Negative",
                               conditional=nightshade_conditional)

##------------Player Passive Skills-----------##

def devourer_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    for status in user.statusList[:]:
        if status.family in ["Burn", "Bleed", "Poison"] and random.randint(1,100) >= 60:
            status.remove(user, full=True)
            
            heal = 20 + round(user.maxHealth * 0.02)
            user.health += heal
            user.health = min(user.health, user.maxHealth)
            say(f"{Color['green']}{user.name} Restored {heal}!{Color['reset']}")
passive_devourer = PlayerSkill("Devourer", [PASSIVE], 0, 0,
                          f"For each Bleed/Poison/Burn status present, chance to remove it and restore health (20 + 2% of Max Health points per status).")
passive_devourer.passive = types.MethodType(devourer_passive, passive_devourer)

def resilienece_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.sanity <= -10 and random.randint(1,100) >= 55:
        say(f"{Color['yellow']}Resilience Triggered!{Color['reset']}")
        user.sanity += 5
        if not any("Regen" == s.name for s in user.statusList):
            Regen.inflict(user)
        if not any("Mana Regen" == s.name for s in user.statusList):
            ManaRegen.inflict(user)
passive_resilience = PlayerSkill("Resilience", [PASSIVE], 0, 0,
                                 f"If sanity is lower than -10, chance to; gain 5 sanity and gain Regen/Mana Regen.")
passive_resilience.passive = types.MethodType(resilienece_passive, passive_resilience)

def rise_again_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if any("Frail" in status.name or "Slow" in status.name for status in user.statusList) and random.randint(1,100) >= 55:
        say(f"{Color['yellow']}Rise Again Triggered!{Color['reset']}")
        user.sanity += 10
        for status in user.statusList[:]:
            if "Frail" in status.name or "Slow" in status.name:
                status.remove(user, full=True)
                break
passive_rise_again = PlayerSkill("Rise Again", [PASSIVE], 0, 0,
                                 f"If any Frail/Slow statuses are present, chance to; remove 1 of them and gain 10 sanity.")
passive_rise_again.passive = types.MethodType(rise_again_passive, passive_rise_again)

def deescalate_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    sanity = 0
    if user.lastAction and user.lastAction == "Wait":
        for status in user.statusList[:]:
            if status.canStack and status.align == "Negative":
                if status.stacks > 0:
                    status.remove(user, full=True)
                    say(f"{Color['green']}{user.name} Lost A Stack of {self.name}!{Color['reset']}")
            
                if sanity < 6:
                    sanity += 2
                    user.sanity += sanity
                    say(f"{Color['blue']}{user.name} Gain 2 Sanity!{Color['reset']}")
                
                heal = round(user.maxHealth * 0.03)
                user.health += heal
                user.health = min(user.health, user.maxHealth)
                say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
passive_deescalate = PlayerSkill("Deescalate", [PASSIVE], 0, 0,
                                 "If Wait is used, for each stacking Negative status present, remove 1 stack, gain 2 sanity (max 6), and restore health (3% of Max Health).")
passive_deescalate.passive = types.MethodType(deescalate_passive, passive_deescalate)

def beacon_positive_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    sanity = 0
    heal = 0
    for status in user.statusList[:]:
        if status.align == "Negative":
            if sanity < 6:
                sanity += 2
            if heal < 0.08:
                heal += 0.02
            
    if sanity and heal:
        user.sanity += sanity
        say(f"{Color['blue']}{user.name} Gain {sanity} Sanity!{Color['reset']}")

        heal = round(user.maxHealth * heal)
        user.health += heal
        user.health = min(user.health, user.maxHealth)
        say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
passive_beacon_positive = PlayerSkill("Beacon of Positivity", [PASSIVE], 0, 0,
                                      "For each Negative status present, gain 2 sanity (max 6) and restore health (2% of Max Health, max 8%).")
passive_beacon_positive.passive = types.MethodType(beacon_positive_passive, passive_beacon_positive)

def mighty_prowess_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "mighty":
        damage = round(damage * 0.35)
        enemy.health -= damage
        say(f"{Color['red']}{user.name} Dealt {damage} To {enemy.name}!{Color['reset']}")
passive_mighty_prowess = PlayerSkill("Mighty Prowess", [PASSIVE], 0, 0,
                                     "If skill with the Mighty element is used, deal damage (35% of damage dealt this action).")
passive_mighty_prowess.passive = types.MethodType(mighty_prowess_passive, passive_mighty_prowess)

def poison_lord_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element in ["mighty", "physical"]:
        if random.randint(1, 100) + user.luck >= enemy.luck + 35:
            Poison.inflict(enemy)
            Plague.inflict(enemy)
    
    for status in enemy.statusList:
        if status.family == "Poison":
            status.count += 1
            say(f"{Color['green']}{enemy.name} Gained 1 Count Of {self.name} Due To {self.name}!{Color['reset']}")
passive_poison_lord = PlayerSkill("Poison Lord", [PASSIVE], 0, 0,
                                  "If skill with the Mighty/Physical element is used, chance to inflict Poison/Plague. For each Poison status present on the opposer, increase its count by 1 each action.")
passive_poison_lord.passive = types.MethodType(poison_lord_passive, passive_poison_lord)

def mother_follower_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element in ["fire", "wind"]:
        if random.randint(1, 100) + user.luck >= enemy.luck + 35:
            Bleed.inflict(enemy)
            Gash.inflict(enemy)
    
    chance = 0.03 + sum(0.01 for i in range(0, user.luck, 5))
        
    for status in enemy.statusList:
        if status.family == "Bleed":
            if chance >= random.random():
                if "Special" not in status.type_:
                    status.simple(enemy)
                else:
                    status.special(enemy)
passive_mother_follower = PlayerSkill("Formless Mother's Follower", [PASSIVE], 0, 0,
                                  "If skill with the Fire/Wind element is used, chance to inflict Bleed/Gash. For each Bleed status present on the opposer, at a chance of 3% + 1% per 5 points of Luck, chance to retrigger status.")
passive_mother_follower.passive = types.MethodType(mother_follower_passive, passive_mother_follower)

def dimensional_master_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element in ["thunder", "mighty"] and any(s.name == "Keen" for s in user.statusList) and not any(s.name == "Rift Master" for s in user.skills):
        for i in range(0, next(s for s in user.statusList if s.name == "Keen").stacks):
            if random.randint(1, 100) + user.luck >= enemy.luck + 35:
                Rupture.inflict(enemy, 1, 1)
passive_dimensional_master = PlayerSkill("Dimensional Master", [PASSIVE], 0, 0,
                                         "If a Thunder/Mighty element skill is used, for every stack of Keen present, chance to inflict 1 stack of Rupture (with 1 count). If Rift Master is equipped, the passive's effect will not work.")
passive_dimensional_master.passive = types.MethodType(dimensional_master_passive, passive_dimensional_master)

def rift_master_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if any(s.name == "Rupture" for s in enemy.statusList) and user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and not any(s.name == "Dimensional Master" for s in user.skills):
        rupture = next(s for s in enemy.statusList if s.name == "Rupture")
        Rupture.inflict(enemy, 0, 1)
        
        dam = round(rupture.stacks + user.strength * 1.25 + user.hit * 0.25)
        enemy.health -= dam
        say(f"{Color['red']}{user.name} Dealt {dam} To {enemy.name}s Health!{Color['reset']}")
passive_rift_master = PlayerSkill("Rift Master", [PASSIVE], 0, 0,
                                  "If Rupture is present on the opposer and a damaging skill was used, increase Rupture's count by 1 and deal damage (stacks of Rupture present on the opposer + 125% of Strength + 25% of Hit). If Dimensional Master is equipped, the passive's effect will not work.")
passive_rift_master.passive = types.MethodType(rift_master_passive, passive_rift_master)

def double_up_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Wait":
        chance = 0.05
        for i in range(0, user.luck, 10):
            chance += 0.05
            if chance >= 0.6:
                break
        
        for status in enemy.statusList:
            if status.align == "Negative" and status.canStack:
                if chance > random.random():
                    status.inflict(enemy, 1, 1)
passive_double_up = PlayerSkill("Double Up", [PASSIVE], 0, 0,
                                "If Wait is used, for each Negative status that stacks present on the opposer, at a chance of 5% + 5% per 10 points of Luck (max 60%), inflict 1 stack of the status (with 2 count (if applicable)).")
passive_double_up.passive = types.MethodType(double_up_passive, passive_double_up)

def pacifist_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    restore = round(user.maxHealth * 0.01 + min(10, enemy.actions)) * 2
    user.health += min(restore, user.maxHealth - user.health)
    say(f"{Color['green']}{user.name}s Health Was Restored By {restore}!{Color['reset']}")
passive_pacifist = PlayerSkill("Pacifist", [PASSIVE], 0, 0,
                               "Restore health (1% of Max Health + enemy actions (max 10)) x 2 each action.")
passive_pacifist.passive = types.MethodType(pacifist_passive, passive_pacifist)

def battle_nurse_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.actions == 1:
        self.tracker = 0
    
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Healing" in user.lastSkill.type_:
        self.tracker += damage # This is Heal
    
    if user.actions % 5 == 0:
        user.health += min(self.tracker * 0.3, user.maxHealth - user.health)
        say(f"{Color['green']}{user.name}s Health Was Restored By {self.tracker * 0.3}!{Color['reset']}")
    
        if user.actions % 10 == 0:
            self.tracker = 0
passive_battle_nurse = PlayerSkill("Battle Nurse", [PASSIVE], 0, 0,
                                   "Track amount of health restored by healing skills (non-conditional). Every 5th user action, restore health (30% of total healing). Tracked total is reset every 10th user action after healing.")
passive_battle_nurse.passive = types.MethodType(battle_nurse_passive, passive_battle_nurse); passive_battle_nurse.tracker = 0

def fafnirs_crest_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    for status in enemy.statusList:
        if status.family == "Burn" and status.canStack:
            status.inflict(enemy)
            
            for i in range(0, status.stacks):
                dam = round(enemy.maxHealth * 0.01)
                enemy.health -= dam
                say(f"{Color['red']}{user.name} Dealt {dam} To {enemy.name}s Health!{Color['reset']}")
passive_fafnirs_crest = PlayerSkill("Fafnir's Crest", [PASSIVE], 0, 0,
                                    "For each Burn status on the opposer, if it stacks, inflict 1 stack of the status. For each stack of a stackable Burn status present on the opposer, deal damage (1% of opposers Max Health).")
passive_fafnirs_crest.passive = types.MethodType(fafnirs_crest_passive, passive_fafnirs_crest)

def nuclear_aura_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "fire":
        Scorch.inflict(enemy)
    
    for status in enemy.statusList:
        if status.family == "Burn" and status.name != "Scorch":
            status.duration -= 1
            say(f"{Color['green']}{status.name}s Duration Was Extended By 1!{Color['reset']}")
            
            dam = round(enemy.maxHealth * 0.01)
            enemy.health -= dam
            say(f"{Color['red']}{user.name} Dealt {dam} To {enemy.name}s Health!{Color['reset']}")
passive_nuclear_aura = PlayerSkill("Nuclear Aura", [PASSIVE], 0, 0,
                                   "If a Fire element skill is used, inflict Scorch. For each Burn status present on the opposer (excluding Scorch), reduce the statuses duration by 1 and deal damage (1% of Max Health).")
passive_nuclear_aura.passive = types.MethodType(nuclear_aura_passive, passive_nuclear_aura)

def bird_cage_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    for status in enemy.statusList:
        if enemy.ultimateMeter > 0:
            if status.name == "Bind II":
                enemy.ultimateMeter -= 20
                say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Reduced By 20!{Color['reset']}")
            
            elif status.name == "Bind I":
                enemy.ultimateMeter -= 10
                say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Reduced By 10!{Color['reset']}")
    
    if enemy.ultimateMeter <= 0:
        enemy.speedMeter -= 10
        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Reduced By 10!{Color['reset']}")
passive_bird_cage = PlayerSkill("Bird Cage", [PASSIVE], 0, 0,
                                "If Bind I/Bind II status is present on the opposer, lower opposers Ultimate Meter by 10/20. If opposers Ultimate Meter is at 0, lower opposers Speed Meter by 10.")
passive_bird_cage.passive = types.MethodType(bird_cage_passive, passive_bird_cage)

def out_pace_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element in ["ice", "physical"]:
        if random.randint(1, 100) + user.luck >= enemy.luck + 35:
            SlowII.inflict(enemy)
        
    if any("Slow" in s.name for s in enemy.statusList):
        user.speedMeter += 15
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
passive_out_pace = PlayerSkill("Out Pace", [PASSIVE], 0, 0,
                               "If a Ice/Physical element skill is used, chance to inflict Slow II. If any Slow status is present on the opposer, raise Speed Meter by 15.")
passive_out_pace.passive = types.MethodType(out_pace_passive, passive_out_pace)

def basilisk_eye_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Wait" and sum(1 for s in enemy.statusList if s.align == "Negative" and s.family == "Mental") >= 3 and enemy.sanity <= -15:
        Burnout.inflict(enemy)
passive_basilisk_eye = PlayerSkill("Basilisk Eye", [PASSIVE], 0, 0,
                                   "If Wait is used, 3+ Negative Mental statuses are present on the opposer, and their sanity is below -15, inflict Burnout.")
passive_basilisk_eye.passive = types.MethodType(basilisk_eye_passive, passive_basilisk_eye)

def christmas_bells_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "ice" and sum(1 for s in enemy.statusList if s.family == "Chill") >= 3:
        if random.randint(1, 100) + user.luck >= enemy.luck + 35:
            DeepFreeze.inflict(enemy)
            
    elif user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "fire" and sum(1 for s in enemy.statusList if s.family == "Chill") >= 3:
        for i in range(0, 3):
            next(s for s in enemy.statusList if s.family == "Chill").remove(user, full=True)
            
        dam = round(user.magic * 2)
        enemy.health -= dam
        say(f"{Color['red']}{user.name} Dealt {dam} To {enemy.name}s Health!{Color['reset']}")
passive_christmas_bells = PlayerSkill("Christmas Bells", [PASSIVE], 0, 0,
                                      "If a Ice element skill is used and 3+ Chill statuses are present on the opposer, chance to inflict Deep Freeze. If a Fire element skill is used and 3+ Chill statuses are present on the opposer, remove 3 Chill statuses and deal damage (200% of Magic).")
passive_christmas_bells.passive = types.MethodType(christmas_bells_passive, passive_christmas_bells)

def energizer_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "thunder":
        for status in user.statusList[:]:
            if status.family == "Shock" and status.canStack:
                status.inflict(user)
passive_energizer = PlayerSkill("Energizer", [PASSIVE], 0, 0,
                                "If a Thunder element skill is used, for each Shock status that stacks that is present, gain 1 stack of the status.")
passive_energizer.passive = types.MethodType(energizer_passive, passive_energizer)

def castle_cannons_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if (user.lastAction and user.lastAction == "Wait" 
        and 
        enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_):
        GuardP.inflict(user)
        
        dam = round(user.strength * 1.5)
        enemy.health -= dam
        say(f"{Color['red']}{user.name} Dealt {dam} To {enemy.name}s Health!{Color['reset']}")
    
    if (user.lastAction and user.lastAction == "Wait" 
        and not
        (enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_)):
        FrailIII.inflict(user)
passive_castle_cannons = PlayerSkill("Castle Cannons", [PASSIVE], 0, 0,
                                     "If Wait is used and opposers last action was a damaging skill, gain Guard. P and deal damage (150% of Strength). If Wait is used and opposers last action was not a damaging skill, gain Frail III.")
passive_castle_cannons.passive = types.MethodType(castle_cannons_passive, passive_castle_cannons)

def gloomy_mood_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
   if user.sanity <= -15 and any(s.name == "Sinking" and s.stacks >= 2 for s in enemy.statusList) and not any(s.name == "Gloom" for s in enemy.statusList):
       Gloom.inflict(enemy)
passive_gloomy_mood = PlayerSkill("Gloomy Mood", [PASSIVE], 0, 0,
                                  "If sanity is below -15 and opposer has 2+ stacks of Sinking present, inflict Gloom (only if not present).")
passive_gloomy_mood.passive = types.MethodType(gloomy_mood_passive, passive_gloomy_mood)

def downtrodden_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    for status in user.statusList[:]:
        if status.align == "Negative":
            user.sanity -= 3
    
    if user.sanity <= -20:
        ToughII.inflict(user, 2)
        Regen.inflict(user)
        
        user.speedMeter += 50
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 50!{Color['reset']}")
        user.sanity += 25
passive_downtrodden = PlayerSkill("Downtrodden", [PASSIVE], 0, 0,
                                  "For every Negative status present, lose 3 sanity. If sanity is below -20, gain 2 stacks of Tough II/Regen, raise Speed Meter by 50, and gain 25 sanity.")
passive_downtrodden.passive = types.MethodType(downtrodden_passive, passive_downtrodden)

def dirty_strikes_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Attack":
        bleed = 0
        poison = 0
        for status in enemy.statusList[:]:
            if status.family == "Bleed":
                if random.randint(1, 100) >= 50 and bleed < 2:
                    if "Special" not in status.type_:
                        status.simple(enemy)
                    else:
                        status.special(enemy)
                    bleed += 1

            if status.family == "Poison":
                if random.randint(1, 100) >= 50 and poison < 2:
                    if "Special" not in status.type_:
                        status.simple(enemy)
                    else:
                        status.special(enemy)
                    poison += 1
passive_dirty_strikes = PlayerSkill("Dirty Strikes", [PASSIVE], 0, 0,
                                  "If an attack is used, chance to retrigger 1-2 Bleed/Poison statuses (indivisual).")
passive_dirty_strikes.passive = types.MethodType(dirty_strikes_passive, passive_dirty_strikes)

def great_echo_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if enemy.lastAction and (enemy.lastAction == "Attack" or enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_) and any(s.name in ["Bind II", "Cripple II"] for s in enemy.statusList):
        if random.randint(1, 100) + user.luck >= enemy.luck + 35:
            Burnout.inflict(enemy)
passive_great_echo = PlayerSkill("Great Echo", [PASSIVE], 0, 0,
                                  "If an attack or damaging skill was used by the opposer last action and either Bind II or Cripple II is present on the opposer, 6% chance to inflict Burnout.")
passive_great_echo.passive = types.MethodType(great_echo_passive, passive_great_echo)

def headstart_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.actions == 1:
        user.sanity += 15
        Overload.inflict(user, 3)
passive_headstart = PlayerSkill("Headstart", [PASSIVE], 0, 0,
                                "After the 1st action of the user, gain 15 sanity and 3 stacks of Overload")
passive_headstart.passive = types.MethodType(headstart_passive, passive_headstart)

def close_combatant_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_ and user.lastSkill.element == "physical":
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
        
        enemy.speedMeter -= 15
        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Lowered By 15!{Color['reset']}")
passive_close_combatant = PlayerSkill("Close Combatant", [PASSIVE], 0, 0,
                                      "If a Physical skill is used, raise Speed Meter by 25 and lower opposers Speed Meter by 15.")
passive_close_combatant.passive = types.MethodType(close_combatant_passive, passive_close_combatant)

def warp_train_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    rupture = next((s for s in enemy.statusList if s.name == "Rupture"), None)
    if rupture:
        for i in range(1, rupture.stacks):
            if random.randint(1,100) >= 50:
                rai = random.randint(1,25)
                user.speedMeter += rai
                say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By {rai}!{Color['reset']}")
            else:
                rai = random.randint(-10,-1)
                user.speedMeter += rai
                say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By {rai}!{Color['reset']}")
passive_warp_train = PlayerSkill("Warp Train", [PASSIVE], 0, 0,
                                  "If opposer has Rupture, for each stack on the opposer, either; raise Speed Meter by 1-25 or lower 1-10 Speed Meter.")
passive_warp_train.passive = types.MethodType(warp_train_passive, passive_warp_train)

def warp_strike_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Attack" and any(s.name == "Rupture" for s in enemy.statusList):
        user.attackHits = 6
        Rupture.inflict(enemy, 1, 3)
passive_warp_strike = PlayerSkill("Warp Strike", [PASSIVE], 0, 0,
                                  "If an attack is used and Rupture is present on the opposer treat attack as if 6 hits were done for statuses and inflict Rupture (with 3 count).")
passive_warp_strike.passive = types.MethodType(warp_strike_passive, passive_warp_strike)

def charge_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Wait":
        FullPower.inflict(user)
        user.speedMeter -= 30
        say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By 30!{Color['reset']}")
passive_charge = PlayerSkill("Charge", [PASSIVE], 0, 0,
                             "If wait is used, lower Speed Meter by 30 and gain Full Power.")
passive_charge.passive = types.MethodType(charge_passive, passive_charge)

def cleanup_demonstration_passive(self, user: Player, enemy: Enemy, damage=0):
    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    rupture = next((s for s in enemy.statusList if s.name == "Rupture"), None)
    if charge and rupture and charge.stacks  >= 10 and rupture.stacks >= 10:
        charge.remove(user, 2)
        damage = round(enemy.maxHealth * 0.02 * (rupture.stacks / 2))
        enemy.health -= damage
        say(f"{Color['red']}{enemy.name} Took {damage} Health Damage!{Color['reset']}")  
passive_cleanup_demonstration = PlayerSkill("Cleanup Demonstration", [PASSIVE], 00, 00,
                                            "If Charge is present and at 2+ stacks and Rupture is present on the opposer and at 10+ stacks, lose 2 stacks of Charge and deal damage (2% of opposers Max Health x (stacks of Rupture / 2)).")
passive_cleanup_demonstration.passive = types.MethodType(cleanup_demonstration_passive, passive_cleanup_demonstration)

def speculum_passive(self, user: Player, enemy: Enemy, damage=0):
    if any(s.name == "Rupture" for s in enemy.statusList):
        Rupture.inflict(enemy, 2)

        if any(s.name == "Rupture" and s.stacks >= 10 for s in enemy.statusList):
            FrailII.inflict(enemy)
passive_speculum = PlayerSkill("Speculum", [PASSIVE], 0, 0,
                                "If Rupture is present on the opposer, inflict 2 stacks of Rupture (with 2 count) and if Rupture is at 10+ stacks, inflict Frail II.")
passive_speculum.passive = types.MethodType(speculum_passive, passive_speculum)

def central_energy_passive(self, user: Player, enemy: Enemy, damage=0):
    deathrite = next((s for s in enemy.statusList if "Deathrite" in s.name), None)
    if deathrite and deathrite.count != 1:
        deathrite.remove(enemy)
        Rupture.inflict(enemy, 2, 2)
        Shell.inflict(user, 2)
passive_central_energy = PlayerSkill("Central Energy", [PASSIVE], 0, 0,
                                     "If any Deathrite statuses are present on the opposer and has been active for more than 1 action, opposer loses 1 stack of the status, inflict 2 stacks of Rupture (with 2 count), and gain 2 stacks of Shell.")
passive_central_energy.passive = types.MethodType(central_energy_passive, passive_central_energy)

def rain_tears_passive(self, user: Player, enemy: Enemy, damage=0):
    sinking = next((s for s in enemy.statusList if s.name == "Sinking"), None)
    if sinking:
        user.sanity -= sinking.stacks * 2
        sinking.remove(user)

    negatives = sum(1 for s in user.statusList if s.align == "Negative" and s.family == "Mental")
    if negatives >= 4:
        Protection.inflict(user, 2)
passive_rain_tears = PlayerSkill("Rain of Tears", [PASSIVE], 00, 00,
                                 "If Sinking is present on the opposer, lose (stacks of Sinking x 2) sanity and opposer loses 1 stack of Sinking. If 4+ Negative Mental statuses are present, gain 2 stack of Protection.")
passive_rain_tears.passive = types.MethodType(rain_tears_passive, passive_rain_tears)

def legerdemain_passive(self, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Attack":
        enemy.sanity -= 3
        Maggots.inflict(enemy)
        Rot.inflict(enemy)
passive_legerdemain = PlayerSkill("Legerdemain", [PASSIVE], 00, 00,
                                  "If attack is used, opposer loses 3 sanity and inflict Maggot/Rot.")
passive_legerdemain.passive = types.MethodType(legerdemain_passive, passive_legerdemain)

def hard_headed_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill":
        if user.lastSkill.recoil:
            heal = round((damage * (user.lastSkill.recoil[1] / 100)) * 0.5)
            user.health = min(user.maxHealth, user.health + heal)
            say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")

            if random.randint(1, 100) >= 55:
                Power.inflict(user, 3)
passive_hard_headed = PlayerSkill("Hard Headed", [PASSIVE], 00, 00,
                                  "If a recoil skill is used, restore health (50% of recoil) and chance to gain 3 stacks of Power.")
passive_hard_headed.passive = types.MethodType(hard_headed_passive, passive_hard_headed)

def reckless_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.actions == 1:
        self.tracker = 0

    if self.tracker > 5:
        self.tracker = 5

    if user.lastAction and user.lastAction == "Skill":
        if user.lastSkill.recoil:
            self.tracker += 1
            damage = (20 + random.randint(1,15))
            user.health -= damage
            say(f"{Color['red']}{user.name} Took {damage} Health Damage!{Color['reset']}") 
            Power.inflict(user, 2)

    if self.tracker >= 10:
        BoostIII.inflict(user)
        self.tracker = 0
passive_reckless = PlayerSkill("Reckless", [PASSIVE], 00, 00,
                               "Track total number of recoil skills used (max 5). If a recoil skill is used, deal damage (20 + 1-15) to self and 2 stacks of Power. If 5 recoil skills are used, gain Boost III and reset tracker.")
passive_reckless.passive = types.MethodType(reckless_passive, passive_reckless); passive_reckless.tracker = 0

def iron_head_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill":
        if user.lastSkill.recoil:
            ToughII.inflict(user)

    if any(s.name == "Tough II" and s.stacks >= s.maxStack for s in user.statusList):
        Protection.inflict(user)
passive_iron_head = PlayerSkill("Iron Head", [PASSIVE], 00, 00,
                                "If a recoil skill is used, gain 1 stack of Tough II. If Tough II is present and at max stacks, gain 1 stack of Protection.")
passive_iron_head.passive = types.MethodType(iron_head_passive, passive_iron_head)

def cling_on_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.actions == 1:
        self.trigger = False

    if user.lastAction and user.lastAction == "Skill" and not self.trigger:
        if user.lastSkill.recoil and isinstance(damage, int):
            if user.health <= 0:
                user.health = round(user.maxHealth * 0.5)
                say(f"{Color['green']}{user.name}s Health Was Restored By {round(user.maxHealth * 0.5)}!{Color['reset']}")
                self.trigger = True
passive_cling_on = PlayerSkill("Cling On", [PASSIVE], 00, 00,
                                "If a recoil skill is used and the recoil would reduce health to 0, restore health (50% of Max Health) (once).")
passive_cling_on.passive = types.MethodType(cling_on_passive, passive_cling_on); passive_cling_on.trigger = None

def street_brawler_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.health <= round(user.maxHealth * 0.45) and sum(1 for s in user.skills if s.recoil) >= 2:
        Might.inflict(user, 2)
    
    if user.lastAction == "Skill" and user.lastSkill.element is not None and user.lastSkll.element == "physical":
        Power.inflict(user, 3)
passive_street_brawler = PlayerSkill("Street Brawler", [PASSIVE], 0, 0,
                                     "If health is below 45% and 2+ recoil skills are equipped, gain 2 stacks of Might. If a Physical element skill is used, gain 3 stacks of Power.")
passive_street_brawler.passive = types.MethodType(street_brawler_passive, passive_street_brawler)

def swimmer_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    for status in user.statusList[:]:
        if status.name in ["Sinking", "Gloom", "Deluge", "Butterfly"]:
            user.speedMeter += 5
            say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 5!{Color['reset']}")
passive_swimmer = PlayerSkill("Swimmer", [PASSIVE], 0, 0,
                              "For any Sinking adjacent status present, raise Speed Meter by 5 and decrease damage taken from the status (35%!). ")

def kai_body_passive(self: PlayerSkill, user: Player, enemy: Enemy, damage=0):
    if user.lastAction and user.lastAction == "Skill":
        if user.lastSkill.element == "mighty":
            Charge.inflict(user)
            Boon.inflict(user)

    if user.health <= round(user.maxHealth * 0.6):
        Rejuvenate.inflict(user, 3)
passive_kai_body = PlayerSkill("Kai Body", [PASSIVE], 00, 00,
                               "If a Mighty element skill is used, gain Charge/Boon. If health is below 60%, gain 3 stacks of Rejuvenate.")
passive_kai_body.passive = types.MethodType(kai_body_passive, passive_kai_body)

##------------Enemy Basic Skills------------##

def cleanse_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")

    if len(user.statusList) > 0:
        statuses = user.statusList[:]
        random.shuffle(statuses)
        canRemove = []
        for status in statuses[:]:
            if status.align == "Negative":
                canRemove.append(status)
        
        if len(canRemove) > 0:
            for i in range(min(random.randint(1, 2), len(canRemove))):
                idx = random.randint(0, len(canRemove) - 1)
                removed = canRemove.pop(idx)

                removed.remove(user, full=True)
        else:
            say("Nothing Happened")
    else:
        say("Nothing Happened")
eskill_cleanse = EnemySkill("Cleanse", [SPECIAL],
                      f"Remove 1-2 Negative statuses.",
                      weight=8, customEffect=cleanse_effect, 
                      condition=lambda enemy, target: sum(1 for s in enemy.statusList if s.align == "Negative") > 1)

eskill_recharge = EnemySkill("Recharge", [HEAL],
                      f"Restore Health (50% of Magic + 50% of Resistance). Gain Boost II.",
                      weight=10, status=[BoostI], statusTarget="user", statsUsed=[[("magic", 50), ("resistance", 50)], "health"], 
                      condition= lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.30) or any(status.align == "Negative" for status in enemy.statusList))

eskill_exhaust = EnemySkill("Exhaust", [STATUS],
                      f"Gain Overload/Burn/Static.",
                      weight=8, status=[Overload, Burn, Static], statusTarget="user",
                      condition=lambda enemy, target: enemy.speed + 10 <= target.speed)

eskill_warm_up = EnemySkill("Warm Up", [STATUS],
                      f"Gain Shock.",
                      weight=8, opener=True, status=[Shock], stacks=1, statusTarget="user" ,
                      condition=lambda enemy, target: enemy.speed <= target.speed)

eskill_harden_i = EnemySkill("Harden I", [STATUS],
                      f"Gain Tough I.",
                      weight=8, opener=True, status=[ToughI], stacks=1, statusTarget="user", 
                      condition=lambda enemy, target: enemy.defense <= enemy.baseDefense)

eskill_harden_ii = EnemySkill("Harden II", [STATUS],
                      f"Gain Tough II.",
                      weight=8, opener=True, status=[ToughII], stacks=1, statusTarget="user", 
                      condition=lambda enemy, target: enemy.defense <= enemy.baseDefense)

eskill_counter_stance = EnemySkill("Counter Stance", [STATUS],
                      f"Gain Counter.",
                      weight=8, opener=True, status=[Counter], stacks=1, statusTarget="user")

def consume_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    sanity = 0
    count = 0
    
    for status in user.statusList[:]:
        if status.align == "Negative":
            sanity += 2
            count += 1
            status.remove(user, full=True)
            ToughI.inflict(user)
            
    user.sanity += sanity
    say(f"{Color['yellow']}{user.name} Gained {sanity} Sanity!{Color['reset']}")
    
    if count >= 3:
        BoostII.inflict(user)
eskill_consume = EnemySkill("Consume", [SPECIAL], 
                            "Only usable when a Negative status is present. For each Negative status, remove it, gain 2 sanity, gain 1 stack of Tough I, and gain Boost II (if 3+ Negative statuses are present).",
                            weight=8, customEffect=consume_effect, conditional=lambda enemy, target: sum(1 for s in enemy.statusList if s.align == "Negative") >= 2,
                            weightConditional=lambda enemy, target, actions=1: sum(1 for s in enemy.statusList if s.align == "Negative") >= 2)

eskill_burning_whirl = EnemySkill("Burning Whirl", [DAMAGE, [MULTI, 3]],
                       f"Magic vs. Resistance x 3. Chance to inflict 2 stacks of Burn.",
                       weight=12, hit=50, critical=30, element="fire", status=[Burn], stacks=2, statsUsed=["magic", "resistance", 1.5])

def chant_of_fire_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    if (self.hit + (user.hit * 0.5)) >= random.randint(1, 100):
        for status in target.statusList:
            if status.name == "Burn":
                for i in range(2):
                    status.simple(target)
                
                status.duration -= 1
                Heated.inflict(target)
                break
        else:
            Burn.inflict(target)
    else:
        say(f"It Missed!")
eskill_chant_of_fire = EnemySkill("Chant of Fire", [SPECIAL],
                      f"If Burn is present on the opposer, inflict Heated, trigger Burn 2 times and extend its duration by 1, else inflict Burn.",
                      weight=5, hit=50, statusTarget="target", 
                      condition=lambda enemy, target: any(s.name == "Burn" for s in target.statusList), customEffect=chant_of_fire_effect)

def icy_aura_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Freeze" == s.name for s in target.statusList):
        damage *= 2

        if random.randint(1, 100) >= 65:
            AbsoluteZero.inflict(target)
    return damage
eskill_icy_aura = EnemySkill("Icy Aura", [DAMAGE],
                      f"Magic vs. Resistance. Increased damage (2x!) if opposer has Freeze. Chance to inflict Frostbite/Absolute Zero.",
                      weight=15, hit=100, critical=10, element="ice", status=[Frostbite, AbsoluteZero], statsUsed=["magic", "resistance", 2],
                      condition= lambda enemy, target: any("Chill" == s.family for s in target.statusList), conditional=icy_aura_conditional)

eskill_snow_storm = EnemySkill("Snow Storm", [DAMAGE, [MULTI, HITS(4,6)]],
                       f"Magic vs. Resistance x 4-6. Chance to inflict Frostbite/Deep Freeze/Freeze.",
                       weight=10, hit=80, critical=20, element="ice", status=[[Frostbite, Freeze], [DeepFreeze, Freeze], Freeze], statsUsed=["magic", "resistance", 1.5])

eskill_ice_shard = EnemySkill("Ice Shard", [DAMAGE],
                      f"Magic vs. Resistance. Chance to inflict Bleed/Ice Veins.",
                      weight=13, hit=80, critical=65, element="ice", status=[Bleed, IceVeins], statsUsed=["magic", "resistance", 2])

eskill_wild_storm = EnemySkill("Wild Storm", [DAMAGE, [MULTI, HITS(3,4)]],
                       f"Magic vs. Resistance x 3-4. Chance to gain 2 stack of Shock/Static.",
                       weight=10, hit=70, critical=50, element="thunder", status=[Shock, Static], stacks=2, statusTarget="user", statsUsed=["magic", "resistance", 1.5])

eskill_thunderous_roar = EnemySkill("Thunderous Roar", [DAMAGE, [MULTI, HITS(1,5)]],
                       f"Magic vs. Resistance x 1-5. Chance to inflict 3 Spark/Static/Frail II.",
                       weight=14, hit=85, critical=120, element="thunder", status=[Spark, Static], stacks=3, statsUsed=["magic", "resistance", 1.5])

eskill_wild_thungerga = EnemySkill("Wild Thungerga", [DAMAGE, [MULTI, 3]],
                              "Magic vs. Resistance x 3. Chance to inflict 2 stacks of Burn/Spark/Slow II.",
                              weight=12, hit=65, critical=120, element="thunder", status=[Burn, Spark, SlowII], stacks=2, statsUsed=["magic", "resistance", 2])

def aura_strike_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 5
    percent = 0
    for i in range(0, user.sanity, 2):
        percent += 0.02
    percent = min(percent, 0.50)
    if percent:
        damage += round(damage * percent)
    return damage
eskill_aura_strike = EnemySkill("Aura Strike", [DAMAGE], 
                                "Magic vs. Resistance. Increase damage (5% per 2 sanity). Gain 5 sanity. Will inflict Sinking.",
                                weight=13, hit=80, critical=90, element="mighty", status=[Sinking], willStatus=True, statsUsed=["magic", "resistance", 2],
                                conditional=aura_strike_conditional)

eskill_rundown = EnemySkill("Rundown", [DAMAGE, [MULTI, 2]],
                       f"Strength vs. Defense x 2. Chance to inflict Break.",
                      weight=13, hit=80, critical=80, element="physical", status=[Break], statsUsed=["strength", "defense", 1.5])

eskill_serration = EnemySkill("Serration", [DAMAGE, [MULTI, lambda : random.randint(1,3)]], 
                      f"Strength vs. Defense x 1-3. Chance to inflict Bleed/Gash.",
                      weight=15, hit=80, critical=80, element="physical", status=[Bleed, Gash], statsUsed=["strength", "defense", 1.5])

def prideful_slash_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in user.statusList[:]:
            if status.align == "Positive":
                damage += round(damage * 0.05)

    return damage
eskill_prideful_slash = EnemySkill("Prideful  Slash", [DAMAGE],
                       f"Strength vs. Defense. Increased damage (5%!) for every Positive status. Chance to inflict Bleed.",
                       weight=12, hit=100, critical=100, element="physical", status=[Bleed], statsUsed=["strength", "defense", 2], 
                       conditional=prideful_slash_conditional)

eskill_rough_housing = EnemySkill("Rough Housing", [DAMAGE, [MULTI, HITS(2,4)]],
                       f"Strength vs. Defense x 2-4. Chance to inflict Muddy/Gash/Venom.",
                       weight=12, hit=70, critical=50, element="physical", status=[[Muddy, Gash], [Muddy, Venom], Gash, Venom], statsUsed=["strength", "defense", 1.8])

eskill_surprise_gift = EnemySkill("Surprise Gift", [DAMAGE, [MULTI, lambda : random.randint(2,3)]],
                      f"Magic vs. Resistance. Chance to inflict Poison/Venom/Plague.",
                      weight=15, hit=65, critical=30, element="mighty", status=[[Plague, Poison], [Venom, Poison], Poison], statsUsed=["magic", "resistance", 1.5],
                      condition=lambda enemy, target: not any("Poison" == s.family for s in target.statusList))

def earthen_chains_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if target.health < round(target.maxHealth * 0.65):
        Break.inflict(target)
        Gash.inflict(target)
    return damage
eskill_earthen_chains = EnemySkill("Earthen Chains", [DAMAGE, [MULTI, 2]],
                                   "Magic vs. Resistance x 2. If opposers health is below 65%, inflict Break/Gash. Will inflict Bind II.",
                                   weight=11, hit=90, critical=50, element="mighty", status=[BindII], willStatus=True, statsUsed=["magic", "resistance", 2],
                                   conditional=earthen_chains_conditional)

eskill_mana_leech = EnemySkill("Mana Leech", [DAMAGE], 
                      f"Magic vs. Resistance. Targets Mana. Restores health (25% of damage dealt). Chance to inflict Husk.",
                      weight=7, hit=65, critical=20, element="mighty", status=[Husk], statsUsed=["magic", "resistance", 1.3],
                      meterDamage="mana", damHeal=0.25, meter="health",
                      condition=lambda enemy, target: target.mana <= round(target.maxMana * 0.50))

eskill_health_leech = EnemySkill("Health Leech", [DAMAGE], 
                      f"Magic vs. Resistance. Restores health (25% of damage dealt). If Boost I is present on user, gain Boost II. Chance to gain Boost I.",
                      weight=8, hit=65, critical=20, element="mighty", status=[[BoostII, BoostI], BoostI], statusTarget="user", statsUsed=["magic", "resistance", 1.3],
                      meterDamage="health", damHeal=0.25, meter="health",
                      condition=lambda enemy, target: target.health <= round(target.maxHealth * 0.50))

def power_charge_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    user.ultimateMeter += self.statsUsed
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Increased By {self.statsUsed}!{Color['reset']}")
eskill_power_charge_I = EnemySkill("Power Charge I", [SPECIAL],
                                   f"Increase Ultimate Meter By 10.",
                                   statsUsed= 10, weight=6, customEffect=power_charge_effect,
                                   condition=lambda user, target: user.ultimateMeter <= 45)

eskill_power_charge_II = EnemySkill("Power Charge II", [SPECIAL],
                                   f"Increase Ultimate Meter By 20.",
                                   statsUsed= 20, weight=6, customEffect=power_charge_effect,
                                   condition=lambda user, target: user.ultimateMeter <= 45)

eskill_power_charge_III = EnemySkill("Power Charge III", [SPECIAL],
                                   f"Increase Ultimate Meter By 30.",
                                   statsUsed= 30, weight=10, customEffect=power_charge_effect,
                                   condition=lambda user, target: user.ultimateMeter <= 45)

eskill_power_charge_ex = EnemySkill("Power Charge Ex", [SPECIAL],
                                     f"Increase Ultimate Meter By 100.",
                                     statsUsed= 100, weight=11, customEffect=power_charge_effect,
                                     condition=lambda user, target: user.ultimateMeter <= 700)

def counter_strike_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Counter.inflict(user)
    if target.strength >= 28 or target.magic >= 28:
        SuperCounter.inflict(user)
    return damage
eskill_counter_strike = EnemySkill("Counter Strike", [DAMAGE],
                                   "Strength vs. Defense. If the opposers Strength or Magic are greater than 28, gain Super Counter. Gain Counter. Chance to inflict 5 stacks of Hemorrhage.",
                                   weight=12, hit=75, critical=90, element="physical", status=[Hemorrhage], stacks=5, statsUsed=["strength", "defense", 2],
                                   condition=lambda enemy, target: target.strength >= 28 or target.magic >= 28, conditional=counter_strike_conditional)

def moon_blade_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    target.sanity -= 5
    return damage
eskill_moon_blade = EnemySkill("Moon Blade", [DAMAGE], 
                               "Strength vs. Resistance. Opposer loses 5 sanity. Chance to inflict 2 stacks of Sinking.",
                               weight=11, hit=80, critical=80, element="ice", status=[Sinking], stacks=2, statsUsed=["strength", "resistance", 2],
                               condition=lambda enemy, target: target.sanity >= 0, conditional=moon_blade_conditional)

def punishing_blade_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    for i in range (len([s for s in target.statusList if s.align == "Negative" and "Damage" in s.type_])):
        percent += 0.05
    
    if percent:
        damage += round(damage * percent)
        
    count = 0
    for status in target.statusList[:]:
        if status.align == "Negative" and "Damage" in status.type_:
            if random.randint(1, 100) >= 50 and count < 2:
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target)
                count += 1
    return damage
eskill_punishing_blade = EnemySkill("Punishing Blade", [DAMAGE], 
                                    "Strength vs. Resistance. Increase damage (5% per Negative status present on the opposer). Chance to retrigger 1-2 damaging Negative statuses present on the opposer. Chance to inflict Sinking.",
                                    weight=10, finsher=True, hit=70, critical=80, element="mighty", status=[Sinking], statsUsed=["strength", "resistance", 1.5],
                                    condition=lambda enemy, target: len(target.statusList) >= 3, conditional=punishing_blade_conditional)

eskill_reckless_assault = EnemySkill("Reckless Assault", [DAMAGE, [MULTI, HITS(2,4)]],
                                     "Strength vs. Defense x 2-4. Will inflict Break/Gash/Clot. Take recoil (35% of damage).",
                                     weight=10, hit=65, critical=110, element="physical", status=[Break, Gash, Clot], willStatus=True, statsUsed=["strength", "defense", 1.8], recoil=[True, 35],
                                     condition=lambda enemy, target: enemy.health >= round(enemy.maxHealth * 0.75))

def upheaval_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Break" or "Bind" in s.name for s in target.statusList):
        damage *= 2
    return damage
eskill_upheaval = EnemySkill("Upheaval", [DAMAGE, [MULTI, HITS(1,5)]], 
                             "Strength vs. Defense x 1-5. If Break or any Bind statuses are present on the opposer, increase damage (2x!). Chance to inflict Break/Frail II.",
                             weight=11, hit=60, critical=125, element="mighty", status=[Break, FrailII], statsUsed=["strength", "defense", 1.8],
                             condition=lambda enemy, target: any(s.name == "Break" or "Bind" in s.name for s in target.statusList), conditional=upheaval_conditional)

eskill_red_cyclone = EnemySkill("Red Cyclone", [DAMAGE, [MULTI, HITS(2,3)]], 
                                "Strength vs. Defense x 2-3. Chance to inflict 3 stacks of Hemorrhage/Bleed/Cripple I.",
                                weight=12, hit=80, critical=100, element="physical", status=[Hemorrhage, Bleed, CrippleI], stacks=3, statsUsed=["strength", "defense", 1.5])

eskill_spliting_slash = EnemySkill("Spliting-Slash", [DAMAGE, [MULTI, 3]],
                                "Strength vs. Defense x 3. Will inflict Bind II/Split.",
                                weight=9, hit=75, critical=100, element="physical", status=[BindII, Split], willStatus=True, statsUsed=["strength", "defense", 2])

eskill_molten_cobble = EnemySkill("Molten Cobble", [DAMAGE, [MULTI, HITS(1,4)]],
                                  "Strength vs. Defense x 1-4. Chance to inflict 2 stacks of Heated/Molten.",
                                  weight=9, hit=80, critical=85, element="fire", status=[Heated, Molten], stacks=2, statsUsed=["strength", "defense", 1.7])

def head_hunter_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.hit + random.randint(1,40) >= 140:
        Shock.inflict(user, 2)
        Haze.inflict(user)
    return damage
eskill_head_hunter = EnemySkill("Head Hunter", [DAMAGE],
                                "Hit vs. Defense. If Hit + 1-40 is greater than 140, gain 2 stacks of Shock/Haze. Will inflict Slow II.",
                                weight=8, finsher=True, hit=90, critical=10, element="physical", status=[SlowII], willStatus=True, statsUsed=["hit", "defense", 1.5],
                                condition=lambda enemy, target: enemy.hit >= 80, conditional=head_hunter_conditional)

def head_shot_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.luck + random.randint(1,50) >= 150:
        Keen.inflict(user, 5)
        BoostII.inflict(user)
    return damage
eskill_head_shot = EnemySkill("Head Shot", [DAMAGE],
                                "Luck vs. Defense. If Luck + 1-50 is greater than 150, gain 5 stacks of Keen/Boost II. Will inflict Gash/Puncture.",
                                weight=8, opener=True, hit=45, critical=15, element="physical", status=[Gash, Puncture], willStatus=True, statsUsed=["luck", "defense", 1.5],
                                condition=lambda enemy, target: enemy.luck >= 90, conditional=head_shot_conditional)

def air_stasis_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Bind I" for s in target.statusList):
        BindII.inflict(target)
    return damage
eskill_air_stasis = EnemySkill("Air Stasis", [DAMAGE],
                               "Magic vs. Resistance. If Bind I is present on the opposer, inflict Bind II. Chance to inflict BInd I/Slow I/Cripple I.", 
                               weight=12, hit=75, critical=100, element="wind", status=[BindI, SlowI, CrippleI], statsUsed=["magic", "resistance", 2],
                               condition=lambda enemy, target: any("Bind I" == s.name for s in target.statusList), conditional=air_stasis_conditional)

def aqua_breath_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.family == "Shock" for s in target.statusList):
        CrippleII.inflict(target)
        damage *= 2
    return damage
eskill_aqua_breath = EnemySkill("Aqua Breath", [DAMAGE, [MULTI, HITS(2,3)]],
                                "Magic vs. Resistance x 2-3. If any Shock statuses are present on the opposer, inflict Cripple II and increase damage (2x!). Chance to inflict Freeze.",
                                weight=11, hit=80, critical=85, element="ice", status=[Freeze], statsUsed=["magic", "resistance", 1.5],
                                condition=lambda enemy, target: any("Shock" == s.family for s in target.statusList), conditional=aqua_breath_conditional)

def falling_hail_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    for status in target.statusList:
        if status.family == "Chill":
            percent += 0.05
    if percent:
        damage += round(damage * percent)
    return damage
eskill_falling_hail = EnemySkill("Falling Hail", [DAMAGE, [MULTI, HITS(2,7)]],
                                 "Magic vs. Resistance x 2-7. Increase damage (5% per Chill status present on the opposer). Chance to inflict 2 stacks of Frostbite/Absolute Zero.",
                                 weight=10, hit=65, critical=85, element="ice", status=[Frostbite, AbsoluteZero], stacks=2, statsUsed=["magic", "resistance", 1.5],
                                 condition=lambda enemy, target: any("Chill" == s.family  for s in target.statusList), conditional=falling_hail_conditional)

def cataclysm_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    target.sanity -= 4
    
    percent = 0
    for i in range(0, target.sanity, -5):
        percent += 0.05
    
    if percent:
        damage += round(damage * percent)
    return damage
eskill_cataclysm = EnemySkill("Cataclysm", [DAMAGE],
                              "Magic vs. Resistance. Increase damage (5% per 5 points of Negative sanity (opposer)). Opposer loses 4 sanity. Chance to inflict 2 stacks of Frostbite/Burn/Consumed.",
                              weight=11, finsher=True, hit=80, critical=135, element="mighty", status=[Frostbite, Burn, Consumed], stacks=3, statsUsed=["magic", "resistance", 2],
                              condition=lambda enemy, target: any("Negative" == s.align for s in target.statusList), conditional=cataclysm_conditional, sanLean="Negative")

eskill_voiding_beam = EnemySkill("Voiding Beam", [DAMAGE, [MULTI, HITS(3,6)]],
                                 "Magic vs. Resistance x 3-6. Chance to inflict Devoid/Poison/Plague/Blight. Take recoil (25% of damage).",
                                 weight=9, finsher=True, hit=70, critical=100, element="mighty", status=[Devoid, Poison, Plague, Blight], statsUsed=["magic", "resistance", 1.5], recoil=[True, 25])

def esuna_conditional(self, heal: int, user: Enemy, target: Player):
    count = 0
    for status in user.statusList[:]:
        if status.align == "Negative":
            status.remove(user, full=True)
            count += 1

        if count >= 2:
            break
        
    user.speedMeter += 25
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
    return heal
eskill_esuna = EnemySkill("Esuna", [HEAL],
                         "Restore health (25% of Max Health). Raise Speed Meter by 25. Chance to remove 1-2 Negative statuse.",
                          weight=7, statsUsed=[[("maxHealth", 25)], "health"],
                          condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.5), conditional=esuna_conditional)

def haste_conditional(self, user: Enemy, target: Player, actions=1):
    user.speedMeter += 25
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
eskill_haste = EnemySkill("Haste", [STATUS],
                          "Raise Speed Meter by 25. Gain 2 stacks of Burn/Energetic.",
                          weight=9, status=[Energetic, Burn], stacks=2, statusTarget="user", 
                          condition=lambda enemy, target: target.speed > enemy.speed, conditional=haste_conditional)

##------------Enemy Basic Passives------------##

def lucky_play_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill:
        chance = 0.1
        for i in range(0,  user.luck, 10):
            chance += 0.05
        
        if chance > random.random():
            user.lastSkill.effect(user, target, damage)
epassive_lucky_play = EnemySkill("Lucky Play", [PASSIVE],
                                 "If a skill is used, at a chance of 10% + 5% per 10 points of Luck, reuse skill.")
epassive_lucky_play.passive = types.MethodType(lucky_play_passive, epassive_lucky_play)

def experience_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.speed > user.speed:
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
epassive_experience  = EnemySkill("Experience", [PASSIVE],
                                 "If Speed is lower than opposers Speed, raise Speed Meter by 25.")
epassive_experience.passive = types.MethodType(experience_passive, epassive_experience)

def rift_espers_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and "Damage" in user.lastSkill.type_:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Rupture.inflict(target, random.randint(3,5), random.randint(2,4))
epassive_rift_espers = EnemySkill("Rift Espers", [PASSIVE],
                                  "If a damaging skill is used, chance to inflict 3-5 stacks of Rupture (with 2-4 count).")
epassive_rift_espers.passive = types.MethodType(rift_espers_passive, epassive_rift_espers)

def lock_down_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if self.usable:
        if user.health <= round(user.maxHealth * 0.4):
            user.baseDefense += 10
            user.baseResistance += 10

            Fix.statMutation(user)
            
            self.usable =  False
epassive_lock_down = EnemySkill("Lock Down", [PASSIVE],
                                "If health is below 40%, raise Defense/Resistance by 10 (permenant).")
epassive_lock_down.passive = types.MethodType(lock_down_passive, epassive_lock_down)

##------------Enemy Ultimate Skills------------##

uskill_aerial_collide = EnemySkill("Aerial Collide", [DAMAGE],
                        f"Strength vs. Defense. Chance to inflict Frail II/Break/Bleed. Take recoil (30% of damage).",
                        useType="Ultimate", weight=100, hit=65, critical=110, element="wind", status=[FrailII, Break, Bleed], statsUsed=["strength", "defense", 3], recoil=[True, 30])

uskill_charge_ii = EnemySkill("Charge II", [STATUS],
                      f"Gain 3 stacks Tough I/Boost II.",
                      useType="Ultimate", weight=100, status=[ToughI, BoostII], stacks=3, statusTarget="user")

uskill_festering_ripple = EnemySkill("Festering Ripple", [DAMAGE, [MULTI, HITS(3,5)]],
                        f"Magic vs. Resistance. Chance to inflict Venom/Plague/Rot.",
                        useType="Ultimate", weight=100, hit=50, critical=100, element="mighty", status=[[Venom, Poison], [Plague, Poison], [Rot, Poison]], statsUsed=["magic", "resistance", 2])

uskill_great_chrysalis = EnemySkill("Great Chrysalis", [HEAL],
                        f"Restore health (30% of Max Health). Gain Tough II.",
                        useType="Ultimate", weight=100, statsUsed=[[("maxHealth", 30)], "health"], status=[ToughII], statusTarget="user")

uskill_soul_piercing_stare = EnemySkill("Soul Piercing Stare", [STATUS],
                        f"Will inflict Deep Freeze/Husk.",
                        useType="Ultimate", weight=100, status=[DeepFreeze, Husk], statusTarget="target")

def spirit_stare_conditional(self, user: Enemy, target: Player, actions=1):
    user.ultimateMeter -= 35
    say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Reduced By 35!{Color['reset']}")
    
    target.sanity -= 10
uskill_spirit_stare = EnemySkill("Spirit Stare", [STATUS],
                        f"Will inflict Stun/Collapsing Husk. Lower Ultimate Meter by 35. Lower opposers sanity by 10.",
                        useType="Ultimate", weight=100, status=[Stun, CollapsingHusk], statusTarget="target",
                        conditional=spirit_stare_conditional)

def survival_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    missing = user.maxHealth - user.health
    damage += round((missing / user.maxHealth) * damage)
    return damage
uskill_survival = EnemySkill("Survival", [DAMAGE],
                        f"Strength vs. Defense. Increase damage (scales!) the lower Health the enemy has. Chance to inflict Gash/Clot.",
                        useType="Ultimate", weight=100, hit=110, critical=60, element="physical", status=[Gash, Clot], statsUsed=["strength", "defense", 3],
                        conditional=survival_conditional)

def high_surge_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Shock.inflict(user, 2)
    Energetic.inflict(user)
    return damage
uskill_high_surge = EnemySkill("High Surge", [DAMAGE, [MULTI, HITS(1,5)]],
                               "Magic vs. Resistance x 1-5. Gain 2 stacks of Shock/Energetic. Will inflict 2 stacks of Burn/Heated.",
                               useType="Ultimate", weight=100, hit=75, critical=100, element="thunder", status=[Burn, Heated], willStatus=True, stacks=2, statsUsed=["magic", "resistance", 2],
                               conditional=high_surge_conditional)

def soul_drain_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 10
    return damage
uskill_soul_drain = EnemySkill("Soul Drain", [DAMAGE],
                              "Magic vs. Resistance. Gain 10 sanity. Restore health (50% of damage dealt). Gain 2 stacks of Tough II/Regen.",
                              useType="Ultimate", weight=100, hit=65, critical=55, element="mighty", status=[ToughII, Regen], stacks=2, statusTarget="user", statsUsed=["magic", "resistance", 3], damHeal=0.50, meter="health",
                              conditional=soul_drain_conditional)

def set_back_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    target.speedMeter -= 100
    say(f"{Color['magenta']}{target.name}s Speed Meter Was Lowered By 100!{Color['reset']}")
    return damage
uskill_setback = EnemySkill("Set Back", [DAMAGE],
                              "Speed vs. Defense. Lowers opposers Speed Meter by 100. Chance to gain 2 stacks of Shock/Overload.",
                              useType="Ultimate", weight=100, hit=85, critical=100, element="thunder", status=[Shock, Overload], stacks=2, statusTarget="user", statsUsed=["speed", "defense", 2.5],
                              conditional=set_back_conditional)

uskill_lockout_chains = EnemySkill("Lockout Chains", [STATUS],
                                    f"Will inflict 3 stacks of Frostbite/Freeze/Burnout.",
                                    useType="Ultimate", weight=100, status=[Frostbite, Freeze, Burnout], stacks=3, willStatus=True, statusTarget="target")

def devils_bell_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    target.sanity -= 6
    return damage
uskill_devils_bell = EnemySkill("Devil's Bell", [DAMAGE, [MULTI, HITS(3,5)]],
                                "Magic vs. Resistance x 3-5. Lower opposers sanity by 6. Will inflict 5 stacks of Burn/Frostbite/Madness.",
                                useType="Ultimate", weight=100, hit=70, critical=85, element="fire", status=[Burn, Frostbite, Madness], stacks=3, statsUsed=["magic", "resistance", 2],
                                conditional=devils_bell_conditional, sanLean="Negative")

def wound_play_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    count = 0
    for status in target.statusList[:]:
        if "Damage" in status.type_:
            if "Special" not in status.type_:
                status.simple(target)
            else:
                status.special(target)
            count += 1
        if count >= 5:
            break
    return damage
uskill_wound_play = EnemySkill("Wound Play", [DAMAGE],
                               "Strength vs. Defense. Retrigger 1-5 damagining Negative statuses present on the opposer. Chance to inflict 3 stacks of Hemorrhage/Sinking.",
                               useType="Ultimate", weight=100, hit=70, critical=130, element="physical", status=[Hemorrhage, Sinking], stacks=3, statsUsed=["strength", "defense", 2.5],
                               conditional=wound_play_conditional)

##------------Special Enemy Skills------------##

def blue_cyclone_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Charge" for s in user.statusList):
        Charge.inflict(user)

        if user.speed >= 40:
            Haste.inflict(user)
    
    spark = next((s for s in target.statusList if s.name == "Spark"), None)
    static = next((s for s in target.statusList if s.name == "Static"), None)
    if spark and static:
        Arc.inflict(target)
        spark.duration = 0
        static.duration = 0
    
    Shock.inflict(user)
    return damage
spskill_blue_cyclone = EnemySkill("Blue Cyclone", [DAMAGE, [MULTI, HITS(1,4)]],
                                  "Strength vs. Defense x 1-4. If Charge is present, gain 1 stack of Charge, and if Speed is greater than 40, gain 1 stack of Haste. If Spark and Static are present on the opposer, inflict Arc and set both statuses duration to 0. Gain 1 stack of Shock. Chance to inflict 5 stacks of Spark/Static.",
                                  weight=18, hit=85, critical=90, element="thunder", status=[Spark, Static], stacks=5, statsUsed=["strength", "defense", 1.8],
                                  condition=lambda enemy, target: any(s.name == "Charge" for s in enemy.statusList) and enemy.speed >= 40 or any(s.name == "Spark" for s in target.statusList) and any(s.name == "Static" for s in target.statusList), conditional=blue_cyclone_conditional)

def spin_conditional(self, user: Enemy, target: Player, actions=1):
    if user.speed < target.speed:
        Charge.inflict(user, 2)
        Shock.inflict(user, 2)
    
    if any(s.name == "Charge" and s.stacks >= 8 for s in user.statusList):
        Haste.inflict(user)
spskill_spin = EnemySkill("Spin", [STATUS],
                          "Gain 2 stacks of Charge/Keen. If Speed is lower than opposers, gain 2 stacks of Charge/Shock. If Charge is present and at 8+ stacks, gain 2 stacks of Haste.",
                          weight=15, opener=True, status=[Charge, Keen], stacks=2, statusTarget="user",
                          condition=lambda enemy, target: enemy.speed < target.speed or any(s.name == "Charge" and s.stacks >= 8 for s in enemy.statusList), conditional=spin_conditional)

def blurring_rush_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if actions >= 15:
        damage = round(getattr(user, "speed") + random.randint(1, 5) - (getattr(target, self.statsUsed[1]) // 2)) * 2

        # Critical
        if "Critical" in strikes:
            damage *= 2

        # Precision
        totalHit = self.hit + (user.hit * 0.5)
        if "Precision" in strikes:
            overflow = max(0, totalHit - 50) 
            damage = round(damage * ((overflow * 0.20) / 10))
        
        if "Super Precision" in strikes:
            overflow = max(0, totalHit - 175)
            damage = round(damage * ((overflow  * 0.40) / 10))
    
    Charge.inflict(user)
    Might.inflict(user)
    return damage
spskill_blurring_rush = EnemySkill("Blurring Rush", [DAMAGE, [MULTI, HITS(1,5)]],
                                   "Strength vs. Defense x 1-5. If global actions is at 15+, use Speed instead of Strength. Gain 1 stack of Charge/Might. Chance to inflict 2 stacks of Slug/Super Break.",
                                   weight=14, finsher=True, hit=60, critical=125, element="thunder", status=[Slug, SuperBreak], stacks=2, statsUsed=["strength", "defense", 2.5],
                                   condition=lambda enemy, target: enemy.actions + target.actions >= 15, conditional=blurring_rush_conditional)

def herbal_remedy_conditional(self, heal: int, user: Enemy, target: Player):
    missing = (user.maxHealth - user.health) / user.maxHealth
    bonus = min(0.25, int(missing * 100 // 5) * 0.05)
    heal += round(heal * bonus)

    if user.health <= round(user.maxHealth * 0.5):
        Rejuvenate.inflict(user, 10)
    return heal
spskill_herbal_remedy = EnemySkill("Herbal Remedy", [HEAL],
                                   "Restore health (8% of Max Health). Increase heal (1-% of heal per 5% of missing health, max 25%). If health is below 50%, gain 10 stacks of Rejuvenate.",
                                   weight=15, statsUsed=[[("maxHealth", 8)], "health"],
                                   condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.6), conditional=herbal_remedy_conditional)

def rapid_fire_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if "Critical" in strikes:
        Poise.inflict(user, 2)
        Keen.inflict(user, 2)
        Shock.inflict(user, 2)
    
    if user.health <= round(user.maxHealth * 0.3):
        Haste.inflict(user)
    
    return damage
spskill_rapid_fire = EnemySkill("Rapid Fire!", [DAMAGE, [MULTI, HITS(1,8)]],
                                "Strength vs. Defense x 1-8. If skill lands a Critical, gain 2 stacks of Poise/Keen/Shock. If Health is below 30%, gain Haste. Chance to inflict 2 stacks of Hemorrhage/Fragile/Puncture.",
                                weight=17, opener=True, hit=70, critical=110, element="fire", status=[Hemorrhage, Fragile, Puncture], stacks=2, statsUsed=["strength", "defense", 1.8],
                                condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.3) or enemy.luck >= 110, conditional=rapid_fire_conditional)

def tongue_attach_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Super Break" for s in target.statusList):
        Spark.inflict(target, 2)
        Fragile.inflict(target, 2)

        ToughII.inflict(user)
        BoostII.inflict(user)
    Regen.inflict(user)
spskill_tongue_attach = EnemySkill("Tongue Attach", [STATUS], 
                                    "Inflict Bind I/Cripple II. Gain Regen. If Super Break is present on the opposer, inflict 2 stacks of Spark/Fragile and gain Tough II/Boost II.",
                                    weight=14, status=[BindI, CrippleII],
                                    condition=lambda enemy, target: any(s.name == "Super Break" for s in target.statusList) or target.speed >= 35, conditional=tongue_attach_conditional)

def bottom_bash_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.defense > target.defense:
        Fragile.inflict(target, 2)
        FrailII.inflict(target)
    
    if any("Frail" in s.name for s in target.statusList):
        if random.randint(1, 100) >= 70:
            Stun.inflict(target)
    return damage
spskill_bottom_bash = EnemySkill("Bottom Bash", [DAMAGE],
                                 "Strength vs. Defense. If Defense is greater than opposers, inflict 2 stacks of Fragile/Frail II. If any Frail statuses are present on the opposer, chance to inflict Stun. Will inflict 3 stacks of Spark/Super Break.",
                                 weight=18, opener=True, hit=80, critical=85, element="physical", status=[Spark, SuperBreak], stacks=3, willStatus=True, statsUsed=["strength", "defense", 2.4],
                                 condition=lambda enemy, target: enemy.defense > target.defense or any("Frail" in s.name for s in target.statusList), conditional=bottom_bash_conditional)

def chakra_rupture_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Rupture" and s.stacks >= 10 for s in target.statusList):
        WindSheer.inflict(target, 4, 5)
spskill_chakra_rupture = EnemySkill("Chakra Rupture", [STATUS],
                                  "Inflict 8 stacks of Rupture (with 8 count). If Rupture is present on the opposer and at 10+ stacks, inflict 4 stacks of WInd Sheer (with 5 count).",
                                  weight=15, status=[Rupture], stacks=8, count=8, 
                                  condition=lambda enemy, target: not any(s.name == "Rupture" and s.stacks >= 5 for s in target.statusList), conditional=chakra_rupture_conditional)

def swan_song_conditional(self, heal: int, user: Enemy, target: Player):
    user.ultimateMeter += 25
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")

    user.speedMeter += 25
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
    return heal
spskill_swan_song = EnemySkill("Swan Song", [HEAL],
                               "Restore health (4% of Max Health + 150% of Magic). Raise Ultimate/Speed Meter by 25. Gain 2 stacks of Serenity/Health Shield/Haste.",
                               weight=13, statsUsed=[[("maxHealth", 4), ("magic", 150)], "health"], status=[Serenity, HealthShield, Haste], stacks=2, statusTarget="user",
                               condition=lambda enemy, target: target.lastAction and target.lastAction in ["Skill", "Attack", "Item"], conditional=swan_song_conditional)

def wind_lashes_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.4):
        Power.inflict(user, 5)
        Rejuvenate.inflict(user, 5)
    return damage
spskill_wind_lashes = EnemySkill("Wind Lashes", [DAMAGE, [MULTI, HITS(2,5)]], 
                                 "Magic vs. Resistance x 2-5. If health is below 40%, gain 5 stacks of Power/Rejuvenate. Will inflict 3 stacks of Wind Sheer/Rupture (with 4 count).",
                                 weight=18, hit=85, critical=115, element="wind", status=[WindSheer, Rupture], stacks=3, count=4, willStatus=True, statsUsed=["magic", "resistance", 2.2],
                                 condition=lambda enemy, target: enemy.health >= round(enemy.maxHealth * 0.4), conditional=wind_lashes_conditional)

def soul_snare_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if target.sanity <= -15:
        FullPower.inflict(user)
        Fragile.inflict(target, 2)

    target.sanity -= 5
    return damage
spskill_soul_snare = EnemySkill("Soul Snare", [DAMAGE, [MULTI, HITS(1,3)]],
                                "Strength vs. Defense x 1-3. If opposers sanity is below -15, gain Full Power and inflict 2 stacks of Fragile. Lower opposers sanity by 5. Chance to inflict 2 stacks of Raw Embers/Sinking.",
                                weight=18, hit=70, critical=90, element="fire", status=[RawEmbers, Sinking], stacks=2, statsUsed=["magic", "resistance", 2.4],
                                condition=lambda enemy, target: target.sanity <= -15, conditional=soul_snare_conditional)

##------------Special Enemy Passives------------##

def jewel_collector_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        user.ultimateMeter -= 300
    
    for status in user.statusList[:]:
        if status.align == "Negative" and status.canStack:
            status.remove(user, random.randint(1,2))
spassive_jewel_collector = EnemySkill("Jewel Collector", [PASSIVE],
                                      "After acting, lower Ultimate Meter by 300 (once). Remove 1-2 stacks from each Negative status that stacks (does not remove if status cannot stack).")
spassive_jewel_collector.passive = types.MethodType(jewel_collector_passive, spassive_jewel_collector)

def infinite_speed_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    user.speedMeter += 25

    if user.speed < target.speed and user.health <= round(user.maxHealth * 0.5):
        Haste.inflict(user, 2)

        amount = 0 
        number = random.randint(1,2)
        for status in user.statusList[:]:
            if status.align == "Negative":
                status.remove(user, full=True)
                amount += 1
            
            if amount >= number:
                break
spassive_infinite_speed = EnemySkill("Infinite Speed", [PASSIVE], 
                                     "After acting, raise Speed Meter by 25. If Speed is lower than opposers and health is below 50%, gain 2 stacks of Haste and remove 1-2 Negative statuses.")
spassive_infinite_speed.passive = types.MethodType(infinite_speed_passive, spassive_infinite_speed)

def survivalist_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.health <= round(user.maxHealth * 0.6):
        Vitality.inflict(user)

        if sum(1 for s in target.skills if "Damage" in s.type_ and s.statsUsed[0] in ["magic", "resistance"]) >= 2:
            MagicShield.inflict(user)
        
        if user.health <= round(user.maxHealth * 0.25):
            HealthShield.inflict(user)
            Keen.inflict(user)
spassives_survivalist = EnemySkill("Survivalist", [PASSIVE],
                                   "If health is below 60%, gain Vitality, and if opposer has 2+ Magic skills, gain Magic Shield. If health is below 25%, gain Health Shield/Keen.")
spassives_survivalist.passive = types.MethodType(survivalist_passive, spassives_survivalist)

## Generic Only ###

def monster_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if not self.trigger and user.health <= round(user.maxHealth * 0.35):
        Rejuvenate.inflict(user, 15)

        user.baseStrength += 8
        user.baseMagic += 8
        user.baseResistance += 6
        user.baseDefense += 6
        user.baseSpeed += 5
        Fix.statMutation(user)
        self.trigger = True
spassives_monster = EnemySkill("Monster", [PASSIVE],
                               "If health is below 35%, gain 15 stacks of Rejuvenate and raise Strength/Magic/Defense/Resistance/Speed by 8/8/6/6/5 (permanently, once).")
spassives_monster.passive = types.MethodType(monster_passive, spassives_monster); spassives_monster.trigger = False

def predator_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.health <= round(target.maxHealth * 0.35):
        Haste.inflict(user, 2)
        Might.inflict(user, 2)
spassive_predator = EnemySkill("Predator", [PASSIVE],
                               "If opposers health is below 35%, gain 2 stacks of Haste/Might.")
spassive_predator.passive = types.MethodType(predator_passive, spassive_predator)

def closed_off_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        HealthShield.inflict(user, 3)

    if user.actions % 3 == 0:
        HealthShield.inflict(user, 2)
spassive_closed_off = EnemySkill("Closed Off", [PASSIVE],
                                 "After acting, gain 3 stacks of Health Shield (once). Every 3 user actions, gain 2 stacks of Health Shield.")
spassive_closed_off.passive = types.MethodType(closed_off_passive, spassive_closed_off)

##------------Special Enemy Ultimates------------##

def seven_jewels_conditional(self, user: Enemy, target: Player, actions=1):
    if user.health <= round(user.maxHealth * 0.3):
        Protection.inflict(user, 3)
        Might.inflict(user, 3)
uspskill_seven_jewels = EnemySkill("Seven Jewels of Power", [STATUS],
                                   "Gain 3 stacks of Haste/Poise. If health is below 30%, gain 3 stacks of Protection/Might.",
                                   useType="Ultimate", weight=100, status=[Haste, Poise], stacks=3, statusTarget="user", conditional=seven_jewels_conditional)

def world_fracture_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Haste.inflict(user, 2)
    return damage
uspskill_world_fracture = EnemySkill("World Fracture", [DAMAGE], 
                                     "Magic vs. Resistance. Gain 2 stacks of Haste. Will inflict 6 stacks of Wind Sheer/Rupture (with 8 count).",
                                     useType="Ultimate", weight=100, hit=80, critical=90, element="wind", status=[WindSheer, Rupture], stacks=6, count=8, willStatus=True, statsUsed=["magic", "resistance", 3.4],
                                     conditional=world_fracture_conditional)

def rebirth_conditional(self, heal: int, user: Enemy, target: Player):
    if user.health <= round(user.maxHealth * 0.3) and not self.trig:
        Phoenix.inflict(user) 
        self.trig = True
    return heal
uspskill_rebirth = EnemySkill("Rebirth", [HEAL],
                              "Restore health (25% of Max Health +  130% of Magic). If health is below 30%, gain Phoenix Blessing (once).",
                              useType="Ultimate", weight=100, statsUsed=[[("maxHealth", 25), ("magic", 130)], "health"],
                              conditional=rebirth_conditional); uspskill_rebirth.trig = False

def vital_squeeze_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.ultimateMeter += 20
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 20!{Color['reset']}")

    target.sanity -= 15
    return damage
uspskill_vital_squeeze = EnemySkill("Vital Squeeze", [DAMAGE, [MULTI, 4]],
                                    "Strength vs. Defense x 4. Targets Mana. Raise Ultimate Meter by 20. Lower opposers sanity by 15. Will inflict 2 stacks of Sinking/Gloom/Bind II.",
                                    useType="Ultimate", weight=100, hit=65, critical=150, element="mighty", status=[Sinking, Gloom, BindII], stacks=2, willStatus=True, statsUsed=["strength", "defense", 2], meter="Mana",
                                    conditional=vital_squeeze_conditional)

##------------Boss Skills------------##

##--Meliane, the Singing Gale (Raid Boss)--##

def passionate_hymn_conditional(self, heal: int, user: Enemy, target: Player):
    if sum(1 for s in user.statusList if s.align == "Negative") >= 4:
        Haste.inflict(user, 2)

    if user.health <= round(user.maxHealth * 0.4):
        Shock.inflict(user, 2)
    return heal
bskill_passionate_hymn = EnemySkill("Passionate Hymn", [HEAL],
                                    "Restore health (5% of Max Health + 200% of Magic). If 4+ Negative statuses are present, gain 2 stacks of Haste. If health is below 40%, gain 2 stacks of Shock.",
                                    weight=19, statsUsed=[[("maxHealth", 5), ("magic", 200)], "health"],
                                    condition=lambda enemy, target: sum(1 for s in enemy.statusList if s.align == "Negative") >= 4 or enemy.health <= round(enemy.maxHealth * 0.4), conditional=passionate_hymn_conditional)

def feeble_song_conditional(self, user: Enemy, target: Player, actions=1):
    if user.health >= round(user.maxHealth * 0.5):
        FrailII.inflict(target)
        Regen.inflict(user)

    if user.health < round(user.maxHealth * 0.5):
        WindSheer.inflict(target, 5, 5)
        CollapsingHusk.inflict(target)
        Rejuvenate.inflict(user, 10)
bskill_feeble_song = EnemySkill("Feeble Song", [STATUS],
                                "Inflict Slug/Husk. If health is above or at 50%, inflict Frail II and gain Regen. If health is below 50%, inflict 5 stacks of Wind Sheer (with 5 count)/Collapsing Husk and gain 10 stacks of Rejuvenate.",
                                weight=17, opener=True, status=[Slug, Husk],
                                condition=lambda enemy, target: enemy.health < round(enemy.maxHealth * 0.5) and not any(s.name == "Collapsing Husk" for s in target.statusList)or enemy.health >= round(enemy.maxHealth * 0.5) and not any(s.name == "Frail II" for s in target.statusList), conditional=feeble_song_conditional)

def skys_wrath_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if random.randint(1, 100) + user.luck >= target.luck + 35:
        WindSheer.inflict(target, 6, 6)  

    if user.health <= round(user.maxHealth * 0.5):
        Rejuvenate.inflict(user, 5)

    wind = next((s for s in target.statusList if s.name == "Wind Sheer"), None)
    if wind and wind.stacks >= 10:
        Fragile.inflict(target)
        Slug.inflict(target)

        amount = 0
        for status in target.statusList:
            if status.align == "Positive":
                status.remove(target, full=True)
                amount += 1

            if amount >= 2:
                break

    return damage
bskill_skys_wrath = EnemySkill("Sky's Wrath", [DAMAGE, [MULTI, HITS(1,4)]],
                               "Magic vs. Resistance x 1-4. If Wind Sheer is present on the opposer and at 10+ stacks, inflict Fragile/Slug and remove 2 Positive statuses from the opposer. If health is below 50%, gain 5 stacks of Rejuvenate. Restore health (10% of damage dealt). Chance to inflict 6/3/1 stacks if Wind Sheer (with 6 count)/Hemorrhage/Clouded II.",
                               weight=13, finsher=True, hit=75, critical=110, element="wind", status=[Hemorrhage, CloudedII], stacks=3, statsUsed=["magic", "resistance", 2.2], damHeal=0.10, meter="health",
                               condition=lambda enemy, target: any(s.name == "Wind Sheer" and s.stacks >= 10 for s in target.statusList) or enemy.health <= round(enemy.maxHealth * 0.5), conditional=skys_wrath_conditional)

def winds_guidance_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    wind = next((s for s in target.statusList if s.name == "Wind Sheer"), None)
    if wind:
        WindSheer.inflict(target, 2, 3)
        Keen.inflict(user, 2)
        Rejuvenate.inflict(user, 2)
    
    elif not wind and user.actions >= 6:
        WindSheer.inflict(target, 4, 6)

    if user.health <= round(user.maxHealth * 0.5):
        for status in user.statusList[:]:
            for setS in status.mutate:
                if "speed" == setS[0] and "Debuff" in status.type_:
                    if random.randint(1, 100) >= 75:
                        status.remove(user, full=True)
bpassive_winds_guidance = EnemySkill("Wind's Guidance", [PASSIVE],
                                     "If Wind Sheer is present on the opposer, inflict 2 stacks of Wind Sheer (with 3 count) and gain 2 stacks of Keen/Rejuvenate. After 6 user actions, if Wind Sheer is not present, inflict 4 stacks of Wind Sheer (with 6 count). If health is below 50%, for any Speed debuffing statuses present, chance to remove it.")
bpassive_winds_guidance.passive = types.MethodType(winds_guidance_passive, bpassive_winds_guidance)

##--Hanbo, the Uncarring Phoenix Lord (Raid Boss) --##

def ghost_flame_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.3):
        WillowWisp.inflict(user, 10)
        RawEmbers.inflict(user, 3)

        damage -= round(damage * 0.2)

    if any(s.name == "Raw Embers" and s.stacks >= 6 for s in target.statusList):
        Might.inflict(user, 2)
        Protection.inflict(user, 2)

        Fragile.inflict(target, 2)
        CollapsingHusk.inflict(target)
    return damage
bskill_ghost_flame = EnemySkill("Ghost Flames", [DAMAGE, [MULTI, HITS(2,5)]],
                                "Magic vs. Resistance x 2-5. If health is below 30%, inflict 10/3 stacks of Willow Wisp/Raw Embers and decrease damage (20%!). If Raw Embers is present on the opposer and at 6+ stacks, gain 2 stacks of Might/Protection and inflict 2 stacks of Fragile/Collapsing Husk. Chance to inflict 2 stacks of Burn/Glint/Raw Embers.",
                                weight=17, opener=True, hit=80, critical=90, element="fire", status=[Burn, Glint, RawEmbers], stacks=2, statsUsed=["magic", "resistance", 1.8], 
                                condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.3) or any(s.name == "Raw Embers" and s.stacks >= 6 for s in target.statusList), conditional=ghost_flame_conditional)

def heartless_flames_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    RawEmbers.inflict(target, 3)

    if user.health <= round(user.maxHealth * 0.4):
        for status in [RawEmbers, FrailIII]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target, 2)

    if any(s.name == "Soul Bind" for s in target.statusList):
        damage *= 3

    return damage
bskill_heartless_flames = EnemySkill("Heartless Phoenix Flames", [DAMAGE],
                                     "Only usable every 5 user action. Magic vs. None. If health is below 30%, restore health (40% of damage dealt). If opposers health is below 40%, chance to inflict 2 stacks of Raw Embers/Frail III. If Soul Bind is present on the opposer, increase damage (3x!). Will inflict 2/2/3 stacks of Heated/Frostbite/Raw Embers.",
                                     weight=20, finsher=True, hit=75, critical=125, element="fire", status=[Burn, Glint], stacks=2, willStatus=True, statsUsed=["magic", None, 3.2], damHeal=0.4, meter="health", healCondition=lambda damage, user, target:user.health <= round(user.maxHealth * 0.3),
                                     condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.3) or target.health <= round(target.maxHealth * 0.4) or any(s.name == "Soul Bind" for s in target.statusList), conditional=heartless_flames_conditional, weightConditional=lambda enemy, target, actions=1: enemy.actions % 5 == 0)

def rebirth_anchor_conditional(self, user: Enemy, target: Player, actions=1):
    Slug.inflict(target)

    if random.randint(1, 100) + user.luck >= 30 + target.luck:
        SoulBind.inflict(target)

    for status in user.statusList[:]:
        if status.align == "Negative" and status.canStack:
            status.remove(user, random.randint(1,2))
bskill_rebirth_anchor = EnemySkill("Rebirth Anchor", [STATUS],
                                   "Inflict 2/2/1 Willow Wisp/Frostbite/Slug. Chance to inflict Soul Bind. Remove 1-2 stacks from each Negative statuses present (does not remove if status cannot stack).",
                                   weight=14, status=[WillowWisp, Frostbite], stacks=2,
                                   condition=lambda enemy, target: not any(s.name == "Soul Bind" for s in target.statusList), conditional=rebirth_anchor_conditional)

def lord_nether_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    for status in user.statusList[:]:
        if status.align == "Negative" and status.canStack:
            status.remove(target)

    raw = next((s for s in target.statusList if s.name == "Raw Embers"), None)
    if raw:
        gain = raw.stacks * 5

        if gain > 0:
            user.ultimateMeter += gain
            say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Increased By {gain}!{Color['reset']}")

        if user.health <= round(user.maxHealth * 0.25) and raw.stacks >= 10:
            Phoenix.inflict(user)
bpassive_lord_nether = EnemySkill("Lord of the Nether Realms", [PASSIVE],
                                  "Remove 1 stack from all Negative statuses present (does not remove if status cannot stack). If Raw Embers is present on the opposer, raise Ultimate Meter by 5 per stack. If health is below 25% and Raw Embers is present on the opposer and at 10+ stacks, gain Phoenix Blessing.")
bpassive_lord_nether.passive = types.MethodType(lord_nether_passive, bpassive_lord_nether)

##--Sol (Summer Boss)--##

def light_ray_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if sum(1 for status in target.statusList if status.family == "Burn") >= 2:
        Heated.inflict(target)
        Radiant.inflict(target)
        damage *= 2
    return damage
bskill_light_ray = EnemySkill("Light Ray", [DAMAGE, [MULTI, HITS(3,5)]],
                              "Magic vs. Resistance x 3-5. If 2+ Burn statuses are present, inflict Heated/Radiant and increase damage (2x!). Will inflict Radiant.",
                              weight=11, hit=90, critical=60, element="fire", status=[Radiant], willStatus=True, statsUsed=["magic", "resistance", 1.8],
                              condition=lambda enemy, target: sum(1 for status in target.statusList if status.family == "Burn") >= 2, conditional=light_ray_conditional)

def yellow_gleam_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if sum(1 for status in target.statusList if status.family == "Burn") >= 4:
        user.speedMeter += 30
    return damage
bskill_yellow_gleam = EnemySkill("Yellow Gleam", [DAMAGE, [MULTI, HITS(1,3)]],
                                 "Magic vs. Resistance x 1-3. If opposer has 4+ Burn statuses, fill Speed meter by 30%. Will inflict max stacks of Burn/Scorch.",
                                 weight=13, hit=75, critical=80, element="fire", status=[Burn, Scorch], stacks=3, willStatus=True, statsUsed=["magic", "resistance", 2],
                                 condition=lambda enemy, target: sum(1 for status in target.statusList if status.family == "Burn") >= 2 or target.speedMeter >= 80, conditional=yellow_gleam_conditional)

def self_bath_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    heal = round(user.maxHealth * 0.1 + user.magic * 0.5)
    user.health += heal
    say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")

    amount = 0
    for status in user.statusList[:]:
        if status.family != "Burn" and status.align == "Negative":
            amount += 1
            status.remove(user, full=True)
        if amount >= 3: break
bskill_self_bath = EnemySkill("Self Bath", ["Special", HEAL],
                              "Restore health (10% of Max Health + 50% of Magic). Remove 2-3 Negative statuses (exluding Burn statuses).",
                              weight=9, customEffect=self_bath_effect,
                              condition=lambda enemy, target: sum(1 for status in enemy.statusList if status.family != "Burn" and status.align == "Negative") >= 2 or enemy.health < round(enemy.maxHealth * 0.40))

def great_sol_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    for status in user.statusList[:]:
        if status.family == "Burn":
            status.remove(user, full=True)
            heal = round(user.maxHealth * 0.03 + random.randint(3,5))
            user.health += heal
            say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
            if random.randint(1,100) >= 85:
                if random.randint(1,100) <= 50:
                    BoostII.inflict(user)
                else:
                    ToughI.inflict(user, 2)
bpassive_great_sol = EnemySkill("Great Sol", [PASSIVE],
                                "For each Burn status, remove it and restore health (3% of Max Health + 3-5), and chance to; gain either 2 stacks of Tough I or Boost II.")
bpassive_great_sol.passive = types.MethodType(great_sol_passive, bpassive_great_sol)

##--White Silenece (Winter Boss)--##

def imobilize_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    count = sum(1 for stat in ["strength", "magic", "defense", "resistance"] if getattr(user, stat) < getattr(target, stat))
    if count >= 2:
        Silence.inflict(target)
        BindII.inflict(target)
    return damage
bskill_imobilize = EnemySkill("Imobilize", [DAMAGE, [MULTI, 2]],
                              "Strength vs. Defense x 2. If 2 of Strength/Defense/Magic/Resistance are lower than the opposers, inflict Silence/Bind II. Chance to inflict Slow I/Bind I.",
                              weight=11, hit=80, critical=75, element="ice", status=[SlowI, BindI], statsUsed=["strength", "defense", 2],
                              condition=lambda enemy, target: any(getattr(target, f"base{stat.capitalize()}") < getattr(target, stat) for stat in ["strength", "magic", "defense", "resistance"]), conditional=imobilize_conditional)

def white_echo_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Silence" == s.name for s in target.statusList):
        Break.inflict(target)
        CrippleII.inflict(target)
        DeepFreeze.inflict(target)
    return damage
bskill_white_echo = EnemySkill("White Echo", [DAMAGE, [MULTI, HITS(1,5)]],
                               "Strength vs. Defense x 1-5. If Silence is present on the opposer, inflict Break/Deep Freeze/Cripple II. Chance to inflict Bleed/Husk/Frostbite.",
                               weight=8, hit=75, critical=120, element="ice", status=[Bleed, Husk, Frostbite], statsUsed=["strength", "defense", 1.5],
                               condition=lambda enemy, target: any("Silence" == s.name for s in target.statusList) or target.health <= round(target.maxHealth * 0.40), conditional=white_echo_conditional)

def snowy_mist_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name in ["Bind I", "Husk"] for s in target.statusList):
        for status in [IceVeins, Silence]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target)
bskill_snowy_mist = EnemySkill("Snowy Mist", [STATUS],
                               "Gain Haze. If either Husk/Bind I are present on the opposer, chance to inflict Ice Veins/Silence.",
                               weight=9, status=[Haze], statusTarget="user", 
                               condition=lambda enemy, target:  any(getattr(target, f"base{stat.capitalize()}") < getattr(target, stat) for stat in ["strength", "magic"]), conditional=snowy_mist_conditional)

def soundless_echo_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.lastAction and target.lastAction == "Skill" and target.lastSkill and "Damage" in target.lastSkill.type_ and any(s.name in ["Bind II", "Cripple II"] for s in target.statusList):
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Stun.inflict(target)
    
    for status in user.statusList[:]:
        if not any(s.name == status.name for s in target.statusList) and status.family == "Chill":
            if random.randint(1, 100) + user.luck >= target.luck + 35:

                status.remove(user, full=True)
                status.inflict(target)
bpassive_soundless_echo = EnemySkill("Soundless Echo", [PASSIVE],
                                     "If a damaging skill is used by the opposer and Bind II or Cripple II are present, chance to inflict Stun. If any Chill statuses are present and not present on the opposer, chance to; remove status from self and inflict it on the opposer.")
bpassive_soundless_echo.passive = types.MethodType(soundless_echo_passive, bpassive_soundless_echo)

##--Super Charged Slime (Fall Boss)--##

def wild_thungeraga_srikes_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Shock.inflict(user, 2)
    for status in user.statusList[:]:
        if status.align == "Positive":
            damage += round(damage * 0.05)
    return damage
bskill_wild_thungerga_strikes = EnemySkill("Wild Thungerga Strikes", [DAMAGE, [MULTI, HITS(2,4)]],
                                          "Magic vs. Resistance x 2-4. Increase damage (5% per Positive status). Gain 2 stacks of Shock. Chance to inflict 5 stacks of Spark/Static.",
                                          weight=12, opener=True, hit=65, critical=100, element="thunder", status=[Spark, Static], stacks=5, statsUsed=["magic", "resistance", 2],
                                          condition=lambda enemy, target: not any("Shock" == s.name for s in enemy.statusList) or sum(1 for s in enemy.statusList if s.align == "Positive") >= 2, 
                                          conditional=wild_thungeraga_srikes_conditional)

def mass_discharge_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Shock.inflict(user, 2)
    for status in user.statusList[:]:
        if status.family == "Shock":
            damage += round(damage * 0.07)
            SlowI.inflict(user)
            CrippleI.inflict(user)
            status.remove(user, full=True)
    return damage
bskill_mass_discharge = EnemySkill("Mass Discharge", [DAMAGE, [MULTI, HITS(3,5)]],
                                   "Magic vs. Resistance x 3-5. For Shock status present, remove status, increase damage (7% per Shock status), and gain Slow I/Cripple I. Chance to inflict Bleed/Sear/Burn",
                                   weight=8, finsher=True, hit=70, critical=120, element="thunder", status=[Bleed, Sear, Burn], statsUsed=["magic", "resistance", 1.5],
                                   condition=lambda enemy, target: sum(1 for s in enemy.statusList if s.family == "Shock") >= 2 or enemy.health <= round(enemy.maxHealth * 0.65), conditional=mass_discharge_conditional)

def super_charge_conditional(self, heal: int, user: Enemy, target: Player):
    energetic = next((status for status in user.statusList if status.name == "Energetic"), None)
    if energetic:
        energetic.duration = 0
    return heal
bskill_super_charge = EnemySkill("Super Charge", [HEAL],
                                 "Restore health (50% of Magic) x 1-4. If Energetic is present, reset duration to 0. Gain Energetic/Boost II.",
                                 weight=9, status=[Energetic, BoostII], statusTarget="user", statsUsed=[[("magic", 50)], "health", HITS(1,4)],
                                 condition=lambda enemy, target: not any("Energetic" == s.name for s in enemy.statusList) or enemy.health <= round(enemy.maxHealth * 0.35), conditional=super_charge_conditional)

def lightning_rod_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if any(s.name == "Static" for s in user.statusList):
        heal = round(user.maxHealth * 0.1)
        user.health += heal
        say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")

        count = sum(1 for status in target.statusList if status.family == "Shock")
        for i in range(count):
            random.choice([Burn, Sear, Static]).inflict(target)
bpassive_lightning_rod = EnemySkill("Lightning Rod", [PASSIVE],
                                     "If Static is present, restore health (10% of Max Health). For Shock status on the opposer, chance to inflict; Burn, Sear, or Static.")
bpassive_lightning_rod.passive = types.MethodType(lightning_rod_passive, bpassive_lightning_rod)

##--Syzoth (Autumn Boss)--##

def force_ball_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList:
        if status.family == "Poison":
            status.count += 2
            say(f"{Color['green']}{target.name} Gained 2 Count Of {self.name}!{Color['reset']}")
    return damage
bskill_force_ball = EnemySkill("Force Ball", [DAMAGE],
                               "Magic vs. Resistance. For Poison status on the opposer, raise its count by 2. Chance to inflict Poison/Venom/Infection.",
                               weight=8, hit=85, critical=80, element="mighty", status=[Poison, Venom, Infection], statsUsed=["magic", "resistance", 3],
                               condition=lambda enemy, target: enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and enemy.lastSkill.name == "Tongue Lash" or sum(1 for s in target.statusList if s.family == "Poison") >= 3, conditional=force_ball_conditional)

bskill_tongue_lash = EnemySkill("Tongue Lash", [DAMAGE, [MULTI, HITS(1,3)]],
                                "Strength vs. Defense x 1-3. If 2+ Bleed statuses are present on the opposer, restore health (25% of damage dealt). Chance to inflic 2 stacks of Hemorrhage/Bleed/Clot.",
                                weight=9, hit=60, critical=120, element="physical", status=[Hemorrhage, Bleed, Clot], stacks=2, statsUsed=["strength", "defense", 2], damHeal=0.25, meter="health", healCondition=lambda damage, user, target: sum(1 for status in target.statusList if status.family == "Bleed") >= 2,
                                condition=lambda enemy, target: sum(1 for s in target.statusList if s.family == "Bleed") >= 2 or enemy.health <= round(enemy.maxHealth * 0.45))

def dirty_claw_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    bleed = 0
    poison = 0
    for status in target.statusList:
        trigger = False
        if status.family == "Poison" and poison < 1:
            poison += 1
            trigger = True
        elif status.family == "Bleed" and bleed < 1:
            bleed += 1
            trigger = True
        
        if trigger:
            if "Special" not in status.type_:
                status.simple(target)
            else:
                status.special(target)
    return damage
bskill_dirty_claw = EnemySkill("Dirty Claw", [DAMAGE],
                               "Strength vs. Defense. Retrigger 1 Bleed/Poison statuses. Chance to inflict Wound/Puncture/Infection/Muddy.",
                               weight=12, hit=70, critical=130, element="physical", status=[Wound, Puncture, Infection, Muddy], statsUsed=["strength", "defense", 1.4],
                               condition=lambda enemy, target: any("Bleed" == s.family for s in target.statusList) or any("Poison" == s.family for s in target.statusList), conditional=dirty_claw_conditional)

def kombatent_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    bleed = 0
    poison = 0
    if (user.health / user.maxHealth) * 100 > (target.health / target.maxHealth) * 100:
        for status in target.statusList:
            trigger = False
            if random.randint(1, 100) + user.luck >= target.luck + 35 and status.family in ["Poison", "Bleed"]:
                if status.family == "Poison" and poison < 2:
                    poison += 1
                    trigger = True
                elif status.family == "Bleed" and bleed < 2:
                    bleed += 1
                    trigger = True
                
                if trigger:
                    if "Special" not in status.type_:
                        status.simple(target)
                    else:
                        status.special(target)
        BoostII.inflict(user)   
        CrippleI.inflict(user)
bpassive_kombatent = EnemySkill("Kombatent", [PASSIVE],
                      "If health percentage is greater than opposers health percentage, gain Boost II, inflict Cripple I, and chance to retrigger 2 Poison/Bleed statuses.")
bpassive_kombatent.passive = types.MethodType(kombatent_passive, bpassive_kombatent)

##--King of the Storms/Nameless King--##

def dragons_breath_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Poise" for s in user.statusList):
        Keen.inflict(user, 2)
        Fragile.inflict(target, 2)
    return damage
bskill_dragons_breath = EnemySkill("Dragon's Breath", [DAMAGE, [MULTI, HITS(3,6)]],
                                   "Magic vs. Defense x 3-6. If Poise is present, gain 2 stacks of Keen and inflict 2 stacks of Fragile. Will inflict 2 stacks of Burn/Sear/Cripple II.",
                                   weight=14, finsher=True, hit=65, critical=90, element="fire", status=[Burn, Sear, CrippleII], stacks=2, willStatus=True, statsUsed=["strength", "defense", 1.6],
                                   condition= lambda enemy, target: any(s.name == "Poise" for s in enemy.statusList), conditional=dragons_breath_conditional)

def air_line_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Charge" and s.stacks >= 7 for s in user.statusList):
        Charge.inflict(user)
        FrailII.inflict(target)
        damage = round(damage * 1.5)
    return damage
bskill_air_line = EnemySkill("Air Line", [DAMAGE],
                             "Strength vs. Resistance. If Charge is present and at 7+ stacks, gain 1 stack of Charge, inflict Frail II, and increase damage (1.5x). Chance to inflict 2 stacks of Fragile/Husk/Bleed/Slow I.",
                             weight=16, hit=80, critical=110, element="wind", status=[Fragile, Husk, Bleed, SlowI], stacks=2, statsUsed=["strength", "resistance", 2],
                             condition= lambda enemy, target: any(s.name == "Charge" and s.stacks >= 7 for s in enemy.statusList) or not any(s.name == "Husk" for s in target.statusList), conditional=air_line_conditional)

def push_back_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Charge" and s.stacks >= 10 for s in user.statusList):
        Keen.inflict(user, 2)
        Poise.inflict(user, 2)
    target.speedMeter -= 25
    say(f"{Color['magenta']}{target.name}s Speed Meter Was Lowered By 25!{Color['reset']}")
bskill_push_back = EnemySkill("Push Back", [STATUS],
                              "Gain 3 stacks of Charge/Poise. If Charge is present and at 10+ stacks, gain 2 stacks of Keen/Power. Lower opposers Speed Meter by 25.",
                              weight=11, opener=True, status=[Charge, Poise], stacks=3, statusTarget="user", 
                              condition= lambda enemy, target: any(s.name == "Charge" and s.stacks >= 10 for s in enemy.statusList) or target.speedMeter >= 80, conditional=push_back_conditional)

def spear_charge_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Charge.inflict(user, 2)
    Keen.inflict(user, 2)
    return damage
bskill_spear_charge = EnemySkill("Spear Charge", [DAMAGE], 
                                 "Strength vs. Defense. Gain 2 stacks of Charge/Keen. Will inflict Puncture/Frail II.",
                                 weight=15, hit=80, critical=115, element="physical", status=[Puncture, FrailII], willStatus=True, statsUsed=["strength", "defense", 2],
                                 condition= lambda enemy, target: not (any(s.name == "Charge" for s in enemy.statusList) and any(s.name == "Poise" for s in enemy.statusList)), conditional=spear_charge_conditional)

def expanding_lightning_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Charge" and s.stacks >= 10 for s in user.statusList):
        Power.inflict(user, 3)
        Poise.inflict(user, 3)
    return damage
bskill_expanding_lightning = EnemySkill("Expanding Lightning", [DAMAGE, [MULTI, HITS(1,5)]],
                                        "Magic vs. Resistance x 1-5. If Charge is present and at 10+ stacks, gain 3 stacks of Power/Poise. Chance to inflict Sear/Gash/Burn/Spark/Static.",
                                        weight=12, finsher=True, hit=55, critical=130, element="thunder", status=[Sear, Gash, Burn, Spark, Static], statsUsed=["magic", "resistance", 1.8],
                                        condition= lambda enemy, target: any(s.name == "Charge" and s.stacks >= 10 for s in enemy.statusList), conditional=expanding_lightning_conditional)

def lightning_stake_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Charge" and s.stacks >= 5 for s in user.statusList):
        Charge.remove(user, 5)
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
        FrailII.inflict(target)

    if any(s.name == "Power" and s.stacks >= 65 for s in user.statusList):
        Poise.remove(user, 6)
        user.ultimateMeter += 20
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 20!{Color['reset']}")
        Fragile.inflict(user, 3)
    return damage
bskill_lightning_stake = EnemySkill("Lightning Stake", [DAMAGE],
                                    "Strength vs. Resistance. If Charge is present and at 5+ stacks, lose 5 stacks of Charge, raise Speed Meter by 25, and inflict Frail II. If Poise is present and at 6+ stacks, lose 6 stacks of Poise, raise Ultimate Meter by 20, and inflict 3 stacks of Fragile. Chance to inflict 2 stacks of Burn/Husk.",
                                    weight=15, hit=70, critical=100, element="thunder", status=[Burn, Husk], stacks=2, statsUsed=["strength", "resistance", 2],
                                    condition= lambda enemy, target: any(s.name == "Charge" and s.stacks >= 5 for s in enemy.statusList) or any(s.name == "Poise" and s.stacks >= 6 for s in enemy.statusList), conditional=lightning_stake_conditional)

def first_born_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        self.trigger = False

    charge = next((s for s in user.statusList if s.name == "Charge"), None)
    if charge:
        Charge.inflict(user)

    poise = next((s for s in user.statusList if s.name == "Poise"), None)
    if poise:
        Keen.inflict(user)

    if user.health <= round(user.maxHealth * 0.3) and not self.trigger:
        Rejuvenate.inflict(user, 30)
        self.trigger = True
bpassive_first_born = EnemySkill("First Born of Gwyn", [PASSIVE],
                      "If Charge/Poise is present, gain 1 stack of Charge/Keen. If health is below 30%, gain 30 stacks of Rejuvenate (once).")
bpassive_first_born.passive = types.MethodType(first_born_passive, bpassive_first_born); bpassive_first_born.trigger = False

##--Fire Lord--##

bskill_flare_wave = EnemySkill("Flare Wave", [DAMAGE, [MULTI, HITS(2,3)]],
                       f"Magic vs. Resistance x 2-3. Chance to inflict Burn/Scorch.",
                       weight=17, opener=True, hit=75, critical=30, element="fire", status=[Burn, Scorch], statsUsed=["magic", "resistance", 2])

##--Armored Knight--##

bskill_heavy_slash = EnemySkill("Heavy Slash", [DAMAGE],
                       f"Strength vs. Defense. Chance to inflict Frail I/Bleed.",
                       weight=15, finsher=True, hit=80, critical=180, element="physical", status=[FrailI], statsUsed=["strength", "defense", 2],
                       condition= lambda enemy, target: enemy.luck > target.luck)

bskill_timed_stab = EnemySkill("Timed Stab", [DAMAGE],
                       f"Strength vs. Defense. Chance to inflict Slow I/Bleed.",
                       weight=18, hit=100, critical=80, element="physical", status=[SlowI, Bleed], statsUsed=["strength", "defense", 2],
                       condition= lambda enemy, target: enemy.hit > target.hit)

bskill_charge_i = EnemySkill("Charge I", [STATUS],
                      f"Gain Tough I/Boost I.",
                      weight=10, opener=True, status=[ToughI, BoostI], statusTarget="user")

##--Radagon/Elden Beast--##

def radagons_spear_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if actions <= 6:
        damage *= 2
    return damage
bskill_radagons_spear = EnemySkill("Radagon's Spear", [DAMAGE], 
                       f"Magic vs. Resistance. Increased damage (2x!) if used within the first 6 actions. Will inflict 2 stacks of Devotion/Frail I/Bleed.",
                       weight=15, opener=True, hit=85, critical=65, element="mighty", status=[FrailI, Devotion], statsUsed=["magic", "resistance", 2],
                       condition= lambda enemy, target: target.defense > target.baseDefense, conditional=radagons_spear_conditional)

bskill_holy_spear_fan = EnemySkill("Holy Spear Fan", [DAMAGE, [MULTI, HITS(2,3)]], 
                       f"Magic vs. Resistance x 2-3. Chance to inflict 2 stacks of Devotion.",
                       weight=10, hit=70, critical=110, element="mighty", status=[Devotion], stacks=2, statsUsed=["magic", "resistance", 1.5])

bskill_parry_stance = EnemySkill("Parry Stance", [STATUS],
                      f"Gain Parry.",
                      weight=13, status=[Parry], statusTarget="user")

##-- 

bskill_golden_breath = EnemySkill("Golden Breath", [DAMAGE, [MULTI, HITS(3,5)]],
                       f"Magic vs. Resistance x 3-5. Chance to inflict 3 stacks of Burn/Devotion/Scorch.",
                       weight=15, hit=80, critical=50, element="mighty", status=[Burn, Heated, Devotion], stacks=3, statsUsed=["magic", "resistance", 1.5])

bskill_retreating_swing = EnemySkill("Retreating Swing", [DAMAGE],
                       f"Strength vs. Defense. Gain 3 stacks of Overload.",
                       weight=10, hit=100, critical=80, element="mighty", status=[Overload], stacks=3, statusTarget="user", willStatus=True, statsUsed=["strength", "defense", 2],
                       condition= lambda enemy, target: target.speed > enemy.speed)

bskill_flying_flame_sword = EnemySkill("Flying Flame Sword", [DAMAGE, [MULTI, HITS(2,3)]],
                       f"Magic vs. Resistance. Chance to inflict 2 stacks of Heated/Burn/Devotion.",
                       weight=9, finsher=True, hit=70, critical=100, element="fire", status=[[Heated, Burn], Burn, Devotion], stacks=2, statsUsed=["magic", "resistance", 2],
                       condition= lambda enemy, target: target.health <= round(target.maxHealth * 0.65))

##--Gokue Black/Rose--##

bskill_black_wave = EnemySkill("Black Wave", [DAMAGE, [MULTI, HITS(4,6)]],
                       f"Magic vs. Resistance x 9-11. Chance to inflict Sear/2 stacks of Burn.",
                       weight=8, finsher=True, hit=45, critical=60, element="mighty", status=[Burn, Sear], stacks=2, statsUsed=["magic", "resistance", 1.3])

bskill_god_slicer = EnemySkill("God Slicer", [DAMAGE, [MULTI, 2]], 
                       f"Use Stength and target Defense x 2. Chance to inflict Bleed/Gash.",
                       weight=14, hit=75, critical=100, element="mighty", status=[Bleed, Gash], statsUsed=["strength", "defense", 1.8])

bskill_work_of_gods = EnemySkill("Work of the Gods", [STATUS],
                       f"Gain 1 stack of Vestige.",
                       weight=10, status=[Vestige], statusTarget="user",
                       condition= lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.70))

bskill_kai_healing = EnemySkill("Kai Healing", [HEAL],
                       f"Restore Health (55% of Magic + 5% of Max Health). Gain 2 stacks of Tough I.",
                       weight=8, status=[ToughI], statusTarget="user", stacks=2, statsUsed=[[("magic", 55), ("maxHealth", 5)], "health"])

##--Mohg--##

bskill_blood_flame_talons = EnemySkill("Blood Flame Talons", [DAMAGE],
                       f"Magic vs. Resistance. Will inflict Bleed/Sear/Heated.",
                       weight=15, opener=True, hit=75, critical=20, element="fire", status=[Bleed, Sear, Heated], willStatus=True, statsUsed=["magic", "resistance", 2],
                       condition=lambda enemy, target: any(s.family in ["Bleed", "Burn"] for s in target.statusList))

bskill_bloodboon = EnemySkill("Bloodboon", [DAMAGE, [MULTI, HITS(8,10)]],
                       f"Magic vs. Resistance x 8-10. Will inflict Gash/Clot.",
                       weight=13, hit=60, critical=20, element="mighty", status=[Gash, Clot], willStatus=True, statsUsed=["magic", "resistance", 1],
                       condition=lambda enemy, target: any("Bleed" == s.family for s in target.statusList))

bskill_blood_offer = EnemySkill("Blood Offer", [STATUS],
                       f"Gain 1 stack of Bloodboon.",
                       weight=9, status=[Bloodboon], statusTarget="user",
                       condition=lambda enemy, target: enemy.health >= round(enemy.maxHealth * 0.65) and not any(s.name == "Bloodboon" for s in enemy.statusList))

##--Mohg, the Failed Consort--##

def blood_tax_conditional(self, user: Enemy, target: Player, actions=1):
    if user.sanity <= -15:
        BloodGeyser.inflict(target, 15)
        num = random.randint(1,2)
        count = 0
        for status in target.statusList[:]:
            if status.align == "Positive":
                status.remove(target, full=True)
                count += 1

            if count >= num:
                break

        if user.ultimateSkill.name == "Ritual Finish":
            user.ultimateMeter += 30
            say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 30!{Color['reset']}")
            Bloodboon.inflict(user, 2)
            Power.inflict(user, 2)
            Rejuvenate.inflict(user, 25)
bskill_blood_tax = EnemySkill("Blood Tax", [STATUS], 
                              "Inflict 5 stacks of Blood Geyser/Husk. If sanity is below -15, inflict 15 stacks of Blood Geyser and remove 1-2 Positive statuses from the opposer. If ultimate skill is Ritual Finish, raise Ultimate/Speed Meter by 30, and gain 2/2/25 stacks of Bloodboon/Power/Rejuvenate.",
                              weight=14, opener=True, status=[BloodGeyser, Husk], stacks=5, 
                              condition=lambda enemy, target: not any(s.name == "Blood Geyser" for s in target.statusList) or any(s.name == "Blood Geyser" and s.stacks <= 50 for s in target.statusList) or enemy.ultimateSkill.name == "Ritual Finish", conditional=blood_tax_conditional)

def blood_flame_explosion_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity <= -10:
        Scorch.inflict(target)
        FrailII.inflict(target)

    user.sanity -= 2
    target.sanity -= 2

    return damage
bskill_blood_flame_explosion = EnemySkill("Blood Flames Explosion", [DAMAGE, [MULTI, HITS(2,5)]], 
                                          "Magic vs. Resistance x 2-5. If sanity is below -10, inflict Scorch/Frail II. Lose 2 sanity. Lower opposers sanity by 2. Chance to inflict 2 stacks of Burn/Heated/Hemorrhage/Sear.",
                                          weight=16, finsher=True, hit=75, critical=95, element="fire", status=[Burn, Heated, Hemorrhage, Sear], stacks=2, statsUsed=["magic", "resistance", 1.6],
                                          condition=lambda enemy, target: enemy.sanity <= -10, sanLean="Negative")

def omen_claw_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.ultimateMeter += 10
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 10!{Color['reset']}")

    if target.sanity <= -10:
        user.ultimateMeter += 15
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 15!{Color['reset']}")

    target.sanity -= 5

    return damage
bskill_omen_claw = EnemySkill("Omen Claw", [DAMAGE, [MULTI, 2]], 
                              "Strength vs. Defense x 2. Raise Ultimate Meter by 10. If opposers sanity is below -10, raise Ultimate Meter by 15. Lower opposers sanity by 5. Chance to inflict 2 stacks of Hemorrhage/Gash/Bleed/Frail II.",
                              weight=18, hit=80, critical=110, element="physical", status=[Hemorrhage, Gash, Bleed, CrippleII], statsUsed=["strength", "defense", 1.8],
                              condition=lambda enemy, target: enemy.ultimateMeter <= 30 or target.sanity <= -10 or target.sanity > 0, conditional=omen_claw_conditional, sanLean="Negative")

def greatest_child_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        self.trigger = False
        self.tracker = 0

    if user.sanity <= -15:
        Power.inflict(user)
        Protection.inflict(user)

    if user.actions % 3 == 0:
        for status in [BloodGeyser, Hemorrhage, Fragile]:
            status.inflict(target, 2)

    if any(s.name == "Doctor Sigil" for s in target.sigils):
        SlowII.inflict(target)
        BindII.inflict(target)
        if not self.trigger:
            Charge.inflict(user, 5)
            self.trigger = True

    if user.lastAction and user.lastAction == "Ultimate" and user.ultimateSkill.name == "Ritual Countdown":
        self.tracker += 1

    if self.tracker == 3 and user.ultimateSkill.name == "Ritual Countdown":
        say(f"{Color['magenta']}Ritual Countdown Transformed Into Ritual Finish!{Color['reset']}")
        user.ultimateSkill = ubskill_ritual_finish
bpassive_greatest_child = EnemySkill("Greatest Child", [PASSIVE],
                             "If sanity is below -15, gain 1 stack of Power/Protection. Every 3 user actions, inflict 2 stacks of Blood Geyser/Hemorrhage/Fragile. If opposer has the Doctor Sigil equipped, inflict Bind II/Slow II and (once) gain 5 stacks of Charge.")
bpassive_greatest_child.passive = types.MethodType(greatest_child_passive, bpassive_greatest_child); bpassive_greatest_child.trigger = False; bpassive_greatest_child.tracker =0

##--Deus Motus--##

def kinetic_intake_conditional(self, user: Enemy, target: Player, actions=1):
    amount = 0
    for status in user.statusList[:]:
        if amount >= 2:
            break
        if status.family != "Shock" and status.align == "Negative":
            status.remove(user, full=True)
            amount += 1
bskill_kinetic_intake = EnemySkill("Kinetic Intake", [STATUS],
                       f"Gain Energetic/Shock. Remove 2 Negative status.",
                       weight=13, opener=True, status=[Energetic, Shock], statusTarget="user", willStatus=True,
                       condition= lambda enemy, target: target.speed > enemy.speed and not any("Energetic" == s.name for s in enemy.statusList),
                       conditional=kinetic_intake_conditional)

def onero_intake_conditional(self, user: Enemy, target: Player, actions=1):
    amount = 0
    for status in user.statusList[:]:
        if amount >= 2:
            break
        if status.family != "Shock" and status.align == "Negative":
            status.remove(user, full=True)
            amount += 1
bskill_onero_intake = EnemySkill("Onero Intake", [STATUS],
                       f"Gain Short Circuit/Overload. Remove 2 Negative status.",
                       weight=13, opener=True, status=[ShortCircuit, Overload], statusTarget="user", willStatus=True,
                       condition= lambda enemy, target: target.speed > enemy.speed, conditional=onero_intake_conditional)

def deus_discharge_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    number = 0
    for status in user.statusList[:]:
        if status.family == "Shock":
            number+= 1
    
    for i in range(number):
        damage += round(damage * 0.10)
    return damage
bskill_deus_discharge = EnemySkill("Deus Discharge", [DAMAGE, [MULTI, 3]],
                       f"Magic vs. Resistance x 3. Increased damage (10%!) for every Shock status.",
                       weight=20, hit=65, critical=80, element="thunder", status=[FrailI], statusTarget="user", statsUsed=["magic", "resistance", 3],
                       condition=lambda enemy, target: any(s.name in ["Energetic", "Short Circuit"] for s in enemy.statusList), conditional=deus_discharge_conditional)

##--Kratos--##

def gauntlets_of_zeus_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    amount = 0
    for status in target.statusList:
        if status.name in ["Bleed", "Break"]:
            amount += 1

    if amount >= 2:
        BoostII.inflict(user)
    
    if any("Boost II" == s.name for s in user.statusList):
        damage *= 2
    return damage
bskill_gauntlets_of_zeus = EnemySkill("Gauntlets of Zeus", [DAMAGE, [MULTI, 2]], 
                       f"Strength vs. Defense x 2. Increased damage (2x!) if Boost II is present. Chance to inflict Bleed/Break. If the opposer has Bleed and Break, gain Boost II.",
                       weight=15, opener=True, hit=80, critical=100, element="thunder", status=[Bleed, Break], statsUsed=["strength", "defense", 2.5],
                       condition=lambda enemy, target: target.health >= round(target.maxHealth * 0.65), conditional=gauntlets_of_zeus_conditional)

def atlas_quake_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList:
        if status.name == "Break":
            damage *= 2
            ToughII.inflict(user)
            break
    return damage
bskill_atlas_quake = EnemySkill("Atlas Quake", [DAMAGE, [MULTI, HITS(6,10)]], 
                       f"Magic vs. Resistance x 6-10. If the opposer has Break, increase damage (2x!) and gain Tough II.",
                       weight=12, finsher=True, hit=50, critical=30, element="physical", statsUsed=["magic", "resistance", 2],
                       condition=lambda enemy, target: any("Break" == s.name for s in target.statusList), conditional=atlas_quake_conditional)

bskill_power_absorption = EnemySkill("Power Absorption", [DAMAGE], 
                      f"Magic vs. Resistance. Restores health (75% of damage dealt). Gain Warrior.",
                      weight=10, hit=65, critical=20, element="mighty", status=[Warrior], statusTarget="user", statsUsed=["magic", "resistance", 2],
                      meterDamage="health", damHeal=0.75, meter="health", 
                      condition=lambda enemy, target: enemy.health < round(enemy.maxHealth * 0.50) and not any("Warrior" == s.name for s in enemy.statusList))

##--Zamasu--##

def absolute_lightning_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Charge" and s.stacks >= 10 for s in user.statusList):
        Charge.remove(user, 5)

        Vestige.inflict(user, 2)
        Boon.inflict(user, 2)

        Static.inflict(target)
        Sear.inflict(target)

    if user.sanity >= 8:
        Charge.inflict(user, 3)
        Vestige.inflict(user, 3)

    for status in target.statusList[:]:
        if status.family == "Shock":
            status.remove(target, full=True)
            break

    return damage
bskill_absolute_lightning = EnemySkill("Absolute Lightning", [DAMAGE], 
                                       "Magic vs. Resistance x 2-4. If Charge is present and at 10+ stacks, lose 5 stacks of Charge, gain 2 stacks of Vestige/Boon, and inflict Static/Sear. If sanity is at 10+, gain 3 stacks of Charge/Vestige. Remove 1 Shock status/1 stack (if stackable) present on the opposer. Chance to inflict Slow I/Ill/Spark.",
                                       weight=18, hit=85, critical=100, element="thunder", status=[SlowI, Ill, Spark], statsUsed=["magic", "resistance", 2],
                                       condition=lambda enemy, target: any(s.name == "Charge" and s.stacks >= 10 for s in enemy.statusList) or enemy.sanity >= 10 or any(s.family == "Shock" for s in target.statusList), conditional=absolute_lightning_conditional)

def blades_of_judgment_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 4

    if any(s.name == "Charge" and s.stacks >= 5 for s in user.statusList):
        Charge.remove(user, 5)

        Power.inflict(user, 2)
        Rejuvenate.inflict(user, 2)

        Fragile.inflict(target, 2)

        damage = round(damage * 1.5)

    if user.sanity >= 8:
        Charge.inflict(user, 3)
        Vestige.inflict(user, 3)

    return damage
bskill_blades_of_judgment = EnemySkill("Blades of Judgment", [DAMAGE], 
                                        "Magic vs. Resistance x 1-6. If Charge is present and at 5+ stacks, lose 5 stacks of Charge, gain 2 stacks of Power/Rejuvenate, inflict 2 stacks of Fragile, and increase damage (1.5x!). If sanity is at 8+, gain 3 stacks of Charge/Vestige. Gain 4 sanity. Chance to inflict Bleed/Split/Frail II.",
                                        weight=14, hit=75, critical=60, element="mighty", status=[Bleed, Split, FrailII], statsUsed=["magic", "resistance", 1.6],
                                        condition=lambda enemy, target: any(s.name == "Charge" and s.stacks >= 5 for s in enemy.statusList) or enemy.sanity >= 8, conditional=blades_of_judgment_conditional)

def energy_charge_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Rejuvenate" and s.stacks >= 30 for s in user.statusList):
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
        user.ultimateMeter += 25
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")
bskill_energy_charge = EnemySkill("Energy Charge", [STATUS], 
                                  "Gain 3 stacks of Charge/Rejuvenate/Power. If Rejuvenate is at 30+ stacks, raise Speed/Ultimate Meter by 25.",
                                  weight=15, opener=True, status=[Charge, Rejuvenate, Power], stacks=3, statusTarget="user",
                                  condition=lambda enemy, target: not any(s.name in ["Vestige", "Rejuvenate", "Power"] for s in enemy.statusList) or any(s.name == "Rejuvenate" and s.stacks >= 30 for s in enemy.statusList), conditional=energy_charge_conditional)

def purity_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        self.trigger = False

    if user.health >= round(user.maxHealth * 0.5):
        Rejuvenate.inflict(user, 5)
        user.sanity += 3
        user.speedMeter += 15
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")

    else:
        if not self.trigger:
            user.baseMagic += 6
            user.baseDefense += 5
            user.baseResistance += 5
            user.baseHit -= 25
            user.baseLuck -= 15
            Fix.statMutation(user)
            self.trigger = True

        Vestige.inflict(user, 2)
        Charge.inflict(user, 2)
        Consumed.inflict(user)

        user.ultimateMeter += 10
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 10!{Color['reset']}")
bpassive_purity = EnemySkill("Purity", [PASSIVE], 
                             "If health is above or equal to 50%, gain 5 stacks of Rejuvenate, gain 3 sanity, raise Speed Meter by 15. If health is less than 50%, raise Magic/Defense/Resistance by 6/5/5 and lower Luck/Hit by 25/15 (both permanently, once), gain 2 stacks of Vestige/Charge/Consumed, and raise Ultimate Meter by 10.")
bpassive_purity.passive = types.MethodType(purity_passive, bpassive_purity); bpassive_purity.trigger = False

def extinction_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 2

    count = 0
    for status in target.statusList[:]:
        if status.align == "Positive" and random.randint(1, 100) >= 60:
            status.remove(target, full=True)
            count += 1

        if count >= 2:
            break

    if user.sanity <= -15:
        Rejuvenate.inflict(user, 10)

    Charge.inflict(user)
    Keen.inflict(user)
    Vestige.inflict(user)

    return damage
bskill_extinction= EnemySkill("Extinction", [DAMAGE], 
                              "Magic vs. Resistance x 4. Chance to remove 2 Positive statuses from the opposer. If sanity is below -15, gain 10 stacks of Rejuvenate. Lose 2 sanity. Gain 1 stack of Charge/Keen/Vestige. Chance to inflict Frail II.",
                              weight=14, hit=80, finsher=True, critical=90, element="mighty", status=[FrailII], statsUsed=["magic", "resistance", 1.7], sanLean="Negative",
                              condition=lambda enemy, target: enemy.sanity <= -15 or target.health <= round(target.maxHealth * 0.4) or sum(1 for s in target.statusList) >= 3, conditional=extinction_conditional)

def light_of_doom_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 2

    if user.health <= round(user.maxHealth * 0.50):
        Protection.inflict(user, 2)
        Boon.inflict(user, 2)
        Regen.inflict(user)

    Charge.inflict(user)

    return damage
bskill_light_of_doom= EnemySkill("Light of Doom", [DAMAGE], 
                                 "Magic vs. Resistance. If health is below 50%, gain 2 stacks of Protection/Boon/Regen. Lose 2 sanity. Gain 1 stacks of Charge. Chance to inflict 2 stack of Fragile/Break/Cripple II.",
                                 weight=17, hit=85, critical=120, status=[Fragile, Break, CrippleII], stacks=2, element="mighty", statsUsed=["magic", "resistance", 2], sanLean="Negative",
                                 condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.5), conditional=light_of_doom_conditional)

def cloning_conditional(self, user: Enemy, target: Player, actions=1):
    if user.sanity <= -17:
        Vestige.inflict(user)
        Power.inflict(user)
        Fragile.inflict(user)

        user.speedMeter += 10
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 10!{Color['reset']}")

    user.sanity -= 3 + next((s.stacks for s in user.statusList if s.name == "Vestige"), 0)
bskill_cloning = EnemySkill("Cloning", [STATUS], 
                            "Gain 2 stacks of Vestige/Power. If sanity is below -17, gain 1 stack of Vestige/Power/Fragile and raise Speed Meter by 10. Lose 3 + stacks of Vestige sanity.",
                            weight=15, status=[Vestige, Charge, Power], stacks=2, statusTarget="user",
                            condition=lambda enemy, target: not any(s.name in ["Vestige", "Charge", "Power"] for s in enemy.statusList) or enemy.sanity <= -17 or enemy.sanity > 0, conditional=cloning_conditional)

def immortality_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if not hasattr(user, "tag"):
        self.trigger = False
        user.tag = True

    if user.health <= round(user.maxHealth * 0.4):
        Rejuvenate.inflict(user, 4)
        user.sanity - 2

    if not self.trigger:
        Phoenix.inflict(user)
        self.trigger = True
bpassive_immortality = EnemySkill("Immortality", [PASSIVE], 
                                  "If health is below 40%, gain 5 stacks of Rejuvenate and lose 2 sanity. Gain Phoenix Blessing (once).")
bpassive_immortality.passive = types.MethodType(immortality_passive, bpassive_immortality); bpassive_immortality.trigger = False

##--Crying Children--##

def unseeing_murmur_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user)

    if any("Wax" == s.name and s.stacks >= 5 for s in user.statusList):
         if random.randint(1, 100) + user.luck >= target.luck + 35:
             BindII.inflict(target)

    if any("Wax" == s.name and s.stacks >= 6 for s in user.statusList): 
        damage = round(damage * 1.5)
        for status in target.statusList[:]:
            if status.align == "Positive":
                status.remove(target, full=True)
                break
    return damage
bskill_unseeing_murmur = EnemySkill("Unseeing Murmur", [DAMAGE],
                                    "Magic vs. Resistance. If Wax is at 5+ stacks, chance to inflict Bind II. If Wax is at 6+ stacks, remove 1 Positive statuses from the opposer and increase damage (1.5x!). Gain 1 stack of Wax. Chance to inflict Bind I.",
                                    weight=9, hit=75, critical=70, element="mighty", status=[BindI], statsUsed=["magic", "resistance", 2], 
                                    condition=lambda enemy, target: any("Wax" == s.name and s.stacks >= 5 for s in enemy.statusList) or any("Positive" == s.align for s in target.statusList), conditional=unseeing_murmur_conditional)

def unhearing_murmur_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user, 2)

    if any("Wax" == s.name and s.stacks >= 6 for s in user.statusList):
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Sear.inflict(target)
        damage = round(damage * 1.5)

    if user.health <= round(user.maxHealth * 0.60):
        damage *= 2
    return damage
bskill_unhearing_murmur = EnemySkill("Unhearing Murmur", [DAMAGE, [MULTI, 2]],
                                    "Magic vs. Resistance x 2. If Wax is at 6+ stacks, increase damage (1.5x!) and chance to inflict Sear. If Health is below 60%, increase damage (2x!). Gain 2 stacks of Wax. Chance to inflict 2 stacks of Burn.",
                                    weight=8, hit=70, critical=50, element="fire", status=[Burn], stacks=2, statsUsed=["magic", "resistance", 1.5], 
                                    condition=lambda enemy, target: any("Wax" == s.name and s.stacks >= 6 for s in enemy.statusList) or enemy.health <= round(enemy.maxHealth * 0.60), conditional=unhearing_murmur_conditional)

def unspeaking_murmur_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 4

    if user.sanity >= 10:
        BoostII.inflict(user)
        ToughI.inflict(user, 3)

    if (target.lastSkill and "Damage" in target.lastSkill.type_) and (target.lastAction and target.lastAction == "Skill"):
        Burn.inflict(target, 3)
        Bleed.inflict(target)
        BindII.inflict(target)
    return damage
bskill_unspeaking_murmur = EnemySkill("Unspeaking Murmur", [DAMAGE],
                                    "Magic vs. Resistance. If opposer used a damaging skill last action, inflict Burn/Bleed/Bind II If sanity is 10+, gain 3 stacks of Tough I/Boost II. Gain 4 sanity.",
                                    weight=11, hit=90, critical=90, element="fire", statsUsed=["magic", "resistance", 2], 
                                    condition=lambda enemy, target: target.lastSkill and "Damage" in target.lastSkill.type_ and target.lastAction and target.lastAction == "Skill", conditional=unspeaking_murmur_conditional)

##-- 

def distored_illusion_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if target.health <= round(target.maxHealth * 0.65):
        Sear.inflict(target)

    if user.sanity >= 10:
        Heated.inflict(target)
    return damage
bskill_distored_illusion = EnemySkill("Distored Illusion", [DAMAGE, [MULTI, 3]],
                                    "Magic vs. Resistance x 3. If opposers health is below 65%, inflict Sear. If sanity is at 10+, inflict Heated. Chance to inflict Burn/Scorch.",
                                    weight=10, hit=85, critical=70, element="fire", status=[Burn, Scorch], statsUsed=["magic", "resistance", 1.5],
                                    condition=lambda enemy, target: target.health <= round(target.maxHealth * 0.65) or enemy.sanity >= 10, conditional=distored_illusion_conditional)

def bygone_illusion_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user, 2)

    if user.speed > target.speed:
        BindII.inflict(target)

    if target.sanity >= 15:
        FrailII.inflict(target)

    for status in target.statusList:
        if status.family == "Burn":
            damage += round(damage * 0.06)
    return damage
bskill_bygone_illusion = EnemySkill("Bygone Illusion", [DAMAGE, [MULTI, 3]],
                                    "Magic vs. Resistance x 3. If Speed is greater than opposers Speed, inflict Bind II. If opposers sanity is at 15+, inflict Frail II. Increase damage (6% for Burn status on opposer). Gain 2 stacks of Wax.",
                                    weight=8, hit=80, critical=80, element="mighty", statsUsed=["magic", "resistance", 1.5], 
                                    condition=lambda enemy, target: enemy.speed > target.speed or target.sanity >= 15, conditional=bygone_illusion_conditional)

def facade_impact_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user)
    
    amount = 0
    for status in target.statusList:
        if status.family == "Burn":
            amount += 1
    
    if amount >= 3:
        damage *= 4

    return damage
bskill_facade_impact = EnemySkill("Facade Impact", [DAMAGE],
                                    "Magic vs. Resistance. If opposer has 3 Burn statuses, increase damage (4x!). Gain Wax. Will inflict 2 stacks of Heated/Molten.",
                                    weight=6, hit=50, critical=100, element="fire", status=[Heated, Molten], stacks=2, willStatus=True, statsUsed=["magic", "resistance", 1.4], 
                                    condition=lambda enemy, target: enemy.sanity <= -10 or sum(1 for s in target.statusList if s.family == "Burn") >= 3, conditional=facade_impact_conditional)

##-- 

def inconsolable_grief_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity >= 20:
        Sear.inflict(target)
        Scorch.inflict(target)
        FrailI.inflict(target)
        user.sanity -= 25
        if user.sanity <= -5:
            Stun.inflict(user)
    return damage
bskill_inconsolable_grief = EnemySkill("Inconsolable Grief", [DAMAGE, [MULTI, HITS(5,10)]],
                                    "Magic vs. Resistance x 5-10. If sanity is at 20+, inflict Sear/Scorch/Frail I, lose 25 sanity, and if sanity is now below -5, gain Stun. Will inflict Burn/Heated/Molten.",
                                    weight=7, hit=50, critical=80, element="fire", status=[Burn, Heated, Molten], stacks=3, willStatus=True, statsUsed=["magic", "resistance", 1.2], 
                                    condition=lambda enemy, target: enemy.sanity >= 20, conditional=inconsolable_grief_conditional)

def victimize_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user, 2)

    if user.sanity >= 15:
        for status in [Stun, FrailII]:
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                status.inflict(target)
    return damage
bskill_victimize = EnemySkill("Victimize", [DAMAGE, [MULTI, 3]],
                              "Magic vs. Resistance x 3. If sanity is at 15+, chance to inflict Stun/Frail II. Gain 2 stacks Wax. Will inflict Frail I/Break.",
                               weight=10, finsher=True, hit=70, critical=90, element="mighty", status=[FrailI, Break], willStatus=True, statsUsed=["magic", "resistance", 1.5], 
                               condition=lambda enemy, target: enemy.sanity >= 15, conditional=victimize_conditional)

def restrain_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    Wax.inflict(user)

    if any("Wax" == s.name and s.stacks >= 5 for s in user.statusList): 
        for status in target.statusList[:]:
            if status.align == "Positive":
                status.remove(target, full=True)

        for status in user.statusList[:]:
            if status.name == "Wax":
                status.stacks = max(0, status.stacks - 5)
    return damage
bskill_restrain = EnemySkill("Restrain", [DAMAGE, [MULTI, 3]],
                              "Magic vs. Resistance. If Wax is at 5+ stacks, remove all Positive statuses from the opposer and remove 5 Wax. Gain 1 Wax.",
                               weight=8, hit=80, critical=85, element="mighty", statsUsed=["magic", "resistance", 2], 
                               condition=lambda enemy, target: any("Positive" == s.align for s in target.statusList) and any("Wax" == s.name and s.stacks >= 5 for s in enemy.statusList), conditional=restrain_conditional)

##--Phillip, the Waxen Pinion--##

def torrid_sword_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 4

    if not any(s.name == "Light" for s in user.statusList):
        Light.inflict(user)

    if target.health >= round(target.maxHealth * 0.65) and user.sanity >= 10:
        for status in [Fragile, Molten]:
            if random.randint(1,100) + user.luck >= target.luck + 35:
                Fragile.inflict(target, 2)
                Molten.inflict(target)

    Melting.inflict(user, 5)
    return damage
bskill_torrid_sword = EnemySkill("Torrid Sword", [DAMAGE, [MULTI, HITS(1,3)]],
                                 "Strength vs. Defense x 1-3. If Light is not present, gain 1 stack of Light. If opposers health is above 65% and sanity is at 10+, chance to inflict 2 stacks of Fragile/Molten. Gain 4 sanity. Gain 5 stacks of Melting. Chance to inflict 2 stacks of Slug/Heated/Burn/Scorch.",
                                 weight=16, hit=85, critical=80, element="fire", status=[Slug, Heated, Burn, Scorch], stacks=2, statsUsed=["strength", "defense", 1.5], 
                                 condition=lambda enemy, target: not any(s.name == "Light" for s in enemy.statusList) or target.health >= round(target.maxHealth * 0.65) and enemy.sanity >= 10, conditional=torrid_sword_conditional)

def scorching_strike_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity < 0:
        user.sanity += 20
        damage //= 2

    if user.sanity >= 15:
        user.sanity += 5
        Light.inflict(user)
        Melting.inflict(user, 5)
        damage = round(damage * 1.5)

    WillowWisp.inflict(target, 25)
    return damage
bskill_scorching_strike = EnemySkill("Scorching Strike", [DAMAGE],
                                     "Only usable when in Sword Mode or if sanity is at 10+. Strength vs. Defense. If sanity is Negative, lose 20 sanity and decrease damage (50%!). If sanity is at 15+, gain 5 sanity, gain 1/5 stacks of Light/Melting, and increase damage (1.5x!). Will inflict 25/2 stacks of Willow Wisp/Heated/Cripple II.",
                                     weight=20, finsher=True, hit=75, critical=135, element="fire", status=[Heated, CrippleII], stacks=2, willStatus=True, statsUsed=["strength", "defense", 2.5], 
                                     condition=lambda enemy, target: hasattr(enemy, "mode") and (enemy.mode == "sword" or enemy.sanity >= 15), conditional=scorching_strike_conditional, weightConditional=lambda enemy, target, actions=1: hasattr(enemy, "mode") and enemy.mode == "sword" or enemy.sanity >= 10)

def wax_winged_conditional(self, user: Enemy, target: Player, actions=1):
    user.sanity += 4
    
    if user.sanity >= 15:
        Light.inflict(user, 2)

    increase =0 
    for i in range(0, user.sanity, 5):
        Melting.inflict(user)
        increase += 5

    if increase:
        user.speed += increase
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By {increase}!{Color['reset']}")
bskill_wax_winged = EnemySkill("Wax Winged Shield", [STATUS],
                               "Gain 1 stack of Protection/Health Shield. Raise sanity by 4. If sanity is at 15+, gain 2 stacks of Light. For every 5 sanity, gain 1 stack of Melting and raise Speed Meter by 5.",
                               weight=14, opener=True, status=[Protection, HealthShield], stacks=2, statusTarget="user", 
                               condition=lambda enemy, target: enemy.health >= round(enemy.maxHealth * 0.45) or enemy.sanity >= 15 or enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill.name == "Wax Winged Shield", conditional=wax_winged_conditional)

def shimmering_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions % 3 == 0:
        Light.inflict(user)

    if not any("Stun" in s.type_ for s in user.statusList):
        if any(s.name == "Light" for s in user.statusList):
            increase = 0
            for i in range(0, next(s for s in user.statusList if s.name == "Light").stacks):
                increase += 5

            if increase:
                user.speedMeter += min(35, increase)
                say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By {increase}!{Color['reset']}")

        if any(s.name == "Melting" for s in user.statusList):
            increase = 0
            for i in range(0, next(s for s in user.statusList if s.name == "Melting").stacks):
                increase += 2

            if increase:
                user.ultimateMeter += min(30, increase)
                say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By {increase}!{Color['reset']}")
bpassive_shimmering = EnemySkill("Shimmering", [PASSIVE],
                             "Every 3 actions, gain 1 stack of Light. If no Stun statuses are present, for each stack of Light present, raise Speed Meter by 5 (max of 35). If no Stun statuses are present, for each stack of Melting preset, raise Ultimate Meter by 2 (max of 30).")
bpassive_shimmering.passive = types.MethodType(shimmering_passive, bpassive_shimmering)

def heros_passion_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.health >= round(target.maxHealth * 0.65):
        if not any(s.name == "Burn" for s in target.statusList):
            Burn.inflict(target, 2)

        if not any(s.name == "Heated" for s in target.statusList):
            Heated.inflict(target, 2)

    if user.health <= round(user.maxHealth * 0.65):
        num = random.randint(1,2)
        count = 0
        for status in user.statusList[:]:
            if status.mutate and len(status.mutate) > 0:
                if any(s[0] == "speed" for s in status.mutate):
                    status.remove(user, full=True)
                    count += 1

            if count >= num:
                break
bpassive_heros_passion = EnemySkill("Hero's Passion", [PASSIVE],
                                    "If opposer’s health is above 65%, inflict 2 stacks of Burn/Heated (if not already present, both). If health is below 65%, remove 1-2 Speed Debuffing statuses.")
bpassive_heros_passion.passive = types.MethodType(heros_passion_passive, bpassive_heros_passion)

##--Midra--##

def flame_frenzy_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Madness" == s.name and s.stacks >= 3 for s in target.statusList):
        Shock.inflict(user, 2)
    return damage
bskill_flame_frenzy = EnemySkill("Flames of Frenzy", [DAMAGE, [MULTI, HITS(1,3)]],
                                  "Magic vs. Resistance x 1-3. If opposer has 3+ stacks of Madness, gain 2 stacks of Shock. Chance to inflict 2 stacks of Burn/Madness/Frenzied Flames.",
                                  weight=13, hit=90, critical=80, element="fire", status=[Burn, Madness, FrenziedFlames], stacks=2, statsUsed=["magic", "resistance", 2],
                                  condition=lambda enemy, target: any("Madness" == s.name and s.stacks >= 3 for s in target.statusList), conditional=flame_frenzy_conditional)

def sweeping_frenzy_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 6

    if user.sanity <= -10:
        damage = round(damage * 1.5)
    
    if any(s.align == "Negative" and s.family == "Mental" for s in user.statusList):
        BoostII.inflict(user)
    return damage
bskill_sweeping_frenzy = EnemySkill("Sweeping Frenzy", [DAMAGE, [MULTI, HITS(2,3)]],
                                  "Magic vs. Resistance x 2-3. If sanity is below -10, increase damage (1.5x!). If any Negative Mental status is present, gain Boost II. Lose 6 sanity. Will inflict 5 stacks of Madness/Scorch",
                                  weight=11, hit=80, critical=40, element="fire", status=[Madness, Scorch], stacks=5, willStatus=True, statsUsed=["magic", "resistance", 1.5],
                                  condition=lambda enemy, target: enemy.sanity <= -10 or any(s.align == "Negative" and s.family == "Mental" for s in enemy.statusList), conditional=sweeping_frenzy_conditional, sanLean="Negative")

def barbed_thrust_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 2

    if user.sanity <= -15:
        Gash.inflict(target)
        Wound.inflict(target)
    
    if target.health < round(target.maxHealth * 0.35) or target.sanity <= -10:
        damage = round(damage * 1.5)
    
    madness = next((s.stacks for s in target.statusList if s.name == "Madness"), 0)
    amount = sum(random.randint(1, 5) for _ in range(madness))
    heal = round(user.maxHealth * 0.05) + amount
    user.health = min(user.health + heal, user.maxHealth)
    say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
    return damage
bskill_barbed_thrust = EnemySkill("Barbed Thrust", [DAMAGE, [MULTI, HITS(3,5)]],
                                  "Strength vs. Defense x 3-5. Restore health (5% of Max Health + 1-5 per stack of Madness on the opposer). If sanity is below -15, inflict Gash/Wound. If opposers health is below 35% or opposers sanity -10, increase damage (1.5x!). Lose 2 sanity. Will inflict 2 stacks of Madness/Bleed.",
                                  weight=9, hit=90, critical=120, element="physical", status=[Madness, Bleed], stacks=2, willStatus=True, statsUsed=["strength", "defense", 2],
                                  condition=lambda enemy, target: enemy.sanity <= -10 or target.health < round(target.maxHealth * 0.35), conditional=barbed_thrust_conditional, sanLean="Negative")

def vassal_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions <= 1:
        user.sanity = 12
    
    if user.sanity > 0:
        FrailI.inflict(user)

    if user.sanity >= 5:
        for status in user.statusList[:]:
            if status.align == "Positive":
                status.remove(user, full=True)
    
    if user.sanity >= 7:
        FrailII.inflict(user)
    
    if user.sanity <= -10:
        BoostI.inflict(user)
    
    if user.sanity <= -15:
        ToughI.inflict(user)
    
    if user.sanity <= -20:
        BoostII.inflict(user)
    
    if user.sanity < 0:
        for status in user.statusList[:]:
            if random.randint(1, 100) >= 45 and status.family != "Mental" and status.align == "Negative":
                status.remove(user, full=True)


    user.sanity -= 2
bpassive_vassal = EnemySkill("Vassal of the Three Fingers", [PASSIVE],
                             "Start the battle with 12 sanity. If sanity is above 0, gain Frail I. If sanity is at 7+, gain Frail II. If sanity is below -10/-15/-20, gain Boost I/Tough I/Boost II. If sanity is negative, chance to remove any non-Mental Negative status present. Lose 2 sanity each action.")
bpassive_vassal.passive = types.MethodType(vassal_passive, bpassive_vassal)

##--Time Ripper--##

def you_afraid_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    StolenTime.inflict(user, 100)
    if any("Stolen Time" == s.name and s.stacks >= 200 for s in user.statusList):
        Clot.inflict(target)
        amount = 0
        for status in target.statusList:
            if status.family == "Bleed":
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target, 0, user)
                amount += 1
            
            if amount >= 2:
                break
        
        stolenTime = next(status for status in user.statusList if status.name == "Stolen Time")
        damage += round(damage * 0.10 * (stolenTime.stacks // 100))
        stolenTime.remove(user, 100)
    return damage
bskill_you_afraid = EnemySkill("Are You Afraid?", [DAMAGE, [MULTI, 2]], 
                               "Strength vs. Defense x 2. If Stolen Time is at 200+ Stacks, inflict Clot, retrigger 2 Bleed statuses, increase damage (10% per 100 stack of Stolen Time!), and remove 100 Stolen Time. Gain 100 stacks of Stolen Time. Chance to inflict Bleed/Gash.",
                               weight=10, hit=75, critical=100, element="thunder", status=[Bleed, Gash], statsUsed=["strength", "defense", 1.5],
                               condition=lambda enemy, target: any("Stolen Time" == s.name and s.stacks >= 200 for s in enemy.statusList) or sum("Bleed" == s.family for s in target.statusList) >= 2, conditional=you_afraid_conditional)

def extraction_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    StolenTime.inflict(user, 100)
    if any("Stolen Time" == s.name and s.stacks >= 300 for s in user.statusList):
        Wound.inflict(target)
    return damage
bskill_extraction = EnemySkill("Extraction", [DAMAGE, [MULTI, 3]], 
                               "Strength vs. Defense x 3. If Stolen Time is at 300+ Stacks, inflict Wound. Gain 100 stacks of Stolen Time. Chance to inflict Bleed/Puncture.",
                               weight=8, hit=75, critical=90, element="thunder", status=[Bleed, Puncture], statsUsed=["strength", "defense", 1.3],
                               condition=lambda enemy, target: any("Stolen Time" == s.name and s.stacks >= 300 for s in enemy.statusList) or enemy.speed > target.speed, conditional=extraction_conditional)

def time_steal_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    skills = target.skills[:]
    random.shuffle(skills)
    for skill in skills:
        if skill.usable == False and not PASSIVE in skill.type_:
            skill.cooldownProgress = max(0, skill.cooldownProgress - 1)
            say(f"{Color['magenta']}{target.name}s {skill.name} Had Its Cooldown Extended By 1!{Color['reset']}")
            break
    
    if any("Stolen Time" == s.name and s.stacks >= 300 for s in user.statusList):
        skills = target.skills[:]
        random.shuffle(skills)
        for skill in skills:
            if skill.usable == False and not PASSIVE in skill.type_:
                skill.cooldownProgress = max(0, skill.cooldownProgress - 1)
                say(f"{Color['magenta']}{target.name}s {skill.name} Had Its Cooldown Extended By 1!{Color['reset']}")
                break
    
    if any("Stolen Time" == s.name and s.stacks >= 400 for s in user.statusList):
        Shock.inflict(user, 2)
        skills = target.skills[:]
        random.shuffle(skills)
        amount = 0
        for skill in skills:
            if skill.usable == False and not PASSIVE in skill.type_:
                skill.cooldownProgress = max(0, skill.cooldownProgress - 1)
                say(f"{Color['magenta']}{target.name}s {skill.name} Had Its Cooldown Extended By 1!{Color['reset']}")
                amount += 1
            
            if amount >= 3:
                break
bskill_time_steal = EnemySkill("Time Steal", [SPECIAL],
                               "Extend 1 of the opposers unusable skills by 1. If Stolen Time is at 300+ stacks, extend 1 of the opposers unusable skills by 1. If Stolen Time at 400+, gain 2 stacks of Shock and extend 3 of the opposers unusable skills by 1.",
                               weight=5, customEffect=time_steal_effect,
                               condition=lambda enemy, target: any(not s.usable and PASSIVE not in s.type_ for s in target.skills))

def resentment_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    stolenTime = next((status for status in user.statusList if status.name == "Stolen Time"), None)
    if not stolenTime:
        return

    for i in range(stolenTime.stacks // 100):
        shock = next((s for s in user.statusList if s.name == "Shock"), None)

        if shock and shock.stacks >= shock.maxStack:
            Energetic.inflict(user)
            break
        else:
            Shock.inflict(user)
bpassive_resentment = EnemySkill("Resentment", [PASSIVE],
                                 "For every 100 stacks of Stolen Time, gain Shock. If Shock is at max stacks, gain Energetic.",)
bpassive_resentment.passive = types.MethodType(resentment_passive, bpassive_resentment)

##--The Father--##

def harsh_lecture_effect(self, user: Enemy, target: Player, actions=1): 
    say(f"{user.name} Used {self.name}!")

    observation = next((skill for skill in user.skills if skill.name == "Observation"), None)
    highest = max(observation.score.values(), default=1) if observation else 1
    damage = round((user.strength + random.randint(4,9))* 0.40) * highest

    target.health -= damage
    say(f"{Color['red']}{user.name} Dealt {damage} Health To {target.name}!{Color['reset']}")

    damage //= 2
    target.mana -= damage
    say(f"{Color['red']}{user.name} Dealt {damage} Mana To {target.name}!{Color['reset']}")

    if observation and (target.lastAction == "Skill"):
        observation.score[target.lastSkill.name] = observation.score.get(target.lastSkill.name, 0) + 1
    BoostII.inflict(user)
    ToughII.inflict(user)
bskill_harsh_lecture = EnemySkill("Harsh Lecture", [SPECIAL],
                                  "Deal damage to health and mana ((75% of Strength + 4-9) x Highest Score). Raise opposers last used skills Score by 1. Gain Boost II/Tough II.",
                                  weight=11, customEffect=harsh_lecture_effect,
                                  condition=lambda enemy, target: any(next((skill for skill in enemy.skills if skill.name == "Observation"), None).score.get(skill.name, 0) < 2 for skill in target.skills))

def harsh_glare_effect(self, user: Enemy, target: Player, actions=1): 
    say(f"{user.name} Used {self.name}!")
    SlowI.inflict(target)
    CrippleII.inflict(target)
    observation = next((skill for skill in user.skills if skill.name == "Observation"), None)
    if observation and (target.lastAction == "Skill"):
        observation.score[target.lastSkill.name] = observation.score.get(target.lastSkill.name, 0) + 1

        if any(observation.score.get(skill.name, 0) >= 3 for skill in target.skills):
            Stun.inflict(target)
    else:   
        say("Nothing Happened")
bskill_harsh_glare = EnemySkill("Harsh Glare", [SPECIAL],
                                  "Raise opposers last used skills Score by 1. If any of the opposers skills Score are at 3+, inflict Stun. Will inflict Slow I/Cripple II.",
                                  weight                                                                              =9, customEffect=harsh_glare_effect,
                                  condition=lambda enemy, target: any(next((skill for skill in enemy.skills if skill.name == "Observation"), None).score.get(skill.name, 0) >= 3 for skill in target.skills))

def frigid_lesson_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    observation = next((skill for skill in user.skills if skill.name == "Observation"), None)
    if observation and any(observation.score.get(skill.name, 0) >= 3 for skill in target.skills):
        damage *= 3
    
    if any("Stun" == s.name for s in target.statusList):
        FrailII.inflict(target)
    return damage
bskill_frigid_lesson = EnemySkill("Frigid Lesson", [DAMAGE, [MULTI, HITS(3,5)]],
                                  "Strength vs. Defense x 3-5. If any of the opposers skills are at 3+ Score, increase damage (3x!). If Stun is present on the opposer, inflict Frail II. Chance to inflict Break/Bleed/Clot.",
                                  weight=12, hit=80, critical=120, element="ice", status=[Bleed, Clot, Break], statsUsed=["strength", "defense", 1.5],
                                  condition=lambda enemy, target: any(next((skill for skill in enemy.skills if skill.name == "Observation"), None).score.get(skill.name, 0) >= 3 for skill in target.skills) or any("Stun" == s.name for s in target.statusList), conditional=frigid_lesson_conditional)

def observation_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions <= 1:
        for skill in target.skills:
            self.score[skill.name] = 0

    if (target.lastAction == "Skill"):
        self.score[target.lastSkill.name] += 1
        say(f"{Color['magenta']}{target.name}s {target.lastSkill.name} Score Was Increased By 1!{Color['reset']}")
        
        if self.score[target.lastSkill.name] >= 2:
            damage = round(target.strength * 0.50 + target.maxHealth * 0.05)
            say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}!{Color['reset']}")
            target.health -= damage

        if self.score[target.lastSkill.name] >= 3:
            if random.randint(1, 100) >= 65:
                FrailII.inflict(target)

        if self.score[target.lastSkill.name] >= 4:
            damage = round(target.strength * 0.75 + target.maxHealth * 0.05)
            say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}!{Color['reset']}")
            target.health -= damage

        if self.score[target.lastSkill.name] >= 5:
            boostII = next((status for status in user.statusList if status.name == "Boost II"), None)
            if boostII:
                boostII.duration = 0
            else:
                BoostII.inflict(user)

    for skill in self.score:
        if self.score[skill] > 5: self.score[skill] = 5
        say(f"{Color['cyan']}{skill}: {self.score[skill]}{Color['reset']}")
bpassive_observation = EnemySkill("Observation", [PASSIVE],
                                  "Each of the opposers skills start at 0 Score. Using a skill increases its Score by 1. If the last used skills Score is 2+, deal damage (50% of opposers Strength + 5% of opposers Max Health). If the last used skills Score is 3+, chance to inflict Frail II. If the last used skills Score is 4+, deal damage (75% of opposers Strength + 5% of opposers Max Health). If the last used skills Score is 5+, Gain Boost II/Reset Boost IIs duration to 0.",)
bpassive_observation.passive = types.MethodType(observation_passive, bpassive_observation)
bpassive_observation.score = {}

##--Salax the Lustful Harpy--##

def aroma_spread_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Charm" == s.name for s in target.statusList) and not any("Lust" == s.name for s in target.statusList):
        damage *= 2
    elif any("Lust" == s.name for s in target.statusList):
        damage *= 3
    return damage
bskill_aroma_spread = EnemySkill("Aroma Spread", [DAMAGE, [MULTI, HITS(1,3)]], 
                            "Magic vs. Resistance x 1-3. If Charm/Lust are present, increase damage (2x/3x!). Will inflict 2 stacks of Charm/Burn.",
                            weight=12, hit=75, critical=75, element="fire", status=[Charm, Burn], willStatus=True, stacks=2, statsUsed=["magic", "resistance", 1.5],
                            condition=lambda enemy, target: any(s.name in ["Charm", "Lust"] for s in target.statusList), conditional=aroma_spread_conditional)

def feather_shot_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and user.lastSkill.name == "Aroma Spread" or any("Gash" == s.name for s in target.statusList):
        Charm.inflict(target, 2)
        Hemorrhage.inflict(target, 2)
        damage += round(damage * 1.5)
    return damage
bskill_feather_shot = EnemySkill("Feather Shot", [DAMAGE, [MULTI, HITS(1,4)]],
                            "Magic vs. Resistance x 1-4. If last used skill was Aroma Spread or Gash is present on the opposer, inflict 2 stacks of Charm/Hemorrhage and increase damage (1.5x!). Chance to inflict Charm/Gash/Puncture.",
                            weight=10, hit=65, critical=125, element="physical", status=[Charm, Gash, Puncture], statsUsed=["strength", "defense", 1.5],
                            condition=lambda enemy, target: (enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and enemy.lastSkill.name == "Aroma Spread") or any("Gash" == s.name for s in target.statusList), conditional=feather_shot_conditional)

def wind_slam_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Lust" == s.name for s in target.statusList):
        Stun.inflict(target)
        damage *= 2
    return damage
bskill_wind_slam = EnemySkill("Wind Slam", [DAMAGE], 
                            "Strength vs. Defense. If Lust is present on the opposer, inflict Stun and increase damage (2x!). Will inflict 2 stacks of Hemorrhage/Break. Take recoil (25% of damage).",
                            weight=6, hit=60, critical=130, element="wind", status=[Hemorrhage, Break], stacks=2, willStatus=True, statsUsed=["strength", "defense", 2.5], recoil=[True, 25],
                            condition=lambda enemy, target: any("Lust" == s.name for s in target.statusList) or enemy.health >= round(enemy.maxHealth * 0.65), conditional=wind_slam_conditional)

def display_love_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    charm = next((status for status in target.statusList if status.name == "Charm"), None)
    if charm:
        for i in range (charm.stacks):
           if random.randint(1, 100) > 75:
               FrailI.inflict(target)
               CrippleI.inflict(target)      
    
    lust = next((status for status in target.statusList if status.name == "Lust"), None)
    if lust:
        if random.randint(1, 100) > 60:
           FrailII.inflict(target)
           CrippleII.inflict(target)      
    
    if not (charm or lust) and user.actions >= 3:
        FrailII.inflict(user)
        CrippleI.inflict(user)
bpassive_display_love = EnemySkill("Display of Love", [PASSIVE], 
                              "For each stack of Charm on the opposer, chance to inflict Frail I/Cripple I. If Lust is present on the opposer, inflict Frail II/Cripple II. If Charm or Lust are not present on the opposer after having acted 3+ times, gain Frail II/Cripple I.")
bpassive_display_love.passive = types.MethodType(display_love_passive, bpassive_display_love)

##--Dolor the Sorrowful Man--##

def panic_attack_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 5
    Consumed.inflict(user)
    
    percent = 0
    for status in user.statusList[:]:
        if status.family == "Mental":
            percent += 0.10
    if percent:
        damage += round(damage * percent)
    return damage
bskill_panic_attack = EnemySkill("Panic Attack", [DAMAGE, [MULTI, HITS(1,3)]],
                            "Magic vs. Resistance x 1-3. Increase damage (10% per Mental status on user). Lose 5 Sanity. Gain Consumed. Chance to inflict Frigid/Clouded I.",
                            weight=13, hit=80, critical=70, element="mighty", status=[Frigid, CloudedI], statsUsed=["magic", "resistance", 1.5],
                            condition=lambda enemy, target: sum(1 for s in enemy.statusList if s.family == "Mental") >= 3, conditional=panic_attack_conditional, sanLean="Negative")

def brood_effect(self, user: Enemy, target: Player, actions=1): 
    say(f"{user.name} Used {self.name}!")
    
    BoostII.inflict(user)
    
    playerNeg = [s.name for s in target.statusList if s.align == "Negative"]
    enemyNeg = [s.name for s in user.statusList if s.align == "Negative"]
    negatives = [s for s in enemyNeg if s not in playerNeg]
    number = min(random.randint(2, 3), len(negatives))
    
    if len(negatives) >= 2:
        for i in range(number):
            Status.allStatuses[negatives[i]].inflict(target)
        Frigid.inflict(target)
bskill_brood = EnemySkill("Brood", [SPECIAL],
                     "If 2+ Negative statuses are present on user and not on opposer, inflict 2-3 of the Negative statuses/Frigid. Gain Boost II.",
                     weight=10, customEffect=brood_effect, 
                     condition=lambda enemy, target: len([s for s in enemy.statusList if s.align == "Negative" and not any(t.name == s.name for t in target.statusList)]) >= 2)

def shared_pain_effect(self, user: Enemy, target: Player, actions=1): 
    say(f"{user.name} Used {self.name}!")
    
    CloudedII.inflict(user)
    Sinking.inflict(user)
    
    heal = round(user.maxHealth * min(sum(0.04 for s in user.statusList if s.align == "Negative"), 0.24))
    user.health += heal
    say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
    
    damage = target.health // 2
    target.health -= damage
    say(f"{Color['red']}{target.name} Took {damage} Health Damage!{Color['reset']}")
    
    damage = target.mana // 2
    target.mana -= damage
    say(f"{Color['red']}{target.name} Took {damage} Mana Damage!{Color['reset']}")
    
    target.sanity = user.sanity - 3
    say(f"{Color['magenta']}{target.name}s Sanity Is Now {user.sanity - 3}!{Color['reset']}")
bskill_shared_pain = EnemySkill("Shared Pain", [SPECIAL],
                     "Only usable below 50% health. Restore health (4% per Negative status, max 24%). Halve the opposers health and mana. Set opposers sanity to users sanity - 3. Gain Clouded II/Sinking.",
                     weight=11, customEffect=shared_pain_effect, 
                     condition=lambda enemy, target: enemy.sanity <= -15, weightConditional=lambda enemy, target, actions=1: enemy.health <= round(enemy.maxHealth * 0.5) and actions >= 12)

def waning_moon_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if sum(1 for status in target.statusList if status.family == "Mental" and status.align == "Negative") >= 3 and target.health <= round(target.maxHealth * 0.6):
        count = 0
        for status in target.statusList[:]:
            if status.family == "Mental" and status.align == "Negative":
                status.remove(target, full=True)
                count += 1
            if count >= 2:
                break
        
        Devoid.inflict(target)
        Stun.inflict(target)
    
    if user.actions in [1, 10]:
        Frigid.inflict(target, 2)
bpassive_waning_moon = EnemySkill("Waning Moon", [PASSIVE],
                              "If opposer has 3+ Negative Mental statuses and their health is below 60%, remove 2 Negative Mental statuses from the opposer and inflict Empty/Stun. After acting for the 1st and 10th times, inflict 2 stacks of Frigid.")
bpassive_waning_moon.passive = types.MethodType(waning_moon_passive, bpassive_waning_moon)

##--Egenus the Lacking Snake--##

def oozing_envy_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if random.randint(1,100) >= 50:
        Regen.inflict(user)
        
    if sum(1 for s in target.statusList if s.align == "Positive") >= 2:
        Muddy.inflict(target)
        damage *= 2
    return damage
bskill_oozing_envy = EnemySkill("Oozing Envy", [DAMAGE, [MULTI, HITS(1,2)]],
                           "Magic vs. Resistance x 1-2. If opposer has 2+ Positive statuses, inflict Muddy and increase damage (2x!). Chance to; gain Regen/Inflict Poison/Venom.",
                           weight=11, hit=80, critical=80, element="mighty", status=[Poison, Venom], statsUsed=["magic", "resistance", 2],
                           condition=lambda enemy, target: sum(1 for s in target.statusList if s.align == "Positive") >= 2, conditional=oozing_envy_conditional)

def mine_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if random.randint(1,100) >= 70:
        BoostII.inflict(user)
        
    for status in target.statusList[:]:
        if status.align == "Positive":
            status.remove(target, full=True)
            Status.allStatuses[status.name].inflict(user)
            break
    return damage
bskill_mine = EnemySkill("Mine!", [DAMAGE], 
                    "Strength vs. Defense. Remove 1 Positive statuses from the opposer and gain it. Chance to; gain Boost II/inflict Avarice/Bind I.",
                    weight=9, hit=85, critical=130, element="physical", status=[Avarice, BindI], statsUsed=["strength", "defense", 2],
                    condition=lambda enemy, target: any("Positive" == s.align for s in target.statusList), conditional=mine_conditional)

def underhanded_tactics_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if random.randint(1,100) >= 50:
        Keen.inflict(user, 2)
        
    if sum(1 for s in target.statusList if s.align == "Positive") >= 3:
        Avarice.inflict(target)
    
    if any("Venom" == s.name for s in target.statusList):
        Muddy.inflict(target)
        Blight.inflict(target)
    return damage
bskill_underhanded_tactics = EnemySkill("Underhanded Tactics", [DAMAGE, [MULTI, 3]],
                                   "Magic vs. Resistance x 3. If opposer has 3+ Positive statuses, inflict Avarice. If Venom is present on the opposer, inflict Muddy/Blight. Chance to; gain 2 stacks of Keen/inflict Venom/Plague/Infection.",
                                    weight=8, hit=80, critical=110, element="mighty", status=[Venom, Plague, Infection], statsUsed=["magic", "resistance", 1.5],
                                    condition=lambda enemy, target: sum(1 for s in target.statusList if s.align == "Positive") >= 3 or any("Venom" == s.name for s in target.statusList), conditional=underhanded_tactics_conditional)

def abysmal_greed_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    enemy_positive = [s for s in target.statusList if s.align == "Positive" and not any(u.name == s.name for u in user.statusList)]

    if len(enemy_positive) >= 2:
        random.shuffle(enemy_positive)

        count = 0
        for status in enemy_positive:
            if count >= 3:
                break

            if random.randint(1, 100) > 75 and status.name != "Mana Regen":
                Status.allStatuses[status.name].inflict(user)
                count += 1

    userPositiveCount = sum(1 for s in user.statusList if s.align == "Positive")
    enemyPositiveCount = sum(1 for s in target.statusList if s.align == "Positive")

    if enemyPositiveCount < userPositiveCount and target.sanity < user.sanity:
        BoostIII.inflict(user)

    elif enemyPositiveCount > userPositiveCount and target.sanity > user.sanity:
        CrippleII.inflict(user)
        CloudedII.inflict(user)

    positives = [s for s in user.statusList if s.align == "Positive"]
    negatives = [s for s in user.statusList if s.align == "Negative"]

    count = 0
    for _ in positives:
        if not negatives:
            break

        if random.randint(1, 100) > 65:
            status = random.choice(negatives)
            negatives.remove(status)
            status.remove(user, full=True)
            count += 1

        if count >= 2:
            break
bpassive_abysmal_greed = EnemySkill("Abysmal Greed", [PASSIVE],
                               "If opposer has 2+ Positive statuses that is not present on the user, chance to gain 2-3 of the opposers Positive statuses. If the number of Positive statuses the opposer has and their sanity are lower than users, gain Boost III. If the number of Positive statuses the opposer has and their sanity are greater than the users, gain Cripple II/Clouded II. For each Positive status present, chance to remove 1 Negative status.")
bpassive_abysmal_greed.passive = types.MethodType(abysmal_greed_passive, bpassive_abysmal_greed)

##--Mamzer the Bastard Lycon--##

def moons_sanatio_effect(self, user: Enemy, target: Player, actions=1): 
    say(f"{user.name} Used {self.name}!")

    CrimsonMoonsBlessing.inflict(user)
    
    heal = round(user.maxHealth * 0.25)
    user.health += heal
    if user.health > user.maxHealth:
        user.health = user.maxHealth
    say(f"{Color['green']}{target.name}s Health Was Restored By {heal}!{Color['reset']}")
    
    for s in user.statusList[:]:
        if s.align == "Negative":
            s.remove(user, full=True)
            break
bskill_moons_sanatio = EnemySkill("Moon's Sanatio", [SPECIAL],
                            "Only usable below 45% health. Remove 1 Negative status. Restore health (25% of Max Health). Gain Crimson Moon's Blessing.",
                            weight=8, customEffect=moons_sanatio_effect, 
                            condition=lambda enemy, target: not any("Crimson Moon's Blessing" == s.name for s in enemy.statusList), weightConditional=lambda enemy, target, actions: enemy.health <= round(enemy.maxHealth * 0.45) and actions % 5 == 0)

bskill_pillage = EnemySkill("Pillage", [DAMAGE], 
                            "Strength vs. Defense. Restore health (15% of damage dealt). Will inflict 3 stacks of Hemorrhage/Break. ",
                            weight=11, hit=60, critical=160, element="physical", status=[Hemorrhage, Break], stacks=3, willStatus=True, statsUsed=["strength", "defense", 2], damHeal=0.15, meter="health",
                            condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.5))

def cruentos_amor_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Crimson Moon's Blessing" == s.name for s in user.statusList):
        CrippleII.inflict(target)
        damage *= 2
    return damage
bskill_cruentos_amor = EnemySkill("Cruentos Amor", [DAMAGE, [MULTI, 3]], 
                            "Strength vs. Defense x 3. If Crimson Moon's Blessing is present, inflict Cripple II and increase damage (2x!). Chance to inflict Bleed/Gash/Puncture.",
                            weight=9, hit=90, critical=100, element="physical", status=[Bleed, Gash, Puncture], statsUsed=["strength", "defense", 1.5],
                            condition=lambda enemy, target: any("Crimson Moon's Blessing" == s.name for s in enemy.statusList) or not (enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and enemy.lastSkill.name == "Cruentos Amor"), conditional=cruentos_amor_conditional)

def living_remant_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    blessing = next((status for status in user.statusList if status.name == "Crimson Moon's Blessing"), None)
    if blessing:
        blessing.count += 1
    
        for status in target.statusList:
            if status.family == "Bleed" and random.randint(1,100) >= 70:
                blessing.duration -= 1
                if blessing.duration < 0:
                    blessing.duration = 0
        
        if blessing.count == 4:
            ToughII.inflict(user, 2)
        if blessing.count == 5:
            BoostII.inflict(user)
        if blessing.count == 6:
            Shock.inflict(user, 2)
            
    if user.lastAction and user.lastAction == "Skill" and user.lastSkill and user.lastSkill.name in ["Cruentos Amor", "Pillage"] and sum(1 for s in target.statusList if s.family == "Bleed") >= 2:
        count = 0
        for status in target.statusList:
            if random.randint(1,100) >= 50:
                status.duration -= 1
                if status.duration < 0:
                    status.duration = 0
                say(f"{Color['magenta']}{status.name} Had Its Duration Extended By 1!{Color['reset']}")
                count += 1
            if count >= 2: 
                break
bpassive_living_remnant = EnemySkill("The Living Remnant", [PASSIVE],
                                "If Crimson Moon's Blessing is present: For each Bleed status present on the opposer, chance to extend the duration of Crimson Moon's Blessing. If Crimson Moon's Blessing was present for 4/5/6 actions, gain 2 stacks of Tough  II/Boost II/Shock. If last used skill was Cruentos Amor or Pillage and 2+ Bleed statuses are present on the opposer, chance to extend 2 Bleed statuses duration by 1. ")
bpassive_living_remnant.passive = types.MethodType(living_remant_passive, bpassive_living_remnant)

##--Dionus Lord of the Twin Moons--##

def finest_wine_effect(self, user: Enemy, target: Player, actions=1):
    user.speedMeter += 15
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
    bpassive_lord_moons.passive(user, target, 0)
    return self.healEffect(user, target, who="enemy")
bskill_finest_wine = EnemySkill("Finest Wine", [HEAL],
                                "Restore health (10% of Max Health). Increase Speed Meter by 20. Trigger Lord the Twin Moons.",
                                weight=13, statsUsed=[[("maxHealth", 10)], "health"], customEffect=finest_wine_effect,
                                condition=lambda enemy, target: enemy.health < round(enemy.maxHealth * 0.65))

def lords_firaja_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if sum(1 for s in user.statusList + target.statusList if s.name in ["Crimson Moon's Blessing", "Charm", "Lust", "Frigid", "Devoid", "Avarice"]) >= 2:
        Ill.inflict(target)
        FrailI.inflict(target)
    return damage
bskill_lords_friaja = EnemySkill("Lord's Firaja", [DAMAGE, [MULTI, 2]],
                                 "Magic vs. Resistance x 2. If opposer has any 2 Lust/Charm/Frigid/Devoid/Avarice, inflict Ill/Frail I. Chance to inflict 2 stacks of Burn/Heated/Molten.",
                                 weight=11, hit=100, critical=65, element="fire", status=[Burn, Heated, Molten], stacks=2, statsUsed=["magic", "resistance", 2],
                                 condition=lambda enemy, target: sum(1 for s in enemy.statusList + target.statusList if s.name in ["Crimson Moon's Blessing", "Charm", "Lust", "Frigid", "Devoid", "Avarice", "Burn", "Heated", "Molten"]), conditional=lords_firaja_conditional)

def lords_aura_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if (user.health / user.maxHealth) * 100 > (target.health / target.maxHealth) * 100:
        Ill.inflict(target)
    
    if target.health < round(target.maxHealth * 0.45):
        FrailII.inflict(target)
        Ill.inflict(target)
    return damage
bskill_lords_aura = EnemySkill("Lord's Aura", [DAMAGE, [MULTI, HITS(1,5)]], 
                               "Magic vs. Resistance x 1-5. If health percent is greater than opposers health perccent, inflict Ill. If opposers health is below 45%, inflict Ill/Frail II. Chance to inflict Bind II/Slow II.",
                               weight=13, hit=75, critical=150, element="mighty", status=[BindII, SlowII], statsUsed=["magic", "resistance", 1.5],
                               condition=lambda enemy, target: (enemy.health / enemy.maxHealth) * 100 > (target.health / target.maxHealth) * 100 or target.health < round(target.maxHealth * 0.45), conditional=lords_aura_conditional)

def lord_moons_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions <= 1 and target.actions <= 1:
        self.trigOne = False
        self.trigTwo = False
        
    status = [CrimsonMoonsBlessing, Charm, Frigid, Devoid, Avarice]
    count = 0
    for s in status[:]:
        if random.randint(1, 100) + user.luck >= target.luck + 40:
            if s.name == "Crimson Moon's Blessing":
                s.inflict(user)
                count += 1
            else:
                s.inflict(target)
                count += 1
            
            if count >= 2:
                break
    
    if user.health <= round(user.maxHealth * 0.4) and not self.trigOne:
        BoostII.inflict(user)
        ToughI.inflict(user, 3)
        self.trigOne = True
    
    if self.trigOne:
        try:
            next(s for s in user.statusList if s.name == "Boost II").duration = 0
            next(s for s in user.statusList if s.name == "Tough I").duration = 0
        except StopIteration:
            pass

    if user.health <= round(user.maxHealth * 0.5) and not self.trigTwo:
        user.health += round(user.maxHealth * 0.25)
        say(f"{Color['green']}{user.name} Restored {round(user.maxHealth * 0.25)} Health!{Color['reset']}")
        loss = target.mana // 2
        target.mana -= loss
        say(f"{Color['red']}{target.name} Lose {loss} Mana!{Color['reset']}")
        self.trigTwo = True
bpassive_lord_moons = EnemySkill("Lord of the Twin Moons", [PASSIVE],
                                 "Chance to; gain Crimson Moon's Blessing/inflict (max 2 statuses) 2 stacks of Charm/Frigid/Devoid/Avarice. Once, at 50% health, restore health (25% of Max Health) and halve opposers mana. Once, at 40% of health, gain permanent 3 stacks of Tough I/Boost II.")
bpassive_lord_moons.passive = types.MethodType(lord_moons_passive, bpassive_lord_moons); bpassive_lord_moons.trigOne = False; bpassive_lord_moons.trigTwo = False

##--Chionizei, Bringer of Snow--##

def eight_cage_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 4
    if user.sanity >= 10:
        user.sanity += 5
        Haze.inflict(user)
        
        if random.randint(1, 100) >= 60:
            DeepFreeze.inflict(target)
    
    if any(s.name == "Deep Freeze" for s in target.statusList):
        Glint.inflict(target, 2)
        LunarBind.inflict(target)
    
    if target.sanity >= 10:
        target.sanity -= 15
    
    return damage 
bskill_eight_cage = EnemySkill("Eight-Sided Ice Cage", [DAMAGE, [MULTI, HITS(1,8)]],
                                     "Magic vs. Resistance x 1-8. If sanity is at 10+, gain 5 sanity, gain Haze, chance to inflict Deep Freeze. If Deep Freeze is present on the opposer, inflict 2 stacks of Glint/Lunar Bind. If opposers sanity is at 10+, lower opposers sanity by 15. Gain 4 sanity. Chance to inflict 2 stacks of Glint/Frostbite/Absolute Zero/Bind II.",
                                     weight=17, hit=80, critical=100, element="ice", status=[Glint, Frostbite, AbsoluteZero, BindII], stacks=2, statsUsed=["magic", "resistance", 1.6],
                                     condition=lambda enemy, target: enemy.sanity >= 10 or any(s.name == "Deep Freeze" for s in target.statusList) or target.sanity >= 10, conditional=eight_cage_conditional)

def moons_blessing_conditional(self, user: Enemy, target: Player, actions=1):
    if user.sanity >= 10:
        Power.inflict(user, 2)
        user.sanity -= 5
    
    if any(s.name == "Lunar Bind" for s in target.statusList):
        FullPower.inflict(user)
    
    Glint.inflict(target, 2)
    Frigid.inflict(target, 2)
    
    user.sanity += 5
bskill_moons_blessing = EnemySkill("Moon's Blessing", [STATUS],
                                   "Gain Boost II. Inflict 2 stacks of Glint/Frigid. If sanity is at 10+, gain 2 stacks of Power and lose 5 sanity. If Lunar Bind is present on the opposer, gain Full Power. Gain 5 sanity.",
                                   weight=15, status=[BoostII], statusTarget="user", 
                                   condition=lambda enemy, target: enemy.sanity >= 10 or enemy.sanity <= 0 or any(s.name == "Lunar Bind" for s in target.statusList), conditional=moons_blessing_conditional)

def hibernate_conditional(self, heal: int, user: Enemy, target: Player):
    user.sanity += 4
    
    if user.sanity >= 15:
        Protection.inflict(user, 2)
        user.sanity -= 10
    
    if user.health <= round(user.maxHealth * 0.5):
        Vitality.inflict(user)
    
    Rejuvenate.inflict(user, 10)
    ToughII.inflict(user)
    
    return heal
bskill_hibernate = EnemySkill("Hibernate", [HEAL],
                              "Restore health (10% of Max Health + 75% of Magic). If sanity is at 15+, gain 2 stacks of Protection and lose 10 sanity. If health is below 50%, gain Vitality. Gain 4 sanity. Gain 10/1 stacks of Rejuvenate/Tough II.",
                               weight=13, statsUsed=[[("magic", 75), ("maxHealth", 10)], "health"],
                               condition=lambda enemy, target:  enemy.health <= round(enemy.maxHealth * 0.5) or enemy.sanity >= 15 or any(setS is not None and setS[0] in ["defense", "resistance"] for s in enemy.statusList for setS in s.mutate) or any(s.name == "Fragile" for s in enemy.statusList), conditional=hibernate_conditional)

def freezing_eye_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.lastAction and target.lastAction == "Skill" and target.lastSkill.element and target.lastSkill.element == "fire":
        Rejuvenate.inflict(user, 2)
        Shell.inflict(user, 2)
    else:
        Glint.inflict(target)
        Frigid.inflict(target)
        user.sanity += 3
    
    if user.sanity >= 20:
        user.sanity += 5
        DeepFreeze.inflict(target)
bpassive_freezing_eye = EnemySkill("Freezing Eye", [PASSIVE],
                                   "If opposer used a Fire element skill, gain 2 stacks of Rejuvenate/Shell. If opposer did not use a Fire element skill, inflict 1 stack of Glint/Frigid and gain 3 sanity. If sanity is at 20+, inflict Deep Freeze and gain 5 sanity.")
bpassive_freezing_eye.passive = types.MethodType(freezing_eye_passive, bpassive_freezing_eye)

##--Kataigida, Bringer of Storms--##

def seven_charged_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Electric Bridge" for s in target.statusList):
        Haste.inflict(user)
    
    if any(s.name == "Slug" for s in target.statusList):
        Power.inflict(user, 2)
        
        arc = next((s for s in target.statusList if s.name == "Arc"), None)
        if arc and random.randint(1, 100) >= 60:
            arc.duration -= 2
            say(f"{Color['magenta']}Arc Had Its Duration Extended By 2!{Color['reset']}")
    return damage
bskill_seven_charged = EnemySkill("Seven-Charged Strikes", [DAMAGE, [MULTI, HITS(3, 7)]],
                                  "Strength vs. Defense x 3-7. If Electric Bridge is present on the opposer, gain 1 stack of Haste. If Slug is present on the opposer, gain 2 stacks of Power and if Arc is present on the opposer, chance to extend its duration by 2. Chance to inflict 3 stacks of Spark/Static/Cripple II.",
                                  weight=16, finsher=True, hit=70, critical=125, element="thunder", status=[Spark, Static, CrippleII], stacks=3, statsUsed=["strength", "defense", 2.2],
                                  conditional=seven_charged_conditional, condition=lambda enemy, target: any(s.name in ["Electric Bridge", "Slug", "Arc"] for s in target.statusList))

def lightning_dance_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name in ["Static", "Spark"] for s in target.statusList):
        Arc.inflict(target)
        Shock.inflict(target)
        Fragile.inflict(target)
    
    user.speedMeter += 15
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
bskill_lightning_dance = EnemySkill("Lightning Dance", [STATUS], 
                                    "Gain 2 stacks of Charge/Boon. If Static or Spark is present on the opposer, inflict Arc/Shock/Fragile. Raise Speed Meter by 15.",
                                    weight=14, opener=True, status=[Charge, Boon], stacks=2, statusTarget="user", 
                                    condition=lambda enemy, target: any(s.name in ["Static", "Spark"] for s in target.statusList) or not any(s.name in ["Charge", "Boon"] for s in enemy.statusList), conditional=lightning_dance_conditional)

def thunderous_drums_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Arc" for s in target.statusList) and not sum(1 for s in target.statusList if s.family == "Shock" and s.name not in ["Arc", "Electric Bridge"]) >= 2:
        Static.inflict(target)
    
    if any(s.name == "Electric Bridge" for s in target.statusList):
        Spark.inflict(target, 2)
        ShortCircuit.inflict(target, 2)
    
    Boon.inflict(user, 2)
    return damage
bskill_thunderous_drums = EnemySkill("Thunderous Drums", [DAMAGE, [MULTI, HITS(1,3)]],
                                     "Strength vs. None x 1-3. If Arc is present on the opposer and 2+ Shock statuses are not present (excluding Arc/Electric Bridge), inflict Static. If Electric Bridge is present on the opposer, inflict 2 stacks of Spark/Short Circuit. Gain 2 stacks of Boon. Chance to inflict 2 stacks of Spark/Slug.",
                                     weight=17, hit=65, critical=100, element="thunder", status=[Spark, Slug], stacks=2, statsUsed=["strength", None, 1.6],
                                     conditional=thunderous_drums_conditional, condition=lambda enemy, target:(any(s.name == "Arc" for s in target.statusList) and sum(1 for s in target.statusList if s.family == "Shock" and not s.name in ["Arc", "Electric Bridge"]) < 2) or any(s.name == "Electric Bridge" for s in target.statusList) or not any(s.name == "Slug" for s in target.statusList))

def roaring_laughter_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if any(s.name == "Haste" for s in user.statusList):
        Charge.inflict(user)
        Keen.inflict(user)
    
    if any(s.name == "Slug" for s in target.statusList):
        if target.lastAction and target.lastAction == "Skill" and "Damage" in target.lastSkill.type_:
            Haste.inflict(user)
    
    if any(s.name == "Spark" and s.stacks >= 10 for s in target.statusList):
        Arc.inflict(target)
bpassive_roaring_laughter = EnemySkill("Roaring Laughter", [PASSIVE],
                                       "If Haste is present, gain 1 stack of Charge/Keen. If Slug is present on the opposer and the opposer used a damaging skill, gain 1 stack of Haste. If Spark is present on the opposer and at 10+ stacks, inflict Arc.")
bpassive_roaring_laughter.passive = types.MethodType(roaring_laughter_passive, bpassive_roaring_laughter)

##--Vilis, the Vile One--##

def infinite_defect_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    poison = 0
    for status in target.statusList:
        if status.family == "Poison":
            status.count += 2
            say(f"{Color['green']}{target.name} Gained 2 Count Of {self.name}!{Color['reset']}")
            poison += 1
        
    if user.ultimateMeter >= 50:
        user.ultimateMeter -= 25
        say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Reduced By 25!{Color['reset']}")
        
        damage = round(user.magic * 0.5 * (poison if poison > 0 else 1))
        target.health -= damage
        say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}s Health !{Color['reset']}")
    
    for status in self.status:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            status.inflict(target, self.stacks)
bskill_infinite_defect = EnemySkill("Infinite Defect", [SPECIAL],
                                    "For each Poison status present on the opposer, increase count by 2. If Ultimate Meter is at 50+, reduce Ultimate Meter by 25 and deal damage (50% of Magic x number of Poison statuses present on the opposer). Chance to inflict Slow II/Rot/Blight.",
                                    weight=5, status=[SlowII, Rot, Blight], customEffect=infinite_defect_effect, 
                                    condition=lambda enemy, target: sum(1 for s in target.statusList if s.family == "Poison") >= 3 or sum(s.count for s in target.statusList if s.family == "Poison") <= 10)

def undae_ventae_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.ultimateMeter >= 50:
        user.ultimateMeter -= 25
        say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Reduced By 25!{Color['reset']}")
        
        poison = 0
        cap = random.randint(1,2)
        for status in target.statusList:
            if status.family == "Poison":
                status.count += 1
                poison += 1
                say(f"{Color['green']}{target.name} Gained 1 Count Of {self.name}!{Color['reset']}")
                
            if poison >= cap:
                break
            
        damage *= 2
    return damage
bskill_undae_ventae = EnemySkill("Undae Ventae", [DAMAGE, [MULTI, HITS(3,4)]],
                                 "Strength vs. Defense x 3-4. If Ultimate Meter is at 50+, reduce Ultimate Meter by 25, raise 1-2 Poison statuses count by 1, and increase damage (2x!). Chance to inflict 3 stacks of Deadly Poison/Venom/Plague.",
                                  weight=13, hit=70, critical=80, element="mighty", status=[DeadlyPoison, Venom, Plague], statsUsed=["strength", "defense", 2],
                                  conditional=undae_ventae_conditional, condition=lambda enemy, target: enemy.ultimateMeter >= 50)

def globus_luti_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.ultimateMeter >= 50:
        user.ultimateMeter -= 30
        say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Reduced By 30!{Color['reset']}")
        
        BoostII.inflict(user)
        
        count = 0
        cap = random.randint(1,3)
        for status in target.statusList[:]:
            if "Damage" in status.type_ and "Poison" == status.family:
                if "Special" not in status.type_:
                    status.simple(target)
                else:
                    status.special(target)
                count += 1
            if count >= cap:
                break
    return damage
bskill_globus_luti = EnemySkill("Globus Luti", [DAMAGE],
                                 "Strength vs. Defense. If Ultimate Meter is at 50+, reduce Ultimate Meter by 30, gain Boost II, and retrigger 1-3 Poison statuses present on the opposer. Chance to inflict 4 stacks of Deadly Poison/Poison/Muddy/Infection/Corruption.",
                                  weight=10, finsher=True, hit=65, critical=80, element="mighty", status=[DeadlyPoison, Poison, Muddy, Infection, Corruption], statsUsed=["strength", "defense", 2],
                                  condition=lambda enemy, target: enemy.ultimateMeter >= 60)

def one_corruption_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    count = 0
    cap = random.randint(1, 2)
    for status in user.statusList[:]:
        if status.align == "Negative" and random.randint(1, 100) >= 45:
            count += 1
            status.remove(user, full=True)
            user.ultimateMeter += 10
            say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 10!{Color['reset']}")
            user.speedMeter += 10
            say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 10!{Color['reset']}")
        
        if count >= cap:
            break
        
    if user.health < round(user.maxHealth * 0.35):
        for status in target.statusList:
            if status.family == "Poison" and status.count < 10:
                status.count = 10          
bpassive_one_corruption = EnemySkill("One With Corruption", [PASSIVE],
                                          "For 1-2 Negative statuses present, chance to remove it and raise Ultimate/Speed Meter by 10. If health is below 35%, for each Poison status present on the opposer, set count to 10 (if count is below 10).")
bpassive_one_corruption.passive = types.MethodType(one_corruption_passive, bpassive_one_corruption)

##--Solumn Lament--##

def butterfly_flight_conditional(self, user: Enemy, target: Player, actions=1):
    user.speedMeter += 15
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
bskill_butterfly_flight = EnemySkill("A Butterfly Takes Flight", [STATUS],
                                     "Gain Coffin. Raise Speed Meter by 15.",
                                     weight=10, opener=True, status=[Coffin], statusTarget="user", 
                                     condition=lambda enemy, target: any(s[0] > s[1] for s in [[target.magic, enemy.resistance], [target.strength, enemy.defense]]), conditional=butterfly_flight_conditional)

def celebration_departed_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 2
    
    if user.sanity >= 5:
        Butterfly.inflict(target)
    
    if target.sanity <= -10:
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            Burnout.inflict(target)
    
    return damage
bskill_celebration_departed = EnemySkill("Celebration for the Departed", [DAMAGE, [MULTI, 2]],
                                         "Strength vs. Defense x 2. If sanity is at 5+, inflict Butterfly. If opposers sanity is below -10, chance to inflict Burnout. Gain 2 sanity. Will inflict Sinking.",
                                         weight=14, hit=70, critical=70, element="mighty", status=[Sinking], willStatus=True, statsUsed=["strength", "defense", 2],
                                         condition=lambda enemy, target: enemy.sanity >= 5 or target.sanity <= -10, conditional=celebration_departed_conditional)

def lament_living_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 3
    target.sanity -= 3
    
    if user.sanity >= 10:
        Sinking.inflict(target, 2)
        Butterfly.inflict(target, 2)
        
    if any(s.name == "Deluge" for s in target.statusList):
        Butterfly.inflict(target, 3)
        next(status for status in target.statusList if status.name == "Deluge").remove(target)
    return damage
bskill_lament_living = EnemySkill("Lament for the Living", [DAMAGE, [MULTI, 3]],
                                  "Strength vs. Defense x 3. If sanity is at 10+, inflict 2 stacks of Butterfly/Sinking. If Deluge is present on the opposer, remove it and inflict 3 stacks of Butterfly. Gain 3 sanity. Opposer loses 3 sanity. Will inflict Sinking.",
                                  weight=9, finsher=True, hit=75, critical=100, element="mighty", status=[Sinking], willStatus=True, statsUsed=["strength", "defense", 2],
                                  condition=lambda enemy, target: enemy.sanity >= 10 or any(s.name == "Deluge" for s in target.statusList), conditional=lament_living_conditional)

def hand_salvation_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if (target.lastSkill and "Damage" in target.lastSkill.type_) and (target.lastAction and target.lastAction == "Skill") or (target.lastAction and target.lastAction == "Attack"):
        if random.randint(1,100) >= 40:
            if not any(s.name == "Deluge" for s in target.statusList):
                Sinking.inflict(target)
            else:
                Butterfly.inflict(target)
bpassive_hand_salvation = EnemySkill("Hand of Salvation", [PASSIVE],
                                     "If opposer attacked or used a damaging skill last action, chance to inflict Sinking/Butterfly (if Deluge is present on the opposer).")
bpassive_hand_salvation.passive = types.MethodType(hand_salvation_passive, bpassive_hand_salvation)

##--Court Jester, God of Magic--##

def luck_cards_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    chance = 0.1
    for i in range(0, user.luck, 5):
        chance += 0.05
    
    if random.random() <= chance:
        say(f"{Color['yellow']}{user.name}s Luck!{Color['reset']}")
        BoostIII.inflict(user)
        user.speedMeter += 40
    
    else:
        say(f"{Color['yellow']}{target.name}s Luck!{Color['reset']}")
        BoostIII.inflict(target)
        target.speedMeter += 20
bskill_luck_cards = EnemySkill("Luck of the Cards", [SPECIAL],
                               "At a chance of 10% + 5% per 5 points of Luck, either gain Boost III and raise Speed Meter by 40 or inflict Boost III and raise opposers Speed Meter by 20.",
                               weight=50, opener=True, weightConditional=lambda enemy, target, actions: enemy.actions % 3 == 0, customEffect=luck_cards_effect,)

def ball_juggle_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if random.randint(1,100) >= 50:
        damage = round(max(0,  getattr(user, self.statsUsed[0]) + random.randint(1, 5) - (getattr(target, "defense") // 2)) * self.statsUsed[2])
    else:
        damage = round(max(0,  getattr(user, self.statsUsed[0]) + random.randint(1, 5) - (getattr(target, "resistance") // 2)) * self.statsUsed[2])
    
    if user.luck + random.randint(1,50) >= 140:
        damage *= 2
        
        random.choice([AbsoluteZero, Radiant]).inflict(target)
    
    return damage
bskill_ball_juggle = EnemySkill("Ball Juggle", [DAMAGE],
                                "Magic vs. Resistance or Defense (50/50) x 1-3. If Luck + 1-50 is greater than 140, increase damage (2x!) and inflict either; Absolute Zero or Radiant. Chance to inflict either; 3 stacks of Burn/Heated/Freeze/Ice Veins.",
                                 weight=13, hit=80, critical=50, element="physical", status=[[Burn, Radiant], [Heated, Radiant], [Freeze, AbsoluteZero], [IceVeins, AbsoluteZero]], stacks=3, statsUsed=["magic", "resistance", 2],
                                 condition=lambda enemy, target: enemy.luck >= 110, conditional=ball_juggle_conditional)

def contagious_laughter_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 10
    
    if user.luck > target.luck:
        Oopsie.inflict(target)
        Stun.inflict(target)
        
    return damage
bskill_contagious_laughter = EnemySkill("Contagious Laughter", [DAMAGE, [MULTI, HITS(1,6)]],
                                        "Magic vs. Resistance x 1-6. If Luck is greater than opposers, inflict Oopsie/Stun. Gain 10 sanity. Chance to inflict Bind II.",
                                        weight=11, hit=60, critical=145, element="physical", status=[BindII], statsUsed=["magic", "resistance", 1.5],
                                        condition=lambda enemy, target: enemy.luck > target.luck, conditional=contagious_laughter_conditional)

def laughing_matter_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    user.luck += 5 
    
    if user.actions % 3 == 0:
        user.speed += 2
    
    if user.luck > 100:
        FrailII.inflict(target)
        for status in target.statusList:
            if status.name == "Frail II":
                status.duration = 0

    if user.luck > 115:
        user.ultimateMeter += 10
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 10!{Color['reset']}")
    
    if user.luck > 130:
        CrippleII.inflict(target)
        for status in target.statusList:
            if status.name == "Cripple II":
                status.duration = 0
bpassive_laughing_matter = EnemySkill("Laughing Matter", [PASSIVE], 
                                      "After every action, raise Luck by 5. After every 3 user actions, raise Speed by 2. If Luck is greater than 100, inflict Frail II/set Frail II duration to 0. If Luck is greater than 115, raise Ultimate Meter by 10. If Luck is greater than 130, inflict Cripple II (Once). ")
bpassive_laughing_matter.passive = types.MethodType(laughing_matter_passive, bpassive_laughing_matter)

##--Comedic Delusions--##

def jolly_giggle_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity -= 3
    
    DelusionsOfGrandeur.inflict(user, 2)
    
    if user.sanity <= -5:
        next(s for s in user.statusList if s.name == "Delusions of Grandeur").remove(user)
    
    return damage
bskill_jolly_giggle = EnemySkill("Jolly Giggle", [DAMAGE],
                                 "Magic vs. Resistance. Lose 3 sanity. If sanity is below -5, lose 1 stack of Delusions of Grandeur. Gain 2 stacks of Delusions of Grandeur. Chance to inflict Clouded II/Consumed.",
                                 weight=12, opener=True, hit=100, critical=100, element="physical", status=[CloudedII, Consumed], statsUsed=["magic", "resistance", 2],
                                 condition=lambda enemy, target:enemy.sanity <= -5, conditional=jolly_giggle_conditional)

def laugh_mock_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Delusions of Grandeur" and s.stacks >= 5 for s in user.statusList):
        next(s for s in user.statusList if s.name == "Delusions of Grandeur").remove(user)
        BindII.inflict(target)
        damage *= 2
    return damage
bskill_laugh_mock = EnemySkill("Laugh and Mock", [DAMAGE, [MULTI, 5]],
                               "Magic vs. Resistance x 5. If Delusions of Grandeur is present and at 5+ stacks, remove 1 stack of Delusions of Grandeur, inflict Bind II, and increase damage (2x!). Chance to inflict 3 stacks of Frostbite/Freeze/Cripple II.",
                               weight=9, hit=75, critical=90, element="ice", status=[Frostbite, Freeze, CrippleII], stacks=3, statsUsed=["magic", "resistance", 1],
                               condition=lambda enemy, target: any(s.name == "Delusions of Grandeur" and s.stacks >= 5 for s in enemy.statusList), conditional=laugh_mock_conditional)

def mask_slip_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Delusions of Grandeur" and s.stacks >= 5 for s in user.statusList):
        target.sanity -= 5 + next(s for s in user.statusList if s.name == "Delusions of Grandeur").stacks
        next(s for s in user.statusList if s.name == "Delusions of Grandeur").remove(user, 3)
    
    if user.health < round(user.maxHealth * 0.45):
        damage = round(user.magic * 1.5)
        target.health -= damage
        say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}s Health!{Color['reset']}")
bskill_mask_slip = EnemySkill("Mask Slip", [STATUS],
                              "Will inflict Engulfed. If Delusions of Grandeur is present and at 5+ stacks, opposer loses 5 + stacks of Delusions of Grandeur sanity and remove 3 stacks of Delusions of Grandeur. If health is below 45%, deal damage (150% of Magic).",
                               weight=10, status=[Engulfed], 
                               condition=lambda enemy, target: any(s.name == "Delusions of Grandeur" and s.stacks >= 5 for s in enemy.statusList) or enemy.health <= round(enemy.maxHealth * 0.45), conditional=mask_slip_conditional)

##-- 

def shattering_outburst_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Broken Facade" for s in user.statusList):
        next(s for s in user.statusList if s.name == "Broken Facade").remove(user)
        DeepFreeze.inflict(target)
        damage *= 3
    
    if user.health < round(user.maxHealth * 0.5):
        user.sanity -= 3
        user.ultimateMeter += 25
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")
    
    return damage
bskill_shattering_outburst = EnemySkill("Shattering Outburst", [DAMAGE, [MULTI, HITS(1,3)]],
                                        "Magic vs. Resistance x 1-3. If Broken Facade is present, lose Broken Facade, inflict Deep Freeze, and increase damage (3x!). If health is below 50%, lose 3 sanity and raise Ultimate Meter by 25. Chance to inflict Bind II. ",
                                        weight=11, hit=60, critical=150, element="thunder", status=[BindII], statsUsed=["magic", "resistance", 1.3],
                                        condition=lambda enemy, target: any(s.name == "Broken Facade" for s in enemy.statusList) or enemy.health <= round(enemy.maxHealth * 0.5), conditional=shattering_outburst_conditional, sanLean="Negative")
     
def facade_break_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    BrokenFacade.inflict(user)
    
    if user.health < round(user.maxHealth * 0.5):
        user.ultimateMeter += 25
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")
        damage = round(damage * 1.5)
        
    if user.sanity <= -10:
        Consumed.inflict(user)
        damage *= 2
    
    return damage
bskill_facade_break = EnemySkill("Facade Break", [DAMAGE, [MULTI, 2]],
                                 "Magic vs. Resistance x 2. If health is below 50%, raise Ultimate Meter by 25 and increase damage (1.5x). If sanity is below -10, gain Consumed and increase damage (2x!). Gain Broken Facade. Chance to inflict 2 stacks of Sinking/Frostbite. Take recoil (40% of damage).",
                                 weight=14, hit=80, critical=100, element="ice", status=[Sinking, Frostbite], stacks=2, statsUsed=["magic", "resistance", 1.5], recoil=[True, 40],
                                 condition=lambda enemy, target: enemy.health <= round(enemy.maxHealth * 0.5) or enemy.sanity <= -10, conditional=facade_break_conditional, sanLean="Negative")

def piece_together_conditional(self, heal: int, user: Enemy, target: Player):
    user.sanity -= 3
    
    if user.ultimateMeter >= 50:
        user.ultimateMeter -= 50
        Regen.inflict(user)
        BoostII.inflict(user)
    
    return heal
bskill_piece_together = EnemySkill("Piece Together", [HEAL],
                                   "Restore health (Resistance x 3). Lose 3 sanity. If Ultimate Meter is at 50+, lose 50 Ultimate Meter and gain Regen/Boost II.",
                                    weight=9, statsUsed=[[("resistance", 300)], "health"],
                                    condition=lambda enemy, target:  enemy.health <= round(enemy.maxHealth * 0.75), conditional=piece_together_conditional)

def blank_mask_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions % 4 == 0:
        for status in target.statusList[:]:
            if status.align == "Positive" and random.randint(1,100) >= 45:
                status.remove(target, full=True)
                
    for status in user.statusList[:]:
        if status.family in ["Bleed", "Burn", "Poison"]:
            status.remove(user, full=True)
bpassive_blank_mask = EnemySkill("Blank Mask", [PASSIVE], 
                                 "Every 4 user actions, for each Positive status present on the opposer, chance to remove it. If any Poison/Burn/Bleed statuses are present, chance to remove it.")
bpassive_blank_mask.passive = types.MethodType(blank_mask_passive, bpassive_blank_mask)

##-- 

bskill_confusing_fake = EnemySkill("Confusing Fake", [DAMAGE, [MULTI, 3]],
                                   "Magic vs. Resistance x 3. Chance to inflict Stun.",
                                   weight=15, hit=80, critical=150, element="mighty", status=[Stun], statsUsed=["magic", "resistance", 2.5])

def world_isolate_conditional(self, user: Enemy, target: Player, actions=1):
    user.speedMeter += 30
    user.ultimateMeter += 30
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 30!{Color['reset']}")
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 30!{Color['reset']}")
bskill_world_isolate = EnemySkill("World Isolate", [STATUS],
                                  "Gain Isolation. Increase Speed/Ultimate Meter by 30.",
                                  weight=12, status=[Isolation], statusTarget="user", 
                                  condition=lambda enemy, target: enemy.actions % 4 == 0, conditional=world_isolate_conditional)

def consumption_self_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    user.health -= round(user.magic * 0.75 * 2)
    say(f"{Color['red']}{user.name} Lost {round(user.magic * 0.75 * 2)} Health!{Color['reset']}")
    
    for status in [Frostbite, Deluge, Engulfed, Consumed]:
        status.inflict(target, 5)
bskill_consumption_self = EnemySkill("Consumption of Self", [SPECIAL],
                                     "Lose health (75% of Magic x 2). Will inflict 5 stacks of Frostbite/Deluge/Engulfed/Consumed.",
                                     weight=100, customEffect=consumption_self_effect, weightConditional=lambda enemy, target, actions: enemy.actions % 3 == 0 and enemy.health <= round(enemy.maxHealth * 0.25))

def acceptance_self_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions % 3 == 0:
        for status in user.statusList[:]:
            if status.family == "Mental" and status.name != "Isolation":
                status.remove(user, full=True)
                user.sanity -= 2
                ToughII.inflict(user, 2)
bpassive_acceptance_self = EnemySkill("Acceptance of Self", [PASSIVE],
                                      "Every 3 user actions, for each Mental status present, remove it, lose 2 sanity, and Tough II.")
bpassive_acceptance_self.passive = types.MethodType(acceptance_self_passive, bpassive_acceptance_self)

##--Knight of Orion--##

def sword_tunnel_effect(self : EnemySkill, user: Enemy, target: Player, actions=1):
    if self.useCheck(user, target, "enemy"):
        boon = 0
        failure = False
        qtTarget = 2 if user.health >= round(user.maxHealth * 0.50) else 1.5
        try:
            for i in range(random.randint(3,4)):
                start = time.perf_counter()
                qt = "".join(random.choices(string.ascii_lowercase, k=3))
                res = inputimeout(prompt=f"{Color['red']}Input {Color['green']}{qt}{Color['yellow']}!{Color['reset']}:", timeout=qtTarget).lower()
                end = time.perf_counter()
                used = end - start
                
                if res == qt:
                    if used < qtTarget // 2:
                        say(f"{Color['yellow']}Perfect!{Color['reset']}")
                        boon += 2
                    else:
                        say(f"{Color['green']}Good!{Color['reset']}")
                        boon += 0.5
                else:
                    say(f"{Color['red']}Failure!{Color['reset']}")
                    failure = True
                    break
                
        except TimeoutOccurred:
            say(f"{Color['red']}Failure!{Color['reset']}")
            failure = True
        
        if boon <= 4.5:
            self.applyStatus(user, target)

            if any(s.name == "Nebulize" for s in user.statusList):
                Hemorrhage.inflict(target, next(s for s in user.statusList if s.name == "Nebulize").stacks)
                next(s for s in user.statusList if s.name == "Nebulize").remove(user)
        damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        if boon:
            damage = round(damage * (1 - boon / 10))

        if failure:
            damage = round (damage * 1.5)
        return self.applyDamage(user, target, damage)
bskill_sword_tunnel = EnemySkill("Sword Tunnel", [DAMAGE, [MULTI, HITS(1,5)]],
                                 "Strength vs. Defense x 1-5. Quick Time event; enter a randomized string of characters within 1/2 seconds 3/4 times. Based on the accuracy of the Quick Time event, increase or reduce damage. If Nebulize is present, lose 1 stack of Nebulize, and for each stack of Nebulize present, inflict Hemorrhage. Chance to inflict Bleed/Split.",
                                 weight=15, opener=True, hit=80, critical=75, element="mighty", status=[Bleed, Split], statsUsed=["strength", "defense", 2], customEffect=sword_tunnel_effect,
                                 condition=lambda enemy, target: any(s.name == "Nebulize" and s.stacks >= 3 for s in enemy.statusList))

def star_fury_effect(self, user: Enemy, target: Player, actions=1):
    if self.useCheck(user, target, "enemy"):
        qtTime = 3 if user.health >= round(user.maxHealth * 0.5) else 2
        key = random.choice(string.ascii_lowercase)
        say(f"{Color['red']}Mash {Color['green']}{key}{Color['yellow']}!{Color['reset']}")
        
        count = 0
        failure = False
        start = time.perf_counter()
        while time.perf_counter() - start < qtTime:
            if keyboard.is_pressed(key):
                count += 1
                
                while keyboard.is_pressed(key):   
                    if time.perf_counter() - start >= qtTime: break
            time.sleep(0.01)
        
        flushInput()
        
        if count == 0:
            say(f"{Color['red']}Failure!{Color['reset']}")
            failure = True
        
        if count <= 8:
            self.applyStatus(user, target)
            
            if any(s.name == "Nebulize" for s in user.statusList):
                Heated.inflict(target, next(s for s in user.statusList if s.name == "Nebulize").stacks)
                Radiant.inflict(target)
                next(s for s in user.statusList if s.name == "Nebulize").remove(user)
        damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        damage = round(damage * (1 - min(count, 15) / 25))

        if failure:
            damage *= 2
        return self.applyDamage(user, target, damage)
bskill_star_fury = EnemySkill("Star Fury", [DAMAGE, [MULTI, HITS(1,7)]],
                              "Magic vs. Resistance x 1-7. Quick Time event; mash a randomized key during a 2/3 window. Based on the amount of mashed during the Quick Time event, increase or reduce damage. If Nebulize is present, lose 1 stack of Nebulize, and for each stack of Nebulize present, inflict Heated/Radiant. Chance to inflict Burn/Scald.",
                              weight=10, finsher=True, hit=60, critical=100, element="mighty", status=[Burn, Scald], statsUsed=["magic", "resistance", 1.7], customEffect=star_fury_effect,
                              condition=lambda enemy, target: any(s.name == "Nebulize" and s.stacks >= 3 for s in enemy.statusList))

def nebulizer_conditional(self, user: Enemy, target: Player, actions=1):
    user.ultimateMeter += 15
    say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 15!{Color['reset']}")
    user.speedMeter += 15
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
bskill_nebulizer = EnemySkill("Nebulizer", [STATUS],
                              "Gain Nebulize. Raise Ultimate/Speed Meter by 15.",
                              weight=12, status=[Nebulize], statusTarget="user",
                              condition=lambda enemy, target: not any(s.name == "Nebulize" for s in enemy.statusList) or enemy.actions % 3 == 0, conditional=nebulizer_conditional)

def arrogant_boasting_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions % 5 == 0:
        for skill in user.skills:
            skill.weight = 0
        chosen = random.choice([skill for skill in user.skills if "Passive" not in skill.type_])
        chosen.weight = 100
        say(f"{Color['yellow']}The Knight Announces His Next Skill, {chosen.name}!{Color['reset']}")
    else:
        i = 0
        l = [15, 10, 12]
        for i in range(3):
            user.skills[i].weight = l[i]
    
    if user.actions % 6 == 0:
        user.strength += 5
        user.magic += 5
bpassive_arrogant_boasting = EnemySkill("Arrogant Boasting", [PASSIVE],
                                        "Every 6 user actions, Gain 5 Strength/Magic. Every 5th user action, announce the skill to be used next action.")
bpassive_arrogant_boasting.passive = types.MethodType(arrogant_boasting_passive, bpassive_arrogant_boasting)

##--Three-Headed-Dragon King--##

def waking_avalanche_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Sapien Head" and s.count <= 5 for s in user.statusList):
        Frostbite.inflict(target, 5)
        damage *= 2
    
    return damage
bskill_waking_avalanche = EnemySkill("Waking Avalanche", [DAMAGE, [MULTI, HITS(1,3)]],
                                     "Magic vs. Resistance x 1-3. If Sapien Head is present and has a count of 5 or below, inflict max stacks of Frostbite and increase damage (2x!). Chance to inflict 2 stacks of Frigid/Freeze.",
                                     weight=14, hit=75, critical=80, element="ice", status=[Frigid, Freeze], stacks=2, statsUsed=["magic", "resistance", 1.5], 
                                     condition=lambda enemy, target: any(s.name == "Sapien Head" and s.count <= 5 for s in enemy.statusList), conditional=waking_avalanche_conditional)

def icy_barrier_conditional(self, user: Enemy, target: Player, actions=1):
    if random.randint(1, 100) + user.luck >= target.luck + 35:
        DeepFreeze.inflict(target)
bskill_icy_barrier = EnemySkill("Icy Barrier", [STATUS],
                                "Gain 2 stacks of Tough II. Chance to inflict Deep Freeze.",
                                weight=12, status=[ToughII], stacks=2, statusTarget="user",
                                condition=lambda enemy, target: target.strength >= 50 or target.magic >= 50, conditional=icy_barrier_conditional)

def flare_impact_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Temerarios Head" and s.count <= 5 for s in user.statusList):
            Molten.inflict(target)
            damage *= 3
            next(s for s in user.statusList if s.name == "Temerarios Head").count -= 1
            say(f"{Color['red']}{user.name}s Temerarios Head Lost 1 Count!{Color['reset']}")
        
    return damage
bskill_flare_impact = EnemySkill("Mega Flare Impact", [DAMAGE],
                                 "Strength vs. Defense. If Temerarios Head is present and has a count of 5 or below, Temerarios Head loses 1 count, inflict Molten, and increase damage (3x!). Chance to inflict 3 stacks of Burn/Scorch/Sear.",
                                 weight=15, opener=True, hit=80, critical=125, element="fire", status=[Burn, Scorch, Sear], stacks=3, statsUsed=["strength", "defense", 2], 
                                 condition=lambda enemy, target: any(s.name == "Temerarios Head" and s.count <= 5 for s in enemy.statusList), conditional=flare_impact_conditional)

def blazing_heart_conditional(self, user: Enemy, target: Player, actions=1):
    user.sanity += 3

    if sum(1 for s in target.statusList if s.family == "Burn") >= 3:
        next(s for s in user.statusList if s.name == "Temerarios Head").count += 3
        say(f"{Color['green']}{user.name}s Temerarios Head Gained 3 Count!{Color['reset']}")
        BoostII.inflict(user)
bskill_blazing_heart = EnemySkill("Blazing Heart", [STATUS],
                                  "Will inflict 2 stacks of Heated. If 3+ Burn statuses are present on the opposer, Temerarios Head gains 3 count and gain Boost II. Gain 5 sanity.",
                                  weight=11, status=[Heated], stacks=2,
                                  condition=lambda enemy, target: sum(1 for s in target.statusList if s.family == "Burn") >= 3 or not any(s.name == "Heated" for s in target.statusList) and any(s.name == "Temerarios Head" for s in enemy.statusList), conditional=blazing_heart_conditional)

def primaeval_rupture_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    for i in range(0, user.ultimateMeter, 10):
        percent += 0.1
    
    if percent:
        damage += round(damage * percent)
    
    return damage
bskill_primaeval_rupture = EnemySkill("Primaeval Rupture", [DAMAGE, [MULTI, HITS(3,5)]],
                                      "Strength vs. Defense x 3-5. Increase damage (10% per 10 points of Ultimate Meter). Chance to inflict Slow II/Frail II.",
                                      weight=13, finsher=True, hit=50, critical=100, element="mighty", status=[SlowII, FrailII], statsUsed=["strength", "defense", 1.5], 
                                      condition=lambda enemy, target: enemy.ultimateMeter >= 50, conditional=primaeval_rupture_conditional)

def planning_king_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if target.lastAction and target.lastAction == "Skill" and target.lastSkill and "Damage" in target.lastSkill.type_ and target.lastSkill.element in ["thunder", "wind", "physical"]:
        for status in user.statusList[:]:
            if status.name in ["Sapien Head", "Temerarios Head", "Fomes Head"]:
                status.count += 2
                say(f"{Color['green']}{user.name}s {status.name} Gained 2 Count!{Color['reset']}")  

        user.ultimateMeter += 25
        user.speedMeter += 25
        say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 25!{Color['reset']}")
bpassive_planning_king = EnemySkill("Planning King", [PASSIVE],
                                    "If the opposer used any Thunder/Wind/Physical element skills on their last action, each Dragon head gains 2 count and raise Ultimate/Speed Meter by 25.")
bpassive_planning_king.passive = types.MethodType(planning_king_passive, bpassive_planning_king)

bskill_feast = EnemySkill("Feast", [DAMAGE, [MULTI, HITS(1,2)]],
                          "Strength vs. Defense x 1-2. Restore health (50% of damage dealt).Chance to inflict 5 stacks of Hemorrhage.",
                          weight=15, hit=80, critical=130, element="physical", status=[Hemorrhage], stacks=5, statsUsed=["strength", "defense", 2], damHeal=0.5, meter="health")

def dragon_king_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if not any(s.name in ["Sapien Head", "Temerarios Head", "Fomes Head"] for s in user.statusList):
        self.tracker += 1

    if self.tracker >= 6:
        statuses = [Sapien, Temerarios, Fomes]
        one = random.choice([Sapien, Temerarios, Fomes])
        two = random.choice([s for s in statuses if not s == one])

        say(f"{Color['green']}{user.name} Regrew Its {one.name}!{Color['reset']}")
        say(f"{Color['green']}{user.name} Regrew Its {two.name}!{Color['reset']}")
        
        one = copy.deepcopy(one)
        one.count = 6

        two = copy.deepcopy(two)
        two.count = 6

        user.statusList.append(copy.deepcopy(one))
        user.statusList.append(copy.deepcopy(two))
        self.tracker = 0
bpassive_dragon_king = EnemySkill("Prime Dragon King", [PASSIVE],
                                  "After all Dragon Heads (Sapien, Temerarios, Fomes) are no longer present, after 6 user actions, regain 2 Dragon Heads at 6 count.")
bpassive_dragon_king.passive = types.MethodType(dragon_king_passive, bpassive_dragon_king); bpassive_dragon_king.tracker = 0

##--Hoarah Loux--##

bskill_plunging_axe = EnemySkill("Plunging Axe", [DAMAGE, [MULTI, 2]],
                                 "Strength vs. Defense x 2. Chance to inflict 3 stacks of Hemorrhage/Split.",
                                 weight=15, opener=True, hit=70, critical=110, element="physical", status=[Hemorrhage, Split], stacks=3, statsUsed=["strength", "defense", 1.5])

def overhead_smash_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    SlowI.inflict(user)
    return damage
bskill_overhead_smash = EnemySkill("Overhead Smash", [DAMAGE],
                                   "Strength vs. Defense. Gain Slow I. Chance to inflict 2 stacks of Hemorrhage/Gash/Cripple II/Break.",
                                   weight=12, hit=65, critical=100, element="physical", status=[Hemorrhage, Gash, Clot, CrippleII, Break], stacks=2, statsUsed=["strength", "defense", 2],
                                   condition=lambda enemy, target: enemy.actions % 3 == 0, conditional=overhead_smash_conditional)

def beastial_sacrifice_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    
    if any(s.name == "Stagger" for s in user.statusList):
        stagger = next(s for s in user.statusList if s.name == "Stagger")
        lost = random.randint(15, 20)
        stagger.remove(user, lost)
        if stagger.stacks < 0:
            stagger.stacks = 0
            
    if user.ultimateMeter >= 35:
        user.ultimateMeter -= 35
        say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Lowered By 35!{Color['reset']}")
        ToughII.inflict(user, 2)
bskill_beastial_sacrifice = EnemySkill("Beastial Sacrifice", [SPECIAL],
                                       "If Stagger is present, lose 15-20 stacks of Stagger. If Ultimate Meter is at 35+, lower Ultimate Meter by 35 and gain 2 stacks of Tough II.",
                                       weight=10, customEffect=beastial_sacrifice_effect, condition=lambda enemy, target: enemy.ultimateMeter >= 35 or any(s.name == "Stagger" and s.stacks >= 30 for s in enemy.statusList))

def tarnished_lord_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    stagger = next((s for s in user.statusList if s.name == "Stagger"), None)
    tiers = stagger.stacks // 10 if stagger else 0
    for stat, amount in [("strength", 1), ("speed", 5), ("hit", 10)]:
        base = getattr(Enemy.allEnemies[user.name], f"base{stat.capitalize()}")
        setattr(user, f"base{stat.capitalize()}", base + amount * tiers)
        
    Fix.statMutation(user)
    
    stagger = next((s for s in target.statusList if s.name == "Stagger"), None)
    if stagger and stagger.stacks >= 80:
        BoostII.inflict(user)
bpassive_tarnished_lord = EnemySkill("Tarnished Lord", [PASSIVE],
                                     "For every 10 stacks of Stagger present, raise Strength/Speed/Hit by 1/5/10 (non-permanent). If Stagger is present on the opposer and at 80+ stacks, gain Boost II.")
bpassive_tarnished_lord.passive = types.MethodType(tarnished_lord_passive, bpassive_tarnished_lord)

##-- 

def earth_stomp_effect(self, user: Enemy, target: Player, actions=1):
    if self.useCheck(user, target):
        self.applyStatus(user, target)
        user.speedMeter -= 25
        say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By 25!{Color['reset']}")
        damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        return self.applyDamage(user, target, damage)
bskill_earth_stomp = EnemySkill("Earth Shattering Stomp", [DAMAGE],
                                "Strength vs. None. Lower Speed Meter by 25. Will inflict Break/Frail II/Cripple II.",
                                weight=13, finsher=True, hit=60, critical=125, element="physical", status=[Break, FrailII, CrippleII], willStatus=True, statsUsed=["strength", None, 2], customEffect=earth_stomp_effect)

def power_bomb_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Stagger" for s in target.statusList):
        Stagger.inflict(target, 15)
    return damage
bskill_power_bomb = EnemySkill("Power Bomb", [DAMAGE],
                               "Strength vs. Defense. If Stagger is present on the opposer, opposer gains 15 stacks of Stagger. Will inflict Bind II.",
                               weight=15, hit=65, critical=100, element="physical", status=[BindII], willStatus=True, statsUsed=["strength", "defense", 2],
                               condition=lambda enemy, target: any(s.name == "Stagger" and s.stacks >= 45 for s in enemy.statusList), conditional=power_bomb_conditional)

def claw_barrage_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Stagger" and s.stacks >= 60 for s in target.statusList):
        SlowII.inflict(user)
    else:
        SlowI.inflict(user)
    return damage
bskill_claw_barrage = EnemySkill("Claw Barrage", [DAMAGE, [MULTI, HITS(2,6)]],
                                 "Strength vs. Defense x 2-6. If Stagger is present on the opposer and at 60+ stacks, gain Slow II and use Power Bomb (half-damage). Gain Slow I. Chance to inflict Bleed/Gash/Split/Clot/Wound.",
                                 weight=12, hit=65, critical=100, element="physical", status=[Bleed, Gash, Split, Clot, Wound], statsUsed=["strength", "defense", 1.5], followUp=[bskill_power_bomb, lambda enemy, target: any(s.name == "Stagger" and s.stacks >= 60 for s in target.statusList)],
                                 condition=lambda enemy, target: any(s.name == "Stagger" and s.stacks >= 60 for s in enemy.statusList), conditional=claw_barrage_conditional)

def lord_badlands_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    staggerOne = next((s for s in user.statusList if s.name == "Stagger"), None)
    staggerTwo = next((s for s in target.statusList if s.name == "Stagger"), None)
    combined = (staggerOne.stacks if staggerOne else 0) + (staggerTwo.stacks if staggerTwo else 0)
    tiers = combined // 20

    restore = round(user.maxHealth * 0.01 * tiers)
    user.health = min(user.maxHealth, user.health + restore)
    if restore > 0:
        say(f"{Color['green']}{user.name}s Health Was Restored By {restore}!{Color['reset']}")

    for stat, amount in [("strength", 3), ("speed", 10), ("hit", 20)]:
        base = getattr(Enemy.allEnemies[user.name], f"base{stat.capitalize()}")
        setattr(user, f"base{stat.capitalize()}", base + amount * tiers)
        
    Fix.statMutation(user)
    
    if staggerTwo and staggerTwo.stacks >= 75 and user.sanity >= 20:
        BoostIII.inflict(user)
bpassive_lord_badlands = EnemySkill("Lord of the Badlands", [PASSIVE],
                                    "For every 20 stacks of Stagger present on the user and the opposer, restore health (1% of Max Health) and raise Strength/Speed/Hit by 3/10/20 (non-permanent). If Stagger is present on the opposer and at 75+ stacks and sanity is at 20+, gain Boost III.")
bpassive_lord_badlands.passive = types.MethodType(lord_badlands_passive, bpassive_lord_badlands)

##--Wayward Passenger--##

def rip_space_effect(self: EnemySkill, user: Enemy, target: Player, actions=1):
    if self.useCheck(user, target):
        rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
        if rupture and rupture.count >= 10:
            damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
            rupture.count -= 4
            damage = self.bonusChecks(user, target, actions, damage)
            reflect, absorb = False, False
        else:
            damage, reflect, absorb  = self.calculateDamage(user, target, "enemy", actions)
        return self.applyDamage(user, target, damage, reflect, absorb)
bskill_rip_space = EnemySkill("Rip Space", [DAMAGE, [MULTI, 2]],
                              "Strength vs. Defense x 2. If Rupture is present on the opposer and is at 10+ count, ignore Defensive stats and lower count by 4. Will inflict 6 stacks of Rupture (with 4 count).",
                              weight=15, hit=80, critical=150, element="mighty", status=[Rupture], stacks=6, count=4, willStatus=True, statsUsed=["strength", "defense", 2],
                              condition=lambda enemy, target: any(s.name == "Rupture" and s.count >= 10 for s in enemy.statusList))

def dimensional_slice_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    if rupture:
        rupture.count += 2
        damage *= 2
    
    return damage
bskill_dimensional_slice = EnemySkill("Consecutive Dimensional Slice", [DAMAGE, [MULTI, 3]],
                                      "Strength vs. Defense x 3. If Rupture is present on the opposer, increase its count by 2 and increase damage (2x!). Chance to inflict 3 stacks of Rupture (with 3 count)/Hemorrhage.",
                                      weight=13, opener=True, hit=75, critical=125, element="thunder", status=[Rupture, Hemorrhage], stacks=3, count=3, statsUsed=["strength", "defense", 2])

def hideaway_rift_conditional(self, user: Enemy, target: Player, actions=1):
    if target.lastAction and target.lastAction == "Skill" and target.lastSkill and "Damage" in target.lastSkill.type_:
        Rupture.inflict(target, 5, 3)
bskill_hideaway_rift = EnemySkill("Hideaway Rift", [STATUS], 
                                  "Gain Haze. If the opposer used a damaging skill last action, inflict 5 stacks of Rupture (with 3 count).",
                                  weight=11, status=[Haze], statusTarget="user",
                                  condition=lambda enemy, target: target.lastAction and target.lastAction == "Skill" and target.lastSkill and "Damage" in target.lastSkill.type_, conditional=hideaway_rift_conditional)

def dimensional_escape_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    tiers = rupture.count if rupture else 0
    for stat in ["luck", "speed"]:
        base = getattr(Enemy.allEnemies[user.name], f"base{stat.capitalize()}")
        setattr(user, f"base{stat.capitalize()}", base + 2 * tiers)
            
    Fix.statMutation(user)
        
    if any(s.name == "Haze" for s in user.statusList):
        Rupture.inflict(target, 1)
bpassive_dimensional_escape = EnemySkill("Dimensional Escape", [PASSIVE],
                                         "For every count of Rupture present on the opposer, raise Luck/Speed by 2 (non-permanent). For every action that Haze is present, inflict 1 stack of Rupture (with 1 count).")
bpassive_dimensional_escape.passive = types.MethodType(dimensional_escape_passive, bpassive_dimensional_escape)

##--Shadow Daemon--##

def pareidolia_conditional(self, user: Enemy, target: Player, actions=1):
    target.sanity -= 5
    madness = next((s for s in target.statusList if s.name == "Madness"), None)
    flame = next((s for s in target.statusList if s.name == "Flame Shields"), None)

    if madness and flame and flame.stacks >= 5 and actions >= 15:
        flame.remove(target, 2)
        Fragile.inflict(target, 2)
bskill_pareidolia = EnemySkill("Pareidolia", [STATUS],
                               "Inflict 3 stacks of Madness. Lower opposers sanity by 5. If Madness and Flame Shields are present on the opposer and Flame Shields is at 5+ stacks and global actions is at 15+, opposer loses 2 stacks of Flame Shields and inflict 2 stacks of Fragile.",
                               weight=12, status=[Madness], stacks=3, 
                               condition=lambda enemy, target: (enemy.actions > 7 or target.actions > 7) and any(s.name == "Madness" for s in target.statusList) and any(s.name == "Flame Shields" for s in target.statusList), conditional=pareidolia_conditional)

def anti_mystic_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 3
    target.sanity -= 3
    if any(s and s.element == "mighty" for s in target.skills):
        damage *= 2

    if user.sanity >= 15:
        Power.inflict(user, 3)
        Poise.inflict(user, 3)
        Keen.inflict(user, 3)

    
    if target.sanity <= -10:
        WillowWisp.inflict(target, 30)
    return damage
bskill_anti_mystic = EnemySkill("Anti Mystic", [DAMAGE],
                                "Magic vs. Resistance. If opposer has any Mighty element skills, increase damage (2x!). If sanity is at 15+, gain 3 stacks of Power/Poise/Keen. If opposers sanity is below -10, inflict 30 stacks of Willow Wisp. Gain 3 sanity. Lower opposers sanity by 3. Chance to inflict 2 stacks of Sinking/Willow Wisp/Scorch/Cripple III.",
                                weight=18, hit=70, critical=125, element="fire", status=[Sinking, WillowWisp, Scorch, CrippleIII], stacks=2, statsUsed=["magic", "resistance", 2.3],
                                condition=lambda enemy, target: any(s and s.element == "mighty" for s in target.skills) or enemy.sanity >= 15 or target.sanity <= -10)

def volatile_embers_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.ultimateMeter >= 50:
        damage *= 2
        if random.randint(1, 100) + user.luck >= target.luck + 35:
            FrenziedFlames.inflict(target, 2)

    user.sanity += 3
    return damage
bskill_volatile_ember = EnemySkill("Volatile Embers", [DAMAGE],
                                   "Magic vs. Resistance x 1-3. If Ultimate Meter is at 50+, increase damage (2x!) and chance to inflict 2 stacks of Frenzied Flames. Gain 3 sanity. Chance to inflict 2 stacks of Sinking/Burn/Madness.",
                                   weight=14, hit=80, critical=90, element="fire", status=[Sinking, Burn, Madness], stacks=2, statsUsed=["magic", "resistance", 1.8],
                                   condition=lambda enemy, target: enemy.ultimateMeter >= 50 or not any(s.name in ["Frenzied Flames", "Sinking"] for s in target.statusList), conditional=volatile_embers_conditional)

def gossamer_passive(self: EnemySkill, user: Enemy, target: Player, damage=0):
    if user.actions == 1:
        self.trigger = False

    if user.actions % 7 == 0 and user.actions != 1:
        PurpleHaze.inflict(user, 1)

    if user.health <= round(user.maxHealth * 0.3) and not self.trigger:
        Power.inflict(user, 3)
        PurpleHaze.inflict(user, 3)
        self.trigger = True

    for status in user.statusList[:]:
        if status.family in ["Bleed", "Burn", "Poison"]:
            status.remove(user, full=True)
bpassive_gossamer = EnemySkill("Gossamer", [PASSIVE],
                               "Every 7 user actions, gain 1 stacks of Purple Haze. If health is below 30%, gain 3 stacks of Power/Purple Haze (once). Remove any Bleed/Poison/Burn status present.")
bpassive_gossamer.passive = types.MethodType(gossamer_passive, bpassive_gossamer); bpassive_gossamer.trigger = False

##------------Boss Ultimates------------##

def soothing_aria_conditional(self, heal: int, user: Enemy, target: Player):
    amount = 0
    reach = random.randint(1, 2)
    for status in user.statusList[:]:
        if status.align == "Negative":
            status.remove(user, full=True)
            amount += 1

        if amount >= reach:
            break

    user.ultimateMeter -= 125
    say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Lowered By 125!{Color['reset']}")

    Rejuvenate.inflict(user, 15)
    return heal
ubskill_soothing_aria = EnemySkill("Soothing Aria", [HEAL], 
                                   "Restore health (20% of Max Health + 175% of Magic + 175% of Resistance). Remove 1-2 Negative statuses. Lower Ultimate Meter by 125. Gain 15/1 stacks of Rejuvenate/Haste.",
                                   useType="Ultimate", weight=100, statsUsed=[[("maxHealth", 20), ("magic", 175), ("resistance", 175)], "health"], status=[Haste], statusTarget="user",
                                   conditional=soothing_aria_conditional)

def ghastly_rebirth_conditional(self, heal: int, user: Enemy, target: Player):
    if user.health <= round(user.maxHealth * 0.5):
        damage = heal // 2
        target.health -= damage
        say(f"{Color['red']}{user.name} Dealt {damage} To {target.name}s Health!{Color['reset']}")

    if any(s.name == "Soul Bind" for s in target.statusList):
        Shell.inflict(user, 10)
        Power.inflict(user, 10)

    return heal
ubskill_ghastly_rebirth = EnemySkill("Ghastly Rebirth", [HEAL], 
                                     "Restore health (225% of Magic + 5% of Max Health). If health is below 50%, deal damage (50% of heal). If Soul Bind is present on the opposer, gain 10 stacks of Shell/Power.",
                                     useType="Ultimate", weight=100, statsUsed=[[("maxHealth", 5), ("magic", 225)], "health"],
                                     conditional=ghastly_rebirth_conditional)

def solar_eclipse_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    heated = False
    for status in user.statusList[:]:
        if status.family == "Burn":
            percent += 0.05
            status.remove(user, full=True)
    
    for status in target.statusList[:]:
        if status.family == "Burn":
            if status.name == "Heated":
                heated = True
            else:
                heated = False
            percent += 0.05
            status.remove(target, full=True)
    
    damage += round(damage * percent)

    if heated:
        Volcanic.inflict(target)
    return damage
ubskill_solar_eclipse = EnemySkill("Solar Eclipse", [DAMAGE, [MULTI, HITS(3,4)]],
                                  "Magic vs. Resistance x 3-4. For Burn status present and present on opposer, remove status and increase damage (5% per Burn status). If Heated is present on the opposer, inflict Volcanic. Will inflict Molten/Sear/Gash.",
                                  useType="Ultimate", weight=100, hit=75, critical=90, element="fire", status=[Molten, Sear, Gash], willStatus=True, statsUsed=["magic", "resistance", 2.5], conditional=solar_eclipse_conditional)

def lacrimosa_crescendo_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    FrailII.inflict(user)
    CrippleII.inflict(user)
    user.sanity -= 10
    return damage
ubskill_lacrimosa_crescendo = EnemySkill("Lacrimosa Crescendo", [DAMAGE, [MULTI, 9]],
                                        "Strength vs. Defense x 9. Gain Frail II/Cripple II. Lose 10 sanity. Will inflict Gash/Bleed/Husk/Ice Veins.",
                                        useType="Ultimate", weight=100, hit=80, critical=95, element="mighty", status=[Gash, Bleed, Husk, IceVeins], willStatus=True, statsUsed=["strength", "defense", 1.5], 
                                        conditional=lacrimosa_crescendo_conditional)

def catastrophic_overload_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    SlowII.inflict(user)

    percent = 0
    for status in user.statusList[:]:
        if status.family == "Shock":
            percent += 0.1
            status.remove(user, full=True)
    
    damage += round(damage * percent)
    return damage
ubskill_catastrophic_overload = EnemySkill("Catastrophic Overload", [DAMAGE, ["MultiHit ", lambda: random.randint(4,6)]], 
                                          "Magic vs. Resistance 4-6. For Shock status present, remove status and increase damage (10% per Shock status). Gain Slow II. Will inflict Static/Short Circuit.",
                                          useType="Ultimate", weight=100, hit=65, critical=150, element="thunder", status=[Static, ShortCircuit], statsUsed=["magic", "resistance", 2], conditional=catastrophic_overload_conditional)

def beast_unleashed_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    BoostII.inflict(user)
    for status in target.statusList:
        if status.family == "Bleed":
            if "Special" not in status.type_:
                status.simple(target)
            else:
                status.special(target)
    return damage
ubskill_beast_unleashed = EnemySkill("Beast Unleashed", [DAMAGE],
                                    "Strength vs. Defense. Retrigger 2 Bleed statuses. Gain Boost II. Chance to inflict 4 stacks of Hemorrhage/Infection/Puncture/Break.",
                                    useType="Ultimate", weight=100, hit=80, critical=120, element="physical", status=[Hemorrhage, Infection, Puncture, Break], stacks=4, statsUsed=["strength", "defense", 3], conditional=beast_unleashed_conditional)

def kings_storm_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.speedMeter -= 20
    say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By 20!{Color['reset']}")

    Charge.inflict(user, 5)
    Poise.inflict(user, 5)

    if any(s.name == "Charge" and s.stacks >= 10 for s in user.statusList):
        Fragile.inflict(target, 3)
    return damage
ubskill_kings_storm = EnemySkill("King's Storm", [DAMAGE, [MULTI, 6]],
                                 "Strength vs. Resistance x 6. Lower Speed Meter by 20. If Charge is present and at 10+ stacks, inflict 3 stacks of Fragile. Gain 5 stacks of Charge/Poise. Chance to inflict Static/Bind II.",
                                 useType="Ultimate", weight=100, hit=70, critical=90, element="thunder", status=[Static, BindII], statsUsed=["strength", "defense", 1.6],
                                 conditional=kings_storm_conditional)

def kings_shockwave_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.3):
        target.speedMeter -= 15
        say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By 15!{Color['reset']}")

        damage = round(damage * 1.5)
    return damage
ubskill_kings_shockwave = EnemySkill("King's Shockwave", [DAMAGE, [MULTI, 3]],
                                     "Magic vs. Resistance x 3. If health is below 30%, lower opposers Speed Meter by 15 and increase damage (1.5x!). Gain 2 stacks of Shock/Charge/Poise.",
                                     useType="Ultimate", weight=100, hit=80, critical=100, element="thunder", status=[Shock, Charge, Poise], stacks=2, statusTarget="user", statsUsed=["strength", "defense", 1.8],
                                     conditional=kings_shockwave_conditional)

ubskill_magnis_flame = EnemySkill("Magnis Flame", [DAMAGE],
                        f"Magic vs. Resistance. If Heated is present on opposer, trigger it and gain missing stacks. Chance to inflict Heated.",
                        useType="Ultimate", weight=100, hit=90, critical=30, element="fire", status=[[Heated, Heated]], stacks=3, statsUsed=["magic", "resistance", 3])

def double_heavy_slash_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList:
        if status.name == "Frail I":
            damage *= 2
            break
    return damage
ubskill_double_heavy_slash = EnemySkill("Double Heavy Slash", [DAMAGE, [MULTI, 2]],
                        f"Strength vs. Defense x 2. If opposer has Frail I, increase damage (2x!) and inflict Frail II.",
                        useType="Ultimate", weight=100, hit=90, critical=75, element="physical", status=[[FrailII, FrailI]], statsUsed=["strength", "defense", 3],
                        conditional=double_heavy_slash_conditional)

ubskill_gold_breaker = EnemySkill("Gold Breaker", [DAMAGE, [MULTI, HITS(1,3)]],
                        f"Strength vs. Defense x 1-3. Will inflict Frail II/4 stacks of Devotion.",
                        useType="Ultimate", weight=100, hit=100, critical=120, element="mighty", status=[FrailII, Devotion], stacks=4, willStatus=True, statsUsed=["strength", "defense", 3])

def elden_stars_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList:
        if status.name == "Devotion":
            damage = round(damage * 1.5)
            break
    return damage
ubskill_elden_stars = EnemySkill("Elden Stars", [DAMAGE, [MULTI, HITS(2,6)]],
                        f"Magic vs. Resistance x 2-6. If Devotion is present on the opposer, increase damage (1.5x!) and inflict Zealotry. Chance to inflict 2 stacks of Devotion/Frail II/Cripple II.",
                        useType="Ultimate", weight=100, hit=90, critical=70, element="mighty", status=[[Zealotry, Devotion], Devotion, FrailII, CrippleII], statsUsed=["magic", "resistance", 2],
                        conditional=elden_stars_conditional)

def godly_severence_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    vestige = next((s for s in user.statusList if s.name == "Vestige"), None)
    if vestige:
        damage = round(damage * (1 + 0.10 * vestige.stacks))
    return damage
ubskill_godly_severence = EnemySkill("Godly Severence", [DAMAGE, [MULTI, 4]],
                        f"Strength vs. Resistance x 4. Increased damage (10% per Vestige stack). Chance to inflict Bleed/Sear/Burn.",
                        useType="Ultimate", weight=100, hit=80, critical=100, element="mighty", status=[Bleed, Sear, Burn], statsUsed=["strength", "resistance", 2], conditional=godly_severence_conditional)

ubskill_sickle_of_sorrow =  EnemySkill("Sickle of Sorrow", [DAMAGE, [MULTI, 3]], 
                         f"Magic vs. Defense x 3. Will inflict Frail II.",
                         useType="Ultimate", weight=100, hit=50, critical=100, element="mighty", status=[FrailII], willStatus=True, statsUsed=["magic", "defense", 2])

def light_divine_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health >= round(user.maxHealth * 0.5):
        Charge.inflict(user, 3)
        Power.inflict(user, 3)
        Boon.inflict(user, 3)

    if user.health < round(user.maxHealth * 0.5):
        Fragile.inflict(user, 2)
        BoostII.inflict(user)

    if any(s.name == "Vestige" and s.stacks >= 5 for s in user.statusList):
        user.speedMeter += 20
        say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 20!{Color['reset']}")

    target.speedMeter -= 15
    say(f"{Color['magenta']}{user.name}s Speed Meter Was Lowered By 15!{Color['reset']}")
    return damage
ubskill_light_divine = EnemySkill("Light of Divine Justice", [DAMAGE, [MULTI, HITS(3,6)]], 
                                  "Magic vs. Resistance x 3-6. If health is above or equal to 50%, gain 3 stacks of Charge/Power/Boon. If health is less than 50%, gain 2 stacks of Fragile/Boost II. If Vestige is present and at 5+ stacks, raise Speed Meter by 20. Lower opposers Speed Meter by 15. Chance to inflict 3 stacks of Burn/Bind II/Cripple II.",
                                  useType="Ultimate", weight=100, hit=75, critical=90, element="mighty", status=[Burn, BindII, CrippleII], stacks=3, statsUsed=["magic", "defense", 2.3],
                                  conditional=light_divine_conditional)

def zamasus_justice_conditional(self, user: Enemy, target: Player, actions=1):
    if user.sanity > 0:
        self.status = [Fragile]
        self.stacks = 3

    elif user.sanity < 0:
        self.status = [Charge, Power, Fragile]
        self.stacks = 3

        Fragile.inflict(target, 2)
        CrippleII.inflict(target, 2)
ubskill_zamasus_justice = EnemySkill("Zamasu's Justice and Order", [STATUS], 
                                     "If sanity is Positive, gain 3 stacks of Fragile. If sanity is Negative, gain 3 stacks of Charge/Power/Fragile and inflict 2 stacks of Fragile/Cripple II.",
                                     useType="Ultimate", weight=100, status=[Fragile], stacks=3, statusTarget="user", conditional=zamasus_justice_conditional)

def bloodboon_ritual_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    bloodboon = next((s for s in user.statusList if s.name == "Blood Boon"), None)
    if bloodboon:
        damage = round(damage * (1 + 0.05 * bloodboon.stacks))
    return damage
ubskill_bloodboon_ritual = EnemySkill("Bloodboon Ritual", [DAMAGE, [MULTI, 3]],
                        f"Magic vs. Resistance x 3. Increase damage (5%!) for every stack of Blood Boon. Chance to inflict Clot/Wound.",
                        useType="Ultimate", weight=100, hit=60, critical=30, element="mighty", status=[Clot, Wound], statsUsed=["magic", "defense", 2], conditional=bloodboon_ritual_conditional)

def ritual_countdown_conditional(self, user: Enemy, target: Player, actions=1):
    user.sanity -= 10
    target.sanity -= 10

    if target.sanity > 0:
        for status in [Hemorrhage, Fragile, BloodGeyser]:
            status.inflict(target, 3)
ubskill_ritual_countdown = EnemySkill("Ritual Countdown", [STATUS],
                                      "Inflict 10 stacks of Blood Geyser. Lose 10 sanity. Lower opposers sanity by 10. If opposers sanity is positive, inflict 3 stacks of Hemorrhage/Fragile/Blood Geyser. After using this skill 3 times, transform this skill into Ritual Finish.",
                                      useType="Ultimate", weight=100, status=[BloodGeyser], stacks=10, conditional=ritual_countdown_conditional)

def ritual_finish_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity <= -15:
        Volcanic.inflict(target)

    if target.sanity <= -15:
        Molten.inflict(user)
    return damage
ubskill_ritual_finish = EnemySkill("Ritual Finish", [DAMAGE, [MULTI, 3]], 
                                   "Magic vs. Resistance x 3. If sanity is below -15, inflict Volcanic. If opposers sanity is below -15, inflict Molten. Will inflict 30 stacks of Blood Geyser.",
                                   useType="Ultimate", weight=100, hit=70, critical=125, element="fire", status=[BloodGeyser], stacks=30, willStatus=True, statsUsed=["magic", "resistance", 2.5], conditional=ritual_finish_conditional)

def divine_motus_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.speed > target.speed:
        damage = round(damage * 1.5)
    return damage
ubskill_divine_motus = EnemySkill("Divine Motus", [DAMAGE, [MULTI, HITS(3,5)]], 
                         f"Strength vs. Defense x 3-5. If Speed is greater than opposer, increase damage (1.5x!). Chance to inflict Break/Frail II.",
                         useType="Ultimate", weight=100, hit=80, critical=100, element="thunder", status=[Break, FrailII], statsUsed=["strength", "defense", 2], conditional=divine_motus_conditional)

def blade_of_olympus_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    amount = 0
    for status in user.statusList[:]:
        if status.align == "Positive":
            damage += round(damage * 0.12)
            amount += 1

    if amount >= 2:
        Warrior.inflict(user, 5)
    return damage
ubskill_blade_of_olympus = EnemySkill("Blade of Olympus", [DAMAGE],
                         f"Strength vs. Resistance. Increased damage (12%) for every Positive status. If 2+ Positive statuses are present, gain 5 stacks of Warrior.",
                         useType="Ultimate", weight=100, hit=80, critical=100, element="mighty", statsUsed=["strength", "resistance", 3], conditional=blade_of_olympus_conditional)

def isolate_effect(self, user: Enemy, target: Player, actions=1):
    say(f"{user.name} Used {self.name}!")
    user.sanity += 5
    Wax.inflict(user, 3)

    if user.name == "Unseeing Child":
        Volcanic.inflict(target)
        Molten.inflict(target)
        Shock.inflict(user)
    
    elif user.name == "Unhearing Child":
        BindII.inflict(target)
        FrailII.inflict(target)
        user.sanity -= 10
ubskill_isolate = EnemySkill("Isolate", [SPECIAL],
                                 "Gain 5 sanity. Gain 3 Wax. If current Boss is Unseeing Child, inflict Volcanic/Molten and gain Shock. If current Boss is Unhearing Child, inflict Bind II/Frail II and lose 10 sanity.",
                                 useType="Ultimate", weight=100, customEffect=isolate_effect)

def melting_star_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity >= 15:
        user.speedMeter += 30 
        damage = round(damage * 1.5)

    if user.sanity <= -10:
        user.speedMeter -= 15
        damage //= 2

    Melting.inflict(user, 15)

    if random.randint(1, 100) + user.luck >= target.luck + 35:
        WillowWisp.inflict(target, 45)
    return damage
ubskill_melting_star = EnemySkill("Melting Star", [DAMAGE],
                                  "Strength vs. Defense. If sanity is at 15+, raise Speed Meter by 30 and increase damage (50%!). If sanity is below -10, lower Speed Meter by 25 and decrease damage (50%!). Gain 15 stacks of Melting. Chance to inflict 45/2 stacks of Willow Wisp/Slug/Radiant.",
                                  useType="Ultimate", weight=100, hit=65, critical=115, element="fire", status=[Slug, Radiant], stacks=2, statsUsed=["strength", "defense", 3], conditional=melting_star_conditional)

def midra_frenzy_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any("Madness" == s.name and s.stacks >= 8 for s in target.statusList):
        Burn.inflict(target, 3)
        Heated.inflict(target, 3)
        Sear.inflict(target)
        Scorch.inflict(target)
    return damage
ubskill_midras_frenzy = EnemySkill("Midra's Frenzy", [DAMAGE, [MULTI, HITS(5,7)]],
                                 "Magic vs. Resistance x 5-7. If Madness is present on the opposer and at 8+ stacks, inflict max stacks of Burn/Heated/Sear/Scorch. Will inflict 5 stacks of Madness.",
                                 useType="Ultimate", weight=100, hit=45, critical=65, element="fire", status=[Madness], stacks=5, willStatus=True, statsUsed=["magic", "resistance", 2], conditional=midra_frenzy_conditional, sanLean="Negative")

def time_save_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    stolenTime = next((status for status in user.statusList if status.name == "Stolen Time"), None)
    if stolenTime and stolenTime.stacks >= 400:
        stolenTime.remove(user, 200)
        damage *= 2
        ShortCircuit.inflict(user)
    return damage
ubskill_time_save = EnemySkill("Time to be Saved", [DAMAGE, [MULTI, 2]], 
                              "Strength vs. Defense x 2. If Stolen Time is at 400+ stacks, lose 200 stacks of Stolen Time, gain Short Circuit, and increase damage (2x!). Chance to inflict Gash/Wound/Static.",
                              useType="Ultimate", weight=100, hit=75, critical=100, element="thunder", status=[Gash, Wound, Static], statsUsed=["strength", "defense", 1.5], conditional=time_save_conditional)

def final_lesson_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    observation = next((skill for skill in user.skills if skill.name == "Observation"), None)
    if observation and any(observation.score[skill.name] >= 4 for skill in target.skills):
        Stun.inflict(target)
    return damage
ubskill_final_lesson = EnemySkill("Final Lesson", [DAMAGE],
                               "Strength vs. Defense. If any of the opposers skills are at 4+ Score, inflict Stun. Will Break/Frail II.",
                               useType="Ultimate", weight=100, hit=80, critical=120, element="ice", status=[Break, FrailII], willStatus=True, statsUsed=["strength", "defense", 3], conditional=final_lesson_conditional)

def desire_moon_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList:
        if status.name == "Lust":
            status.remove(target, full=True)
            damage *= 2
            heal = round(user.maxHealth * 0.15)
            user.health = min(user.maxHealth, user.health + heal)
            say(f"{Color['green']}{user.name}s Health Was Restored By {heal}!{Color['reset']}")
            break
    return damage
ubskill_desire_moon = EnemySkill("Desire for Crimson Moons", [DAMAGE, [MULTI, HITS(3,4)]],
                                "Magic vs. Resistance x 3-4. If Lust is present on the opposer, remove it, restore health (15% of Max Health), and increase damage (2x!). Will inflict 3 stacks of Charm/Burn/Sear.",
                                 useType="Ultimate", weight=100, hit=80, critical=95, element="fire", status=[Charm, Burn, Sear], stacks=3, willStatus=True, statsUsed=["magic", "resistance", 2.5], conditional=desire_moon_conditional)

def tears_moon_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    statuses = [s for s in user.statusList] 
    statuses += [s for s in target.statusList if not any(s.name == t.name for t in statuses)]
    for status in statuses:
        if status.align == "Negative":
            percent += 0.05
    if percent:
        damage += round(damage * percent)
    
    if sum(1 for s in target.statusList if s.align == "Negative") >= 3:
        DeepFreeze.inflict(target)
    return damage
ubskill_tears_moon = EnemySkill("Tears for Crimson Moons", [DAMAGE, [MULTI, HITS(4,6)]],
                                "Magic vs. Resistance x 4-6. Increase damage (5% per Negative statuses present on user and opposer). If opposer has 3+ Negative statuses, inflict Deep Freeze. Will inflict 4 stacks of Frigid/Devoid.",
                                 useType="Ultimate", weight=100, hit=80, critical=90, element="ice", status=[Frigid, Devoid], stacks=4, willStatus=True, statsUsed=["magic", "resistance", 2.5], conditional=tears_moon_conditional)

def yearning_moon_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    for status in user.statusList[:]:
        if status.align == "Positive":
            percent += 0.05
    if percent:
        damage += round(damage * percent)
    
    if (user.health / user.maxHealth) * 100 > (target.health / target.maxHealth) * 100:
        damage *= 2
    
    for status in target.statusList:
        if status.family == "Poison" and status.name != "Blight":
            status.count += 2
            say(f"{Color['green']}{target.name} Gained 2 Count Of {self.name}!{Color['reset']}")
    return damage
ubskill_yearning_moon = EnemySkill("Yearning for Crimson Moons", [DAMAGE, [MULTI, 9]],
                                "Strength vs. Defense x 9. Increase damage (5% per Positive status). If health percent is greater than opposers health perccent, increase damage (2x!). For each Poison stsatus on opposer, raise their count by 2. Chance to inflict Blight/Avarice/Bind II.",
                                 useType="Ultimate", weight=100, hit=70, critical=160, element="mighty", status=[Blight, Avarice, BindII], statsUsed=["strength", "defense", 2], conditional=yearning_moon_conditional)

def scorn_moon_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    CrimsonMoonsBlessing.inflict(user)
    
    percent = 0
    for status in target.statusList:
        if status.family == "Bleed":
            percent += 0.1
        
        if percent >= 0.25:
            percent = 0.25
            break
    
    if percent:
        damage += round(damage * percent)
    
    if any("Crimson Moon's Blessing" == s.name for s in user.statusList) and target.health <= round(target.maxHealth * 0.3):
        FrailII.inflict(target)
        damage = round(damage * 1.5)
    return damage
ubskill_scorn_moon = EnemySkill("Scorn for Crimson Moons", [DAMAGE, [MULTI, HITS(2,3)]],
                                "Strength vs. Defense x 2-3. Increase damage (5% per Bleed status present on opposer, max 25%). If Crimson Moon's Blessing is present and opposers health is below 35%, inflict Frail II and increase damage (1.5x!). Gain Crimson Moon's Blessing. Will inflict 5 stacks of Hemorrhage/Clot/Break.",
                                 useType="Ultimate", weight=100, hit=90, critical=120, element="physical", status=[Hemorrhage, Clot, Break], stacks=5, willStatus=True, statsUsed=["strength", "defense", 2.5], conditional=scorn_moon_conditional)

def detachment_moon_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    percent = 0
    for status in user.statusList + target.statusList:
        if status.name in ["Crimson Moon's Blessing", "Charm", "Lust", "Frigid", "Devoid", "Avarice", "Burn", "Heated", "Molten"]:
            percent += 0.1
    
    percent = min(percent, 0.60)
            
    if percent:
        damage += round(damage * percent)
    return damage
ubskill_detachment_moon = EnemySkill("Detachment of the Twin Moons", [DAMAGE, [MULTI, 4]], 
                                    "Magic vs. Resistance x 4. For each of Crimson Moon's Blessing/Lust/Charm/Frigid/Devoid/Avarice present on the user or opposer, increase damage (10% per status, max 60%). Will inflict Stun.", 
                                    useType="Ultimate", weight=100, hit=50, critical=115, element="mighty", status=[Stun], willStatus=True, statsUsed=["magic", "resistance", 2.5], conditional=detachment_moon_conditional)

def lunar_tear_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Deep Freeze" for s in target.statusList):
        LunarBind.inflict(target)
    
    user.ultimateMeter -= 30
    say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Lowered By 30!{Color['reset']}")
    
    user.sanity += 5 
    target.sanity -= 6
    
    return damage
ubskill_lunar_tear = EnemySkill("Lunar Tear of Chionizei", [DAMAGE],
                                "Magic vs. Resistance. If Deep Freeze is present on the opposer (on use), inflict Lunar Bind. Lower Ultimate Meter by 30. Gain 5 sanity. Lower opposers sanity by 6. Chance to inflict 2 stacks of Glint/Deep Freeze/Bind II/Frail II.",
                                useType="Ultimate", weight=100, hit=80, critical=90, element="ice", status=[Glint, DeepFreeze, BindII, FrailII], stacks=2, statsUsed=["magic", "resistance", 3], conditional=lunar_tear_conditional)

def casting_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Electric Bridge" for s in target.statusList):
        Haste.inflict(user, 2)
        damage += round(damage * 0.5)
    
    if any(s.name == "Haste" for s in user.statusList):
        Slug.inflict(target, 2)
    return damage
ubskill_casting = EnemySkill("Casting of the Kataigida", [DAMAGE],
                                "Strength vs. Defense. If Electric Bridge is present on the opposer, gain 2 stacks of Haste and increase damage (50%!). If Haste is present, inflict 2 stacks of Slug. Will inflict 10 stacks of Spark/Static/Frail II.",
                                useType="Ultimate", weight=100, hit=70, critical=150, element="ice", status=[Spark, Static, FrailII], stacks=10, statsUsed=["strength", "defense", 3], conditional=casting_conditional)

def corrupted_transit_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    for status in target.statusList[:]:
        if status.family == "Poison":
            status.count = 5 if status.count < 5 else status.count
            status.special(target)
            if status in target.statusList:
                status.remove(target, full=True)
        
    user.ultimateMeter -= 25
    say(f"{Color['magenta']}{user.name}s Ultimate Meter Was Lowered By 25!{Color['reset']}")
    
    user.speedMeter += 35
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 35!{Color['reset']}")
    
    dam = round(target.maxHealth * 0.05)
    target.health -= dam
    say(f"{Color['red']}{user.name} Dealt {dam} To {target.name}s Health!{Color['reset']}")
    
    return damage
ubskill_corrupted_transit = EnemySkill("Corrupted Transit", [DAMAGE, [MULTI, HITS(2,8)]],
                                       "Strength vs. Defense x 2-8. For each Poison status present on the opposer, set count to 5 (if count is below 5), retrigger status, and remove it. Reduce Ultimate Meter by 25. Raise Speed Meter by 35. Deal damage (5% of opposers Max Health).",
                                       useType="Ultimate", weight=100, hit=65, critical=60, element="mighty", statsUsed=["strength", "defense", 1.5], conditional=corrupted_transit_conditional)

def goodbye_now_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Butterfly" and s.stacks >= 9 for s in target.statusList):
        next(s for s in target.statusList if s.name == "Butterfly").maxStack = 12
        damage *= 2
    
    if user.sanity >= 15:
        target.sanity -= 5
        BoostII.inflict(user)
    
    if any(s.name == "Deluge" for s in target.statusList):
        next(s for s in target.statusList if s.name == "Deluge").remove(target)
        damage *= 2

    return damage
ubskill_goodbye_now = EnemySkill("Goodbye Now", [DAMAGE, [MULTI, HITS(3,4)]], 
                                 "Strength vs. Defense x 3-4. If Butterfly is present on the opposer and at 9+ stacks, set max stack size of Butterfly to 12 and increase damage (2x!). If sanity is at 15+, opposer loses 5 sanity and gain Boost II. If Deluge is present on the opposer, remove Deluge and increase damage (2x!). Will inflict 2 stacks of Butterfly/Sinking.",
                                 useType="Ultimate", weight=100, hit=90, critical=80, element="mighty", status=[Butterfly, Sinking], stacks=2, willStatus=True, statsUsed=["strength", "defense", 2], 
                                 conditional=goodbye_now_conditional)

def five_spade_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    chance = 0.02
    for i in range(0, user.luck, 5):
        chance += 0.05
    
    if random.random() <= chance:
        dam = round(target.maxHealth * 0.1)
        target.maxHealth -= dam
        say(f"{Color['red']}{user.name} Dealt {dam} To {target.name}s Health!{Color['reset']}")

    return damage
ubskill_five_spade = EnemySkill("Five-Spade Attack", [DAMAGE, [MULTI, 5]],
                                "Magic vs. Resistance x 5. At a chance of 2% + 5% per 5 points of Luck, deal damage (10% of opposers Max Health). Will inflict 5 stacks of Hemorrhage/Frostbite/Burn.",
                                useType="Ultimate", weight=100, hit=75, critical=125, element="physical", status=[Hemorrhage, Frostbite, Burn], stacks=5, willStatus=True, statsUsed=["magic", "resistance", 2.5], 
                                conditional=five_spade_conditional)

def world_delusions_conditional(self, user: Enemy, target: Player, actions=1):
    if any(s.name == "Delusions of Grandeur" for s in user.statusList):
        for i in range(0, next(s for s in user.statusList if s.name == "Delusions of Grandeur").stacks):
            user.ultimateMeter += 15
            say(f"{Color['yellow']}{user.name}s Ultimate Meter Was Raised By 15!{Color['reset']}")
            user.speedMeter += 15
            say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 15!{Color['reset']}")
            
            if random.randint(1, 100) + user.luck >= target.luck + 35:
                FrailIII.inflict(target)
            
            if random.randint(1, 100) >= 80:
                DelusionsOfGrandeur.inflict(user, 2)
ubskill_world_delusions = EnemySkill("World of Delusions", [STATUS],
                                     "Will inflict 2 stacks of Sinking/Engulfed. If Delusions of Grandeur is present, for each stack of Delusions of Grandeur; raise Speed/Ultimate Meter by 15 and chance to; inflict Frail III and gain 2 stacks of Delusions of Grandeur.",
                                     weight=100, status=[Sinking, Engulfed], stacks=2, 
                                     conditional=world_delusions_conditional, sanLean="Negative")

def nobodys_heartbeat_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health < round(user.maxHealth * 0.40):
        target.speedMeter -= 25 
        damage = round(damage * 1.5)
    
    if any(s.name == "Broken Facade" for s in user.statusList):
        Deluge.inflict(target)
    
    return damage
ubskill_nobodys_heartbeat = EnemySkill("Nobody's Heartbeat", [DAMAGE, [MULTI, HITS(1,4)]], 
                                       "Magic vs. Resistance x 1-4. If health is below 40%, lower opposers Speed Meter by 25 and increase damage (1.5x!). If Broken Facade is present, inflict Deluge. Will inflict 4 stacks of Frostbite/Frail II/Bind II.",
                                       useType="Ultimate", weight=100, hit=70, critical=100, element="ice", status=[Frostbite, FrailII, BindII], stacks=4, willStatus=True, statsUsed=["magic", "resistance", 2.5], 
                                       conditional=nobodys_heartbeat_conditional, sanLean="Negative")

def worldly_denial_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.sanity <= -15:
        damage *= 6
        
    return damage
ubskill_worldly_denial = EnemySkill("Worldly Denial", [DAMAGE],
                                    "Magic vs. Resistance. This skill cannot kill (If opposers health is 0, set it to 25). If sanity is below -15, increase damage (6x!). Will inflict 2 stacks of Sinking/Frostbite.",
                                    useType="Ultimate", weight=100, hit=50, critical=200, element="mighty", status=[Sinking, Frostbite], stacks=2, willStatus=True, statsUsed=["magic", "resistance", 1.5],
                                    conditional=worldly_denial_conditional, sanLean="Negative")

def star_roaring_effect(self, user: Enemy, target: Player, actions=1):
    if self.useCheck(user, target, "enemy"):
        boon = 0
        failureOne = False
        qtTarget = 2
        try:
            for i in range(random.randint(4,5)):
                start = time.perf_counter()
                qt = "".join(random.choices(string.ascii_lowercase, k=4))
                res = inputimeout(prompt=f"{Color['red']}Input {Color['green']}{qt}{Color['yellow']}!{Color['reset']}:", timeout=qtTarget).lower()
                end = time.perf_counter()
                used = end - start
                
                if res == qt:
                    if used < qtTarget // 2:
                        say(f"{Color['yellow']}Perfect!{Color['reset']}")
                        boon += 2
                    else:
                        say(f"{Color['green']}Good!{Color['reset']}")
                        boon += 0.5
                else:
                    say(f"{Color['red']}Failure!{Color['reset']}")
                    failureOne = True
                    break
                
        except TimeoutOccurred:
            say(f"{Color['red']}Failure!{Color['reset']}")
            failureOne = True
        
        qtTime = 2
        key = random.choice(string.ascii_lowercase)
        say(f"{Color['red']}Mash {Color['green']}{key}{Color['yellow']}!{Color['reset']}")
        
        count = 0
        failureTwo = False
        start = time.perf_counter()
        while time.perf_counter() - start < qtTime:
            if keyboard.is_pressed(key):
                count += 1
                
                while keyboard.is_pressed(key):   
                    if time.perf_counter() - start >= qtTime: break
            time.sleep(0.01)
        
        flushInput()
        
        if count <= 5:
            say(f"{Color['red']}Failure!{Color['reset']}")
            failureTwo = True
        
        if boon >= 6 and count >= 14:
            say(f"It Missed!")
            return 0
        self.applyStatus(user, target)
        damage = round(getattr(user, self.statsUsed[0]) * self.statsUsed[2])
        damage = self.bonusChecks(user, target, actions, damage)
        if boon:
            damage = round(damage * (1 - boon / 10))
        damage = round(damage * (1 - min(count, 15) / 25))
        
        if failureOne:
            damage = round(damage * 1.5)
        
        if failureTwo:
            damage = round(damage * 1.5)
        
        return self.applyDamage(user, target, damage)
ubskill_roaring = EnemySkill("The Star Roaring", [DAMAGE, [MULTI, HITS(1,10)]],
                             "Magic vs. None x 1-10. Quick Time event; enter a randomized string of characters within 2 seconds 4/5 times and mash a randomized key within a 2 second window. Based on the accuracy of the Quick Time events, increase, reduce damage, or dodge. Chance to inflict max stacks of Heated/Hemorrhage/Sear/Radiant.",
                             useType="Ultimate", weight=100, hit=65, critical=135, element="mighty", status=[Heated, Hemorrhage, Sear, Radiant], stacks=10, statsUsed=["magic", None, 1.5], customEffect=star_roaring_effect)

def diamond_dust_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    user.sanity += 10
    
    return damage
ubskill_diamond_dust = EnemySkill("Diamond Dust", [DAMAGE],
                                  "Magic vs. Resistance. Gain 10 sanity. Will inflict Deep Freeze.",
                                  useType="Ultimate", weight=100, hit=70, critical=100, element="ice", status=[DeepFreeze], willStatus=True, statsUsed=["magic", "resistance", 3],
                                  conditional=diamond_dust_conditional)

def giga_impact_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Temerarios Head" and s.count <= 3 for s in user.statusList):
        Volcanic.inflict(target)
        Radiant.inflict(target)
        damage *= 2

    return damage
ubskill_giga_impact = EnemySkill("Giga Flare Impact", [DAMAGE, [MULTI, HITS(2,4)]],
                                 "Strength vs. Defense x 2-4. If Temerarios Head is present and has a count of 3 or below, inflict Volcanic/Radiant and increase damage (2x!). Chance to inflict 3 stacks of Heated/Burn/Scald.",
                                 useType="Ultimate", weight=100, hit=65, critical=95, element="fire", status=[Heated, Burn, Scald], stacks=3, statsUsed=["strength", "defense", 2],
                                 conditional=giga_impact_conditional)

def imposing_aura_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    target.sanity -= 15
    target.speedMeter -= 50
    
    return damage
ubskill_imposing_aura = EnemySkill("Imposing Aura", [DAMAGE],
                                   "Magic vs. Resistance. Lowers opposers sanity by 15. Decrease opposers Speed Meter by 50. Chance to inflict Frail II/Cripple II.",
                                   useType="Ultimate", weight=100, hit=55, critical=80, element="mighty", status=[FrailII, CrippleII], statsUsed=["magic", "resistance", 3],
                                   conditional=imposing_aura_conditional)

def king_of_monsters_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if user.health <= round(user.maxHealth * 0.45):
        Scald.inflict(target)
        Sear.inflict(target)
        
    return damage
ubskill_king_of_monsters = EnemySkill("King of the Monsters", [DAMAGE, [MULTI, 5]], 
                                      "Strength vs. Defense x 5. If health is below 45%, inflict Scald/Sear and increase damage (2x!). Chance to inflict 3 stacks of Burn/Hemorrhage/Bleed.",
                                      useType="Ultimate", weight=100, hit=80, critical=130, element="physical", status=[Burn, Hemorrhage, Bleed], stacks=3, statsUsed=["strength", "defense", 2],
                                      conditional=king_of_monsters_conditional)

def regal_roar_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Stagger" and s.stacks >= 65 for s in target.statusList):
        Stun.inflict(target)
        damage *= 2
    return damage
ubskill_regal_roar = EnemySkill("Regal Roar", [DAMAGE],
                               "Strength vs. Defense. If Stagger is present on the opposer and at 65+ stacks, inflict Stun and increase damage (2x!). Chance to inflict Slow II/Frail II.",
                               useType="Ultimate", weight=100, hit=60, critical=175, element="physical", status=[SlowII, FrailII],  statsUsed=["strength", "defense", 3],
                               conditional=regal_roar_conditional)

def earthshaker_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if any(s.name == "Stagger" and s.stacks >= 70 for s in target.statusList):
        for status in [Stun, CrippleII]:
            if random.randint(1, 100) + user.luck >= target.luck + 35 or self.willStatus == True:
                status.inflict(target, self.stacks)
                user.sanity += 1
                
    return damage
ubskill_earthshaker = EnemySkill("Hoarah Loux's Earthshaker", [DAMAGE, [MULTI, 3]],
                                 "Strength vs. Defense x 3. If Stagger is present on the opposer and at 70+ stacks, chance to inflict Stun/Cripple II. Chance to inflict Frail II/Break.",
                                 useType="Ultimate", weight=100, hit=65, critical=135, element="physical", status=[FrailII, Break],  statsUsed=["strength", "defense", 2.5],
                                 conditional=earthshaker_conditional)

def high_rip_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    rupture = next((s for s in target.statusList if s.name == "Rupture"), None)
    if rupture:
        rupture.count += 5

        if rupture.count >= 15:
            Hemorrhage.inflict(target, 5)
            damage = round(damage * 1.5)
    
    user.speedMeter += 50
    say(f"{Color['yellow']}{user.name}s Speed Meter Was Raised By 50!{Color['reset']}")
    
    return damage
ubskill_high_rip = EnemySkill("High-Speed Rip Space", [DAMAGE], 
                              "Strength vs. Defense. Raise Speed Meter by 50. If Rupture is present on the opposer, increase its count by 5. If Rupture is at 15+ count, inflict 5 stacks of Hemorrhage and increase damage (1.5x!). Chance to inflict 15 stacks of Rupture (with 3 count).",
                              useType="Ultimate", weight=100, hit=80, critical=125, element="mighty", status=[Rupture], stacks=15, count=3,  statsUsed=["strength", "defense", 3],
                              conditional=high_rip_conditional)

def nightshade_flashover_conditional(self, damage: int, user: Enemy, target: Player, actions=1, strikes=[]):
    if actions >= 15 and user.sanity >= 15:
        Volcanic.inflict(target)
        Engulfed.inflict(target)
    return damage
ubskill_nightshade_flashover = EnemySkill("Nightshade Flashover", [DAMAGE], 
                                          "Magic vs. Resistance. If global actions are at 15+ and sanity is at 15+, inflict Volcanic/Engulfed. Will inflict 2 stacks of Gloom/Madness/Burn.",
                                          useType="Ultimate", weight=100, hit=50, critical=130, element="fire", status=[Gloom, Madness, Burn], stacks=2,  statsUsed=["magic", "resistance", 3])