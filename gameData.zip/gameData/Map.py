from Utility import *
from gameData.Item import *

rewards = {
    "Start Zone": {
        "Coin/Exp": [6,8],
        "Game Point": [7, 10],
        "Items": [item_health_small, item_mana_small, item_red_dew, item_blue_dew, item_fire_tome, item_thunder_tome, item_frost_book, item_breeze_book],
        "Extreme": [skill_patch_up, sigil_unbreakable],
        "Gauntlet": [sigil_asura, skill_ionic_storm, skill_wallop],
        "Seasson": [sigil_fancy, sigil_red_eyes, skill_wind_shift, skill_thunder_shift, skill_fire_shift, skill_ice_shift, skill_mighty_shift, skill_physical_shift],
        "Buddy": [buddy_street, buddy_lovely, buddy_nerdy, buddy_catty]
    }, 
    
    "Break Zone": {
        "Coin/Exp": [11,14], 
        "Game Point": [21, 30], 
        "Items": [item_cleanse_small, item_glowing_small, item_soul_lantern, item_wrangler_lasso, item_caltrops, item_telescope], 
        "Extreme": [skill_guard, skill_stance, sigil_berserker, sigil_sanguine],
        "Gauntlet": [sigil_phoenix, sigil_razor, skill_rasenshuriken],
        "Seasson": [sigil_shadow, sigil_crow, skill_truth_seeking_orb, skill_primary_lotus],
        "Buddy": [buddy_timekeeper_cookie, buddy_electric_sheep, buddy_party_shrimp, buddy_pink_nurse]
    }, 
    
    "Power Zone": {
        "Coin/Exp": [16, 20],
        "Game Point": [41, 50],
        "Items": [item_cleanse_small, item_glowing_small, item_health_medium, item_mana_medium, item_pocket_watch, item_mini_elixer, item_heart_charm],
        "Extreme": [skill_stripping_lash, skill_shimmer, sigil_bahamut, sigil_ifrit],
        "Gauntlet": [sigil_ifrit_risen, sigil_brazen, skill_mantra_burst],
        "Seasson": [sigil_globe, sigil_snail, sigil_battery, sigil_rapid, skill_bacteri_hand, skill_thunderstone, skill_snow_haul, passive_reckless],
        "Buddy": [buddy_dead_butterflies, buddy_singing_alien, buddy_executors_scribe, buddy_young_pup, buddy_wild_pup]
    },
    
    "Mind Zone": {
        "Coin/Exp": [21, 26],
        "Game Point": [61, 72],
        "Items": [item_white_small_sanity, item_black_small_sanity, item_health_medium, item_mana_medium, item_mini_elixer, item_full_power],
        "Extreme": [passive_resilience, passive_rise_again, passive_hard_headed, sigil_blue_star],
        "Gauntlet": [skill_jagged_thrust, skill_wild_tempest, sigil_sanen, sigil_downpour],
        "Seasson": [skill_imogi_kick, skill_ice_crash, skill_lament_dullahan, passive_iron_head, sigil_dullahan, sigil_clone],
        "Buddy": [buddy_wild_kentaurous, buddy_muddy_fish, buddy_shield_bearer, buddy_glacial_chick, buddy_storm_bird]
    },

    "Moon Zone": {
        "Coin/Exp": [26, 32],
        "Game Point": [81, 93],
        "Items": [item_glowing_medium, item_refined_dew, item_charge_small, item_iron_small, item_mini_elixer, item_boulder_sling, item_rubberball, item_soul_lantern],
        "Extreme": [skill_cruenta_saltatio, skill_doloris_flames, skill_windga_razor, sigil_ifrit_burning, sigil_luster],
        "Gauntlet": [skill_divergent_slashes, skill_pentakinesis, sigil_manic],
        "Seasson": [skill_energy_field, skill_high_roller, sigil_three_headed, sigil_vile],
        "Buddy": [buddy_alpha, buddy_gatekeeper, buddy_void_pet, buddy_golden_crab]
    },
    
    "Destruction Zone": {
        "Coin/Exp": [31, 38],
        "Game Point": [100, 111],
        "Items": [item_elixer, item_cleanse_medium, item_glowing_medium, item_charge_medium, item_iron_medium, item_incense, item_refined_dew],
        "Extreme": [skill_ice_breaker, skill_lament_departed, skill_electric_screaming, sigil_bulwark, sigil_clown],
        "Gauntlet": [skill_psi_II, sigil_orions],
        "Seasson": [skill_ward, skill_jet_uppercut, skill_fluid_slam, sigil_mockingjay, sigil_markdown],
        "Buddy": [buddy_white_mage, buddy_black_mage, buddy_red_felm]
    },
    
    "Extreme Zone": {
        "Coin/Exp": [36, 44],
        "Game Point": [120, 132],
        "Items": [item_experience_book, item_experience_page, item_elixer, item_phoenix_feather, item_silph_scope, item_heart_charm],
        "Extreme": [skill_affinity_rattle, skill_energy_cycle, skill_clean_through, passive_dimensional_master, passive_castle_cannons, sigil_trickshot],
        "Gauntlet": [skill_zeta_flare, skill_corroding_pearl, skill_demanding_butterflies, passive_nuclear_aura, passive_bird_cage, passive_gloomy_mood, sigil_sore_winner, sigil_balance],
        "Seasson": [skill_thunderstrike_ripple, skill_sunshower, passive_rift_master, passive_basilisk_eye, sigil_draken_bahamut],
        "Buddy": [buddy_maddinging_flower, buddy_sand_spirit, buddy_djin]
    },
}

shops = {
    "Start Zone": [item_health_small, item_mana_small, item_protein, item_study_papers, item_fire_tome, item_thunder_tome, item_frost_book, item_breeze_book, item_whip, 
                   skill_clean_piercer, skill_dirty_blow, skill_bliz, skill_fira, skill_thunger, skill_wind, skill_cure, 
                   sigil_warmth, sigil_library, sigil_chain, sigil_bull, sigil_virus, sigil_doctor, sigil_executioner
    ],

    "Break Zone": [item_health_small, item_mana_small, item_cleanse_small, item_glowing_small, item_mediocre_shield, item_positive_balm, 
                   skill_blizga, skill_firaga, skill_thungerga, skill_windga, skill_zeta_I, skill_defensive_blow, skill_sword_dance, skill_double_down, skill_drag_down, skill_limit_break, skill_seethe, 
                   passive_devourer, 
                   sigil_ignis, sigil_rabbit, sigil_point, sigil_shred, sigil_double, sigil_leech
    ],

    "Power Zone": [item_health_medium, item_mana_medium, item_red_dew, item_blue_dew, item_incense, item_nasty_bomb, item_razor_knives, item_snow_globe, 
                   skill_curega, skill_mana_bomb, skill_lightning_charge, skill_wither_storm, skill_double_edge, skill_hellfire_press, skill_ill_wind, skill_drill_in, 
                   sigil_shiva, sigil_garuda, sigil_ramuh, sigil_exploiter, sigil_collapse, sigil_drive
    ],

    "Mind Zone": [item_health_medium, item_mana_medium, item_glowing_small, item_clover_bind, item_wrangler_lasso, item_telescope, item_white_small_sanity, item_black_small_sanity, item_rubberball, item_brass_lamp,
                  skill_magic_heart, skill_passion_impact, skill_psi_I, skill_cowards_blade, skill_swift_pierce, 
                  sigil_resilient, sigil_extra, sigil_vulture
    ],

    "Moon Zone": [item_glowing_medium, item_cleanse_medium, item_refined_dew, item_charge_small, item_iron_small, item_boon_talisman, item_curse_reliver, item_pocket_watch, item_electro_trap, item_charge_coil, item_caltrops,
                  skill_steam_blast, skill_blood_branch, skill_star_plummet, skill_shell_shock, skill_mineuchi, 
                  passive_deescalate, passive_beacon_positive, passive_mighty_prowess, passive_cling_on, 
                  sigil_butterfly, sigil_bee, sigil_angel, sigil_headstart, sigil_bookworm
    ],

    "Destruction Zone": [item_health_medium, item_mana_medium, item_cleanse_medium, item_glowing_medium, item_charge_small, item_iron_small, item_white_medium_sanity, item_black_medium_sanity, item_nasty_bomb, item_acid_bomb, item_daggers, item_electro_trap,
                         skill_caltera_cut, skill_bladeblitz, skill_disrupt, skill_vile_breath, skill_hael, skill_dome, skill_rime_shank, 
                         passive_poison_lord, passive_mother_follower, 
                         sigil_winter, sigil_garbage, sigil_roadrunner, sigil_tranquil, sigil_fierce, sigil_survivor
    ],

    "Extreme Zone": [item_health_large, item_mana_large, item_elixer, item_silph_scope, item_heart_charm, item_charge_medium, item_iron_medium, item_acid_bomb, item_rubberball, item_hair_dryer,
                     skill_frenzied_burst, skill_burning_jealousy, skill_moonlight_razor, skill_draining_hold, skill_meditate, skill_linger, skill_shack_off, skill_deep_breath, skill_acid_splash, 
                     passive_double_up, passive_pacifist, passive_battle_nurse, passive_fafnirs_crest, passive_out_pace, passive_christmas_bells, passive_energizer, 
                     sigil_bandage, sigil_goremoth, sigil_warden_light],
}

##------------===------------##
# Hazards - healing/leech/poison/wave
# Types - shop/train/transition/boss/reward/whirl

def makeTile(event=None, hazard=None, shop=None, type="safe", trainingRewards=None, north=False, east=False, south=False, west=False, raidTile=False, raidEnemy=False):
    return {"event": event, "hazard": hazard, "shop": shop, "type": type, "trainingRewards": trainingRewards, "wallNorth": north, "wallEast": east, "wallSouth": south, "wallWest": west, "raidTile": raidTile, "raidEnemy": raidEnemy}

map_start_zone = {
    #y, x
    (1, 1): makeTile(type="none"),
    (1, 2): makeTile(west=True),
    (1, 3): makeTile(hazard=("Break Zone", 2, 1), type="transition"),
    (1, 4): makeTile(east=True),
    (1, 5): makeTile(type="none"),
    
    (2, 1): makeTile(south=True, north=True, type="gate", hazard=("Hidden Start Area", 2, 3, 2000, ())),
    (2, 2): makeTile(),
    (2, 3): makeTile(),
    (2, 4): makeTile(),
    (2, 5): makeTile(south=True, north=True, type="buddyShop"),

    (3, 1): makeTile(type="none"),
    (3, 2): makeTile(west=True),
    (3, 3): makeTile(hazard="healing", type="boon"),
    (3, 4): makeTile(east=True),
    (3, 5): makeTile(type="none"),

    (4, 1): makeTile(south=True, north=True, type="storage"),
    (4, 2): makeTile(),
    (4, 3): makeTile(),
    (4, 4): makeTile(),
    (4, 5): makeTile(south=True, north=True),

    (5, 1): makeTile(type="none"),
    (5, 2): makeTile(),
    (5, 3): makeTile(type="shop", shop=["Start Zone Shop", shops["Start Zone"]]),
    (5, 4): makeTile(type="train", hazard=[lambda: random.randint(2,3), lambda: random.randint(18,20), [boss_fire_lord, boss_armored_knight]]),
    (5, 5): makeTile(type="none"),
}
map_start_zone = Map("Start Zone", map_start_zone, 5, 5, [2,4], [enemy_ice_slime, enemy_poison_slime, enemy_geo_slime], [3, 3], rewards["Start Zone"])

map_hidden_start = {
    # y, x
    (1, 1): makeTile(hazard=[[item_mini_elixer, 2], [item_experience_page, 4], [skill_thungerabolt, None]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(hazard=[[item_wrangler_lasso, 4], [item_charge_small, 2], [sigil_kings_crest, None]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_king_storms, type="boss"),
    (2, 3): makeTile(south=True),

    (3, 1): makeTile(type="none", north=True, east=True),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none", north=True, west=True),
}
map_hidden_start = Map("Hidden Start Area", map_hidden_start, 3, 3, [2,4], [], [2, 3], rewards["Start Zone"])

##--##

map_break_zone = {
    #y, x
    (1, 1): makeTile(type="gateHaz", hazard=("Hidden Break Area", 2, 3, 3000, ())),
    (1, 2): makeTile(hazard=("Start Zone", 3, 1), type="transition"),
    (1, 3): makeTile(type="hazard"),
   
    (2, 1): makeTile(type="hazard"),
    (2, 2): makeTile(type="hazard"),
    (2, 3):  makeTile(type="hazard"),
  
    (3, 1): makeTile(hazard=boss_armored_knight, type="boss"),
    (3, 2): makeTile(hazard=boss_fire_lord, type="boss"),
    (3, 3): makeTile(hazard=boss_mohg, type="boss"),
    
    (4, 1): makeTile(type="shop", shop=["Break Zone Shop", shops["Break Zone"]]),
    (4, 2): makeTile(hazard=("Power Zone", 1, 2), type="transition"),
    (4, 3): makeTile(type="train", hazard=[lambda: random.randint(3,4), lambda: random.randint(17,18), [boss_fire_lord, boss_armored_knight, boss_mohg, boss_radagon]]),
}
map_break_zone = Map("Break Zone", map_break_zone, 4, 3, [4,6], [enemy_fire_skeleton, enemy_red_knight], [2, 1], rewards["Break Zone"])

map_hidden_break = {
    # y, x
    (1, 1): makeTile(hazard=[[item_phoenix_feather, 1], [item_experience_page, 5], [skill_bloodboon_rite, None]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(hazard=[[item_cleanse_medium, 2], [item_turn_over, 1], [buddy_red_albinauric, None]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_mohg_consort, type="boss"),
    (2, 3): makeTile(south=True),

    (3, 1): makeTile(type="none", north=True, east=True),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none", north=True, west=True),
}
map_hidden_break = Map("Hidden Break Area", map_hidden_break, 3, 3, [4, 6], [], [2, 3], rewards["Break Zone"])

##--##

map_power_zone = {
    (1, 1): makeTile(hazard="healing", type="boon", east=True),
    (1, 2): makeTile(type="none"),
    (1, 3): makeTile(type="none"),
    (1, 4): makeTile(type="shop", shop=["Old Powerplant Shop", shops["Power Zone"]]),
    (1, 5): makeTile(hazard="leech", type="hazard"),
    (1, 6): makeTile(hazard="leech", type="hazard", south=True),
    (1, 7): makeTile(hazard="leech", type="hazard", east=True),
    (1, 8): makeTile(type="none"),
    
    (2, 1): makeTile(hazard=("Break Zone", 2, 4), type="transition", south=True),
    (2, 2): makeTile(hazard="leech", type="hazard", north=True, east=True),
    (2, 3): makeTile(type="none"),
    (2, 4): makeTile(type="none"),
    (2, 5): makeTile(hazard=boss_goku_black, type="boss", west=True, east=True),
    (2, 6): makeTile(type="gateNull", hazard=("Hidden Power Area", 2, 3, 4000, ()), north=True, south=True, west=True),
    (2, 7): makeTile(hazard=boss_deus_motus, type="boss"),
    (2, 8): makeTile(type="train", hazard=[lambda: random.randint(4,5), lambda: random.randint(15,17), [boss_radagon, boss_goku_black, boss_deus_motus, boss_kratos]]), 

    (3, 1): makeTile(type="none"),
    (3, 2): makeTile(hazard="leech", type="hazard", west=True),
    (3, 3): makeTile(hazard=boss_radagon, type="boss", north=True),
    (3, 4): makeTile(hazard="leech", type="hazard", north=True),
    (3, 5): makeTile(hazard="leech", type="hazard", east=True),
    (3, 6): makeTile(type="none"),
    (3, 7): makeTile(hazard=("Mind Zone", 1, 1), type="transition", west=True, east=True),
    (3, 8): makeTile(type="none"),
}
map_power_zone = Map("Power Zone", map_power_zone, 3, 8, [5,8], [enemy_yellow_samurai, enemy_serious_slime, enemy_playful_slime], [1, 2], rewards["Power Zone"])

map_hidden_power = {
    # y, x
    (1, 1): makeTile(hazard=[[item_mini_elixer, 3], [passive_kai_body, None], [skill_kai_split, None]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(hazard=[[item_cleanse_medium, 2], [item_full_power, 2], [sigil_time_ring, None]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_fused_zamasu, type="boss"),
    (2, 3): makeTile(south=True),

    (3, 1): makeTile(type="none", north=True, east=True),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none", north=True, west=True),
}
map_hidden_power = Map("Hidden Power Area", map_hidden_power, 3, 3, [5,8], [], [2, 3], rewards["Power Zone"])

##--##

map_mind_zone = { 
    #y, x
    (1, 1): makeTile(hazard=("Power Zone", 7, 3), type="transition", east=True),
    (1, 2): makeTile(type="none"),
    (1, 3): makeTile(hazard="poison", type="hazard", west=True),
    (1, 4): makeTile(hazard=boss_the_father, type="boss"),
    (1, 5): makeTile(hazard="poison", type="hazard",),

    (2, 1): makeTile(hazard="leech", type="hazard", east=True),
    (2, 2): makeTile(type="none"),
    (2, 3): makeTile(hazard="leech", type="hazard", west=True, east=True),
    (2, 4): makeTile(type="none"),
    (2, 5): makeTile(hazard="poison", type="hazard", west=True),

    (3, 1): makeTile(hazard="poison", type="hazard", east=True),
    (3, 2): makeTile(type="none"),
    (3, 3): makeTile(hazard=boss_time_ripper, type="boss", west=True),
    (3, 4): makeTile(type="shop", shop=["Mind Zone Shop", shops["Mind Zone"]]),
    (3, 5): makeTile(hazard="poison", type="hazard", west=True),

    (4, 1): makeTile(hazard="leech", type="hazard", east=True),
    (4, 2): makeTile(type="none"),
    (4, 3): makeTile(hazard="leech", type="hazard", west=True, east=True),
    (4, 4): makeTile(type="none"),
    (4, 5): makeTile(hazard="poison", type="hazard", west=True),

    (5, 1): makeTile(hazard="poison", type="hazard", east=True),
    (5, 2): makeTile(type="none"),
    (5, 3): makeTile(hazard="poison", type="hazard", west=True, east=True),
    (5, 4): makeTile(type="gateNull", hazard=("Hidden Mind Area", 2, 3, 5000, ()), north=True, south=True, west=True),
    (5, 5): makeTile(hazard="poison", type="hazard"),

    (6, 1): makeTile(hazard="leech", type="hazard", east=True),
    (6, 2): makeTile(type="none"),
    (6, 3): makeTile(hazard="leech", type="hazard", west=True, east=True),
    (6, 4): makeTile(type="train", hazard=[lambda: random.randint(4,5), lambda: random.randint(15,16), [boss_unspeaking_child, boss_midra, boss_time_ripper, boss_the_father]]),
    (6, 5): makeTile(hazard=boss_unspeaking_child, type="boss"), 

    (7, 1): makeTile(hazard="poison", type="hazard"),
    (7, 2): makeTile(hazard=boss_midra, type="boss"),
    (7, 3): makeTile(hazard="poison", type="hazard", west=True, east=True),
    (7, 4): makeTile(type="none"),
    (7, 5): makeTile(hazard=("Moon Zone", 6, 1), type="transition", west=True),
}
map_mind_zone = Map("Mind Zone", map_mind_zone, 7, 5, [9, 11], [enemy_zappy_spirit, enemy_frigid_spirit, enemy_negative_revenant], [1, 1], rewards["Mind Zone"])

map_hidden_mind = {
    # y, x
    (1, 1): makeTile(hazard=[[item_pocket_watch, 2], [skill_weak_victimize, None], [skill_sunset_blade, None]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(hazard=[[item_phoenix_feather, 1], [item_heart_charm, 3], [buddy_crying_children, None]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_phillip, type="boss"),
    (2, 3): makeTile(south=True),

    (3, 1): makeTile(type="none", north=True, east=True),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none", north=True, west=True),
}
map_hidden_mind = Map("Hidden Mind Area", map_hidden_mind, 3, 3, [9, 11], [], [2, 3], rewards["Mind Zone"])

##--##

map_moon_zone = {
    # y, x
    (1,  1): makeTile(type="none"),
    (1,  2): makeTile(type="none"),
    (1,  3): makeTile(type="none"),
    (1,  4): makeTile(type="none"),
    (1,  5): makeTile(type="none"),
    (1,  6): makeTile(west=True, hazard=("Mind Zone", 5, 7), type="transition"),
    (1,  7): makeTile(east=True),
    (1,  8): makeTile(type="none"),
    (1,  9): makeTile(type="none"),
    (1, 10): makeTile(type="none"),
    (1, 11): makeTile(type="none"),
    (1, 12): makeTile(type="none"),

    (2,  1): makeTile(type="none"),
    (2,  2): makeTile(type="none"),
    (2,  3): makeTile(type="none"),
    (2,  4): makeTile(type="none"),
    (2,  5): makeTile(north=True, west=True),
    (2,  6): makeTile(hazard="wave", type="hazard"),
    (2,  7): makeTile(hazard="wave", type="hazard"),
    (2,  8): makeTile(north=True, east=True),
    (2,  9): makeTile(type="none"),
    (2, 10): makeTile(type="none"),
    (2, 11): makeTile(type="none"),
    (2, 12): makeTile(type="none"),

    (3,  1): makeTile(type="none"),
    (3,  2): makeTile(type="none"),
    (3,  3): makeTile(type="none"),
    (3,  4): makeTile(type="none"),
    (3,  5): makeTile(south=True, west=True, type="whirl", hazard=[1, 6]),
    (3,  6): makeTile(hazard="wave", type="hazard"),
    (3,  7): makeTile(hazard="wave", type="hazard"),
    (3,  8): makeTile(south=True, east=True, type="whirl", hazard=[12, 6]),
    (3,  9): makeTile(type="none"),
    (3, 10): makeTile(type="none"),
    (3, 11): makeTile(type="none"),
    (3, 12): makeTile(type="none"),

    (4,  1): makeTile(type="none"),
    (4,  2): makeTile(type="none"),
    (4,  3): makeTile(type="none"),
    (4,  4): makeTile(type="none"),
    (4,  5): makeTile(type="none"),
    (4,  6): makeTile(south=True, west=True, type="storage"),
    (4,  7): makeTile(south=True, east=True),
    (4,  8): makeTile(type="none"),
    (4,  9): makeTile(type="none"),
    (4, 10): makeTile(type="none"),
    (4, 11): makeTile(type="none"),
    (4, 12): makeTile(type="none"),

    (5,  1): makeTile(type="none"),
    (5,  2): makeTile(type="none"),
    (5,  3): makeTile(type="none"),
    (5,  4): makeTile(type="none"),
    (5,  5): makeTile(type="none"),
    (5,  6): makeTile(type="none"),
    (5,  7): makeTile(type="none"),
    (5,  8): makeTile(type="none"),
    (5,  9): makeTile(type="none"),
    (5, 10): makeTile(type="none"),
    (5, 11): makeTile(type="none"),
    (5, 12): makeTile(type="none"),

    (6,  1): makeTile(north=True, south=True, type="whirl", hazard=[5, 3]),
    (6,  2): makeTile(north=True, south=True, hazard=boss_mamzer, type="boss"),
    (6,  3): makeTile(north=True, south=True, east=True, type="whirl", hazard=[5, 7]),
    (6,  4): makeTile(type="none"),
    (6,  5): makeTile(type="none"),
    (6,  6): makeTile(north=True, west=True, type="shop", shop=["Moon Zone Shop", shops["Moon Zone"]]),
    (6,  7): makeTile(north=True, west=True, type="train", hazard=[lambda: random.randint(9,11), lambda: random.randint(10,11), [boss_salax, boss_mamzer, boss_dolor, boss_egenus, boss_dionus]]),
    (6,  8): makeTile(type="none"),
    (6,  9): makeTile(type="none"),
    (6, 10): makeTile(north=True, south=True, west=True, type="whirl", hazard=[8, 7]),
    (6, 11): makeTile(north=True, south=True, hazard=boss_salax, type="boss"),
    (6, 12): makeTile(north=True, south=True, type="whirl", hazard=[8, 3]),

    (7,  1): makeTile(type="none"),
    (7,  2): makeTile(type="none"),
    (7,  3): makeTile(type="none"),
    (7,  4): makeTile(type="none"),
    (7,  5): makeTile(north=True, south=True, west=True, type="whirl", hazard=[1, 9]),
    (7,  6): makeTile(south=True, hazard=[[item_curse_reliver, 5], [item_health_medium, 3]], type="reward"),
    (7,  7): makeTile(south=True, hazard=[[item_boon_talisman, 5], [item_mana_medium, 4]], type="reward"),
    (7,  8): makeTile(north=True, south=True, east=True, type="whirl", hazard=[12, 9]),
    (7,  9): makeTile(type="none"),
    (7, 10): makeTile(type="none"),
    (7, 11): makeTile(type="none"),
    (7, 12): makeTile(type="none"),

    (8,  1): makeTile(type="none"),
    (8,  2): makeTile(type="none"),
    (8,  3): makeTile(type="none"),
    (8,  4): makeTile(type="none"),
    (8,  5): makeTile(type="none"),
    (8,  6): makeTile(type="none"),
    (8,  7): makeTile(type="none"),
    (8,  8): makeTile(type="none"),
    (8,  9): makeTile(type="none"),
    (8, 10): makeTile(type="none"),
    (8, 11): makeTile(type="none"),
    (8, 12): makeTile(type="none"),

    (9,  1): makeTile(north=True, south=True, type="whirl", hazard=[5, 7]),
    (9,  2): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9,  3): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9,  4): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9,  5): makeTile(north=True, hazard="wave", type="hazard"),
    (9,  6): makeTile(north=True, type="gateHaz", hazard=("Hidden Moon Area", 2, 3, 6000, ())),
    (9,  7): makeTile(north=True, hazard="wave", type="hazard"),
    (9,  8): makeTile(north=True, hazard="wave", type="hazard"),
    (9,  9): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9, 10): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9, 11): makeTile(north=True, south=True, hazard="wave", type="hazard"),
    (9, 12): makeTile(north=True, south=True, type="whirl", hazard=[8, 7]),

    (10,  1): makeTile(type="none"),
    (10,  2): makeTile(type="none"),
    (10,  3): makeTile(type="none"),
    (10,  4): makeTile(type="none"),
    (10,  5): makeTile(south=True, west=True, hazard="wave", type="hazard"),
    (10,  6): makeTile(hazard="leech", type="hazard"),
    (10,  7): makeTile(hazard="leech", type="hazard"),
    (10,  8): makeTile(south=True, east=True, hazard="wave", type="hazard"),
    (10,  9): makeTile(type="none"),
    (10, 10): makeTile(type="none"),
    (10, 11): makeTile(type="none"),
    (10, 12): makeTile(type="none"),

    (11,  1): makeTile(type="none"),
    (11,  2): makeTile(type="none"),
    (11,  3): makeTile(type="none"),
    (11,  4): makeTile(type="none"),
    (11,  5): makeTile(type="none"),
    (11,  6): makeTile(south=True, west=True, type="whirl", hazard=[1, 13]),
    (11,  7): makeTile(south=True, east=True, type="whirl", hazard=[12, 13]),
    (11,  8): makeTile(type="none"),
    (11,  9): makeTile(type="none"),
    (11, 10): makeTile(type="none"),
    (11, 11): makeTile(type="none"),
    (11, 12): makeTile(type="none"),

    (12,  1): makeTile(type="none"),
    (12,  2): makeTile(type="none"),
    (12,  3): makeTile(type="none"),
    (12,  4): makeTile(type="none"),
    (12,  5): makeTile(type="none"),
    (12,  6): makeTile(type="none"),
    (12,  7): makeTile(type="none"),
    (12,  8): makeTile(type="none"),
    (12,  9): makeTile(type="none"),
    (12, 10): makeTile(type="none"),
    (12, 11): makeTile(type="none"),
    (12, 12): makeTile(type="none"),

    (13,  1): makeTile(north=True, south=True, type="whirl", hazard=[6, 11]),
    (13,  2): makeTile(north=True, south=True, hazard=boss_egenus, type="boss"),
    (13,  3): makeTile(north=True, south=True, east=True, type="whirl", hazard=[5, 13]),
    (13,  4): makeTile(type="none"),
    (13,  5): makeTile(north=True, south=True, west=True, east=True, hazard=("Destruction Zone", 1, 1), type="transition"),
    (13,  6): makeTile(type="none"),
    (13,  7): makeTile(type="none"),
    (13,  8): makeTile(north=True, south=True, west=True, east=True, hazard=("Destruction Zone", 1, 1), type="transition"),
    (13,  9): makeTile(type="none"),
    (13, 10): makeTile(north=True, south=True, west=True, type="whirl", hazard=[8, 13]),
    (13, 11): makeTile(north=True, south=True, hazard=boss_dolor, type="boss"),
    (13, 12): makeTile(north=True, south=True, type="whirl", hazard=[7, 11]),
}
map_moon_zone = Map("Moon Zone", map_moon_zone, 13, 12, [12, 14], [enemy_mountain_slime, enemy_aura_deimon, enemy_howling_spirit], [6, 1], rewards["Moon Zone"])

map_hidden_moon = {
    # y, x
    (1, 1): makeTile(hazard=[[item_refined_dew, 5], [skill_four_sided, None], [item_experience_book, 5]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(east=True, hazard=[[item_full_power, 2], [item_health_large, 2], [buddy_moon_golem, None]], type="reward"),
    (1, 4): makeTile(type="none"),
    (1, 5): makeTile(west=True, hazard=[[item_mana_large, 2], [item_cleanse_large, 2], [sigil_festive, None]], type="reward"),
    (1, 6): makeTile(hazard="healing", type="boon"),
    (1, 7): makeTile(hazard=[[item_buddy_medium, 3], [skill_charged_strikes, None], [item_phoenix_feather, 1]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_chionizei, type="boss"),
    (2, 3): makeTile(east=True, south=True),
    (2, 4): makeTile(type="none"),
    (2, 5): makeTile(west=True, south=True),
    (2, 6): makeTile(hazard=boss_kataigida, type="boss"),
    (2, 7): makeTile(south=True),

    (3, 1): makeTile(type="none"),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none"),
    (3, 4): makeTile(type="none"),
    (3, 5): makeTile(type="none"),
    (3, 6): makeTile(west=True, east=True),
    (3, 7): makeTile(type="none"),

    (4, 1): makeTile(type="none"),
    (4, 2): makeTile(west=True, east=True, type="whirl", hazard=[6, 4]),
    (4, 3): makeTile(type="none"),
    (4, 4): makeTile(type="none"),
    (4, 5): makeTile(type="none"),
    (4, 6): makeTile(west=True, east=True, type="whirl", hazard=[2, 4]),
    (4, 7): makeTile(type="none"),
}
map_hidden_moon = Map("Hidden Moon Area", map_hidden_moon, 4, 7, [12, 14], [], [2, 4], rewards["Moon Zone"])

##--##

map_destruction_zone = {
    # y, x
    (1,  1): makeTile(hazard=("Moon Zone", 5, 13), type="transition"),
    (1,  2): makeTile(),
    (1,  3): makeTile(south=True, east=True, type="whirl", hazard=[5, 13]),
    (1,  4): makeTile(type="none"),
    (1,  5): makeTile(type="none"),
    (1,  6): makeTile(type="none"),
    (1,  7): makeTile(type="none"),
    (1,  8): makeTile(type="none"),
    (1,  9): makeTile(type="none"),
    (1, 10): makeTile(type="none"),
    (1, 11): makeTile(west=True, type="whirl", hazard=[7, 2]),
    (1, 12): makeTile(),
    (1, 13): makeTile(east=True, type="shop", shop=["Destruction Zone Shop", shops["Destruction Zone"]]),
    (1, 14): makeTile(type="none"),
    (1, 15): makeTile(west=True, type="whirl", hazard=[4, 7]),
    
    (2,  1): makeTile(),
    (2,  2): makeTile(south=True, east=True),
    (2,  3): makeTile(type="none"),
    (2,  4): makeTile(type="none"),
    (2,  5): makeTile(type="none"),
    (2,  6): makeTile(type="none"),
    (2,  7): makeTile(north=True, west=True, type="whirl", hazard=[11, 1]),
    (2,  8): makeTile(north=True, east=True, type="hazard"),
    (2,  9): makeTile(type="none"),
    (2, 10): makeTile(type="none"),
    (2, 11): makeTile(south=True, west=True),
    (2, 12): makeTile(hazard=boss_vilis, type="boss"),
    (2, 13): makeTile(south=True, east=True, hazard=[[item_glowing_medium, 4]], type="reward"),
    (2, 14): makeTile(type="none"),
    (2, 15): makeTile(west=True),
    
    (3,  1): makeTile(south=True, east=True, type="whirl", hazard=[4, 3]),
    (3,  2): makeTile(type="none"),
    (3,  3): makeTile(type="none"),
    (3,  4): makeTile(north=True, west=True, east=True, type="whirl", hazard=[1, 3]),
    (3,  5): makeTile(type="none"),
    (3,  6): makeTile(type="none"),
    (3,  7): makeTile(west=True, type="hazard", hazard="wave"),
    (3,  8): makeTile(type="hazard", hazard="wave"),
    (3,  9): makeTile(north=True, east=True, type="train", hazard=[lambda: random.randint(12,14), lambda: random.randint(9,10), [boss_vilis, boss_solumn_lament, boss_court_jester, boss_mask_delusion, boss_orion_knight]]),
    (3, 10): makeTile(type="none"),
    (3, 11): makeTile(type="none"),
    (3, 12): makeTile(south=True, west=True, east=True, type="whirl", hazard=[14, 4]),
    (3, 13): makeTile(type="none"),
    (3, 14): makeTile(north=True, west=True),
    (3, 15): makeTile(),
    
    (4,  1): makeTile(type="none"),
    (4,  2): makeTile(type="none"),
    (4,  3): makeTile(north=True, west=True),
    (4,  4): makeTile(),
    (4,  5): makeTile(north=True, east=True),
    (4,  6): makeTile(type="none"),
    (4,  7): makeTile(south=True, west=True),
    (4,  8): makeTile(),
    (4,  9): makeTile(east=True),
    (4, 10): makeTile(type="none"),
    (4, 11): makeTile(type="none"),
    (4, 12): makeTile(type="none"),
    (4, 13): makeTile(type="none"),
    (4, 14): makeTile(south=True, west=True, type="whirl", hazard=[12, 3]),
    (4, 15): makeTile(south=True, type="storage"),
    
    (5,  1): makeTile(type="none"),
    (5,  2): makeTile(type="none"),
    (5,  3): makeTile(west=True, hazard=[[item_health_medium, 7]], type="reward"),
    (5,  4): makeTile(hazard="healing", type="boon"),
    (5,  5): makeTile(east=True, hazard=[[item_mana_medium, 6]], type="reward"),
    (5,  6): makeTile(type="none"),
    (5,  7): makeTile(type="none"),
    (5,  8): makeTile(south=True, west=True, type="whirl", hazard=[7, 7]),
    (5,  9): makeTile(south=True, east=True),
    (5, 10): makeTile(type="none"),
    (5, 11): makeTile(type="none"),
    (5, 12): makeTile(north=True, west=True, type="whirl", hazard=[12, 1]),
    (5, 13): makeTile(north=True, east=True, hazard="wave", type="hazard"),
    (5, 14): makeTile(type="none"),
    (5, 15): makeTile(type="none"),
    
    (6,  1): makeTile(type="none"),
    (6,  2): makeTile(type="none"),
    (6,  3): makeTile(south=True, west=True),
    (6,  4): makeTile(),
    (6,  5): makeTile(south=True, east=True),
    (6,  6): makeTile(type="none"),
    (6,  7): makeTile(type="none"),
    (6,  8): makeTile(type="none"),
    (6,  9): makeTile(type="none"),
    (6, 10): makeTile(type="none"),
    (6, 11): makeTile(north=True, west=True, type="hazard"),
    (6, 12): makeTile(type="hazard"),
    (6, 13): makeTile(east=True, type="hazard"),
    (6, 14): makeTile(type="none"),
    (6, 15): makeTile(type="none"),
    
    (7,  1): makeTile(type="none"),
    (7,  2): makeTile(type="none"),
    (7,  3): makeTile(type="none"),
    (7,  4): makeTile(south=True, west=True, east=True, type="whirl", hazard=[15, 1]),
    (7,  5): makeTile(type="none"),
    (7,  6): makeTile(type="none"),
    (7,  7): makeTile(north=True, west=True, east=True, type="whirl", hazard=[8, 5]),
    (7,  8): makeTile(type="none"),
    (7,  9): makeTile(type="none"),
    (7, 10): makeTile(type="none"),
    (7, 11): makeTile(south=True, west=True, hazard="wave", type="hazard"),
    (7, 12): makeTile(hazard=boss_solumn_lament, type="boss"),
    (7, 13): makeTile(south=True, east=True, hazard="wave", type="hazard"),
    (7, 14): makeTile(type="none"),
    (7, 15): makeTile(type="none"),
    
    (8,  1): makeTile(type="none"),
    (8,  2): makeTile(type="none"),
    (8,  3): makeTile(type="none"),
    (8,  4): makeTile(type="none"),
    (8,  5): makeTile(type="none"),
    (8,  6): makeTile(type="none"),
    (8,  7): makeTile(west=True, hazard=boss_court_jester, type="boss"),
    (8,  8): makeTile(north=True),
    (8,  9): makeTile(north=True, east=True, hazard=[[item_charge_medium, 2]], type="reward"),
    (8, 10): makeTile(type="none"),
    (8, 11): makeTile(type="none"),
    (8, 12): makeTile(south=True, west=True, east=True, type="whirl", hazard=[15, 10]),
    (8, 13): makeTile(type="none"),
    (8, 14): makeTile(type="none"),
    (8, 15): makeTile(type="none"),
    
    (9,  1): makeTile(north=True, east=True, type="whirl", hazard=[11, 10]),
    (9,  2): makeTile(type="none"),
    (9,  3): makeTile(type="none"),
    (9,  4): makeTile(type="none"),
    (9,  5): makeTile(type="none"),
    (9,  6): makeTile(type="none"),
    (9,  7): makeTile(south=True, west=True),
    (9,  8): makeTile(),
    (9,  9): makeTile(south=True, east=True, hazard=[[item_iron_medium, 3]], type="reward"),
    (9, 10): makeTile(type="none"),
    (9, 11): makeTile(type="none"),
    (9, 12): makeTile(type="none"),
    (9, 13): makeTile(type="none"),
    (9, 14): makeTile(type="none"),
    (9, 15): makeTile(type="none"),
    
    (10,  1): makeTile(east=True, type="hazard", hazard="poison"),
    (10,  2): makeTile(type="none"),
    (10,  3): makeTile(type="none"),
    (10,  4): makeTile(type="none"),
    (10,  5): makeTile(type="none"),
    (10,  6): makeTile(type="none"),
    (10,  7): makeTile(type="none"),
    (10,  8): makeTile(south=True, west=True, east=True, hazard=("Extreme Zone", 5, 1), type="transition"),
    (10,  9): makeTile(type="none"),
    (10, 10): makeTile(type="none"),
    (10, 11): makeTile(north=True, west=True, east=True, type="whirl", hazard=[1, 9]),
    (10, 12): makeTile(type="none"),
    (10, 13): makeTile(type="none"),
    (10, 14): makeTile(type="none"),
    (10, 15): makeTile(north=True, west=True, type="whirl", hazard=[12, 8]),
    
    (11,  1): makeTile(type="hazard", hazard="poison"),
    (11,  2): makeTile(north=True, east=True, type="hazard", hazard="poison"),
    (11,  3): makeTile(type="none"),
    (11,  4): makeTile(type="none"),
    (11,  5): makeTile(type="none"),
    (11,  6): makeTile(type="none"),
    (11,  7): makeTile(type="none"),
    (11,  8): makeTile(type="none"),
    (11,  9): makeTile(type="none"),
    (11, 10): makeTile(north=True, west=True),
    (11, 11): makeTile(east=True, hazard=boss_mask_delusion, type="boss"),
    (11, 12): makeTile(type="none"),
    (11, 13): makeTile(type="none"),
    (11, 14): makeTile(north=True, west=True, hazard="wave", type="hazard"),
    (11, 15): makeTile(hazard="wave", type="hazard"),
    
    (12,  1): makeTile(type="hazard", hazard="poison"),
    (12,  2): makeTile(type="hazard", hazard="poison"),
    (12,  3): makeTile(north=True, type="hazard", hazard="poison"),
    (12,  4): makeTile(north=True, east=True, type="hazard", hazard="poison"),
    (12,  5): makeTile(type="none"),
    (12,  6): makeTile(type="none"),
    (12,  7): makeTile(type="none"),
    (12,  8): makeTile(type="none"),
    (12,  9): makeTile(type="none"),
    (12, 10): makeTile(west=True),
    (12, 11): makeTile(hazard="healing", type="boon"),
    (12, 12): makeTile(north=True, east=True),
    (12, 13): makeTile(type="none"),
    (12, 14): makeTile(west=True, hazard="leech", type="hazard"),
    (12, 15): makeTile(hazard="wave", type="hazard"),
    
    (13,  1): makeTile(type="whirl", hazard=[10, 13]),
    (13,  2): makeTile(type="hazard", hazard="poison"),
    (13,  3): makeTile(type="hazard", hazard="poison"),
    (13,  4): makeTile(type="hazard", hazard="poison"),
    (13,  5): makeTile(north=True, east=True, type="whirl", hazard=[3, 1]),
    (13,  6): makeTile(type="none"),
    (13,  7): makeTile(type="none"),
    (13,  8): makeTile(type="none"),
    (13,  9): makeTile(type="none"),
    (13, 10): makeTile(west=True, type="whirl", hazard=[1, 13]),
    (13, 11): makeTile(),
    (13, 12): makeTile(east=True, type="whirl", hazard=[14, 13]),
    (13, 13): makeTile(type="none"),
    (13, 14): makeTile(west=True, type="whirl", hazard=[12, 13]),
    (13, 15): makeTile(hazard="leech", type="hazard"),
}
map_destruction_zone = Map("Destruction Zone", map_destruction_zone, 13, 15, [13, 15], [enemy_aura_deimon, enemy_incessant_doctor, enemy_titan, enemy_wild_cotton, enemy_the_melded_faces, enemy_the_jailer, enemy_silver_slime], [1, 1], rewards["Destruction Zone"])

##--##

map_extreme_zone = {
    # y, x
    (1,  1): makeTile(type="hazard"),
    (1,  2): makeTile(south=True, type="hazard"),
    (1,  3): makeTile(type="hazard"),
    (1,  4): makeTile(type="hazard"),
    (1,  5): makeTile(hazard=("Destruction Zone", 8, 10), type="transition"),
    (1,  6): makeTile(hazard=("Destruction Zone", 8, 10), type="transition"),
    (1,  7): makeTile(type="hazard"),
    (1,  8): makeTile(type="hazard"),
    (1,  9): makeTile(south=True, type="hazard"),
    (1, 10): makeTile(type="hazard"),

    (2,  1): makeTile(east=True),
    (2,  2): makeTile(type="none"),
    (2,  3): makeTile(west=True),
    (2,  4): makeTile(type="hazard"),
    (2,  5): makeTile(type="hazard"),
    (2,  6): makeTile(type="hazard"),
    (2,  7): makeTile(type="hazard"),
    (2,  8): makeTile(east=True),
    (2,  9): makeTile(type="none"),
    (2, 10): makeTile(west=True),

    (3,  1): makeTile(south=True, east=True, type="whirl", hazard=[1, 6]),
    (3,  2): makeTile(type="none"),
    (3,  3): makeTile(west=True),
    (3,  4): makeTile(hazard="wave", type="hazard"),
    (3,  5): makeTile(hazard="wave", type="hazard"),
    (3,  6): makeTile(hazard="wave", type="hazard"),
    (3,  7): makeTile(hazard="wave", type="hazard"),
    (3,  8): makeTile(east=True),
    (3,  9): makeTile(type="none"),
    (3, 10): makeTile(south=True, west=True, type="whirl", hazard=[10, 6]),

    (4,  1): makeTile(type="none"),
    (4,  2): makeTile(type="none"),
    (4,  3): makeTile(west=True),
    (4,  4): makeTile(hazard="wave", type="hazard"),
    (4,  5): makeTile(hazard="wave", type="hazard"),
    (4,  6): makeTile(hazard="wave", type="hazard"),
    (4,  7): makeTile(hazard="wave", type="hazard"),
    (4,  8): makeTile(east=True),
    (4,  9): makeTile(type="none"),
    (4, 10): makeTile(type="none"),

    (5,  1): makeTile(type="none"),
    (5,  2): makeTile(type="none"),
    (5,  3): makeTile(south=True, west=True),
    (5,  4): makeTile(),
    (5,  5): makeTile(south=True),
    (5,  6): makeTile(south=True),
    (5,  7): makeTile(),
    (5,  8): makeTile(south=True, east=True, type="storage"),
    (5,  9): makeTile(type="none"),
    (5, 10): makeTile(type="none"),

    (6,  1): makeTile(north=True, east=True, hazard=[[item_mana_medium, 3], [item_experience_book, 3]], type="reward"),
    (6,  2): makeTile(type="none"),
    (6,  3): makeTile(type="none"),
    (6,  4): makeTile(east=True, west=True, hazard=boss_wayward_passenger, type="boss"),
    (6,  5): makeTile(type="none"),
    (6,  6): makeTile(type="none"),
    (6,  7): makeTile(east=True, west=True, hazard=boss_orion_knight, type="boss"),
    (6,  8): makeTile(type="none"),
    (6,  9): makeTile(type="none"),
    (6, 10): makeTile(north=True, west=True, hazard=[[item_health_medium, 5], [item_experience_page, 5]], type="reward"),

    (7,  1): makeTile(east=True, hazard=boss_three_drag_king, type="boss"),
    (7,  2): makeTile(type="none"),
    (7,  3): makeTile(type="none"),
    (7,  4): makeTile(east=True, west=True, hazard=[[item_glowing_medium, 5]], type="reward"),
    (7,  5): makeTile(type="none"),
    (7,  6): makeTile(type="none"),
    (7,  7): makeTile(east=True, west=True, hazard=[[item_elixer, 2]], type="reward"),
    (7,  8): makeTile(type="none"),
    (7,  9): makeTile(type="none"),
    (7, 10): makeTile(west=True, hazard=boss_godfrey, type="boss"),

    (8,  1): makeTile(south=True, east=True, type="whirl", hazard=[1, 11]),
    (8,  2): makeTile(type="none"),
    (8,  3): makeTile(type="none"),
    (8,  4): makeTile(east=True, west=True),
    (8,  5): makeTile(type="none"),
    (8,  6): makeTile(type="none"),
    (8,  7): makeTile(east=True, west=True),
    (8,  8): makeTile(type="none"),
    (8,  9): makeTile(type="none"),
    (8, 10): makeTile(south=True, west=True, type="whirl", hazard=[10, 11]),

    (9,  1): makeTile(type="none"),
    (9,  2): makeTile(type="none"),
    (9,  3): makeTile(north=True, west=True, type="raid"),
    (9,  4): makeTile(),
    (9,  5): makeTile(north=True, type="shop", shop=["Extreme Zone Shop", shops["Extreme Zone"]]),
    (9,  6): makeTile(north=True, type="train", hazard=[lambda: random.randint(9,11), lambda: random.randint(8,9), [boss_orion_knight, boss_three_drag_king, boss_godfrey, boss_wayward_passenger]]),
    (9,  7): makeTile(),
    (9,  8): makeTile(north=True, east=True, hazard=("Hidden Extreme Area", 2, 3, 8000, ()), type="gate"),
    (9,  9): makeTile(type="none"),
    (9, 10): makeTile(type="none"),

    (10,  1): makeTile(type="none"),
    (10,  2): makeTile(type="none"),
    (10,  3): makeTile(west=True),
    (10,  4): makeTile(),
    (10,  5): makeTile(),
    (10,  6): makeTile(),
    (10,  7): makeTile(),
    (10,  8): makeTile(east=True),
    (10,  9): makeTile(type="none"),
    (10, 10): makeTile(type="none"),

    (11,  1): makeTile(north=True, east=True),
    (11,  2): makeTile(type="none"),
    (11,  3): makeTile(west=True),
    (11,  4): makeTile(type="hazard"),
    (11,  5): makeTile(type="hazard"),
    (11,  6): makeTile(type="hazard"),
    (11,  7): makeTile(type="hazard"),
    (11,  8): makeTile(east=True),
    (11,  9): makeTile(type="none"),
    (11, 10): makeTile(north=True, west=True),

    (12,  1): makeTile(type="hazard"),
    (12,  2): makeTile(north=True, type="hazard"),
    (12,  3): makeTile(type="hazard"),
    (12,  4): makeTile(type="hazard"),
    (12,  5): makeTile(type="hazard"),
    (12,  6): makeTile(type="hazard"),
    (12,  7): makeTile(type="hazard"),
    (12,  8): makeTile(type="hazard"),
    (12,  9): makeTile(north=True, type="hazard"),
    (12, 10): makeTile(type="hazard"),
}
map_extreme_zone = Map("Extreme Zone", map_extreme_zone, 12, 10, [14, 17], [enemy_the_melded_faces, enemy_aura_deimon, enemy_dimension_wisp, enemy_knight_slime, enemy_calico_slime], [6, 1], rewards["Extreme Zone"])

map_hidden_extreme = {
    # y, x
    (1, 1): makeTile(hazard=[[item_experience_tome, 3], [skill_nightshade, None]], type="reward"),
    (1, 2): makeTile(hazard="healing", type="boon"),
    (1, 3): makeTile(hazard=[[item_pocket_watch, 5], [buddy_shadow_hound, None]], type="reward"),

    (2, 1): makeTile(south=True),
    (2, 2): makeTile(hazard=boss_shadow_daemon, type="boss"),
    (2, 3): makeTile(south=True),

    (3, 1): makeTile(type="none", north=True, east=True),
    (3, 2): makeTile(west=True, east=True),
    (3, 3): makeTile(type="none", north=True, west=True),
}
map_hidden_extreme = Map("Hidden Extreme Area", map_hidden_extreme, 3, 3, [14, 17], [], [2, 3], rewards["Extreme Zone"])


##--##

"""
Map 8 Skills
In The Name of Love and Hate, AEDD
Cleanup Demonstration, Tidal Elegy
Abyssal Dance, Rain of Tears
Ebonny Stem, Legerdemain
Combusting Blade, Explode
Mental Blast, Extreme Speed
Splitting Winds, Arrow Barrage
Bang Bang, Rose Hunter Lasso
Command: Meltdown, To Remain Oneself
Coin Toss, Void Stare
Full Life, Rejuvenate
Downtrodden, Dirty Strikes
Great Echo, Headstart
Close Combatant, Warp Train
Warp Strike, Charge
"""

"""
Map 8 Sigils | Make The Prices
Emperor, Scarecrow, Telamon
Red Blur, Seafarer, Abyssal Heart
Negative Nancy, Twin Moon, Primed Garuda
Bound Buddha, Ultima, Sensei,
Master, Sure FIre
"""