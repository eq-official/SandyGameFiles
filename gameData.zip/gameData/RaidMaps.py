from Utility import *
from gameData.Map import *

# raidTile will allow for tiles to be replaced when finalizing the map. 

def itemScreen(raidPlayer):
    page = []
    currentPage = 0

    while True:
        clear()

        pages = []
        for item in raidPlayer.items:
            if not pages or len(pages[-1]) == 5:
                pages.append([])
            pages[-1].append(item)

        if pages and currentPage >= len(pages):
            currentPage = len(pages) - 1

        if pages:
            number = 0
            print(f"{Color['cyan']}Items | {Color['yellow']}Page: {currentPage + 1}/{len(pages)}{Color['reset']}")
            line("chrMain")
            for item in pages[currentPage]:
                print(f"{number}. {item.name} | {item.playerAmount}/{item.maxAmount} {f'| Hit: {item.hit}' if item.hit > 0 else ''}")
                text = Color['green'] + item.effect + Color['reset']
                names = sorted(Status.allStatuses.keys(), key=len, reverse=True)
                pattern = r"\b(" + "|".join(map(re.escape, names)) + r")\b"
                text = re.sub(pattern, lambda m: colorize(m, Status), text)
                print(text)
                
                shown = set()
                for status in Status.allStatuses.values():
                    printStatus(status, item, shown)
                    
                if "Skill" in item.type_:
                    print(f"Skill Detail: {Color['yellow']}{item.skill.element.capitalize() if item.skill.element != None else item.skill.element } | Cost: {item.skill.cost + round(raidPlayer.sigillessMaxMana * 0.06)} | Hit: {item.skill.hit} | Crit: {item.skill.critical}{Color['reset']}")
                    print(f"Skill Effect: {Color['cyan']}{item.skill.text}{Color['reset']}")
                number += 1
                if number != len(pages[currentPage]):
                    print("")
        else:
            print("No Items!")
        line("chrMain")

        print(f"U + Item Number (Use)\n"
                "0. Back")
        if currentPage + 1 < len(pages): print("1. Next Page")
        if currentPage > 0: print("2. Previous Page")
        line("chrMain")

        itemChoice = input("->")

        if itemChoice.startswith("u") or itemChoice.startswith("U"):
            idx = itemChoice[1:]
            if pages and idx.isdigit() and int(idx) < len(pages[currentPage]):
                chosen = pages[currentPage][int(idx)]
                if "Damage" not in chosen.type_ and "StatusC" not in chosen.type_ and "StatusI" not in chosen.type_ and "Cleanse" not in chosen.type_ and chosen.useType != "Battle":
                    chosen.use(raidPlayer, None)
                else:
                    print("Cannot Use This Item Out Of Battle!")
                input("?>")

        elif itemChoice == "0":
            break

        elif itemChoice == "1" and currentPage + 1 < len(pages):
            currentPage += 1

        elif itemChoice == "2" and currentPage > 0:
            currentPage -= 1

def raidRun(map_, raidPlayer, guide):
    # Guide is the guide function form Main
    clear()

    # Information Display
    print(f"{Color['red']}{map_.name}{Color['reset']}")
    line("battle")
    
    print(f"Health: {Color['red']}{raidPlayer.health}/{raidPlayer.maxHealth}{Color['reset']} | Mana: {Color['blue']}{raidPlayer.mana}/{raidPlayer.maxMana}{Color['reset']}")
    print(f"Strength: {Color['cyan']}{raidPlayer.strength}{Color['reset']} | Magic: {Color['cyan']}{raidPlayer.magic}{Color['reset']}")
    print(f"Defense: {Color['cyan']}{raidPlayer.defense}{Color['reset']} | Resistance: {Color['cyan']}{raidPlayer.resistance}{Color['reset']}")
    print(f"Luck: {Color['yellow']}{raidPlayer.luck}{Color['reset']} | Hit: {Color['yellow']}{raidPlayer.hit}{Color['reset']} | Speed: {Color['yellow']}{raidPlayer.speed}{Color['reset']}")
    line("battle")

    display = map_.display(raidPlayer)
    for row in display:
        print(row)
    line("battle")

    # Movement/Wall Options And Info
    currentTile = map_.tiles.get((raidPlayer.y, raidPlayer.x))

    if currentTile["wallNorth"]:
        print(f"{Color['red']}Wall Ahead!{Color['reset']}")
    if currentTile["wallWest"]:
        print(f"{Color['red']}Wall To The Left!{Color['reset']}")
    if currentTile["wallSouth"]:
        print(f"{Color['red']}Wall Behind!{Color['reset']}")
    if currentTile["wallEast"]:
        print(f"{Color['red']}Wall To The Right!{Color['reset']}")

    result = map_.tileBehavior(raidPlayer)
    if result and result == "Win":
        return "Win"

    elif result and result == "Loss":
        return "Loss"

    elif result and result == "Continue":
        previous = currentTile.get("previous")

        if previous == "north":
            raidPlayer.y -= 1
        elif previous == "south":
            raidPlayer.y += 1
        elif previous == "west":
            raidPlayer.x -= 1
        elif previous == "east":
            raidPlayer.x += 1

        raidPlayer.x = max(1, min(raidPlayer.x, map_.maxX))
        raidPlayer.y = max(1, min(raidPlayer.y, map_.maxY))
        return

    if currentTile["wallNorth"] or currentTile["wallWest"] or currentTile["wallSouth"] or currentTile["wallEast"]:
        line("battle")

    print(f"{Color['yellow']}W.A.S.D{Color['reset']}")

    print(f"0. Use Item\n"
          f'1. Guide')
    if currentTile["type"] in ["transition", "gate", "gateHaz", "gateNull"]:
        print(f"2. Move To Different Location?")
    if currentTile["type"] == "whirl":
        print(f"2. Enter Whril?")
    line("battle")

    choice = input("->").strip()

    # Options Effects
    if choice and choice in "wWaAsSdD":
        map_.movement(raidPlayer, choice, False)
    
    elif choice == "0":
        itemScreen(raidPlayer)
    
    elif choice == "1":
        guide()
    
    elif currentTile["type"] == "transition" and choice == "2":
        map_.transition(raidPlayer, currentTile["hazard"][0], currentTile["hazard"][1], currentTile["hazard"][2])
    
    elif currentTile["type"] in ["gate", "gateHaz", "gateNull"] and choice == "2":
        map_.gate(raidPlayer, currentTile["hazard"][0], currentTile["hazard"][1], currentTile["hazard"][2], currentTile["hazard"][3], currentTile)
    
    elif currentTile["type"] == "whirl" and choice == "2":
        raidPlayer.x = currentTile['hazard'][0]
        raidPlayer.y = currentTile["hazard"][1]
    
    else:
        return
    
## -- Normal Maps -- ##

raid_normal_swamp = {
    #y, x
    (1, 1):  makeTile(type="hazard", hazard="poison", raidTile=True),
    (1, 2):  makeTile(type="hazard", hazard="poison"),
    (1, 3):  makeTile(type="hazard", hazard="poison", raidTile=True),
    (1, 4):  makeTile(type="hazard", hazard="poison", raidTile=True),

    (2, 1):  makeTile(type="hazard", hazard="poison"), # <- Player will be here!
    (2, 2):  makeTile(type="hazard", hazard="poison"),
    (2, 3):  makeTile(type="hazard", hazard="poison", raidTile=True),
    (2, 4):  makeTile(type="hazard", hazard="poison", raidEnemy=True), #<- Enemy will be here!

    (3, 1):  makeTile(type="hazard", hazard="poison", raidTile=True),
    (3, 2):  makeTile(type="hazard", hazard="poison"),
    (3, 3):  makeTile(type="hazard", hazard="poison"),
    (3, 4):  makeTile(type="hazard", hazard="poison", raidTile=True),
}
raid_normal_swamp = Map("Swamp", raid_normal_swamp, 3, 4, None, None, [2, 1], None)

raid_normal_leech = {
    #y, x
    (1, 1):  makeTile(type="hazard", hazard="leech", raidTile=True),
    (1, 2):  makeTile(type="hazard", hazard="leech"),
    (1, 3):  makeTile(type="hazard", hazard="leech", raidTile=True),
    (1, 4):  makeTile(type="hazard", hazard="leech", raidTile=True),

    (2, 1):  makeTile(type="hazard", hazard="leech"), # <- Player will be here!
    (2, 2):  makeTile(type="hazard", hazard="leech"),
    (2, 3):  makeTile(type="hazard", hazard="leech", raidTile=True),
    (2, 4):  makeTile(type="hazard", hazard="leech", raidEnemy=True), #<- Enemy will be here!

    (3, 1):  makeTile(type="hazard", hazard="leech", raidTile=True),
    (3, 2):  makeTile(type="hazard", hazard="leech"),
    (3, 3):  makeTile(type="hazard", hazard="leech"),
    (3, 4):  makeTile(type="hazard", hazard="leech", raidTile=True),
}
raid_normal_leech = Map("Leech Land", raid_normal_leech, 3, 4, None, None, [2, 1], None)

up_to_change = { # <- Change This!!!!!!
    #y, x
    (1, 1):  makeTile(raidTile=True),
    (1, 2):  makeTile(),
    (1, 3):  makeTile(raidTile=True),
    (1, 4):  makeTile(raidTile=True),

    (2, 1):  makeTile(), # <- Player will be here!
    (2, 2):  makeTile(),
    (2, 3):  makeTile(raidTile=True),
    (2, 4):  makeTile(raidEnemy=True), #<- Enemy will be here!

    (3, 1):  makeTile(raidTile=True),
    (3, 2):  makeTile(),
    (3, 3):  makeTile(),
    (3, 4):  makeTile(raidTile=True),
}
up_to_change = Map("up_to_change", up_to_change, 3, 4, None, None, [2, 1], None)

normal_raid_maps = [raid_normal_swamp, raid_normal_leech, up_to_change]

## -- Specal Maps -- ##

special_melianes_plain = {
    #y, x
    (1, 1): makeTile(type="none"),
    (1, 2): makeTile(type="none"),
    (1, 3): makeTile(east=True, west=True, raidTile=True),
    (1, 4): makeTile(type="none"),
    (1, 5): makeTile(type="none"),
    (1, 6): makeTile(east=True, west=True, raidTile=True),
    (1, 7): makeTile(type="none"),
    (1, 8): makeTile(type="none"),

    (2, 1): makeTile(type="none"),
    (2, 2): makeTile(north=True, west=True),
    (2, 3): makeTile(east=True),
    (2, 4): makeTile(type="none"),
    (2, 5): makeTile(north=True, west=True),
    (2, 6): makeTile(),
    (2, 7): makeTile(north=True, east=True, raidTile=True),
    (2, 8): makeTile(type="none"),

    (3, 1): makeTile(north=True, south=True), # <- Player will be here!
    (3, 2): makeTile(raidTile=True),
    (3, 3): makeTile(),
    (3, 4): makeTile(north=True, south=True),
    (3, 5): makeTile(raidTile=True),
    (3, 6): makeTile(),
    (3, 7): makeTile(raidTile=True),
    (3, 8): makeTile(north=True, south=True, raidEnemy=True), #<- Enemy will be here!

    (4, 1): makeTile(type="none"),
    (4, 2): makeTile(west=True),
    (4, 3): makeTile(east=True),
    (4, 4): makeTile(type="none"),
    (4, 5): makeTile(west=True, south=True),
    (4, 6): makeTile(),
    (4, 7): makeTile(east=True, south=True),
    (4, 8): makeTile(type="none"),

    (5, 1): makeTile(type="none"),
    (5, 2): makeTile(type="none"),
    (5, 3): makeTile(west=True, east=True, raidTile=True),
    (5, 4): makeTile(type="none"),
    (5, 5): makeTile(type="none"),
    (5, 6): makeTile(west=True, east=True, raidTile=True),
    (5, 7): makeTile(type="none"),
    (5, 8): makeTile(type="none"),
}
special_melianes_plain = Map("Meliane's Plain", special_melianes_plain, 5, 8, None, None, [3, 1], None)

special_hanbos_temple_entrance = {
    (1, 1): makeTile(type="none"),
    (1, 2): makeTile(type="none"),
    (1, 3): makeTile(type="none"),
    (1, 4): makeTile(type="none"),
    (1, 5): makeTile(type="none"),

    (2, 1): makeTile(type="none"),
    (2, 2): makeTile(type="none"),
    (2, 3): makeTile(type="none"),
    (2, 4): makeTile(type="none"),
    (2, 5): makeTile(type="none"),

    (3, 1): makeTile(north=True, south=True),
    (3, 2): makeTile(north=True, south=True, hazard="poison", type="hazard", raidTile=True),
    (3, 3): makeTile(north=True, south=True, hazard="poison", type="hazard", raidTile=True),
    (3, 4): makeTile(north=True, south=True, hazard="poison", type="hazard", raidTile=True),
    (3, 5): makeTile(north=True, south=True, raidEnemy=True),

    (4, 1): makeTile(type="none"),
    (4, 2): makeTile(type="none"),
    (4, 3): makeTile(type="none"),
    (4, 4): makeTile(type="none"),
    (4, 5): makeTile(type="none"),

    (5, 1): makeTile(type="none"),
    (5, 2): makeTile(type="none"),
    (5, 3): makeTile(type="none"),
    (5, 4): makeTile(type="none"),
    (5, 5): makeTile(type="none"),
}
special_hanbos_temple_entrance = Map("Hanbo's Temple Bridge", special_hanbos_temple_entrance, 5, 5, None, None, [3, 1], None)

## -- Boss Maps -- ##

special_melianes_bank = {
    (1, 1): makeTile(type="none"),
    (1, 2): makeTile(type="none"),
    (1, 3): makeTile(type="none"),

    (2, 1): makeTile(north=True, south=True),
    (2, 2): makeTile(north=True, south=True, raidTile=True),
    (2, 3): makeTile(north=True, south=True, raidEnemy=True),

    (3, 1): makeTile(type="none"),
    (3, 2): makeTile(type="none"),
    (3, 3): makeTile(type="none"),
}
special_melianes_bank = Map("Meliane's River Bank", special_melianes_bank, 3, 3, None, None, [2, 1], None)

special_hanbos_temple = {
    (1, 1): makeTile(east=True),
    (1, 2): makeTile(west=True, type="hazard", hazard="poison", raidTile=True),
    (1, 3): makeTile(south=True, type="hazard", hazard="poison", raidTile=True),
    (1, 4): makeTile(south=True, type="hazard", hazard="poison", raidTile=True),
    (1, 5): makeTile(south=True, type="hazard", hazard="poison", raidTile=True),
    (1, 6): makeTile(type="hazard", hazard="poison", raidTile=True),

    (2, 1): makeTile(east=True, type="hazard", hazard="poison", raidTile=True),
    (2, 2): makeTile(east=True, west=True, type="hazard", hazard="poison", raidTile=True),
    (2, 3): makeTile(north=True, south=True, west=True, type="hazard", hazard="poison", raidEnemy=True),
    (2, 4): makeTile(north=True, south=True, type="hazard", hazard="poison", raidTile=True),
    (2, 5): makeTile(north=True, east=True, type="hazard", hazard="poison", raidTile=True),
    (2, 6): makeTile(west=True, type="hazard", hazard="poison", raidTile=True),

    (3, 1): makeTile(east=True, type="hazard", hazard="poison", raidTile=True),
    (3, 2): makeTile(south=True, west=True, type="hazard", hazard="poison", raidTile=True),
    (3, 3): makeTile(north=True, south=True, type="hazard", hazard="poison", raidTile=True),
    (3, 4): makeTile(north=True, south=True, type="hazard", hazard="poison", raidTile=True),
    (3, 5): makeTile(east=True, south=True, type="hazard", hazard="poison", raidTile=True),
    (3, 6): makeTile(west=True, type="hazard", hazard="poison", raidTile=True),

    (4, 1): makeTile(type="hazard", hazard="poison", raidTile=True),
    (4, 2): makeTile(north=True, type="hazard", hazard="poison", raidTile=True),
    (4, 3): makeTile(north=True, type="hazard", hazard="poison", raidTile=True),
    (4, 4): makeTile(north=True, type="hazard", hazard="poison", raidTile=True),
    (4, 5): makeTile(north=True, type="hazard", hazard="poison", raidTile=True),
    (4, 6): makeTile(type="hazard", hazard="poison", raidTile=True),
}
special_hanbos_temple = Map("Hanbo's Temple", special_hanbos_temple, 4, 6, None, None, [1, 1], None)
