from Utility import *
from gameData.Enemy import *
# Buddy skills and passives will be made in this file
# Buddy skills should use the EnemySkill object to get around cooldown

##------------CONST------------##
##--Skills--##
DAMAGE = "Damage"
MULTI = "MultiHit"
def HITS(num1: int, num2: int):
    return lambda: random.randint(num1, num2)
HEAL = "Healing"
STATUS = "Status"
PASSIVE = "Passive"
SPECIAL = "Special"

##--Affinity--##
FORCE = "Force"
SUPPORT = "Support"
UTILITY = "Utility"

##------------BUDDIES------------##

##--Street Slime--##

def corner_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions <= 0:
        self.trigger = False
    
    if not self.trigger:
        if player.health <= round(player.maxHealth * 0.5):
            Power.inflict(player, 5)
            self.trigger = True
bud_passive_corner = BuddySkill("Corner Guy", [PASSIVE],
                           "If health is below 50%, gain 5 stacks of Power (once).")
bud_passive_corner.passive = types.MethodType(corner_bud_passive, bud_passive_corner); bud_passive_corner.trigger = False
bud_skill_sideline = BuddySkill("Sideline Cheer", [STATUS],
                         "Gain 2 stacks of Power.", 
                         status=[Power], stacks=2, statusTarget="user")

buddy_street = Buddy("Street Slime", UTILITY, 8, 30, 10, bud_passive_corner, bud_skill_sideline, 850)

##--Lovely Slime--##

def baby_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and player.lastSkill.element in ["fire", "wind"]:
        if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
            Charm.inflict(enemy)
bud_passive_baby = BuddySkill("Baby-Doll Eyes", [PASSIVE],
                           "If a Fire/Wind element skill is used, chance to inflict 1 stack of Charm")
bud_passive_baby.passive = types.MethodType(baby_bud_passive, bud_passive_baby)
def lovely_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    missing = max(0, player.maxHealth - player.health) // 12
    bonus = min(missing * 10, 30)

    if bonus > 0:
        damage += round(damage * (bonus / 100))

    return damage
bud_skill_worry = BuddySkill("Worry Blow", [DAMAGE],
                         "Attack vs. Defense. For every 12% of health missing, increase damage (10%, max 30%).", 
                         hit=25, critical=50, statsUsed=["attack", "defense", 2], conditional=lovely_conditional)

buddy_lovely = Buddy("Lovely Slime", FORCE, 12, 30, 5, bud_passive_baby, bud_skill_worry, 1000)

##--Nerdy Slime--##

def cram_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    heal = round(player.maxMana * 0.1 + player.magic * 0.2)
    player.mana += heal
    say(f"{Color['green']}{player.name}s Mana Was Restored By {heal}!{Color['reset']}")
bud_passive_cram = BuddySkill("Cram Study", [PASSIVE],
                           "Restore mana (10% of Max Mana + 20% of Magic).")
bud_passive_cram.passive = types.MethodType(cram_bud_passive, bud_passive_cram)
bud_skill_magic = BuddySkill("Magic Concoction", [HEAL],
                         "Restore mana (10% of Max Mana + 20% of Magic). Gain Mana Regen/Frail I.", 
                         status=[ManaRegen, FrailI], statsUsed=[[["magic", 20], ["maxMana", 10]], "mana"])

buddy_nerdy = Buddy("Nerdy Slime", UTILITY, 7, 35, 8, bud_passive_cram, bud_skill_magic, 950)

##--Catty Slime--##

def pinpoint_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and player.lastSkill.hit >= 85:
        Keen.inflict(player, 3)
bud_passive_pinpoint = BuddySkill("Pinpoint", [PASSIVE],
                           "If a skill with 85+ Hit is used, gain 3 stacks of Keen.")
bud_passive_pinpoint.passive = types.MethodType(pinpoint_bud_passive, bud_passive_pinpoint)
def catty_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.hit >= 130:
        Avarice.inflict(enemy)
        
    return damage
bud_skill_swipe = BuddySkill("Swipe", [DAMAGE, [MULTI, HITS(1,2)]],
                         "Attack vs. Defense x 1-2. If Hit is at 130+, inflict Avarice. Chance to inflict Gash/Muddy.", 
                         hit=30, critical=100, status=[Gash, Muddy], statsUsed=["attack", "defense", 2], conditional=catty_conditional)

buddy_catty = Buddy("Catty Slime", UTILITY, 6, 40, 10, bud_passive_pinpoint, bud_skill_swipe, 900)

##--Timekeeper Cookie--##

def timelord_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions % 2 == 0:
        Boon.inflict(player, 2)
        Power.inflict(player, 2)
bud_passive_timelord = BuddySkill("Timelord", [PASSIVE],
                      "For every 2 user actions, gain 2 stacks of Boon/Power.")
bud_passive_timelord.passive = types.MethodType(timelord_bud_passive, bud_passive_timelord)
def assurance_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")

    if player.lastAction and player.lastAction == "Skill" and player.lastSkill:
        chance = min(0.5, 0.05 + 0.05 * (player.luck // 15))
        if chance >= random.random():
            player.lastSkill.cooldownProgress = player.lastSkill.cooldown
            say(f"{Color['yellow']}{player.lastSkill.name} Cooldown Was Ended!{Color['reset']}")
    else:
        say(f"{Color['cyan']}{buddy.name} Gained 60 Buddy Meter!{Color['reset']}")
        player.buddy.buddyMeter += 60
bud_skill_assurance = BuddySkill("Assurance", [SPECIAL], 
                    "If a skill was used, at a chance of 5% + 5% per 15 points of Luck (max 50%), end that skill's cooldown. If a skill was not used, Buddy gains 60 Buddy Meter.",
                    customEffect=assurance_effect)

buddy_timekeeper_cookie = Buddy("Timekeeper Cookie", UTILITY, 8, 45, 6, bud_passive_timelord, bud_skill_assurance, 950)

##--Electric Sheep--##

def blurred_lines_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    charge = next((s for s in player.statusList if s.name == "Charge"), None)
    if charge and charge.stacks >= 8 and enemy.speedMeter >= 30:
        charge.remove(player, 4)

        say(f"{Color['cyan']}{player.buddy.name} Gained 30 Buddy Meter!{Color['reset']}")
        player.buddy.buddyMeter += 30

        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Reduced By 20!{Color['reset']}")
        enemy.speedMeter -= 20 
bud_passive_blurred_lines = BuddySkill("Blurred Lines", [PASSIVE],
                      "If Charge is present and at 8+ stacks and opposers Speed Meter is at 30+, lose 4 stacks of Charge, Buddy gains 30 Buddy Meter, and opposer loses 20 Speed Meter.")
bud_passive_blurred_lines.passive = types.MethodType(blurred_lines_bud_passive, bud_passive_blurred_lines)
def machine_learning_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    Rupture.inflict(enemy, 2)

    charge = next((s for s in player.statusList if s.name == "Charge"), None)
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and player.lastSkill.element in ["thunder"]:
        if charge and charge.stacks >= 10:
            charge.remove(player, 3)
            Rupture.inflict(enemy, 5, 3)
bud_skill_machine_learning = BuddySkill("Machine Learning", [STATUS], 
                    "Gain 2 stacks of Charge. Inflict 2 stacks of Rupture (with 2 count). If a Thunder element skill is used and Charge is present and at 10+ stacks, lose 3 stacks of Charge and inflict 5 stacks of Rupture (with 3 count).",
                    status=[Charge], stacks=2, statusTarget="user", conditional=machine_learning_conditional)

buddy_electric_sheep = Buddy("Electric Sheep", UTILITY, 7, 30, 3, bud_passive_blurred_lines, bud_skill_machine_learning, 900)

##--Party Shirmp--##

def mythic_beverage_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions <= 1:
        self.triggerOne = False
        self.triggerTwo = False
    
    if player.health <= round(player.maxHealth * 0.35) and not self.triggerOne:
        heal = round(player.maxHealth * 0.35)
        say(f"{Color['green']}{player.name}s Health Was Restored By {heal}!{Color['reset']}")
        player.health = min(player.maxHealth, player.health + heal)
        self.triggerOne = True
    
    if player.mana <= round(player.maxMana * 0.20) and not self.triggerTwo:
        heal = round(player.maxMana * 0.5)
        say(f"{Color['green']}{player.name}s Mana Was Restored By {heal}!{Color['reset']}")
        player.mana = min(player.maxMana, player.mana + heal)
        self.triggerTwo = True
bud_passive_mythic_beverage = BuddySkill("Mythic Beverage", [PASSIVE],
                      "If health is below 35%, restore health (35% of Max Health) (once). If mana is below 20%, restore mana (50% of Max Mana) (once).")
bud_passive_mythic_beverage.passive = types.MethodType(mythic_beverage_bud_passive, bud_passive_mythic_beverage); bud_passive_mythic_beverage.triggerOne = False; bud_passive_mythic_beverage.triggerTwo = False
def refresh_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    player.sanity += 8
bud_skill_refresh = BuddySkill("Refresh", [STATUS], 
                    "Gain 2 stacks of Serenity. Gain 8 sanity.",
                    status=[Serenity], stacks=2, statusTarget="user", conditional=refresh_conditional)

buddy_party_shrimp = Buddy("Party Shrimp", SUPPORT, 6, 35, 7, bud_passive_mythic_beverage, bud_skill_refresh, 950)

##--Pink Nurse--##

def quick_check_up_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        self.trigger = False

    if player.health <= round(player.maxHealth * 0.3) and not self.trigger:
        Rejuvenate.inflict(player, 20)
        
        num = 0
        for status in player.statusList[:]:
            if status.family in ["Burn", "Poison", "Bleed"]:
                status.remove(player, full=True)
                num += 1

            if num >= 3:
                break
        self.trigger =True
bud_passive_quick_check_up = BuddySkill("Quick Check Up", [PASSIVE],
                                      "If health is below 30%, gain 20 stacks of Rejuvenate and remove 3 Burn/Poison/Bleed status (once).")
bud_passive_quick_check_up.passive = types.MethodType(quick_check_up_bud_passive, bud_passive_quick_check_up); bud_passive_quick_check_up.trigger = False
def rush_job_conditional(self: BuddySkill, heal, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.lastAction and player.lastAction == "Wait":
        player.sanity -= 10
        Rejuvenate.inflict(player, 15)
        for status in player.statusList[:]:
            if status.family in ["Burn", "Poison", "Bleed"]:
                status.remove(player, full=True)
                break
    return heal
bud_skill_rush_job = BuddySkill("Rush Job", [HEAL], 
                             "Restore health (2% of Max Health + Attack x 4). Gain Regen. If wait is used, lose 10  sanity, gain 15 stacks of Rejuvenate, and remove 1 Burn/Poison/Bleed status.",
                             status=[Regen], statusTarget="user", statsUsed=[[["maxHealth", 2], ["attack", 40]], "health"], conditional=rush_job_conditional)

buddy_pink_nurse = Buddy("Pink Nurse", SUPPORT, 7, 20, 10, bud_passive_quick_check_up, bud_skill_rush_job, 1000)

##--Red Albinauric--##

def corruption_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    lower = 0
    for status in enemy.statusList:
        if status.family == "Bleed":
            lower += 5

    if lower:
        enemy.ultimateMeter -= lower
        say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Lowered By {lower}!{Color['reset']}")

    if any(s.name == "Blood Geyser" for s in enemy.statusList):
        WillowWisp.inflict(enemy, 2)
        Sear.inflict(enemy)
bud_passive_blood_corruption = BuddySkill("Blood Corruption", [PASSIVE],
                                        "For every Bleed status present on the opposer, lower opposers Speed Meter by 5. If Blood Geyser is present on the opposer, inflict 2 stacks of Willow Wisp/Sear.")
bud_passive_blood_corruption.passive = types.MethodType(corruption_bud_passive, bud_passive_blood_corruption)
def lowly_follower_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    enemy.ultimateMeter -= 10
    say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Lowered By 10!{Color['reset']}")
bud_skill_lowly_follower = BuddySkill("Lowly Follower", [STATUS], 
                                    "Chance to inflict 2 stacks of Willow Wisp/Burn/Hemorrhage. Lower opposers Ultimate Meter by 10.",
                                    status=[WillowWisp, Burn, Hemorrhage], stacks=2, conditional=lowly_follower_conditional)

buddy_red_albinauric = Buddy("Red Albinauric", UTILITY, 9, 35, 8, bud_passive_blood_corruption, bud_skill_lowly_follower, 9999999)

##--Dead Butterflies--##

def the_butter_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    butterfly = next((s for s in enemy.statusList if s.name == "Butterfly"), None)
    if butterfly:
        Power.inflict(player)

        if enemy.sanity <= -8:
            if butterfly.stacks >= 4:
                BoostII.inflict(player)
            
            if butterfly.stacks >= 7:
                Fragile.inflict(enemy, 2)

    sinking = next((s for s in enemy.statusList if s.name == "Sinking"), None)
    if sinking:
        Butterfly.inflict(enemy)
        
        enemy.speedMeter -= 25
        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Reduced By 25!{Color['reset']}")
bud_passive_the_butter = BuddySkill("TWwBFUTPDIMB", [PASSIVE],
                      "If Butterfly is present on the opposer, gain 1 stacks of Power and if Butterfly is at 4+/7+ stacks and opposers sanity is below -8, gain Boost II/inflict 2 stack of Fragile. If Sinking is present, inflict 1 stack of Butterfly and lower opposers Speed Meter by 25.")
bud_passive_the_butter.passive = types.MethodType(the_butter_bud_passive, bud_passive_the_butter)
def reload_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")
    
    if player.sanity < 0:
        Sinking.inflict(enemy, 1)
        Butterfly.inflict(enemy, 1)
    
    enemy.sanity -= 5
    
    if any(s.family == "Mental" and s.align == "Negative" for s in enemy.statusList):
        for status in enemy.statusList:
            if status.family == "Mental" and status.align == "Negative":
                if random.randint(1, 100) >= 60:
                    status.duration = 0
                    say(f"{Color['green']}{status.name}s Duration Was Set To 0!{Color['reset']}")
    else:
        say("Nothing Happened!")
bud_skill_reload = BuddySkill("Reload", [SPECIAL], 
                    "If sanity is Negative, inflict 1 stacks of Sinking/Butterfly. Lower opposers sanity by 5. For every Negative Mental status present on the opposer, chance to reset its duration to 0.",
                    customEffect=reload_effect)

buddy_dead_butterflies = Buddy("Dead Butterflies", UTILITY, 8, 30, 6, bud_passive_the_butter, bud_skill_reload, 1500)

##--Singing Alien--##

def pleasurable_rhythm_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    hemorrhage = next((s for s in enemy.statusList if s.name == "Hemorrhage"), None)
    if hemorrhage:
        num = 0
        for i in range(0, hemorrhage.stacks, 3):
            Fragile.inflict(player)
            Power.inflict(player)
            num += 1

            if num >= 2:
                break
bud_passive_pleasurable_rhythm = BuddySkill("Pleasurable Rhythm", [PASSIVE],
                      "For every 3 stacks of Hemorrhage present on the opposer, gain 1 stack of Fragile/Power (max 2).")
bud_passive_pleasurable_rhythm.passive = types.MethodType(pleasurable_rhythm_bud_passive, bud_passive_pleasurable_rhythm)
def harmony_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")

    hemorrhage = next((s for s in enemy.statusList if s.name == "Hemorrhage"), None)
    burn = next((s for s in enemy.statusList if s.name == "Burn"), None)

    if burn and hemorrhage and burn.stacks >= 3 and hemorrhage.stacks >= 6:
        Serenity.inflict(player)
        Power.inflict(player)

        if hemorrhage.stacks >= 8 and player.sanity >= 15:
            FullPower.inflict(player)
bud_skill_harmony = BuddySkill("Harmony", [SPECIAL], 
                    "If Burn and Hemorrhage are present on the opposer and at 3+/6+ stacks, gain Serenity/Power. If Hemorrhage is at 8+ stacks and sanity is at 15+, gain Full Power.",
                    customEffect=harmony_effect)

buddy_singing_alien = Buddy("Singing Alien", UTILITY, 7, 25, 9, bud_passive_pleasurable_rhythm, bud_skill_harmony, 950)

##--Executor's Scribe--##

def from_above_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.sanity >= 10:
        Protection.inflict(player)
bud_passive_from_above = BuddySkill("From Above", [PASSIVE],
                      "If sanity is at 10+, gain 1 stack of Protection.")
bud_passive_from_above.passive = types.MethodType(from_above_bud_passive, bud_passive_from_above)
def pursuance_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")

    if any(s.name in ["Protection", "Tough II"] for s in enemy.statusList):
        protect = next((s for s in enemy.statusList if s.name == "Protection"), None)
        tough = next((s for s in enemy.statusList if s.name == "Tough II"), None)

        if protect:
            protect.remove(enemy)
            Fragile.inflict(enemy)

        if tough:
            tough.remove(enemy, full=True)
            Fragile.inflict(enemy, 3)
bud_skill_pursuance = BuddySkill("Pursuance", [SPECIAL], 
                    "If Protection/Tough II is present on the opposer, remove 1 stack of Protection/Tough II and inflict 1/3 stack of Fragile.", 
                    customEffect=pursuance_effect)

buddy_executors_scribe = Buddy("Executor's Scribe", SUPPORT, 9, 30, 8, bud_passive_from_above, bud_skill_pursuance, 1000)

##--Young Pup--##

def out_control_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions % 3 == 0 and player.actions != 1:
        thunder = sum((1 for s in player.skills if s.element is not None and s.element == "thunder"), 1)
        ice = sum((1 for s in player.skills if s.element is not None and s.element == "ice"), 1)
        fire = sum((1 for s in player.skills if s.element is not None and s.element == "fire"), 1)
        
        random.choice([ThunderProne] * thunder + [IceProne] * ice + [FireProne] * fire).inflict(enemy)
    
    if player.lastAction == "Skill" and player.lastSkill.element in ["fire", "ice", "thunder"]:
        gain = random.randint(1, 30)
        player.buddy.buddyMeter += gain
        say(f"{Color['cyan']}{player.buddy.name} Gained {gain} Buddy Meter!{Color['reset']}")
bud_passive_out_control = BuddySkill("Out of Control", [PASSIVE],
                                     "Every 3 actions, inflict either Fire Prone, Ice Prone, or Thunder Prone (based on equipped skills elements). If a Fire/Ice/Thunder element skill is uesed, Buddy gains 1-30 Buddy Meter.")
bud_passive_out_control.passive = types.MethodType(out_control_bud_passive, bud_passive_out_control)
def gene_explosion_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")
    
    if player.health < round(player.maxHealth * 0.5):
        heal = round(buddy.talent * 1.5 + random.randint(10, 15))
        player.health = min(player.maxHealth, player.health + heal)
        say(f"{Color['green']}{player.name}s Health Was Restored By {heal}!{Color['reset']}")
    else:
        damage = buddy.attack * 2
        enemy.health -= damage
        say(f"{Color['red']}{buddy.name} Dealt {damage} To {enemy.name}!{Color['reset']}")
    
    if buddy.level >= 5:
        for status in self.status:
            status.inflict(enemy)
    
    buddy.buddyMeter -= 30
    say(f"{Color['cyan']}{player.buddy.name} Lost 30 Buddy Meter!{Color['reset']}")
bud_skill_gene_explosion = BuddySkill("Gene Explosion", [SPECIAL],
                                      "If health is below 50%, restore health (150% of Talent + 10-15). If health is greater than or equal to 50%, deal damage (200% of Attack). If Buddy is at 5+, inflict 1 stack of Burn/Frostbite/Spark. Buddy loses 30 Buddy Meter.",
                                      status=[Burn, Frostbite, Spark], customEffect=gene_explosion_effect)

buddy_young_pup = Buddy("Young Pup", SUPPORT, 5, 30, 3, bud_passive_out_control, bud_skill_gene_explosion, 1200)

##--Wild Pup--##

def rough_house_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction == "Skill" and player.lastSkill.recoil is not None:
        Keen.inflict(player)
        if player.buddy.level >= 5:
            Poise.inflict(player)
    
    if player.health <= round(player.maxHealth * 0.45):
        Power.inflict(player)
        Poise.inflict(player)
        
        player.buddy.buddyMeter += 20
        say(f"{Color['cyan']}{player.buddy.name} Gained 20 Buddy Meter!{Color['reset']}")
bud_passive_rough_house = BuddySkill("Rough House", [PASSIVE],
                                     "If a recoil skill is used, gain 1 stack of Keen and if Buddy level is at 5+, gain 1 stack of Poise. If health is below 45%, gain 1 stack of Power/Poise and Buddy gains 20 Buddy Meter.")
bud_passive_rough_house.passive = types.MethodType(rough_house_bud_passive, bud_passive_rough_house)
def hard_bite_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.health <= round(player.maxHealth * 0.55):
        FullPower.inflict(player)
        damage += round(damage * 0.40)
    
    Keen.inflict(player)
    Power.inflict(player)
    return damage
bud_skill_hard_bite = BuddySkill("Hard Bite", [DAMAGE],
                                 "Attack vs. Defense. If health is below 55%, gain Full Power and increase damage (40%!). Gain 1 stack of Keen/Power. Chance to inflict Frail II/Cripple II.",
                                 hit=35, critical=60, status=[FrailII, CrippleII], statsUsed=["attack", "defense", 3.5], conditional=hard_bite_conditional)

buddy_wild_pup = Buddy("Wild Pup", FORCE, 10, 20, 6, bud_passive_rough_house, bud_skill_hard_bite, 1150)

##--Wild Kentauros--##

def anger_point_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction in ["Miss", "Whiff"]:
        Power.inflict(player, 3)
        BoostII.inflict(player)
bud_passive_anger_point = BuddySkill("Anger Point", [PASSIVE],
                      "If an attack or skill misses or due to enemy affinities, gain 3 stacks of Power/Boost II.")
bud_passive_anger_point.passive = types.MethodType(anger_point_bud_passive, bud_passive_anger_point)
def raging_bull_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.lastAction and player.lastAction == "Skill":
        if player.lastSkill.element == "fire":
            Heated.inflict(enemy, 2)
        elif player.lastSkill.element == "ice":
            Frigid.inflict(enemy, 2)

        if player.lastSkill.recoil:
            damage = round(damage * 1.5)
    return damage
bud_skill_raging_bull = BuddySkill("Raging Bull", [DAMAGE], 
                    "Attack vs. Defense. If Fire element skill was used, inflict 2 stacks of Heated. If Ice element skill was used, inflict 2 stacks of Frigid. If a recoil skill is used, increase damage (1.5!).",
                    hit=25, critical=75, statsUsed=["attack", "defense", 3])

buddy_wild_kentaurous = Buddy("Wild Kentaurous", FORCE, 14, 20, 8, bud_passive_anger_point, bud_skill_raging_bull, 1250)

##--Muddy Fish--##

def unaware_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if any(s.name in ["Fragile", "Frail II"] for s in player.statusList) and not any(s.name == "Tough II" for s in player.statusList):
        ToughII.inflict(player, 2)
bud_passive_unaware = BuddySkill("Unaware", [PASSIVE],
                      "If Fragile/Frail II is present, gain 2 stacks of Tough II (if not already present).")
bud_passive_unaware.passive = types.MethodType(unaware_bud_passive, bud_passive_unaware)
def acid_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if self.useCheck(buddy, enemy):
        fragile = next((s for s in enemy.statusList if s.name == "Fragile"), None)
        damage = self.calculateDamage(buddy, player, enemy, result, actions)
        if fragile:
            oldMax, oldStack = fragile.maxStack, fragile.stacks
            fragile.maxStack *= 2
            fragile.stacks *= 2
            damage = fragile.damageInterupt(enemy, player, damage, "target")
            fragile.maxStack, fragile.stacks = oldMax, oldStack - 1
        self.applyDamage(buddy, player, enemy, damage, ignore=True)
bud_skill_acid = BuddySkill("Acid Spray", [DAMAGE], 
                    "Attack vs. Resistance. If Protection is present on the opposer, ignore it. If Fragile is present on the opposer, treat it as if it has 2x the stacks. Chance to inflict 2 stacks of Deadly Poison/Venom.",
                    hit=35, critical=50, status=[DeadlyPoison, Venom], stacks=2, statsUsed=["attack", "resistance", 3], customEffect=acid_effect)

buddy_muddy_fish = Buddy("Muddy Fish", FORCE, 8, 30, 5, bud_passive_unaware, bud_skill_acid, 1150)

##--Glacial Chick--##

def snow_cloack_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    for status in player.statusList[:]:
        if status.family == "Chill" or "Slow" in status.name:
            if random.randint(1,100) >= 50:
                status.remove(player, full=True)
                
    if player.actions % 3 == 0 and player.actions != 0:
        IceProne.inflict(enemy)
bud_passive_snow_cloak = BuddySkill("Snow Cloak", [PASSIVE],
                      "For every Chill/Slow status present, chance to remove it. Every 3 user actions, inflict Ice Prone.")
bud_passive_snow_cloak.passive = types.MethodType(snow_cloack_bud_passive, bud_passive_snow_cloak)
def blizzard_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    list_ = ["wind", "ice"]
    if any(getattr(enemy, ele) == "Super Weak" for ele in list_):
        damage = round(damage * 2.5)

    elif any(getattr(enemy, ele) == "Weak" for ele in list_):
        damage *= 2

    return damage
bud_skill_blizzard = BuddySkill("Blizzard", [DAMAGE, [MULTI, HITS(1,3)]], 
                    "Attack vs. Resistance x 1-3. If opposer is Super Weak/Weak to Ice/Wind, increase damage (2.5x/2x!). Chance to inflict 2 stacks of Frostbite/Freeze.",
                    hit=30, critical=40, status=[Frostbite, Freeze], stacks=2, statsUsed=["attack", "resistance", 2], conditional=blizzard_conditional)

buddy_glacial_chick = Buddy("Glacial Chick", FORCE, 7, 30, 10, bud_passive_snow_cloak, bud_skill_blizzard, 1050)

##--Storm Bird--##

def weather_cast_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if any(s.name == "Spark" and s.stacks >= 10 for s in enemy.statusList):
        ThunderProne.inflict(enemy)
    
    if player.lastAction == "Skill" and player.lastSkill.element in ["thunder", "wind"]:
        Spark.inflict(enemy)
        
        if random.randint(1, 100) + player.luck >= enemy.luck + 35:
            Shock.inflict(enemy)
bud_passive_weather_cast = BuddySkill("Weather Cast", [PASSIVE],
                                     "If Spark is present on the opposer and at 10+ stacks, inflict Thunder Prone. If a Thunder/Wind element skill is used, inflict 1 stack of Spark and chance to inflict 1 stack of Shock.")
bud_passive_weather_cast.passive = types.MethodType(weather_cast_bud_passive, bud_passive_weather_cast)
def storm_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.element in ["thunder", "wind"]:
        Spark.inflict(enemy, 5)
        damage += round(damage * 0.5)
    return damage
bud_skill_storm = BuddySkill("Storm", [DAMAGE, [MULTI, 3]], 
                            "Attack vs. Resistance x 3. If a Thunder/Wind element skill is used, inflict 5 stacks of Spark and increase damage (50%!). Chance to inflict 2 stacks of Spark/Static.",
                            hit=25, critical=65, status=[Spark, Static], stacks=2, statsUsed=["attack", "resistance", 2], conditional=storm_conditional)

buddy_storm_bird = Buddy("Storm Bird", FORCE, 10, 20, 5, bud_passive_weather_cast, bud_skill_storm, 1050)

##--Shield Bearer--##

def body_guard_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        self.trigger = False
        player.buddy.skill.trigOne = False
        player.buddy.skill.trigTwo = False
        
    Shell.inflict(player, 2)
    if any(s.name == "Shell" and s.stacks >= 8 for s in player.statusList):
        Protection.inflict(player)
    
    if player.buddy.level >= 6 and player.health <= round(player.maxHealth * 0.5) and not self.trigger:
        Shell.inflict(player, 4)
        Regen.inflict(player)
        self.trigger = True
bud_passive_body_guard = BuddySkill("Body Guard", [PASSIVE],
                                    "Gain 2 stack of Shell. If Shell is present and at 8+ stacks, gain 1 stack of Protection. If Buddy level is at 6+ and health is below 50%, gain 4 stacks of Shell/Regen (once).")
bud_passive_body_guard.passive = types.MethodType(body_guard_bud_passive, bud_passive_body_guard); bud_passive_body_guard.trigger = False
def block_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.health <= round(player.maxHealth * 0.6) and not self.trigOne:
        GuardU.inflict(player)
        self.trigOne = True
    
    if player.buddy.level >= 5 and player.health <= round(player.maxHealth * 0.3) and not self.trigTwo:
        Vitality.inflict(player)
        self.trigTwo = True
bud_skill_block = BuddySkill("Block", [STATUS],
                             "Gain 1 stack of Tough II. If health is below 60%, gain Guard. U (once). If Buddy level is at 5+ and health is below 30%, gain Vitality (once).",
                             status=[ToughII], statusTarget="user", conditional=block_conditional)
bud_skill_block.trigOne = False; bud_skill_block.trigTwo = False

buddy_shield_bearer = Buddy("Shield Bearer", SUPPORT, 5, 30, 5, bud_passive_body_guard, bud_skill_block, 1225)

##--Crying Child--##

def star_city_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        player.buddy.skill.trigger = False
            
    if player.sanity >= 15 and player.health >= round(player.maxHealth * 0.75):
        Protection.inflict(player)
        Power.inflict(player)

    if any(s.name == "Sunset Blade" for s in player.skills):
        Melting.inflict(player, 2)

    if any(s.name == "Weak Victimize" for s in player.skills):
        Wax.inflict(player)
bud_passive_star_city = BuddySkill("Star of the City", [PASSIVE],
                                 "If sanity is at 15+ and health is above 75%, gain 1 stack of Protection/Power. If the skill Sunset Blade is equipped, gain 2 stack of Melting. If the skill Weak Victimize is equipped, gain 1 stack of Wax.")
bud_passive_star_city.passive = types.MethodType(star_city_bud_passive, bud_passive_star_city)
def unkillabe_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.health <= 0 and not self.trigger:
        Phoenix.inflict(player)
        self.trigger = True
bud_skill_unkillable = BuddySkill("Unkillable ", [STATUS], 
                                "Gain 6 stacks of Rejuvenate. If health is at 0, gain Phoenix Blessing (once).",
                                status=[Rejuvenate], stacks=6, statusTarget="user", conditional=unkillabe_conditional)
bud_skill_unkillable.trigger = False

buddy_crying_children = Buddy("Crying Children", UTILITY, 3, 20, 20, bud_passive_star_city, bud_skill_unkillable, 9999999)

##--Alpha--##

def unbothered_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    list_ = ["Null", "Reflect", "Absorb"]

    if player.lastAction and player.lastAction == "Skill" and "Damage" in player.lastSkill.type_:
        element = getattr(enemy, player.lastSkill.element) 
        if element is not None and element in list_ and player.buddy.buddyMeter >= 30:
            say(f"{Color['cyan']}{player.buddy.name} Lost 50 Buddy Meter!{Color['reset']}")
            player.buddy.buddyMeter -= 50
            Power.inflict(player, 3)
            Protection.inflict(player, 3)
            if len(player.lastSkill.status) > 0:
                random.choice(player.lastSkill.status).inflict(enemy)
bud_passive_unbothered = BuddySkill("Unbothered", [PASSIVE],
                      "If a damaging skill is used and the opposer is Null/Reflect/Absorb to the element of the damaging skill used and Buddy Meter is at 30+, Buddy loses 50 Buddy Meter, gain 3 stacks of Power/Protection, and inflict 1 status from the skill used.")
bud_passive_unbothered.passive = types.MethodType(unbothered_bud_passive, bud_passive_unbothered)
def judgement_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    percent = 0
    for status in enemy.statusList:
        if status.align == "Negative":
            percent += 0.05

    if percent:
        damage = round(damage * percent)
    return damage
bud_skill_judgement = BuddySkill("Judgement", [DAMAGE, [MULTI, 2]], 
                    "Attack vs. Resistance x 2. For every Negative status present on the opposer, increase damage (5%!). Chance to inflict Cripple II/Bind I.",
                    hit=35, critical=68, status=[CrippleII, BindI], statsUsed=["attack", "resistance", 3], conditional=judgement_conditional)

buddy_alpha = Buddy("Alpha", FORCE, 10, 35, 7, bud_passive_unbothered, bud_skill_judgement, 1200)

##--Gatekeeper--##

def to_report_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions <= 1:
        self.trigger = False

    if not self.trigger and player.health <= round(player.maxHealth * 0.45):
        HealthShield.inflict(player, 4)
        self.trigger = True
bud_passive_to_report = BuddySkill("Something to Report!", [PASSIVE],
                      "If health is below 45%, gain 4 stacks of Health Shield (once).")
bud_passive_to_report.passive = types.MethodType(to_report_bud_passive, bud_passive_to_report); bud_passive_to_report.trigger = False
bud_skill_charging_horn = BuddySkill("Charging Horn", [STATUS], 
                    "Gain 2 stacks of Poise/Keen.",
                    status=[Poise, Keen], stacks=2, statusTarget="user")

buddy_gatekeeper = Buddy("Gatekeeper", SUPPORT, 8, 30, 5, bud_passive_to_report, bud_skill_charging_horn, 1400)

##--Void Pet--##

def gaze_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    lower = 0
    for status in enemy.statusList:
        if status.align == "Negative" and status.family == "Mental":
            lower += 3

    if lower:
        say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Lowered By {lower}!{Color['reset']}")
        enemy.ultimateMeter -= lower
bud_passive_gaze = BuddySkill("Gaze", [PASSIVE],
                      "For every Negative Mental status present on the opposer, lower opposers Ultimate Meter by 3.")
bud_passive_gaze.passive = types.MethodType(gaze_bud_passive, bud_passive_gaze)
def disrupt_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{buddy.name} Used {self.name}!")

    enemy.speedMeter -= 25
    if enemy.sanity <= -15:
        enemy.speedMeter -= 20
        enemy.ultimateMeter -= 20
        say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Lowered By 25!{Color['reset']}")
        say(f"{Color['magenta']}{enemy.name}s Speed Meter Was Lowered By 25!{Color['reset']}")
bud_skill_disrupt = BuddySkill("Disrupt", [SPECIAL], 
                    "Lower opposers Speed Meter by 25. If opposers sanity is at -15, lower opposers Speed/Ultimate Meter by 20.",
                    customEffect=disrupt_effect)

buddy_void_pet = Buddy("Void Pet", UTILITY, 6, 30, 6, bud_passive_gaze, bud_skill_disrupt, 950)

##--Golden Crab--##

def gold_rush_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        player.buddy.skill.trigger = False
        Golden.inflict(player)
    
    if any(s.name == "Boon" for s in player.statusList):
        Golden.inflict(player, next(s for s in player.statusList if s.name == "Boon").stacks)
    
    if player.buddy.level >= 8:
        Diamond.inflict(player)
bud_passive_gold_rush = BuddySkill("Gold Rush", [PASSIVE], 
                                   "After acting, gain Golden (once). If Boon is present, for each stack of Boon, gain 1 stack of Golden. If Buddy's level is at 8+, gain Diamond.")
bud_passive_gold_rush.passive = types.MethodType(gold_rush_bud_passive, bud_passive_gold_rush)
def money_claw_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    stacks = sum(s.stacks for s in player.statusList if s.name == "Golden")
    if stacks:
        damage += round(damage * (0.05 * stacks))
    
    if any(s.name == "Diamond" for s in player.statusList) and not self.trigger:
        Slug.inflict(enemy, 2)
        Golden.inflict(player, 5)
        self.trigger = True
    return damage
bud_skill_money_claw = BuddySkill("Money Claw", [DAMAGE, [MULTI, 2]],
                                  "Attack vs. Defense x 2. For each stack of Golden present, increase damage (5% per stack). If Diamond is present, inflict 2 stacks of Slug and gain 5 stacks of Golden (both once).",
                                  hit=30, critical=45, statsUsed=["attack", "defense", 2], conditional=money_claw_conditional)
bud_skill_money_claw.trigger = False

buddy_golden_crab = Buddy("Golden Crab", UTILITY, 10, 30, 2, bud_passive_gold_rush, bud_skill_money_claw, 1450)

##--Steady Sniper--##

def reload_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction == "Skill" and any(not isinstance(s, list) and s.name == "Rupture" for s in player.lastSkill.status):
        if random.randint(1, 100) >= 55:
            Keen.inflict(player, 2)
        
        if any(s.name == "Keen" and s.stacks >= 4 for s in player.statusList):
            Poise.inflict(player) 
    
    rupture = next((s for s in enemy.statusList if s.name == "Rupture"), None)
    if rupture and rupture.stacks >= 8:
        damage = (rupture.stacks + player.buddy.attack) * 2
        enemy.health -= damage
        say(f"{Color['red']}{player.buddy.name} Dealt {damage} To {enemy.name}!{Color['reset']}")      
bud_passive_reload = BuddySkill("Reload", [PASSIVE],
                                "If a skill that inflicts Rupture is used, chance to gain 2 stacks of Keen. If Keen is present and at 4+ stacks, gain 1 stack of Poise. If Rupture is present on the opposer and at 8+ stacks, deal damage (stacks of Rupture + Attack) x 2.")
bud_passive_reload.passive = types.MethodType(reload_bud_passive, bud_passive_reload)
def fire_effect(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if self.useCheck(buddy, enemy):
        poise = next((s for s in player.statusList if s.name == "Poise"), None)
        rupture = next((s for s in enemy.statusList if s.name == "Rupture"), None)
        if poise and rupture:
            damage = round(rupture.stacks + poise.stacks + buddy.attack * 0.5) * random.randint(1,3)
            if (buddy.talent + self.critical) >= random.randint(1, 200):
                damage = round(damage * 1.5)
                
                if (buddy.talent + self.critical) >= random.randint(1, 400):
                    damage = round(damage * 2)
                    say(f"{Color['yellow']}Super Critical Strike!{Color['reset']}")
                
            enemy.health -= damage
            say(f"{Color['red']}{buddy.name} Dealt {damage} To {enemy.name}!{Color['reset']}")
            
        else:
            Rupture.inflict(enemy, 3, 3)
            Poise.inflict(player)
            
            buddy.buddyMeter -= 25
            say(f"{Color['cyan']}{player.buddy.name} Lost 25 Buddy Meter!{Color['reset']}")

        if random.randint(1, 50) + buddy.talent >= round(enemy.luck * 0.25) + 35:
            Rupture.inflict(enemy, 2, 2)
bud_skill_fire =  BuddySkill("Fire!", [SPECIAL],
                             "If Poise is present and Rupture is present on the opposer, deal damage (stacks of Poise + stacks of Rupture + 50% of Attack) x 1-3 (can Critical Strike). If neither condition is met, inflict 3 stacks of Rupture (with 3 count), gain 1 stack of Poise, and Buddy loses 25 Buddy Meter. Chance to inflict 2 stacks of Rupture (with 2 count).",
                             hit=30, critical=70, customEffect=fire_effect)

buddy_steady_sniper = Buddy("Steady Sniper", UTILITY, 10, 25, 2, bud_passive_reload, bud_skill_fire, 1450)

##--Giddy Yokai--##

def prankster_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.sanity <= -5 and enemy.sanity < 0:
        heal = round(player.maxHealth * 0.01 * abs(enemy.sanity)) 
        player.health = min(player.maxHealth, player.health + heal)
        say(f"{Color['green']}{player.name}s Health Was Restored By {heal}!{Color['reset']}")
    
    if player.lastAction == "Skill" and player.lastSkill.element == "mighty":
        enemy.sanity -= 4
        Slug.inflict(enemy)
        
        if enemy.sanity <= -15:
            Shell.inflict(player, 2)
            damage = round(10 + player.buddy.attack * 0.5) * 2
            enemy.health -= damage
            say(f"{Color['red']}{player.buddy.name} Dealt {damage} To {enemy.name}!{Color['reset']}")
bud_passive_prankster = BuddySkill("Prankster", [PASSIVE],
                                   "If sanity is below -5 and opposers sanity is Negative, restore health (1% of Max Health per point of opposers Negative sanity). If a Mighty element skill is used, lower opposers sanity by 4, inflict 1 stack of Slug, and if opposers sanity is below -15, gain 2 stacks of Shell and deal damage (10 + 50% of Attack) x 2.")
bud_passive_prankster.passive = types.MethodType(prankster_bud_passive, bud_passive_prankster)
def poltergeist_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if enemy.sanity <= -15:
        Slug.inflict(enemy)
        damage += round(damage * 0.5)
    
    if player.sanity < 0:
        Shell.inflict(player, 2)
        
        heal = buddy.talent * 2
        player.health = min(player.maxHealth, player.health + heal)
        say(f"{Color['green']}{player.name}s Health Was Restored By {heal}!{Color['reset']}")
    return damage
bud_skill_poltergeist = BuddySkill("Poltergeist", [DAMAGE, [MULTI, 2]],
                                   "Attack vs. Defense x 2. If opposers sanity is below -15, inflict 1 stack of Slug and increase damage (50%!). If sanity is Negative, gain 2 stacks of Shell and restore health (Talent x 2). Chance to inflict 4 stacks of Down.",
                                   hit=30, critical=50, status=[Down], stacks=4, statsUsed=["attack", "defense", 2.5], conditional=poltergeist_conditional)

buddy_giddy_yokai = Buddy("Giddy Yokai", FORCE, 8, 25, 2, bud_passive_prankster, bud_skill_poltergeist, 1325)

##--Moon Golem--##

def lunar_blessing_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction == "Skill" and player.lastSkill.element is not None and player.lastSkill.element == "ice":
        Glint.inflict(enemy, 2)
        
        if random.randint(1, 100) >= 60:
            BoostII.inflict(player)
            
        if player.sanity >= 15:
            if random.randint(1, 100) + player.luck >= enemy.luck + 35:
                DeepFreeze.inflict(enemy)
bud_passive_lunar_blessing = BuddySkill("Lunar Blessing", [PASSIVE],
                                        "If an Ice element skill is used, inflict 2 stacks of Glint, chance to gain Boost II, and if sanity is at 15+, chance to inflict Deep Freeze.")
bud_passive_lunar_blessing.passive = types.MethodType(lunar_blessing_bud_passive, bud_passive_lunar_blessing)
def winters_wrath_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if any(s.name == "Deep Freeze" for s in enemy.statusList):
        FullPower.inflict(player)
        
    enemy.sanity -= 4
    player.sanity += 4
    return damage
bud_skill_winters_wrath = BuddySkill("Winter's Wrath", [DAMAGE, [MULTI, HITS(2,5)]],
                                   "Attack vs. Resistance x 2-5. If Deep Freeze is present on the opposer, gain Full Power. Lower opposers sanity by 4. Gain 4 sanity. Will inflict 2 stacks of Glint/Frostbite.]",
                                   hit=50, critical=60, status=[Glint, Frostbite], stacks=2, willStatus=True, statsUsed=["attack", "defense", 2.7], conditional=winters_wrath_conditional)

buddy_moon_golem = Buddy("Moon Golem", FORCE, 8, 38, 8, bud_passive_lunar_blessing, bud_skill_winters_wrath, 9999999)

##--Black Mage--##

def magic_sort_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    sort = {"fire": False,
            "ice": False,
            "thunder": False,
            "wind": False,}

    for skill in player.skills:
        if skill.element in sort:
            sort[skill.element] = True

    if player.lastAction and player.lastAction == "Skill" and "Damage" in player.lastSkill.type_:
        if sort["fire"]:
            if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
                Scorch.inflict(enemy)

        if sort["ice"]:
            if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
                AbsoluteZero.inflict(enemy)

        if sort["thunder"]:
            if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
                CrippleII.inflict(enemy)

        if sort["wind"]:
            if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
                BindII.inflict(enemy)
bud_passive_magic_sort = BuddySkill("Magic Sort", [PASSIVE],
                      "If a Fire/Ice/Thunder/Wind (individual) element skill is used, all damaging skills have a chance to inflict Scorch/Absolute Zero/Cripple II/Bind II (individual).")
bud_passive_magic_sort.passive = types.MethodType(magic_sort_bud_passive, bud_passive_magic_sort)
def meteor_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    say(f"{Color['cyan']}{player.buddy.name} Lost 20 Buddy Meter!{Color['reset']}")
    player.buddy.buddyMeter -= 20
    return damage
bud_skill_meteor = BuddySkill("Meteor", [DAMAGE], 
                    "Attack vs. Resistance. Will inflict Frail II/Radiant. Buddy loses 20 Buddy Meter.",
                    hit=25, critical=90, status=[FrailII, Radiant], willStatus=True, statsUsed=["attack", "resistance", 3], conditional=meteor_conditional)

buddy_black_mage = Buddy("Black Mage", FORCE, 10, 40, 6, bud_passive_magic_sort, bud_skill_meteor, 1200)

##--White Mage--##

def unill_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    num = random.randint(1,2)
    count = 0
    for status in player.statusList[:]:
        if random.randint(1,100) > 65 and status.align == "Negative":
            count += 1
            status.remove(player, full=True)

        if count >= num:
            break
bud_passive_unill = BuddySkill("UnIll", [PASSIVE],
                      "Chance to remove 1-2 Negative statuses.")
bud_passive_unill.passive = types.MethodType(unill_bud_passive, bud_passive_unill)
def mini_cure_conditional(self: BuddySkill, heal, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    for status in player.statusList[:]:
        if status.align == "Negative":
            status.remove(player, full=True)
            break
    return heal
bud_skill_mini_cure = BuddySkill("Mini Cure", [HEAL], 
                    "Restore health (50% of Attack + 25% of Magic). Gain 10 stacks of Rejuvenate. Remove 1 Negative status.",
                    status=[Rejuvenate], statusTarget="user", stacks=10, statsUsed=[[["magic", 25], ["attack", 50]], "health"], conditional=mini_cure_conditional)

buddy_white_mage = Buddy("White Mage", SUPPORT, 7, 30, 6, bud_passive_unill, bud_skill_mini_cure, 1200)

##--Red Felm Child--##

def magic_dull_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_ and enemy.lastSkill.statsUsed[0] in ["magic", "resistance"]:
        Protection.inflict(player)
        GuardM.inflict(player)
bud_passive_magic_dull = BuddySkill("Magic Dull", [PASSIVE],
                      "If opposers last skill used was a Magic skill, gain 1 stack of Protection/Guard. M.")
bud_passive_magic_dull.passive = types.MethodType(magic_dull_bud_passive, bud_passive_magic_dull)
def demon_blood_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if any(s.family == "Bleed" for s in enemy.statusList) and any(s.family == "Burn" for s in enemy.statusList):
        WillowWisp.inflict(enemy, 5)
        Fragile.inflict(enemy, 2)
bud_skill_demon_blood = BuddySkill("Demon Blood", [STATUS], 
                    "Will inflict 5 stacks of Willow Wisp. If 1 or more Burn and Blood status is present on the opposer, inflict 5/2 stacks of Willow Wisp/Fragile.",
                    status=[WillowWisp], stacks=5, conditional=demon_blood_conditional)

buddy_red_felm = Buddy("Red Felm Child", UTILITY, 8, 30, 9, bud_passive_magic_dull, bud_skill_demon_blood, 1000)

##--Maddinging Flower--##

def bloom_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction and player.lastAction == "Skill":
        if player.lastSkill.element in ["fire", "mighty"]:
            for status in [FrenziedFlames, Burn]:
                if random.randint(1, 50) + player.buddy.talent >= round(enemy.luck * 0.25) + 35:
                    status.inflict(enemy)
bud_passive_bloom = BuddySkill("Bloom", [PASSIVE],
                      "If a Fire/Mighty element skill is used, chance to inflict Frenzied Flames/Burn.")
bud_passive_bloom.passive = types.MethodType(bloom_bud_passive, bud_passive_bloom)
bud_skill_howl_shabiri = BuddySkill("Howl of Shabiri", [DAMAGE, [MULTI, 2]], 
                    "Attack vs. Resistance x 2. Will inflict 2 stacks of Madness.",
                    hit=40, critical=50, status=[Madness], willStatus=True, statsUsed=["attack", "resistance", 2],)

buddy_maddinging_flower = Buddy("Maddinging Flower", FORCE, 9, 30, 6, bud_passive_bloom, bud_skill_howl_shabiri, 1150)

##--Black Sand Spirit--##

def charged_iron_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.sanity >= 15:
        Charge.inflict(player, 3)
        Poise.inflict(player, 2)

    if player.sanity <= -5:
        Fragile.inflict(player, 2)
bud_passive_charged_iron = BuddySkill("Charged Iron", [PASSIVE],
                      "If sanity is at 15+, gain 3/2 stacks of Charge/Poise. If sanity is below -5, gain 2 stacks of Fragile.")
bud_passive_charged_iron.passive = types.MethodType(charged_iron_bud_passive, bud_passive_charged_iron)
def quick_sand_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.sanity <= -5:
        Sinking.inflict(player)
bud_skill_quick_sand = BuddySkill("Quick Sand", [STATUS], 
                    "Gain 2 stacks of Charge/Poise. If sanity is below -5, gain 3 stacks of Sinking.",
                    status=[Charge, Poise], statusTarget="user", conditional=quick_sand_conditional)

buddy_sand_spirit = Buddy("Black Sand Spirit", UTILITY, 8, 40, 3, bud_passive_charged_iron, bud_skill_quick_sand, 950)

##--Djin--##

def magician_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    chance = 0.02 + 0.03 * (player.luck // 10)
    if chance >= random.random():
        player.speedMeter += enemy.speedMeter // 2
        say(f"{Color['yellow']}{player.name}s Speed Meter Was Raised By {enemy.speedMeter // 2}!{Color['reset']}")
bud_passive_magician = BuddySkill("Magician", [PASSIVE],
                      "At a chance of 2% + 3% per 10 Luck, raise Speed Meter by half of opposers Speed Meter.")
bud_passive_magician.passive = types.MethodType(magician_bud_passive, bud_passive_magician)
def hyperspace_hole_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if actions >= 10:
        damage *= 2
    return damage
bud_skill_hyperspace_hole = BuddySkill("Hyperspace Hole", [DAMAGE, [MULTI, HITS(1,2)]], 
                    "Attack vs. Resistance x 1-2. If global actions is at 10+, increase damage (2x!).",
                    hit=40, critical=125, statsUsed=["attack", "resistance", 2], conditional=hyperspace_hole_conditional)

buddy_djin = Buddy("Djin", FORCE, 12, 35, 5, bud_passive_magician, bud_skill_hyperspace_hole, 1100)

##--Shadow Hound--##

def gossamer_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        self.trigger = False

    if player.sanity > 0:
        Sinking.inflict(player, 5)
        player.sanity -= 10

    if player.actions % 5 == 0 and player.actions != 1:
        PurpleHaze.inflict(player)

    if player.health <= round(player.maxHealth * 0.3) and not self.trigger:
        PurpleHaze.inflict(player, 2)
        self.trigger = True
bud_passive_gossamer = BuddySkill("Faux Gossamer", [PASSIVE],
                      "If sanity is Positive, gain 5 stacks of Sinking and lose 10 sanity. Every 5 user actions, gain 1 stack of Purple Haze. If health is below 30%, gain 2 stacks of Purple Haze.")
bud_passive_gossamer.passive = types.MethodType(gossamer_bud_passive, bud_passive_gossamer); bud_passive_gossamer.trigger = False
def anti_mystic_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.sanity <= -20:
        num = 2
        exclude = []

        for i in range(0, 2):
            sinking = next((s for s in enemy.statusList if s.name in ["Sinking", "Deluge", "Butterfly", "Gloom"] and s.name not in exclude), None)
            if sinking:
                sinking.special(enemy, result, player)
                exclude.append(sinking.name)
                num -= 1

            if num <= 0:
                break

        if num:
            count = 0
            for s in enemy.statusList:
                if s.family == "Mental" and s.align == "Negative" and s.name not in exclude:
                    if "Special" not in s.type_:
                        s.simple(enemy)
                    else:
                        s.special(enemy, result, player)
                    count += 1

                if count >= num:
                    break
bud_skill_anti_mystic = BuddySkill("Faux Anti-Mystic", [SPECIAL],
                                     "Inflict 2 stacks of Fragile/Engulfed. If sanity is below -20, retrigger 2 Negative Mental statuses present on the opposer (Sinking and adjacent statuses priority).",
                                     status=[Fragile, Engulfed], stacks=2, conditional=anti_mystic_conditional)

buddy_shadow_hound = Buddy("Shadow Hound", UTILITY, 9, 50, 15, bud_passive_gossamer, bud_skill_anti_mystic, 9999999)

##--Queen of Hatred--##

def magical_girl_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.lastAction == "Skill" and player.lastSkill.name in ["With Love!", "Minor Arcana Slave!!", "In The Name of Love and Hate!"] and any(s.name == "Love~Hate" for s in player.statusList):
        MarkOfVillainy.inflict(enemy)
        LoveHate.inflict(player)
    
    if any(s.name == "Love~Hate" and s.stacks >= s.maxStack for s in player.statusList):
        Charge.inflict(player)
bud_passive_magical_girl = BuddySkill("Magical Girl Duty!", [PASSIVE],
                                      "If either of the skills With Love!, Minor Arcana Slave!!, or In The Name Of Love And Hate! are used and Love~Hate are present, inflict 1 stack of Mark of Villaniy and gain 1 stack of Love~Hate. If Love~Hate is present and at max stacks, gain 1 stack of Charge.")
bud_passive_magical_girl.passive = types.MethodType(magical_girl_bud_passive, bud_passive_magical_girl)
def love_hate_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if any(s.name == "Love~Hate" for s in player.statusList):
        Haste.inflict(player)
        Might.inflict(player)
        ThunderProne.inflict(enemy)
        
        if any(s.name == "Love~Hate" and s.stacks >= s.maxStack for s in player.statusList):
            damage += round(damage * 0.6)
    else:
        Fragile.inflict(player, 2)
        Sinking.inflict(player, 2)
    return damage
bud_skill_love_hate = BuddySkill("Love/Hate Beam!!", [DAMAGE, [MULTI, HITS(2,3)]],
                                 "Attack vs. Resistance x 2-3. If Love~Hate is at 8+ stacks, gain 1 stack of Haste/Might and inflict Thunder Prone. If Love~Hate is at max stacks, increase damage (60%!). If Love~Hate is not present, gain 2 stacks of Fragile/Sinking. Chance to inflict 3 stacks of Burn/Rupture (wth 2 count).",
                                 hit=40, critical=50, status=[Burn, Rupture], stacks=3, count=2, statsUsed=["attack", "resistance", 3],
                                 conditional=love_hate_conditional)

buddy_queen_hatred = Buddy("Queen of Hatred", FORCE, 12, 30, 4, bud_passive_magical_girl, bud_skill_love_hate, 1450)

##--Mao Hound--##

def bestowed_mission_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if any(s.name == "Rupture" and s.stacks >= 10 for s in enemy.statusList):
        Keen.inflict(player)
        Boon.inflict(player)
bud_passive_bestowed_mission = BuddySkill("Bestowed Mission", [PASSIVE],
                                          "If Rupture is present on the opposer and at 10+, gain 1 stack of Keen/Boon.")
bud_passive_bestowed_mission.passive = types.MethodType(bestowed_mission_bud_passive, bud_passive_bestowed_mission)
def etching_strike_conditional(self: BuddySkill, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if sum(1 for s in player.skills if s.element in ["fire"]) >= 2 and not any(s.name == "Deathrite-Blaze" for s in enemy.statusList):
        DeathriteBlaze.inflict(enemy, 2)
        Burn.inflict(enemy, 2)

    if sum(1 for s in player.skills if s.element in ["physical"]) >= 2 and not any(s.name == "Deathrite-Fissure" for s in enemy.statusList):
        DeathriteFissure.inflict(enemy, 2)
        Poise.inflict(player)
bud_skill_etching_strike = BuddySkill("Etching Strike", [STATUS],
                                      "Inflict 3 stacks of Rupture (with 3 count). If 2+ Fire element skills are equipped and Deathrite-Blaze is not present on the opposer, inflict 2 stacks of Deathrite-Blaze/Burn. If 2+ Physical element skills are equipped and Deathrite-Fissure is not present on the opposer, inflict 2 stacks of Deathrite-Fissure and gain 1 stack of Poise.",
                                      status=[Rupture], stacks=3, count=3, conditional=etching_strike_conditional)

buddy_mao_hound = Buddy("Mao Hound", UTILITY, 10, 30, 5, bud_passive_bestowed_mission, bud_skill_etching_strike, 1500)

##--Capote--##

def stifling_rage_bud_passive(self: BuddySkill, player: Player, enemy: Enemy, result=0):
    if player.actions == 1:
        self.trig = False

    if player.lastAction == "Skill" and "Damage" in player.lastSkill.type_ and player.lastSkill.recoil:
        if result * (player.lastSkill.recoil[1] / 100) > round(player.maxHealth * 0.1):
            Vitality.inflict(player)

        if player.health <= round(player.maxHealth * 0.45) and not self.trig:
            Haste.inflict(player, 2)
            self.trig = True
bud_passive_stifling_rage = BuddySkill("Stifling Rage", [PASSIVE],
                                       "If a recoil skill is used and recoil was more than 10% of health, gain Vitality. If health is below 45%, gain 2 stacks of Haste (once).")
bud_passive_stifling_rage.passive = types.MethodType(stifling_rage_bud_passive, bud_passive_stifling_rage); bud_passive_stifling_rage.trig = False
def let_loose_conditional(self: BuddySkill, damage, buddy: Buddy, player: Player, enemy: Enemy, result, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.recoil:
        Overflow.inflict(player)
        damage += round(result * 0.25)

    Might.inflict(player)
    return damage
bud_skill_let_loose = BuddySkill("Let Loose!", [DAMAGE, [MULTI, 3]], 
                                 "Attack vs. Defense x 3. If a recoil skill is used, gain Overflow and increase damage (25% of users skill damage). Gain 1 stack of Might. Chance to inflict 3 stacks of Willow Wisp/Break.",
                                 hit=35, critical=55, status=[WillowWisp, Break], stacks=3, statsUsed=["attack", "defense", 2.6],
                                 conditional=let_loose_conditional)

buddy_capote = Buddy("Capote", FORCE, 9, 15, 9, bud_passive_stifling_rage, bud_skill_let_loose, 1250)