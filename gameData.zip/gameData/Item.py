from Utility import *
from gameData.Buddy import *

# Price Like This
# Coins By The 10s
# GP Gy The 100s
# If It Cost 15 In Coins, It Cost 120 In GP

##------------SIGIL CONST------------##

typeUTILITY = "Utility"
typeSURVIVE = "Survival"
typePOWER = "Power"
triggerStart = "battleStart"
triggerUserAction = "afterAction"
triggerEnemyAction = "afterEnemyAction"
triggerStatusTick = "statusTick"

##------------Sigils------------##

# Utility - Magic Stats/Utility
# Survival - Defensive Effects
# typePower - Offensive/Physical Stats 

def warmth_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    heal = round(player.maxHealth * 0.04) + random.randint(1,3)

    player.health += heal
    player.health = min(player.health, player.maxHealth)

    say(f"{Color['green']}{player.name} Restored {heal} Health From Warmth Sigil!{Color['reset']}")
sigil_warmth = Sigil("Warmth Sigil", 
                 "Emits a campfire like aura.", 
                 "Raise Speed by 5. Restores health (4% of Max Health + 1-3) each action.", 
                 typeUTILITY, triggerUserAction, [["speed", 5]], 60, 580, warmth_effect)

def library_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    heal = round(player.maxMana * 0.05) + random.randint(1,5)

    player.mana += heal
    player.mana = min(player.mana, player.maxMana)

    say(f"{Color['green']}{player.name} Restored {heal} Mana From Library Sigil!{Color['reset']}")
sigil_library = Sigil("Library Sigil", 
                 "Wearing this sigil opens your mind.", 
                 "Raise Magic/Resistance by 2. Restores mana (5% of Max Mana + 1-5) each action.", 
                 typeUTILITY, triggerUserAction, [["magic", 2], ["resistance", 2]], 60, 580, library_effect)

def chain_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if (player.lastSkill and "Damage" in player.lastSkill.type_) and (player.lastAction and player.lastAction == "Skill"):
        if random.randint(1,100) >= 45:
            say(f"{Color['green']}Chain Sigil Was Triggered!{Color['reset']}")
            BindI.inflict(enemy)
            
            if player.lastSkill.element == "physical":
                Slug.inflict(enemy)
sigil_chain = Sigil("Chain Sigil",
                    "Blue lock cover four.",
                    "Raise Strength by 4. If a damaging skill is used, chance to inflict Bind I. If a Physical element skill is used, chance to inflict 1 stack of Slug.",
                    typePOWER, triggerUserAction, [["strength", 4]], 60, 580, chain_effect)

def bull_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        self.trig = False
    
    if player.health <= round(player.maxHealth * 0.6) and not self.trigger:
        say(f"{Color['green']}Bull Sigil Was Triggered!{Color['reset']}")
        BoostI.inflict(player)
        Power.inflict(player)
        self.trig = True
sigil_bull = Sigil("Bull Sigil",
                    "No horns :(.",
                    "Raise Defense/Strength by 2. If health is below 60%, gain Boost I/Power (once).",
                    typePOWER, triggerUserAction, [["strength", 2]], 50, 480, bull_effect)
sigil_bull.trig = False

def point_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["wind", "thunder", "physical"]) and (player.lastAction and player.lastAction == "Skill") and random.randint(1, 100) >= 55:
        say(f"{Color['green']}Point Sigil Was Triggered!{Color['reset']}")
        Keen.inflict(player, 2)
sigil_point = Sigil("Point Sigil", 
                "Always a bullseye.", 
                "Raise Hit/Speed by 15/5. If a Wind/Thunder/Physical element skill is used, chance to gain 2 stacks of Keen.", 
                typePOWER, triggerUserAction, [["hit", 15], ["strength", 5]], 60, 580, point_effect)

def kings_crest_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if player.lastAction and player.lastAction == "Skill":
        if player.lastSkill.element == "thunder" and player.lastSkill.hit >= 80:
            Charge.inflict(player, 2)
            Keen.inflict(player, 2)

    if any(s.name == "Charge" and s.stacks >= 6 for s in player.statusList) and any(s.name == "Keen" and s.stacks >= 6 for s in player.statusList):
        Boon.inflict(player, 2)
sigil_kings_crest = Sigil("King's Crest Sigil",
                          "The crest of the first born child of Gwyn.",
                          "Raise Strength/Magic by 6/5. Lower Speed by 10. If a Thunder element skill is used and has 80+ Hit, gain 2 stacks of Charge/Keen. If Charge and Keen are present and at 6+ stacks, gain 2 stacks of Boon.",
                          typePOWER, triggerUserAction, [["strength", 6], ["magic", 5], ["speed", -10]], 000, 000, kings_crest_effect)

def shred_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and any(isinstance(s, Status) and "Bleed" == s.family for s in player.lastSkill.status)) and (player.lastAction and player.lastAction == "Skill"):
        count = sum(1 for s in player.lastSkill.status if s.family == "Bleed")
        say(f"{Color['green']}Shred Sigil Was Triggered!{Color['reset']}")
        for i in range(count):
            Hemorrhage.inflict(enemy)
sigil_shred = Sigil("Shred Sigil", 
                "Might even hurt the user.", 
                "Raise Strength by 4. Lower Magic by 3. If a skill that inflicts any Bleed statuses is used, chance to inflict 1 stack of Hemorrhage per Bleed status.", 
                typePOWER, triggerUserAction, [["strength", 4], ["magic", -3]], 50, 480, shred_effect)

def double_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.hit >= 85) and (player.lastAction and player.lastAction == "Skill"):
        Vestige.inflict(player)
sigil_double = Sigil("Double Sigil",
                     "Now you shall see the power of the gods!",
                     "Raise Speed/Hit by 5/10. If skill with 85+ Hit is used, gain Vestige.",
                     typeUTILITY, triggerUserAction, [["speed", 5], ["hit", 10]], 60, 580, double_effect)

def leech_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_) and (player.lastAction and player.lastAction == "Skill"):
        heal = round(player.maxHealth * 0.02 + random.randint(1,4))
        player.health += heal
        player.health = min(player.health, player.maxHealth)

        say(f"{Color['green']}{player.name} Restored {heal} Health From Leech Sigil!{Color['reset']}")
sigil_leech = Sigil("Leech Sigil",
                     "Such flavor!",
                     "Raise Luck/Hit by 5. If damaging skill is used, restore health (2% of Max Health + 1-4).",
                     typeUTILITY, triggerUserAction, [["luck", 5], ["hit", 5]], 60, 580, leech_effect)

def ignis_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    for status in enemy.statusList:
        if status.family == "Burn" and status.canStack:
            say(f"{Color['green']}Ignis Sigil Was Triggered!{Color['reset']}")
            status.inflict(enemy)
    
    for status in player.statusList[:]:
        if status.family == "Burn" and random.randint(1,100) <= 55:
            status.remove(player, full=True)
            say(f"{Color['green']}Ignis Sigil Was Triggered!{Color['reset']}")
            status.remove(player, full=True)
sigil_ignis = Sigil("Ignis Sigil", 
                "A sigil made to ward of the flames of a Fire Lord and his Armored Knights.", 
                "Raises Magic by 5. Burn statuses on enemies gain 1 stack. Chance to remove Burn statuses (55% chance).", 
                typeUTILITY, triggerUserAction, [["magic", 5]], 65, 630, ignis_effect)

def rabbit_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    say(f"{Color['green']}Rabbit Sigil Was Triggered!{Color['reset']}")
    Shock.inflict(player, 1)
sigil_rabbit = Sigil("Rabbit Sigil", 
                "Like a rabbit, move with quickness.", 
                f"Raise Speed/Luck by 5/10. Start battle with 1 stacks of Shock.", 
                typeUTILITY, triggerStart, [["speed", 5], ["luck", 10]], 50, 480, rabbit_effect)

def unbreakable_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    say(f"{Color['green']}Unbreakable Sigil Was Triggered!{Color['reset']}")
    ToughI.inflict(player, 2)
sigil_unbreakable = Sigil("Unbreakable Sigil", 
                "Like diamond!", 
                f"Raise Defense by 4. Start battle with 2 stacks of Tough I.", 
                typeSURVIVE, triggerStart, [["defense", 4]], 0, 1500, unbreakable_effect)

def virus_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and len(player.lastSkill.status) > 0) and (player.lastAction and player.lastAction == "Skill"):
        for status in player.lastSkill.status:
            if isinstance(status, Status) and not any(status.name == s.name for s in enemy.statusList):
                if random.randint(1, 100) + player.luck >= enemy.luck + 35:
                    status.inflict(enemy)
sigil_virus = Sigil("Virus Sigil", 
                "Broadcast everything!",
                f"Raise Luck by 15. If a damaging skill that inflicts statuses (not by conditional), indivisually retry infliction if status infliction was not successful.", 
                typeUTILITY, triggerUserAction, [["luck", 15]], 55, 520, virus_effect)

def doctor_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    amount = 0
    for status in player.statusList[:]:
        if amount >= 2:
            break

        if status.align == "Negative" and random.randint(1,100) <= 65:
            amount += 1
            status.remove(player, full=True)
            say(f"{Color['green']}Doctor Sigil Was Triggered! {player.name} No Longer Has {status.name}!{Color['reset']}")
sigil_doctor = Sigil("Doctor Sigil", 
                "Comes with no oath.", 
                "Raise Resistance by 5. Chance to remove 2 Negative statuses after each player action.", 
                typeSURVIVE, triggerUserAction, [["resistance", 5]], 80, 780, doctor_effect)

def berserker_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (enemy.lastSkill and "Damage" in enemy.lastSkill.type_) and enemy.lastAction == "Skill" and isinstance(actionDamage, int):
        damage = round(actionDamage * 0.5)
        enemy.health -= damage
        say(f"{Color['red']}Berserker Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_berserker = Sigil("Berserker Sigil", 
                "Wearing this sigil drives you mad.", 
                "Raise Strength by 6. Lower Magic by 3. If the enemy uses a damaging skill, deal damage (50% of dealt damage by the enemy).", 
                typePOWER, triggerEnemyAction, [["strength", 6], ["magic", -3]], 0, 2500, berserker_effect)

def executioner_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_) and (player.lastAction and player.lastAction in ["Skill", "Attack"]) and isinstance(actionDamage, int) and enemy.health < round(enemy.maxHealth * 0.35):
        damage = round(actionDamage * 0.40)
        enemy.health -= damage
        say(f"{Color['red']}Executioner Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_executioner = Sigil("Executioner Sigil", 
                "Was once the infamouse executioner Madma, now yours.", 
                "Raises Strength by 4. If enemies health is less than 35%, deal damage (40% of dealt damage by the player) after attacking/using damaging skill.", 
                typePOWER, triggerUserAction, [["strength", 4]], 70, 680, executioner_effect)

def sanguine_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if random.randint(1,100) >= 25:
        say(f"{Color['green']}Sanguine Sigil Was Triggered!{Color['reset']}")
        Bleed.inflict(enemy, 1)
    
    if random.randint(1,100) >= 50:
        say(f"{Color['green']}Sanguine Sigil Was Triggered!{Color['reset']}")
        Gash.inflict(enemy, 1)
sigil_sanguine = Sigil("Sanguine Sigil", 
                 "An attempt at imitating Mamzer, the Bastard.", 
                 f"Raise Strength/Hit by 3/10. Chance to inflict Bleed/Gash on battle start.", 
                 typePOWER, triggerStart, [["strength", 3], ["hit", 10]], 0, 2500, sanguine_effect)
 
def shiva_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.element == "ice":
        say(f"{Color['green']}Shiva Sigil Was Triggered!{Color['reset']}")
        Shell.inflict(player, 3)
        if random.randint(1, 100) + player.luck >= enemy.luck + 35:
            Frostbite.inflict(enemy, 2)
sigil_shiva = Sigil("Shiva Sigil",
                 "The uncaring demeanor of Shiva is but a facade.",
                 "Raise Resistance by 6. Lower Defense by 3. If a Ice element skill is used, gain 3 stacks of Shell and chance to inflict 2 stacks of Frostbite.",
                 typeSURVIVE, triggerUserAction, [["resistance", 6], ["defense", -3]], 60, 580, shiva_effect)

def bahamut_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.health < round(player.maxHealth * 0.35):
        if not any("Boost II" == s.name for s in player.statusList):
            say(f"{Color['green']}Bahamut Sigil Was Triggered!{Color['reset']}")
            BoostII.inflict(player)
        
        if not any("Bleed" == s.name for s in player.statusList):
            say(f"{Color['green']}Bahamut Sigil Was Triggered!{Color['reset']}")
            Bleed.inflict(player)

        if not any("Burn" == s.name for s in player.statusList):
            say(f"{Color['green']}Bahamut Sigil Was Triggered!{Color['reset']}")
            Burn.inflict(player, 2)
sigil_bahamut = Sigil("Bahamut Sigil",
                 "At deaths door, the Eikon of Light, Bahamut, will burn the world with its divine light.",
                 "If health is lower than 35%, gain 2 stacks of Burn/Boost II/Bleed if not already present.",
                 typePOWER, triggerUserAction, [], 60, 580, bahamut_effect)

def ifrit_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    damage = round(player.maxHealth * 0.04) + random.randint(1,6)
    player.health -= damage
    say(f"{Color['red']}Ifrit Sigil Was Triggered! {player.name} Took {damage}!{Color['reset']}")

    amount = 0
    for status in enemy.statusList:
        if status.family == "Burn":
            say(f"{Color['green']}Ifrit Sigil Was Triggered!{Color['reset']}")
            if "Special" not in status.type_:
                status.simple(enemy)
            else:
                status.special(enemy, actionDamage, player)
            amount += 1

        if amount >= 2:
            break
sigil_ifrit = Sigil("Ifrit Sigil",
                 "The flames of Ifrit burn all around with profound remorse.",
                 "Raise Magic by 5. Damage self (4% of Max Health + 1-6) after each player action. Retrigger 2 present Burn statuses.",
                 typeUTILITY, triggerUserAction, [["magic", 5]], 70, 680, ifrit_effect)

def garuda_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "wind") and (player.lastAction and player.lastAction == "Skill"):
        damage = (player.strength if player.strength >= player.magic else player.magic) + round(player.speed * 0.15) - round((enemy.defense if enemy.defense >= enemy.resistance else enemy.resistance) * 0.5)
        damage = max(0, damage)
        enemy.health -= damage
        say(f"{Color['red']}Garuda Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_garuda = Sigil("Garuda Sigil",
                 "The jealous harpy, Garuda, screams with the beckoning of storms.",
                 "Raise Speed by 10. Lowers Strength/Magic by 3. If skill with the Wind element is used, deal damage (strongest offensive stat + 15% of Speed - 50% of enemies strongest defensive stat).",
                 typeUTILITY, triggerUserAction, [["speed", 10], ["strength", -3], ["magic", -3]], 70, 680, garuda_effect)

def ramuh_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "thunder") and (player.lastAction and player.lastAction == "Skill") and not any("Shock" == s.name for s in player.statusList):
        say(f"{Color['green']}Ramuh Sigil Was Triggered!{Color['reset']}")
        Overload.inflict(player)
    
    if any("Overload" == s.name for s in player.statusList):
        heal = round(player.speed * 0.30 + player.magic * 0.5)
        player.health += heal
        player.health = min(player.health, player.maxHealth)
        say(f"{Color['green']}{player.name} Restored {heal} Health From Ramuh Sigil!{Color['reset']}")    
sigil_ramuh = Sigil("Ramuh Sigil", 
                 "From the words of Ramuh sparks thoughts so typepowerful they strike the earth.",
                 "Raise Magic/Hit by 4/10. Lowers Strength by 3. If skill with the Thunder element is used, gain Overload. If Overload is present, restore health (30% of Speed + 50% of Magic).",
                 typeUTILITY, triggerUserAction, [["magic", 4], ["hit", 10], ["strength", -3]], 70, 680, ramuh_effect)

def exploiter_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if actionDamage is not None and ((player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastAction == "Skill") or (player.lastAction == "Attack")):
        family = {"Burn": 0, "Bleed": 0, "Poison": 0, "Chill": 0, "Shock": 0, "Mental": 0, "Other": 0}
        for status in enemy.statusList:
            family[status.family] += 1
        
        if any(fam >= 3 for fam in family.values()):
            damage = round(actionDamage * 2)
            enemy.health -= damage
            say(f"{Color['red']}Exploiter Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_exploiter = Sigil("Exploiter Sigil",
                        "Hackers on ro-ro suck.",
                        f"Raise Hit by 35. If the enemy has 3+ Negative statuses of the same family present and an attack or damaging skill is used, deal damage (damage dealt x 2) and remove 2 of the Negative statuses.",
                        typePOWER, triggerUserAction, [["hit", 35]], 80, 780, exploiter_effect)

def collapse_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    player.sanity -= 2
    say(f"{Color['magenta']}Collapse Sigil Was Triggered! {player.name} Lost 1 Sanity!{Color['reset']}")
    if player.sanity <= -10:
        enemy.sanity -= 4
        say(f"{Color['magenta']}Collapse Sigil Was Triggered! {enemy.name} Lost 2 Sanity!{Color['reset']}")
sigil_collapse = Sigil("Collapse Sigil",
                       "Felt like this was happening to me.",
                        f"Raise Defense/Resistance by 4. Lose 2 sanity each action. If sanity is lower than -10, enemy loses 4 sanity each player action.",
                        typeUTILITY, triggerUserAction, [["defense", 4], ["resistance", 4]], 70, 680, collapse_effect)

def drive_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.defense >= 25:
        Shock.inflict(player, 2)
    
    if player.speed >= 20:
        ToughI.inflict(player, 2)
sigil_drive = Sigil("Drive Sigil",
                    "Rip Destiny 2 :(!",
                    f"Raise Defense/Speed by 3/5. At battle start, if Defense is at 25+, gain 2 stacks of Shock, and if Speed is at 20+, gain 2 stacks of Tough I.",
                    typeUTILITY, triggerStart, [["defense", 3], ["speed", 5]], 80, 780, drive_effect)

def ifrit_risen_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "fire") and (player.lastAction and player.lastAction == "Skill"):
            damage = round(player.maxHealth * 0.05 + random.randint(3,5))
            player.health -= damage
            say(f"{Color['red']}Ifrit Risen Sigil Was Triggered! {player.name} Took {damage}!{Color['reset']}{Color['reset']}")
            
            if random.randint(1, 100) + player.luck >= enemy.luck + 25:
                say(f"{Color['green']}Ifrit Risen Sigil Was Triggered!{Color['reset']}")
                if random.randint(1,100) >=75:
                    Molten.inflict(enemy)
                else:
                    Volcanic.inflict(enemy)
sigil_ifrit_risen = Sigil("Ifrit Risen Sigil", 
                 "Carrying the burdens of its past, the Eikon of Fire Ifrit, presses on in spite of it all.",
                 f"Raise Magic/Strength by 9/5. If skill with the Fire element is used, damage self (5% of Max Health + 3-5) and chance to inflict Molten/Volcanic.",
                 typePOWER, triggerUserAction, [["magic", 9], ["strength", 5]], 0, 2550, ifrit_risen_effect)

def phoenix_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if player.health <= 0 and "Phoenix" not in player.battleTriggers:
        say(f"{Color['yellow']}Phoenix Sigil Was Triggered!{Color['reset']}")
        player.health = round(player.maxHealth * 0.25)
        player.battleTriggers.append("Phoenix")
sigil_phoenix = Sigil("Phoenix Sigil", 
                 "Slain in the comfort of its home, the Phoenix, Eikon of Fire, rises twice again.",
                 f"Once per battle, revive (25% of Max Health) when health reaches 0.",
                 typeUTILITY, triggerEnemyAction, [], 0, 2000, phoenix_effect)

def asura_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "physical") and (player.lastAction and player.lastAction == "Skill") and player.health <= round(player.maxHealth * 0.75):
        for i in range(random.randint(1,2)):
            damage = round(player.strength * 0.40 + random.randint(1,3))
            enemy.health -= damage
            say(f"{Color['red']}Asura Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
            BoostII.inflict(player)
sigil_asura = Sigil("Asura Sigil",
                 "The battle hungry god Asura will stop at nothing to rid the world of Mantra and free his daughter.",
                 "Raise Strength by 10. Lower Defense by 5. If skill with the Physical element is used and health is below 75%, gain Boost II and deal damage x 1-2 (40% of Strength + 1-3).",
                 typePOWER, triggerUserAction, [["strength", 10], ["defense", -5]], 0, 3000, asura_effect)

def fancy_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and getattr(enemy, player.lastSkill.element) == "Neutral") and (player.lastAction and player.lastAction == "Skill"):
        damage = round((player.strength if player.strength >= player.magic else player.magic) * 1.5)
        enemy.health -= damage
        say(f"{Color['red']}Fancy Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_fancy = Sigil("Fancy Sigil",
                 "Like boy with very fancy pants, run wild!",
                 f"Raise Speed/Luck by 10/20. If skill with an element that the opposer is Neutral to is used, deal damage (150% of strongest offensive stat).",
                 typeUTILITY, triggerUserAction, [["speed", 10], ["luck", 20]], 0, 2850, fancy_effect)

def red_eyes_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_ ) and (player.lastAction and player.lastAction == "Skill"):
        if player.lastSkill.hit >= 50:
            Keen.inflict(player)
sigil_red_eyes = Sigil("Red Eyes Sigil",
                 "The percise eyes of a fallen clan.",
                 f"Raise Hit by 25. Lower Luck by 15. If skill with 50+ Hit is uses, gain 1 stack of Keen.",
                 typeUTILITY, triggerUserAction, [["hit", 25], ["luck", -15]], 0, 2000, red_eyes_effect)

def shadow_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    say(f"{Color['green']}Shadow Sigil Was Triggered!{Color['reset']}")
    Haze.inflict(player)
sigil_shadow = Sigil("Shadow Sigil",
                 "Shadow style!",
                 f"Raise Luck by 30. Start battle with Haze.",
                 typeUTILITY, triggerStart, [["luck", 30]], 0, 2000, shadow_effect)

def crow_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if player.lastAction and player.lastAction == "Skill":
        for status in enemy.statusList:
            if status.family == "Poison":
                say(f"{Color['magenta']}Crow Sigil Was Triggered! {status.name} Had Its Duration Extened And Count Increased By 1!{Color['reset']}")
                status.duration -= 1
                status.count += 1
sigil_crow = Sigil("Crow Sigil",
                 "Peck and prod at the remnants of the dead, and the living.",
                 f"Raise Speed/Luck by 5/10. If skill is used by the player, chance to extend the duration and increase the count of any Poison statuses present on the opposer by 1.",
                 typeUTILITY, triggerUserAction, [["speed", 5], ["luck", 10]], 0, 2500, crow_effect)

def globe_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if player.actions == 1:
        self.trig = False
        
    if actions >= 24 and not self.trig:
        say(f"{Color['green']}Globe Sigil Was Triggered!{Color['reset']}")
        Power.inflict(player, 2)
        Protection.inflict(player, 2)
        self.trig = True
sigil_globe = Sigil("Globe Sigil",
                 "Whole world, in in his hands.",
                 f"Raise Strength/Magic/Defense/Resistance by 3. After global action 24, gain 2 stacks of Power/Protection (once).",
                 typePOWER, triggerUserAction, [["strength", 3], ["magic", 3], ["defense", 3], ["resistance", 3]], 0, 2100, globe_effect)
sigil_globe.trig = False

def snail_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if player.actions == 1:
        self.trigOne = False
        self.trigTwo = False
        
    if not self.trigOne:
        say(f"{Color['green']}Snail Sigil Was Triggered!{Color['reset']}")
        Protection.inflict(player, 3)
        self.trigOne = True
        
    if actions >= 15 and not self.trigTwo:
        say(f"{Color['green']}Snail Sigil Was Triggered!{Color['reset']}")
        
        NewOver = copy.deepcopy(Overload)
        NewOver.forever = True
        
        NewBoost = copy.deepcopy(BoostII)
        NewBoost.forever = True
                
        NewOver.inflict(player, 2)
        NewBoost.inflict(player)
        
        self.trigTwo = True
sigil_snail = Sigil("Snail Sigil",
                 "giga-giga-gaga-gah!",
                 f"Lower Strength/Magic/Speed by 5. After acting, gain 3 stacks of Protection (once). After global action 16, gain 2 stacks of Overload/Boost II (permanent, once).",
                 typePOWER, triggerUserAction, [["strength", -5], ["magic", -5], ["speed", -5]], 0, 1850, snail_effect)
sigil_snail.trigOne = False; sigil_snail.trigTwo = False

def resilient_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    for status in player.statusList[:]:
        if any("speed" == setS[0] and setS[1] > 0 for setS in status.mutate) and random.randint(1, 100) <= 50:
            say(f"{Color['green']}Resilient Sigil Was Triggered!{Color['reset']}")
            status.remove(player, full=True)
sigil_resilient = Sigil("Resilient Sigil",
                          "Free from the constrants of society!",
                          "Raise Defense/Resistance by 4. For each Speed debuffing status present, chance to remove it.",
                          typeSURVIVE, triggerUserAction, [["defense", 4], ["resistance", 4]], 65, 630, resilient_effect)

def extra_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if (player.lastSkill and "Damage" in player.lastSkill.type_) and (player.lastAction and player.lastAction == "Skill"):
        if player.speed >= enemy.speed + 15 and player.hit >= enemy.hit + 15 and random.randint(1,100) >= 40:
            say(f"{Color['red']}Extra Sigil Was Triggered!{Color['reset']}")
            player.lastSkill.usable = True
            player.mana -= (player.lastSkill.cost // 2) + round(player.maxMana * 0.06)
            player.mana = max(0, player.mana)
            player.lastSkill.effect(player, enemy, actions)
sigil_extra = Sigil("Extra Sigil",
                          "Again!",
                          "If Speed/Hit are greater than enemies Speed/Hit by 15 and last used skill dealt damage, chance to; lose mana (half of skill cost) and reuse skill.",
                          typePOWER, triggerUserAction, [], 120, 1180, extra_effect)

def vulture_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1): 
    if enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in player.lastSkill.type_ or enemy.health <= round(enemy.maxHealth * 0.35):
        damage = round(enemy.maxHealth * 0.02)
        enemy.health -= damage
        say(f"{Color['red']}Vulture Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_vulture = Sigil("Vulture Sigil",
                          "Take an oath.",
                          "Raise Hit/Luck by 10. If the enemy uses a healing skill or their health is below 35%, deal damage (2% of opposers Max Health).",
                          typePOWER, triggerEnemyAction, [["hit", 10], ["luck", 10]], 120, 1180, vulture_effect)

def blue_star_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.sanity > 0:
        heal = round(player.maxHealth * 0.03 + player.resistance * 0.25) 
        player.health += heal
        player.health = min(player.health, player.maxHealth)
        say(f"{Color['green']}{player.name} Restored {heal} Health From Blue Star Sigil!{Color['reset']}")       
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.statsUsed[0] == "magic") and (player.lastAction and player.lastAction == "Skill"):
        heal = round(player.maxMana * 0.05) 
        player.mana += heal
        player.mana = min(player.mana, player.maxMana)
        say(f"{Color['green']}{player.name} Restored {heal} Mana From Blue Star Sigil!{Color['reset']}")   
sigil_blue_star = Sigil("Blue Star Sigil",
                   "Forged from five yellow stars to create the poweful Mana Star.",
                   f"Raise Magic/Resistance by 4. If sanity is Positive, restore health (3% of Max Health + 25% of Resistance). If Magic skill is used, restore mana (5% of Max Mana) and gain Mana Regen.",
                   typeUTILITY, triggerUserAction, [["magic", 4], ["resistance", 4]], 0, 2900, blue_star_effect)

def sanen_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.sanity >= 15:
        say(f"{Color['green']}San'en Sigil Was Triggered!{Color['reset']}")
        ToughI.inflict(player)
        BoostII.inflict(player)

    if player.sanity <= -5:
        say(f"{Color['green']}San'en Sigil Was Triggered!{Color['reset']}")
        CrippleII.inflict(player)
        BindI.inflict(player)
sigil_sanen = Sigil("San'en Sigil",
                   "Hear no eveil. See no evil. Speak no evil.",
                   f"Raise Magic/Strength by 5. If sanity is 15+, gain 2 stacks of Tough I/Boost II. If sanity is below -5, gain Cripple II/Bind I.",
                   typePOWER, triggerUserAction, [["magic", 5], ["strength", 5], ["defense", -4], ["resistance", -4]], 0, 2500, sanen_effect)

def dullahan_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill.name == "Lament, Mourn, and Despair":
        say(f"{Color['green']}Dullahan Sigil Was Triggered!{Color['reset']}")
        if random.randint(1, 100) + player.luck >= enemy.luck + 35:
            Sinking.inflict(enemy)
            Hemorrhage.inflict(enemy)
        enemy.sanity -= 3
sigil_dullahan = Sigil("Dullahan Sigil",
                   "Let's ride, Dullahan!",
                   f"Raise Strength/Magic by 3. If Lament, Mourn, and Despair is used, lower opposers sanity by 3 and chance to inflict Sinking and Hemorrhage.",
                   typePOWER, triggerUserAction, [["magic", 3], ["strength", 3]], 0, 2400, dullahan_effect)

def time_ring_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        self.trig = False

    if player.sanity >= 20:
        say(f"{Color['green']}Time Ring Was Triggered!{Color['reset']}")
        Charge.inflict(player, 2)
        Keen.inflict(player, 2)

    if player.health <= round(player.maxHealth * 0.6) and not self.trigger:
        say(f"{Color['green']}Time Ring Was Triggered!{Color['reset']}")
        Vestige.inflict(player, 3)
        Charge.inflict(player, 3)
        self.trig = True
sigil_time_ring = Sigil("Time Ring",
                        "Not a sigil, but a ring of time.",
                        "Raise Hit/Luck/Speed by 15/15/5. If sanity is at 20+, gain 2 stacks of Charge/Keen. If health is below 60%, gain 3 stacks of Vestige/Charge (once).",
                        typeUTILITY, triggerUserAction, [["hit", 15], ["luck", 15], ["speed", 5]], 000, 000, time_ring_effect)
sigil_time_ring.trig = False

def clone_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if (player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.hit >= 80) and (player.lastAction and player.lastAction == "Skill"):
        say(f"{Color['green']}Clone Sigil Was Triggered!{Color['reset']}")
        Vestige.inflict(player, 2)
        Keen.inflict(player, 2)

        damage = round(player.maxHealth * 0.06) + random.randint(1,4)
        player.health -= damage
        player.health = min(player.health, player.maxHealth)
        say(f"{Color['red']}{player.name} Lost {damage} Health From Clone Sigil!{Color['reset']}")
sigil_clone = Sigil("Clone Sigil",
                   "Why not another?",
                   f"Raise Hit by 20. If skill with 80+ Hit is used, gain 2 stack of Vestige/Keen, and lose health (6% of Max Health + 1-4).",
                   typeUTILITY, triggerUserAction, [["hit", 20]], 0, 2725, clone_effect)

def butterfly_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and (player.luck * 0.5 + random.randint(1, 50) >= 115):
        say(f"{Color['yellow']}Butterfly Sigil Was Triggered! {player.lastSkill.name} Cooldown Was Ended!{Color['reset']}")
        player.lastSkill.cooldownProgress = player.lastSkill.cooldown
sigil_butterfly = Sigil("Butterfly Sigil",
                        "Fast like a butterfly,",
                        "Raise Speed by 10. Lower Strength/Magic by 4. If a skill was used, chance to end skill cooldown.",
                        typeUTILITY, triggerUserAction, [["speed", 10], ["strength", -4], ["magic", -4]], 95, 930, butterfly_effect)

def bee_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["mighty", "physical"] and (player.luck + random.randint(1, 50) > enemy.luck + random.randint(1, 30)):
        say(f"{Color['green']}Bee Sigil Was Triggered!{Color['reset']}")
        random.choice([Venom, Poison]).inflict(enemy)            
sigil_bee = Sigil("Bee Sigil",
                    "Sting like a bee.",
                    "Raise Strength/Speed by 5. If a Mighty/Physical skill was used, chance to inflict Poison/Venom.",
                    typePOWER, triggerUserAction, [["strength", 5], ["speed", 5]], 80, 780, bee_effect)

def angel_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Healing" in player.lastSkill.type_ and random.randint(1,100) >= 55:
        heal = round(player.maxHealth * 0.04 + random.randint(1,5))
        player.health += heal
        player.health = min(player.health, player.maxHealth)

        say(f"{Color['green']}{player.name} Restored {heal} Health From Angel Sigil!{Color['reset']}")
        
        for status in player.statusList[:]:
            if status.align == "Negative":
                say(f"{Color['green']}Angel Sigil Was Triggered! {player.name} No Longer Has {status.name}!{Color['reset']}")
                status.remove(player, full=True)
                break
sigil_angel = Sigil("Angel Sigil",
                    "Mercy?",
                    "Raise Resistance by 4. If a healing skill (not by secondary effect) is used, chance to remove 1 Negative status and restore health (4% of Max Health + 1-5).",
                    typeSURVIVE, triggerUserAction, [["resistance", 4]], 70, 680, angel_effect)

def headstart_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.speed < enemy.speed:
        say(f"{Color['yellow']}Headstart Sigil Was Triggered! {player.name} Gained Max Speed Meter!{Color['reset']}")
        player.speedMeter = 100
sigil_headstart = Sigil("Headstart Sigil",
                        "Cheater!",
                        "Raise Speed/Luck by 5/15. If Speed is lower than opposers, start battle with max Speed Meter.",
                        typeUTILITY, triggerStart, [["speed", 5], ["luck", 15]], 90, 880, headstart_effect)

def ifrit_burning_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    Burn.inflict(player)
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "fire":
        damage = round(player.magic * 0.5 + random.randint(1,3)) 
        enemy.health -= damage
        say(f"{Color['red']}Burning Ifrit Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
        Heated.inflict(enemy)
sigil_ifrit_burning = Sigil("Burning Ifrit Sigil",
                            "Manifested by the flames of its host, the Eikon of Fire Ifrit embraces its role as a beast, destroying all in its way.",
                            "Raise Strength/Magic by 5. Lower Luck by 30. If a skill with the Fire element is used, inflict Heated and deal damage (50% of Magic + 1-3). Gain Burn after each player action.",
                            typePOWER, triggerStart, [["strength", 5], ["magic", 5], ["luck", -30]], 0, 3000, ifrit_burning_effect)

def luster_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    Burn.inflict(player)
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["fire", "wind"]:
        say(f"{Color['green']}Luster Sigil Was Triggered!{Color['reset']}")
        Charm.inflict(enemy)
sigil_luster = Sigil("Luster Sigil",
                            "Once the whole betrayer of man, now a one of four beast of the crimson moon.",
                            "Raise Luck by 30. If a skill with the Fire/Wind element is used, inflict Charm.",
                            typeUTILITY, triggerStart, [["luck", 30]], 0, 2400, luster_effect)

def manic_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if (enemy.lastSkill and "Damage" in enemy.lastSkill.type_) and enemy.lastAction == "Skill" and player.sanity <= -5:
        damage = round(actionDamage * 1.25)
        enemy.health -= damage
        say(f"{Color['red']}Manic Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
        
        damage = round(player.maxHealth * 0.03)
        player.health -= damage
        player.health = max(1, player.health - damage)
        say(f"{Color['red']}{player.name} Took {damage} Health Damage!{Color['reset']}")
        
        ToughII.inflict(player)
sigil_manic = Sigil("Manic Sigil", 
                    "Magic Magic Mew Mew.", 
                    "Lower Defense/Resistance by 3. If the enemy uses a damaging skill and sanity is below -5, gain Tough II, deal damage (3% of Max Health), and deal damage (125% of dealt damage by the enemy) to the enemy.", 
                    typePOWER, triggerEnemyAction, [["defense", -3], ["resistance", -3]], 0, 2825, manic_effect)

def three_headed_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.statsUsed[0] == "magic" and  player.sanity >= 5:
        if random.randint(1,100) >= 45:
            say(f"{Color['green']}Three Headed Sigil Was Triggered!{Color['reset']}")
            Frigid.inflict(enemy)
            
    elif player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.statsUsed[0] == "strength" and player.sanity <= -5:
        if random.randint(1,100) >= 45:
            say(f"{Color['green']}Three Headed Sigil Was Triggered!{Color['reset']}")
            if any(s.name == "Molten" for s in enemy.statusList):
                Heated.inflict(enemy)
            else:
                random.choice([Heated, Molten]).inflict(enemy)
sigil_three_headed = Sigil("Three Headed Sigil",
                           "Out of control.",
                           "Raise Luck/Hit/Speed by 15/15/5. If sanity is at 5+, Magic skills have a chance to inflict Frigid. If sanity is below -5, Physical skills have a chance to inflict Heated/Molten.",
                           typeUTILITY, triggerUserAction, [["luck", 15], ["hit", 15], ["speed", 5]], 0, 3000, three_headed_effect)

def vile_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.health < round(player.maxHealth * 0.65):
        for s in enemy.statusList:
            if s.family == "Poison" and random.randint(1, 100) >= 45:
                say(f"{Color['green']}Vile Sigil Was Triggered!{Color['reset']}")
                if hasattr(s, "count"):
                    s.count += 1
                    say(f"{Color['magenta']}{s.name}s Count Was Increased By 1!{Color['reset']}")
                s.special(enemy, actionDamage, player)
sigil_vile = Sigil("Vile Sigil",
                   "For the kings of vileness.",
                   "Raise Luck by 30. Lower Hit by 20. If health is below 65%, for each Poison status present on the opposer, chance to; increase count (turns active) by 1 and retrigger it.",
                    typeUTILITY, triggerUserAction, [["luck", 30], ["hit", -20]], 0, 2950, vile_effect)

def winter_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if any("Frostbite" == s.name for s in enemy.statusList):
        frostCount = 0
        count = 0
        for status in enemy.statusList[:]:
            if status.name == "Frostbite":
                frostCount += 1 + status.stacks
                status.remove(enemy, full=True)
                
            if status.family == "Chill" and status.name != "Chill":
                count += 1

                if count >= 2:
                    continue
        
        count += frostCount
        damage = round(player.magic * 0.5)
        damage += round(damage * (count * 0.02))
        enemy.health -= damage
        say(f"{Color['red']}Winter Sigil Triggered! {enemy.name} Took {damage} Health Damage!{Color['reset']}")
sigil_winter = Sigil("Winter Sigil",
                     "No santa :(.)", 
                     "Raise Magic/Resistance by 5/3. If Frostbite is present on the opposer, remove Frostbite and (if present) 1-2 other Chill statuses, and deal damage (50% of Magic) after enemy action. For each status removed + stacks of Frostbite, increase damage (2%!).",
                     typePOWER, triggerEnemyAction, [["magic", 5], ["resistance", 3]], 85, 840, winter_effect)

def garbage_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if sum(1 for s in enemy.statusList if s.family == "Poison") >= 4:
        say(f"{Color['green']}Garbage Sigil Was Triggered!{Color['reset']}")
        for status in enemy.statusList[:]:
            if status.family == "Poison":
                status.count += 1
                say(f"{Color['magenta']}{status.name}s Count Was Increased By 1!{Color['reset']}")
                
                enemy.ultimateMeter -= 5
                say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Reduced By 5!{Color['reset']}")
sigil_garbage = Sigil("Garbage Sigil",
                     "Its actaully very effective!", 
                     "Raise Luck/Magic by 25/3. If the opposer has 4+ Poison statuses, increase all Poison statuses count by 1 and reduce enemies Ultimate Meter by 5.",
                     typeUTILITY, triggerUserAction, [["magic", 3], ["luck", 25]], 75, 740, garbage_effect)

def roadrunner_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    bonus = 0
    for status in player.statusList:
        if status.family == "Shock":
            bonus += 5
            if status.stacks:
                bonus += status.stacks
    
    say(f"{Color['yellow']}Roadrunner Sigil Was Triggered! {player.name} Gained {bonus} Speed Meter!{Color['reset']}")
    player.speedMeter += bonus
sigil_roadrunner = Sigil("Roadrunner Sigil",
                     "Was it a bird?", 
                     "Raise Speed by 5. For each Shock status, raise Speed Meter by 10 (if the status stacks, another 2) after acting.",
                     typeUTILITY, triggerUserAction, [["speed", 5]], 70, 690, roadrunner_effect)

def tranquil_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    say(f"{Color['yellow']}Tranquil Sigil Triggered!{Color['reset']}")
    say(f"{Color['blue']}{player.name} Gaine 1 Sanity!{Color['reset']}")
    player.sanity += 1
    
    if player.sanity >= 15:
        health = round(player.maxHealth * 0.05)
        player.health += health
        if player.health > player.maxHealth:
            player.health = player.maxHealth
        say(f"{Color['green']}{player.name} Restored {health} Health From Tranquil Sigil!{Color['reset']}")
        
        mana = round(player.maxMana * 0.05)
        player.mana += mana
        if player.mana > player.maxMana:
            player.mana = player.maxMana
        say(f"{Color['green']}{player.name} Restored {mana} Mana From Tranquil Sigil!{Color['reset']}")
        
    if player.sanity <= -5:
        Devoid.inflict(player)
sigil_tranquil = Sigil("Tranquil Sigil",
                     "One with the world.", 
                     "Raise Hit/Luck by 20. Gain 1 sanity after acting. Starting at 15 sanity, restore health/mana (5% of Max Health/Mana). If sanity is below -5, gain Devoid.",
                     typeUTILITY, triggerUserAction, [["hit", 20], ["luck", 20]], 80, 790, tranquil_effect)

def fierce_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if enemy.sanity <= -5:
        enemy.ultimateMeter -= 5
        say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Reduced By 5!{Color['reset']}")
    
    if enemy.sanity > 0:
        enemy.sanity -= 3
        say(f"{Color['magenta']}{enemy.name} Lost 3 Sanity!{Color['reset']}")
sigil_fierce = Sigil("Fierce Sigil",
                     "Orderly disrupter.", 
                     "Raise Strength/Magic by 6. Lowers Resistance/Defense by 4. If sanity is below -5, reduce enemies Ultimate Meter by 5 after enemy acts. If the enmies sanity is Positive, they lose 3 sanity after acting.",
                     typePOWER, triggerEnemyAction, [["magic", 6], ["strength", 6], ["resistance", -4], ["defense", -4]], 9, 880, fierce_effect)

def survivor_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions <= 1 and enemy.actions <= 1:
        self.tracker  = 0 
        
    if actionDamage and actionDamage >= 300 and self.tracker < 2:
        self.tracker += 1 
        say(f"{Color['yellow']}Survivor Sigil Triggered! {player.name}s Health Was Set To 75%!{Color['reset']}")
        player.health = round(player.maxHealth * 0.75)
sigil_survivor = Sigil("Survivor Sigil",
                     "Might pair it with a sash for focus.", 
                     "Raise Defense/Resistance by 3. Twice per battle, if the opposers damage is greater than 300, set health to 75% of Max Health",
                     typeSURVIVE, triggerEnemyAction, [["defense", 3], ["resistance", 3]], 95, 930, survivor_effect)

def mockingjay_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and "Damage" in player.lastSkill.type_:
        chance = 0.03 
        for i in range(0, player.luck + player.hit, 10):
            chance += 0.05

        if random.random() <= chance:
            boon = 0
            failure = False
            qtTarget = random.randint(2,3)
            try:
                for i in range(random.randint(2,3)):
                    start = time.perf_counter()
                    qt = "".join(random.choices(string.ascii_lowercase, k=3))
                    res = inputimeout(prompt=f"{Color['red']}Input {Color['green']}{qt}{Color['yellow']}!{Color['reset']}:", timeout=qtTarget).lower()
                    end = time.perf_counter()
                    used = end - start
                    
                    if res == qt:
                        if used < qtTarget // 2:
                            say(f"{Color['yellow']}Perfect!{Color['reset']}")
                            boon += 2
                        else:
                            say(f"{Color['green']}Good!{Color['reset']}")
                            boon += 0.5
                    else:
                        say(f"{Color['red']}Failure!{Color['reset']}")
                        failure = True
                        break
                    
            except TimeoutOccurred:
                say(f"{Color['red']}Failure!{Color['reset']}")
                failure = True
            
            if not failure:
                say(f"{Color['red']}Mockingjay Sigil Was Triggered!{Color['reset']}")
                player.lastSkill.usable = True
                player.mana -= round(player.lastSkill.cost * (boon / 10))
                player.mana = max(0, player.mana)
                player.lastSkill.effect(player, enemy, actions)
sigil_mockingjay = Sigil("Mockingjay Sigil", 
                        "Mimic like the mockingjay.",
                        "Raise Hit/Luck by 15. At a chance of 3% + 5% per 10 points of Luck + Hit, trigger Quick Time event; enter a randomized string of characters within 2/3 seconds 2/3 times. On succes, lose mana (a percent of the skills cost based on accuracy) and reuse skill.",
                        typeUTILITY, triggerUserAction, [["hit", 15], ["luck", 15]], 000, 3000, mockingjay_effect)

def clown_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    say(f"{Color['green']}The Clown Sigil Was Triggered!{Color['reset']}")
    
    pLuck = 1
    eLuck = 1
    for i in range(0, player.luck, 15): pLuck += 1
    for i in range(0, enemy.luck, 15): eLuck += 1
    
    chosen = random.choice(["player"] * pLuck + ["enemy"] * eLuck)
    if chosen == "player":
        BoostII.inflict(player)
        player.speedMeter += 25
    elif chosen == "enemy":
        BoostII.inflict(enemy)
        enemy.speedMeter += 25
sigil_clown = Sigil("The Clown Sigil", 
                    "The world is a play and you are it's director.",
                    "Raise Luck/Speed by 15/10. At the start of the battle, at the starting chances of 50%/50% influenced by both partys Luck, either gain Boost II and raise Speed Meter by 25/inflict Boost II and raise opposers Speed Meter by 25.",
                    typeUTILITY, triggerUserAction, [["luck", 15], ["speed", 10]], 000, 2550, clown_effect)

def orions_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_:
        chance = 0.03
        for i in range(0, player.luck, 5):
            chance += 0.05
        
        if random.random() <= chance:
            qtTime = random.randint(2,3)
            key = random.choice(string.ascii_lowercase)
            say(f"{Color['red']}Mash {Color['green']}{key}{Color['yellow']}!{Color['reset']}")
            
            count = 0
            failure = False
            start = time.perf_counter()
            while time.perf_counter() - start < qtTime:
                if keyboard.is_pressed(key):
                    count += 1
                    
                    while keyboard.is_pressed(key):   
                        if time.perf_counter() - start >= qtTime: break
                time.sleep(0.01)
        
            flushInput()
                    
            if count <= 5:
                say(f"{Color['red']}Failure!{Color['reset']}")
                failure = True
            
            if not failure:
                damage = round(player.strength * 1.5)
                enemy.health -= damage
                say(f"{Color['red']}Orions Stars Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")              
sigil_orions = Sigil("Orions Stars Sigil", 
                    "A sigil made for all the knights of Orion.",
                    "Raise Strength/Magic by 7. After the enemy acts, if the enemy used a damaging skill, at a chance of 3% + 5% per 5 points of Luck, trigger Quick Time event; mash a randomized key during a 2/3 window. On success, deal damage (Strength * 1.5).",
                    typePOWER, triggerEnemyAction, [["strength", 7], ["magic", 7]], 000, 2666, orions_effect)

def markdown_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if enemy.lastAction and enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_ and enemy.lastSkill.hit >= 90:
        BindII.inflict(enemy)
        CrippleII.inflict(enemy)
sigil_markdown = Sigil("Markdown Sigil", 
                        "Aim, focus, shoot!",
                        "Raise Hit by 30. If a damaging skill with 90+ Hit is used, inflict Bind II/Cripple II.",
                        typeUTILITY, triggerUserAction, [["hit", 30]], 000, 2450, markdown_effect)

def bulwark_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        say(f"{Color['green']}Bulwark Sigil Was Triggered!{Color['reset']}")
        Vitality.inflict(player)
        self.trigOne = False

    if player.health <= round(player.maxHealth * 0.65) and not self.trigOne:
        Shell.inflict(player, 5)
        Protection.inflict(player, 2)
        self.trigOne = True
sigil_bulwark = Sigil("Bulwark Sigil", 
                      "Survial in patience.",
                      "Raise Defense/Resistance by 5. After acting, gain Vitality (once). If health is below 65%, gain 5/2 stacks of Shell/Protection (once).",
                      typeSURVIVE, triggerUserAction, [["defense", 5], ["resistance", 5]], 000, 2550, bulwark_effect)
sigil_bulwark.trigOne = False

def bandage_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Healing" in player.lastSkill.type_ and actionDamage:
        say(f"{Color['green']}Bandage Sigil Was Triggered!{Color['reset']}")
        
        num = random.randint(1,2)
        count = 0
        for status in player.statusList[:]:
            if status.family == "Bleed" and random.randint(1, 100) >= 50:
                status.remove(player, full=True)
                count += 1
            
            if count >= num:
                break
        
        if actionDamage and actionDamage >= round(player.maxHealth * 0.1):
            Shell.inflict(player, 5)
            Rejuvenate.inflict(player, 5)
sigil_bandage = Sigil("Bandage Sigil",
                      "Could do for a patch up.",
                      "Raise Max Health/Speed by 50/5. if a healing skill is used, chance to remove 1-2 Bleed statuses present, and if heal is greater than 10% of health, gain 5 stacks of Shell/Rejuvenate.",
                      typeSURVIVE, triggerUserAction, [["maxHealth", 50], ["speed", 5]], 90, 880, bandage_effect)

def bookworm_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill":
        if random.randint(1, 100) + player.luck // 2 >= 135:
            restore = player.lastSkill.cost // 2 
            say(f"{Color['magenta']}Bookworm Sigil Was Triggered! {restore} Restored {Color['reset']}")
            player.mana = min(player.maxMana, player.mana + restore)
            
            if player.lastSkill.statsUsed[0] in ["magic", "resistance"]:
                MagicShield.inflict(player)
sigil_bookworm = Sigil("Bookworm Sigil",
               "Head and nose into books.",
               "Raise Max Mana/Resistance by 40/4. If a skill is used, chance to refund half of skill cost and if skill used was Magic, chance to gain Magic Shield.",
               typeUTILITY, triggerUserAction, [["maxMana", 40], ["resistance", 4]], 80, 780, bookworm_effect)

def brazen_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.recoil:
        say(f"{Color['green']}Brazen Sigil Was Triggered!{Color['reset']}")
        Fragile.inflict(enemy)
        
        if player.lastSkill.element in ["fire", "physical"]:
            if random.randint(1, 100) + player.luck >= enemy.luck + 35:
                Slug.inflict(enemy)
        
        if any(s.name == "Bull Sigil" for s in player.sigils):
            for status in enemy.statusList[:]:
                if status.name in ["Protection", "Shell"] and random.randint(1, 100) >= 65:
                    num = random.randint(1,3)
                    status.remove(enemy, num)
                    break
sigil_brazen = Sigil("Brazen Sigil",
               "Where's the bull?",
               "Raise Max Health/Defense by 25/5. If a recoil skill is used, inflict 1 stack of Fragile and if skill’s element is Fire/Physical, chance to inflict Slug. If Bull Sigil is equipped and Protection or Shell is present on the opposer, chance to remove 1-3 stacks of status.",
               typePOWER, triggerUserAction, [["maxHealth", 25], ["defense", 5]], 60, 2320, brazen_effect)

def downpour_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        self.trig = False
        
    if player.lastAction == "Skill" and player.lastSkill.element in ["ice", "mighty"]:
        Down.inflict(enemy, 2)
    
    if enemy.sanity <= -15 and not self.trig:
        Slug.inflict(enemy, 2)
        self.trig = True
sigil_downpour = Sigil("Downpour Sigil",
                "Am I sweating?",
                "Raise Luck/Magic by 20/5. If a Ice/Mighty element skill is used, inflict 2 stacks of Down. If opposers sanity is below -15, inflict 2 stacks of Slug (once).",
                typePOWER, triggerUserAction, [["luck", 20], ["magic", 5]], 65, 630, downpour_effect)
sigil_downpour.trig = False

def battery_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        Charge.inflict(player, 3)
    
    if player.lastAction == "Skill" and player.lastSkill.element == "thunder":
        Charge.inflict(player)
sigil_battery = Sigil("Battery Sigil",
                      "Maximum percent!",
                      "Raise Hit/Luck/Speed by 10. Lower Strength/Magic by 5. After acting, gain 3 stacks of Charge (once). If a Thunder element skill is used, gain 1 stack of Charge.",
                      typeSURVIVE, triggerUserAction, [["hit", 10], ["luck", 10], ["speed", 10], ["strength", -5], ["magic", -5]], 70, 680, battery_effect)

def rapid_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.health <= round(player.maxHealth * 0.75) and player.lastAction == "Skill" and player.lastSkill.element in ["wind", "thunder"]:
        Rupture.inflict(enemy, 3, 3)
sigil_rapid = Sigil("Rapid Sigil",
                "Urshfu?",
                "Raise Luck/Speed/Strength by 20/5/3. Lower Defense by 5. If health is below 75% and a Thunder/Wind element skill is used, inflict 3 stacks of Rupture (with 3 count).",
                typeSURVIVE, triggerUserAction, [["luck", 20], ["speed", 5], ["strength", 3], ["defense", -5]], 70, 680, rapid_effect)

def razor_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill" and any(not isinstance(s, list) and s.family == "Bleed" for s in player.lastSkill.status):
        Fragile.inflict(enemy)
sigil_razor = Sigil("Razor Sigil",
                "This one hurts to equip.",
                "Raise Hit/Strength by 15/4. If a skill is used and inflicts any Bleed statuses, inflict 1 stack of Fragile",
                typeSURVIVE, triggerUserAction, [["hit", 15], ["strength", 4]], 50, 480, razor_effect)

def goremoth_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and actionDamage:
        heal = round(actionDamage * 0.10)
        player.health += heal
        if player.health > player.maxHealth: 
            player.health = player.maxHealth
        say(f"{Color['green']}Goremoth Sigil Was Triggered! {player.name} Restored {heal} Health!{Color['reset']}")
    
    if player.health <= round(player.maxHealth * 0.3):
        percent = 0
        for status in enemy.statusList:
            if status.align == "Negative":
                percent += 0.02
            
            if percent >= 0.08:
                break
            
        if percent:
            heal = round(player.maxHealth * percent)
            player.health += heal
            if player.health > player.maxHealth:
                player.health = player.maxHealth
            say(f"{Color['green']}Goremoth Sigil Was Triggered! {player.name} Restored {heal} Health!{Color['reset']}")
sigil_goremoth = Sigil("Goremoth Sigil",
                      "Gore + Moth.",
                      "Raise Strength/Defense by 6. Lower Speed by 5. If a damaging skill is used, restore health (10% of damage done). If health is below 30%, for every Negative status on the opposer, restore health (2% of Max Health, max 8%).",
                      typeSURVIVE, triggerUserAction, [["strength", 6], ["defense", 6], ["speed", -5]], 105, 1050, goremoth_effect)

def trickshot_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    Keen.inflict(player)
    
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.hit + player.lastSkill.hit >= 240 and player.mana >= round(player.lastSkill.cost * 0.25):
        player.mana -= round(player.lastSkill.cost * 0.25)
        oldS, oldM = player.strength, player.magic
        player.strength //= 2
        player.magic //= 2
        player.lastSkill.usable = True
        player.lastSkill.effect(player, enemy, actions)
        player.strength, player.magic = oldS, oldM
sigil_trickshot = Sigil("Trickshot Sigil",
                      "Might come back around.",
                      "Raise Hit by 35. Lower Luck by 25. Gain 1 stack of Keen each action. If a damagin skill is used and Hit + skills Hit  is greater than 240, lose mana (quarter of skills cost) and reuse skill (half damage).",
                      typeUTILITY, triggerUserAction, [["hit", 35], ["luck", -25]], 00, 2300, trickshot_effect)

def draken_bahamut_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions < 1:
        self.trig = False
        
    if player.health <= round(player.maxHealth * 0.3) and not self.trig:
        say(f"{Color['green']}Draken Bahamut Sigil Was Triggered!{Color['reset']}")
        for s in [Shock, Burn, BoostII]:
            s.inflict(player, 3)
        self.trig = True
sigil_draken_bahamut = Sigil("Draken Bahamut Sigil",
                      "Corrupted by guilt, the Eikon of Light, Bahamut, burns with power.",
                      "Raise Strength/Magic by 12. Lowers Defense/Resistance by 8. If health is below 30%, gain 3 stacks of Shock/Burn/Boost II (once).",
                      typePOWER, triggerUserAction, [["strength", 12], ["magic", 12], ["defense", -8], ["resistance", -8]], 000, 3200, draken_bahamut_effect)
sigil_draken_bahamut.trig = False

def warden_light_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if any(s.name == "Draken Bahamut Sigil" for s in player.sigils) and player.health < round(player.maxHealth * 0.40):
        hits = random.randint(1, 2)
        damage = round(player.magic * 1.5 * hits)
        enemy.health -= damage
        say(f"{Color['red']}Warden of Light Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_warden_light = Sigil("Warden of Light Sigil",
                      "The Warden of Light, the Eikon of Light, Dion Lesage.",
                      "If Draken Bahamut Sigil is equipped and health is below 40%, after enemy acts, deal damage (150% of Magic x 1-2).",
                      typePOWER, triggerEnemyAction, [], 120, 1180, warden_light_effect)

def sore_winner_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.speed - enemy.speed >= 10:
        chance = 0.02 + 0.05 * (player.luck // 10)
        if random.random() < chance:
            say(f"{Color['yellow']}Sore Winner Sigil Was Triggered! {player.name} Acts Again!{Color['reset']}")
            player.speedMeter += 100
sigil_sore_winner = Sigil("Sore Winner Sigil",
                      "Love winning, but hate the process",
                      "Raise Speed by 5. If Speed is greater than opposers by 10, at a chance of 2% + 5% (per 10 points of Luck), act immediately.",
                      typeUTILITY, triggerUserAction, [["speed", 5]], 000, 2500, sore_winner_effect)

def balance_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 0:
        self.high = False
        self.low = False
        self.trig = False

    if player.sanity >= 15:
        self.high = True
    if player.sanity <= -15:
        self.low = True

    if self.high and self.low and not self.triggered:
        self.triggered = True
        say(f"{Color['green']}Balance Sigil Was Triggered!{Color['reset']}")
        ManaRegen.inflict(player)
        newRegen = next(s for s in player.statusList if s.name == "Mana Regen")
        newRegen.forever = True

        damage = round(player.magic * 1.5 * 2)
        enemy.health -= damage
        say(f"{Color['red']}Balance Sigil Dealt {damage} To {enemy.name}!{Color['reset']}")
sigil_balance = Sigil("Balance Sigil",
                      "Equilize everything.",
                      "Raise Magic by 6. Track if sanity ever reaches 15 and -15. If sanity has reached both, gain Mana Regen (permanent) and deal damage (150% of Magic x 2) (both once).",
                      typeUTILITY, triggerUserAction, [["magic", 6]], 000, 2650, balance_effect)
sigil_balance.high = False; sigil_balance.low = False; sigil_balance.trig = False

def emperor_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.strength > enemy.strength and random.randint(1, 100) >= 60:
        player.speedMeter += 30
        enemy.ultimateMeter -= 20
        say(f"{Color['yellow']}Emperor Sigil Was Triggered!{Color['reset']}")
        say(f"{Color['yellow']}{player.name}s Speed Meter Was Raised By 30!{Color['reset']}")
        say(f"{Color['magenta']}{enemy.name}s Ultimate Meter Was Lowered By 20!{Color['reset']}")
    
    positive = sum(1 for s in player.statusList if s.align == "Positive")
    if positive:
        gain = 5 * positive
        player.speedMeter += gain
        say(f"{Color['yellow']}Emperor Sigil Was Triggered! {player.name}s Speed Meter Was Raised By {gain}!{Color['reset']}")
sigil_emperor = Sigil("Emperor Sigil",
                 "Like a king, but more!",
                 "Raise Strength by 10. Lower Magic by 8. If Strength is greater than opposers Strength, chance to; raise Speed Meter by 30 and lower opposers Ultimate Meter by 20. For every Positive status present, raise Speed Meter by 5.",
                 typePOWER, triggerUserAction, [["strength", 10], ["magic", -8]], 00, 00, emperor_effect)

def scarecrow_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    poisons = [s for s in enemy.statusList if s.family == "Poison"]
    if len(poisons) >= 4 and random.randint(1,100) >= 50:
        amount = random.randint(1,4)
        say(f"{Color['green']}Scarecrow Sigil Was Triggered!{Color['reset']}")
        for status in poisons[:amount]:
            if "Special" not in status.type_:
                status.simple(enemy)
            else:
                status.special(enemy, actionDamage, player)
    
    if any(s.name == "Crow Sigil" for s in player.sigils) and random.randint(1,100) >= 50:
        say(f"{Color['green']}Scarecrow Sigil Was Triggered!{Color['reset']}")
        if random.randint(1,100) >= 50:
            CrippleII.inflict(enemy)
        else:
            FrailII.inflict(enemy)
sigil_scarecrow = Sigil("Scarecrow Sigil",
                 "Where are the crows?",
                 "Raise Defense/Resistance by 6. If 4+ Poison statuses are present on the opposer, chance to retrigger 1-4 Poison statuses. If Crow Sigil is equipped, chance to inflict Cripple II/Frail II.",
                 typeUTILITY, triggerUserAction, [["defense", 6], ["resistance", 6]], 00, 00, scarecrow_effect)

def telamon_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "thunder":
        enemy.speedMeter -= 25
        say(f"{Color['magenta']}Telamon Sigil Was Triggered! {enemy.name}s Speed Meter Was Lowered By 25!{Color['reset']}")
    
    if player.actions < 1:
        self.trig = False
    
    if any(s.name == "Ramuh Sigil" for s in player.sigils) and player.health < round(player.maxHealth * 0.30) and not self.trig:
        say(f"{Color['green']}Telamon Sigil Was Triggered!{Color['reset']}")
        Energetic.inflict(player)
        self.trig = True
sigil_telamon = Sigil("Telamon Sigil",
                 "Cid, the goat.",
                 "Raise Strength/Magic/Speed by 5. If a Thunder element skill is used, lower opposers Speed Meter by 25. If Ramuh Sigil is equipped and health is below 30%, gain Energetic (once).",
                 typeUTILITY, triggerUserAction, [["strength", 5], ["magic", 5], ["speed", 5]], 00, 00, telamon_effect)
sigil_telamon.trig = False

def red_blur_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["thunder", "wind", "physical"]:
        bleeds = min(sum(1 for s in enemy.statusList if s.family == "Bleed"), 3)
        if bleeds >= 1:
            shock = next((s for s in player.statusList if s.name == "Shock"), None)
            if shock and shock.stacks >= shock.maxStack:
                say(f"{Color['green']}Red Blur Sigil Was Triggered!{Color['reset']}")
                Overload.inflict(player)
            else:
                say(f"{Color['green']}Red Blur Sigil Was Triggered!{Color['reset']}")
                Shock.inflict(player)
sigil_red_blur = Sigil("Red Blur Sigil",
                 "The fastest man alive!",
                 "Raise Speed/Luck by 10/25. If a Thunder/WInd/Physical element skill is used, for 1-3 Bleed status present on the opposer, gain Shock/Overload (if Shock is at max Stack).",
                 typePOWER, triggerUserAction, [["speed", 10], ["luck", 25]], 00, 00, red_blur_effect)

def seafarer_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    player.sanity -= 2
    say(f"{Color['magenta']}Seafarer Sigil Was Triggered! {player.name} Lost 2 Sanity!{Color['reset']}")
    
    if player.sanity < -15 and any(s.name == "Consumed" for s in enemy.statusList):
        say(f"{Color['green']}Seafarer Sigil Was Triggered!{Color['reset']}")
        Sinking.inflict(enemy)
        Gloom.inflict(enemy)
sigil_seafarer = Sigil("Seafarer Sigil",
                 "Something, something, Arknights!",
                 "Raise Magic/Resistance by 5/7. Lose 2 sanity after acting. If sanity is below -15 and Consumed is present on the opposer, inflict Sinking/Gloom.",
                 typeUTILITY, triggerUserAction, [["magic", 5], ["resistance", 7]], 00, 00, seafarer_effect)

def abyssal_heart_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    for status in enemy.statusList:
        if status.family in ["Poison", "Mental"]:
            if hasattr(status, "count"):
                status.count += 1
            else:
                status.duration -= 1
            enemy.ultimateMeter -= 5
            say(f"{Color['magenta']}Abyssal Heart Sigil Was Triggered! {enemy.name}s Ultimate Meter Was Lowered By 5!{Color['reset']}")
    
    if player.actions < 1:
        self.trig = False
    
    if player.health < round(player.maxHealth * 0.20) and not self.trig:
        say(f"{Color['green']}Abyssal Heart Sigil Was Triggered!{Color['reset']}")
        negatives = sum(1 for s in enemy.statusList if s.align == "Negative")
        for status in enemy.statusList[:]:
            if status.align == "Negative":
                status.remove(enemy, full=True)
        
        player.mana -= round(player.maxMana * 0.25)
        
        heal = round(player.maxHealth * 0.05 * negatives)
        player.health = min(player.maxHealth, player.health + heal)
        say(f"{Color['green']}Abyssal Heart Sigil Was Triggered! Restored {heal} Health!{Color['reset']}")
        
        damage = round(player.magic * 0.20 * negatives)
        enemy.health -= damage
        say(f"{Color['red']}Abyssal Heart Sigil Was Triggered! Dealt {damage} To {enemy.name}!{Color['reset']}")
        
        self.trig = True
sigil_abyssal_heart = Sigil("Abyssal Heart Sigil",
                 "Something, something, Terraria, somethin, something, Void.",
                 "Raise Magic by 10. Lower Defense/Resistance by 5. For each Poison/Mental status present on the opposer, gain 1 count/reduce duration by 1 and lower opposers Ultimate Meter by 5. If health is below 20%, remove all Negative statuses on the opposer, lose mana (25% of Max Mana), restore health (5% of Max Health x number of Negative statuses present on the opposer), and deal damage (20% of Magic x number of Negative statuses present on the opposer) (all once).",
                 typeSURVIVE, triggerUserAction, [["magic", 10], ["defense", -5], ["resistance", -5]], 00, 00, abyssal_heart_effect)
sigil_abyssal_heart.trig = False

def negative_nancy_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.sanity < 0 and enemy.lastAction and (enemy.lastAction == "Attack" or (enemy.lastAction == "Skill" and enemy.lastSkill and "Damage" in enemy.lastSkill.type_)):
        player.sanity -= 3
        damage = round(player.magic * 0.30 + player.strength * 0.30 + abs(player.sanity))
        enemy.health -= damage
        say(f"{Color['red']}Negative Nancy Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_negative_nancy = Sigil("Negative Nancy Sigil",
                 "What I am now.",
                 "Raise Strength/Magic by 6. Lower Hit/Luck by 15. If sanity is Negative and the opposer attacks/uses damaging skill, lose 3 sanity and deal damage (30% of Magic + 30% of Strength + sanity (turned Positive if Negative)).",
                 typePOWER, triggerEnemyAction, [["strength", 6], ["magic", 6], ["hit", -15], ["luck", -15]], 00, 00, negative_nancy_effect)

def twin_moon_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["fire", "ice"] and player.sanity >= 5:
        enemy.sanity -= 5
        say(f"{Color['magenta']}Twin Moon Sigil Was Triggered! {enemy.name} Lost 5 Sanity!{Color['reset']}")
        if player.lastSkill.element == "fire":
            Heated.inflict(enemy)
        else:
            Frigid.inflict(enemy)
    
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["mighty", "physical"] and player.sanity < -5:
        player.sanity -= 3
        say(f"{Color['magenta']}Twin Moon Sigil Was Triggered! {player.name} Lost 3 Sanity!{Color['reset']}")
        Sinking.inflict(enemy)
        Hemorrhage.inflict(enemy)
sigil_twin_moon = Sigil("Twin Moon Sigil",
                 "Loved that project.",
                 "Raise Strength/Magic/Speed by 3/3/5. If a Fire/Ice skill is used and sanity is at 5+, lower opposers sanity by 5 and inflict Heated or Frigid. If a Mighty/Physical skill is used and sanity is below -5, lose 3 sanity and Sinking/Hemorrhage.",
                 typeUTILITY, triggerUserAction, [["strength", 3], ["magic", 3], ["speed", 5]], 00, 00, twin_moon_effect)

def primed_garuda_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions < 1:
        self.windCount = 0
    
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "wind":
        self.windCount = min(self.windCount + 1, 6)
    
    if self.windCount:
        gain = 8 * self.windCount
        player.speedMeter += gain
        say(f"{Color['yellow']}Primed Garuda Sigil Was Triggered! {player.name}s Speed Meter Was Raised By {gain}!{Color['reset']}")
sigil_primed_garuda = Sigil("Primed Garuda Sigil",
                 "Wounded and afraid, Garuda takes control of her holder.",
                 "Raise Speed by 15. Lower Strength/Magic by 8. Track number of Wind element skills used. Based on the number of Wind element skills used, raise Speed Meter (8 x number (max 6)).",
                 typeUTILITY, triggerUserAction, [["speed", 15], ["strength", -8], ["magic", -8]], 00, 00, primed_garuda_effect)
sigil_primed_garuda.windCount = 0

def bound_buddha_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Wait" and random.randint(1,100) >= 50:
        say(f"{Color['green']}Bound Buddha Sigil Was Triggered!{Color['reset']}")
        if random.randint(1,100) >= 50:
            BindII.inflict(enemy)
        else:
            SlowII.inflict(enemy)
    
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element in ["wind", "mighty"] and any(s.name in ["Bind II", "Slow II"] for s in enemy.statusList) and random.randint(1,100) >= 50:
        say(f"{Color['green']}Bound Buddha Sigil Was Triggered!{Color['reset']}")
        if random.randint(1,100) >= 50:
            FrailII.inflict(enemy)
        else:
            CrippleII.inflict(enemy)
sigil_bound_buddha = Sigil("Bound Buddha Sigil",
                 "Advisor to the Kind in Binds.",
                 "Raise Defense/Resistance by 9. Lower Strength/Magic by 5. If Wait is used, chance to inflict Bind II or Slow II. If a Wind/Mighty element skill is used and Bind II or Slow II is present on the opposer, chance to inflict Frail II or Cripple II.",
                 typeSURVIVE, triggerUserAction, [["defense", 9], ["resistance", 9], ["strength", -5], ["magic", -5]], 00, 00, bound_buddha_effect)

def ultima_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    tiers = enemy.ultimateMeter // 10
    if tiers and tiers > 0:
        damage = round(player.magic * 0.25 * tiers) * 3
        enemy.health -= damage
        say(f"{Color['red']}Ultima Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_ultima = Sigil("Ultima Sigil",
                 "The ultimate sigil.",
                 "Raise Magic by 12. Lower Defense/Resistance by 6. For every 10 points of Ultimate Meter opposer has, deal damage (25% of Magic x (1 per every 10 Ultimate Points)) x 3.",
                 typePOWER, triggerUserAction, [["magic", 12], ["defense", -6], ["resistance", -6]], 00, 00, ultima_effect)

def sensei_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.sanity >= 20 and player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "wind" and player.mana >= 30 and random.randint(1,100) >= 50:
        say(f"{Color['green']}Sensei Sigil Was Triggered!{Color['reset']}")
        player.mana -= 30
        player.lastSkill.usable = True
        player.lastSkill.effect(player, enemy, actions)
    
    if player.actions < 1:
        self.trig = False
    
    if any(s.name == "Master Sigil" for s in player.sigils) and not self.trig:
        say(f"{Color['green']}Sensei Sigil Was Triggered!{Color['reset']}")
        FullPower.inflict(player)
        player.speedMeter += 35
        say(f"{Color['yellow']}{player.name}s Speed Meter Was Raised By 35!{Color['reset']}")
        self.trig = True
sigil_sensei = Sigil("Sensei Sigil",
                 "Ms. Thibadoux is the master.",
                 "Raise Hit by 40. Lower Luck by 20. If sanity is at 20+ and a Wind element skill is used, chance to; lose 30 mana and reuse skill. If Master Sigil is equipped, gain Full Power and raise Speed Meter by 35 (once).",
                 typeUTILITY, triggerUserAction, [["hit", 40], ["luck", -20]], 00, 00, sensei_effect)
sigil_sensei.trig = False

def master_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.hit >= 180:
        Keen.inflict(player)
        player.speedMeter += 20
        say(f"{Color['yellow']}Master Sigil Was Triggered! {player.name}s Speed Meter Was Raised By 20!{Color['reset']}")
    
    if any(s.name == "Sensei Sigil" for s in player.sigils) and player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.lastSkill.element == "wind":
        say(f"{Color['green']}Master Sigil Was Triggered!{Color['reset']}")
        Poise.inflict(player, 2)
sigil_master = Sigil("Master Sigil",
                 "And I am the Sensei.",
                 "Raise Strength by 6. If Hit is at 180+, gain 1 stack of Keen and raise Speed Meter by 20. If Sensei Sigil is equipped and a Wind element skill is used, gain 2 stacks of Poise.",
                 typeUTILITY, triggerUserAction, [["strength", 6]], 00, 00, master_effect)

def sure_fire_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and any(isinstance(t, list) for t in player.lastSkill.type_) and player.attackHits >= 6 and random.randint(1,100) >= 50:
        say(f"{Color['green']}Sure Fire Sigil Was Triggered!{Color['reset']}")
        amount = 0
        for status in enemy.statusList[:]:
            if amount >= player.attackHits:
                break
            if "Special" not in status.type_:
                status.simple(enemy)
            else:
                status.special(enemy, 0, player)
            amount += 1
    
    if player.lastAction and player.lastAction == "Skill" and player.lastSkill and "Damage" in player.lastSkill.type_ and player.hit > 180:
        for i in range(player.attackHits):
            damage = round(player.strength * 0.35 + player.hit * 0.15)
            enemy.health -= damage
            say(f"{Color['red']}Sure Fire Sigil Was Triggered! {enemy.name} Took {damage}!{Color['reset']}")
sigil_sure_fire = Sigil("Sure Fire Sigil",
                 "Make sure there down.",
                 "Raise Speed/Hit by 10/25. If 6+ hits are landed consecutivly, chance to retrigger hits landed number of statuses. If a damaging skill is used and Hit is greater than 180, for each hit, deal damage (35% of Strength + 15% of Hit).",
                 typePOWER, triggerUserAction, [["speed", 10], ["hit", 25]], 00, 00, sure_fire_effect)

def festive_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.element is not None and player.lastSkill.element == "thunder":
        Boon.inflict(player)
        
        if random.randint(1, 100) + player.luck >= enemy.luck + 35:
            Spark.inflict(enemy, 2)
        
        if any(s.name == "Boon" and s.stacks >= 5 for s in player.statusList):
            Power.inflict(player,3)
sigil_festive = Sigil("Festive Sigil",
                      "Prepare for the return of the god of storm!",
                      "raise Luck/Speed by 25/10. Lower Hit by 15. If a Thunder element skill is used, gain 1 stack of Boon and chance to inflict 2 stacks of Spark. If Boon is present and at 5+, gain 3 stacks of Power.",
                      typeUTILITY, triggerUserAction, [["luck", 25], ["speed", 10], ["hit", -15]], 00, 00, festive_effect)

def cleanup_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    charge = next((s for s in player.statusList if s.name == "Charge"), None)
    if charge:
        Rupture.inflict(enemy, 1, 1)
    
    rupture = next((s for s in enemy.statusList if s.name == "Rupture"), None)
    if rupture:
        Charge.inflict(player)
    
    if any(s.name == "Cleanup Demonstration" for s in player.skills) and (charge and charge.stacks >= 8) and (rupture and rupture.stacks >= 10):
        Might.inflict(player)
        Haste.inflict(player)
sigil_cleanup = Sigil("Cleanup Sigil",
                      "The cleaners of W Corp work very fast.",
                      "Raise Speed/Hit by 5/30. If Charge is present, inflict 1 stack of Rupture (with 1 count). If Rupture is present on the opposer, gain 1 stack of Charge. If the skill Cleanup Demonstration is equipped and Charge is present and at 8+ stacks and Rupture is present on the opposer and at 10+ stacks, gain 1 stack of Might/Haste.",
                      typeUTILITY, triggerUserAction, [["speed", 5], ["hit", 30]], 100, 1000, cleanup_effect)

def green_star_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.lastAction == "Skill" and player.lastSkill.element and player.lastSkill.element == "wind":
        Rupture.inflict(enemy, 3, 3)

    rupture = next((s for s in enemy.statusList if s.name == "Rupture" and s.stacks >= 20), None)
    if rupture:
        rupture.remove(enemy, 15)
        FrailIII.inflict(enemy)
sigil_green_star = Sigil("Green Star Sigil",
                         "Would've been the Tiangang Star.",
                         "Raise Hit/Luck by 25. If a Wind element skill is used, inflict 3 stacks of Rupture (with 3 count). If Rupture is present on the opposer and at 20+ stacks, opposer loses 15 stacks and inflict Frail III.",
                         typeUTILITY, triggerUserAction, [["hit", 25], ["luck", 25]], 110, 1010, green_star_effect)

def foolish_effect(self: Sigil, player: Player, enemy: Enemy, tickStatus: Status, actionDamage: int, actions=1):
    if player.actions == 1:
        self.tracker = 0

    if player.lastAction == "Skill" and player.lastSkill.recoil:
        self.tracker += 1

    if self.tracker % 3 == 0:
        Power.inflict(player, 4)
        Haste.inflict(player, 1)

    if self.tracker % 6 == 0:
        Fragile.inflict(enemy, 2)
sigil_foolish = Sigil("Foolish Sigil",
                      "Reckless, foolish, all the same.",
                      "Raise Strength by 8. Lower Defense/Resistance by 4. Track total number of recoil skills used. Every 3rd recoil skill used, gain 4/1 stacks of Power/Haste. Every 6th recoil skill used, inflict 2 stacks of Fragile.",
                      typePOWER, triggerUserAction, [["strength", 8], ["defense", -4], ["resistance", -4]], 100, 1000, foolish_effect)
sigil_foolish.tracker = 0
##------------ITEMS CONST------------##

HEAL = "Heal"
CLEANSE = "Cleanse"
STATUS_I = "StatusI"
SPECIAL = "Special"
DAMAGE = "Damage"
SPEED = "Speed"
EXP = "Exp"
BUD = "Buddy"

##------------Items------------##

##--Items--##

##--Health/Mana--##
item_health_small = Item("Red S.Valens Potion", "Restore 130 health.", [HEAL], 99, [("health", 130)], coinCost=10, gpCost=20)

item_health_medium = Item("Red M.Valens Potion", "Restore 240 health.", [HEAL], 99, [("health", 240)], coinCost=20, gpCost=40)

item_health_large = Item("Red L.Valens Potion", "Restore 440 health.", [HEAL], 99, [("health", 440)], coinCost=40, gpCost=80)

item_mana_small = Item("Blue S.Valens Potion", "Restore 60 mana.", [HEAL], 99, [("mana", 60)], coinCost=12, gpCost=24)

item_mana_medium = Item("Blue M.Valens Potion", "Restore 120 mana.", [HEAL], 99, [("mana", 120)], coinCost=24, gpCost=48)

item_mana_large = Item("Blue L.Valens Potion", "Restore 240 mana.", [HEAL], 99, [("mana", 240)], coinCost=48, gpCost=96)

item_cleanse_small = Item("Cleanse S. Potion", "Restore 8% of health. Remove 1 Negative status.", [HEAL, CLEANSE], 10, [("health", 0.08)], removeAmount=1, removeTarget=["Negative"], removeChance=False, target="player", coinCost=15, gpCost=30)

item_cleanse_medium = Item("Cleanse M. Potion", "Restore 16% of health. Remove 2 Negative status.", [HEAL, CLEANSE], 10, [("health", 0.16)], removeAmount=2, removeTarget=["Negative"], removeChance=False, target="player", coinCost=30, gpCost=60)

item_cleanse_large= Item("Cleanse L. Potion", "Restore 32% of health. Remove 3 Negative status.", [HEAL, CLEANSE], 10, [("health", 0.32)], removeAmount=3, removeTarget=["Negative"], removeChance=False, target="player", coinCost=60, gpCost=120)

item_glowing_small = Item("Glowing S.Valens Potion", "Restore 65 health and 30 mana.", [HEAL], 99, [("health", 65), ("mana", 30)], coinCost=16, gpCost=32)

item_glowing_medium = Item("Glowing M.Valens Potion", "Restore 135 health and 65 mana.", [HEAL], 99, [("health", 135), ("mana", 65)], coinCost=32, gpCost=64)

item_glowing_large = Item("Glowing L.Valens Potion", "Restore 275 health and 135 mana.", [HEAL], 99, [("health", 275), ("mana", 135)], coinCost=64, gpCost=128)

item_red_dew = Item("Red Dew", "Restore 5% of health. Gain Regen.", [HEAL, STATUS_I], 99, [("health", 0.05)], status=[Regen], target="player", coinCost=15, gpCost=30)

item_blue_dew = Item("Blue Dew", "Restore 10% of mana. Gain Mana Regen.", [HEAL, STATUS_I], 99, [("mana", 0.15)], status=[ManaRegen], target="player", coinCost=20, gpCost=40)

item_refined_dew = Item("Refined Dew", "Restore 15% of health/mana. Gain 5 stacks of Rejuvenate.", [HEAL, STATUS_I], 99, [("health", 0.15), ("mana", 0.15)], status=[Rejuvenate], stacks=5, target="player", coinCost=45, gpCost=90)

item_mini_elixer = Item("Mini Elixer", "Restore 25% of health.", [HEAL], 10, [("health", 0.25)], coinCost=80, gpCost=160)

item_elixer = Item("Elixer", "Restore 50% of health.", [HEAL], 5, [("health", 0.50)], coinCost=160, gpCost=320)

item_phoenix_elixer = Item("Phoenix Elixer", "Restore 100% of health and 50% of mana.", [HEAL], 5, [("health", 1.0), ("mana", 0.50)], coinCost=320, gpCost=640)

##--Utility--##

item_boon_talisman = Item("Boon Talisman", "Chance to remove 1-2 Positive statuses from the opposer.", [CLEANSE], 99, useType="Battle", removeAmount=2, removeTarget=["Positive"], removeChance=True, coinCost=23, gpCost=46) 

item_curse_reliver = Item("Curse Reliver", "Chance to remove 1-2 Negative statuses from the opposer.", [CLEANSE], 99, useType="Battle", removeAmount=2, removeTarget=["Negative"], removeChance=True, coinCost=21, gpCost=42) 

item_incense = Item("Incense", "Chance to remove 1-3 Mental statuses.", [CLEANSE], 99, useType="Battle", removeAmount=3, removeTarget=["Mental"], removeChance=True, target="player", coinCost=25, gpCost=50)

item_phoenix_feather = Item("Phoenix Feather", "Gain Phoenix Blessing.", [STATUS_I], 2, useType="Battle", status=[Phoenix], target="player", coinCost=250, gpCost=500)

def pocket_watch_special(item: Item, player: Player, enemy: Enemy):
    skills = []
    for skill in player.skills:
        if not skill.usable and not "Passive" in skill.type_:
            skills.append(skill)
    
    if len(skills) > 0:
        skill = min(skills, key=lambda s: s.cooldown - s.cooldownProgress)
        say(f"{Color['yellow']}{skill.name}s Cooldown Was Reduced By 2!{Color['reset']}")
        skill.cooldownProgress += 2
    else:
        say("Nothing Happened!")
item_pocket_watch = Item("Pocket Watch", "For the skill closest to coming off of cooldown, reduce cooldown by 2 actions.", [SPECIAL], 10, useType="Battle", coinCost=150, gpCost=300)
item_pocket_watch.special = types.MethodType(pocket_watch_special, item_pocket_watch)


##--EXP Items--##

def experience_effect(item: Item, player: Player, enemy: Enemy):
    gain = round((item.type_[1] / 100) * player.levelGoal)
    player.levelValue += gain
    print(f"{Color['yellow']}{player.name} Gained {gain} EXP!{Color['reset']}")
item_experience_page = Item("Experience Page", "Gain 10% of Level Goal as EXP.", [EXP, 10], 99, extraEffect=experience_effect, useType="Overworld", gpCost=300)

item_experience_book = Item("Experience Book", "Gain 20% of Level Goal as EXP.", [EXP, 20], 99, extraEffect=experience_effect, useType="Overworld", gpCost=650)

item_experience_tome = Item("Experience Tome", "Gain 50% of Level Goal as EXP.", [EXP, 50], 99, extraEffect=experience_effect, useType="Overworld", gpCost=1300)

##--Buddy Items--##

def buddy_experience_effect(item: Item, player: Player, enemy: Enemy):
    if player.buddy:
        gain = item.type_[1]
        player.buddy.levelValue += gain
        print(f"{Color['yellow']}{player.buddy.name} Gained {gain} EXP!{Color['reset']}")
    
    else:
        print("Nothing Happened!")
        item.tracker(1, "Add", player)
item_buddy_small = Item("Pet Food Small", "Equipped Buddy gains 100 EXP.", [EXP, 100], 99, extraEffect=buddy_experience_effect, useType="Overworld", gpCost=200)

item_buddy_medium = Item("Pet Food Medium", "Equipped Buddy gains 250 EXP.", [EXP, 250], 99, extraEffect=buddy_experience_effect, useType="Overworld", gpCost=405)

def buddy_treat_effect(item: Item, player: Player, enemy: Enemy):
    if player.buddy:
        if len(player.buddy.treats) < 6:
            while True:
                clear()
                print(f"Feed {player.buddy.name} {item.name}? | {player.buddy.name} Eaten Treats: {len(player.buddy.treats)}")
                line("buddy")

                print(f"1. {Color['green']}Yes{Color['reset']} | 2. {Color['red']}No{Color['reset']}")
                line("buddy")

                choice = None
                while choice not in ["1", "2"]:
                    choice = input("->")

                if choice == "1":
                    player.buddy.treats[f"treat{len(player.buddy.treats) + 1}"] = item.type_[1]
                    setattr(player.buddy, item.type_[1], getattr(player.buddy, item.type_[1]) + item.type_[2])
                    print(f"{Color['cyan']}{player.buddy.name}s {item.type_[1].capitalize()} Was Increased By {item.type_[2]}{Color['reset']}")
                    break
                else:
                    item.tracker(1, "Add", player)
                    break
        else:
            print(f"{player.buddy.name} Refuses To Eat Anymore!")
            item.tracker(1, "Add", player)
    else:
        print("There Is No Buddy To Feed!")
        item.tracker(1, "Add", player)
item_strength_food = Item("Strength Treat", "Increase Equipped Buddy's Attack by 3.", [BUD, "attack", 3], 99, extraEffect=buddy_treat_effect, useType="Overworld", gpCost = 150)

item_cool_food = Item("Cool Treat", "Increase Equipped Buddy's Talent by 4.", [BUD, "talent", 4], 99, extraEffect=buddy_treat_effect, useType="Overworld", gpCost = 200)

item_hastey_food = Item("Hastey Treat", "Increase Equipped Buddy's Speed by 5.", [BUD, "speed", 5], 99, extraEffect=buddy_treat_effect, useType="Overworld", gpCost = 200)

##--Buff--##

item_mediocre_shield = Item("Mediocre Shield", "Gain DeF~Up/ReS~Up.", [STATUS_I], 99, useType="Battle", status=[DeFUp, ReSUp], target="player", coinCost=40, gpCost=80)

item_protein = Item("Protein", "Gain StR~Up.", [STATUS_I], 99, useType="Battle", status=[StRUp], target="player", coinCost=35, gpCost=70)

item_study_papers = Item("Study Papers", "Gain MgC~Up.", [STATUS_I], 99, useType="Battle", status=[MgCUp], target="player", coinCost=35, gpCost=80)

item_telescope = Item("Telescope", "Gain 2 stacks of Keen.", [STATUS_I], 99, useType="Battle", status=[Keen], stacks=2, coinCost=50, gpCost=100)

item_silph_scope = Item("Silph Scope", "Gain Poise.", [STATUS_I], 99, useType="Battle", status=[Poise], coinCost=65, gpCost=130)

item_heart_charm = Item("Heart Charm", "Gain 2 stacks of Health Shield.", [STATUS_I], 99, useType="Battle", status=[HealthShield], stacks=2, coinCost=75, gpCost=150)

def speed_meter_effect(item: Item, player: Player, enemy: Enemy):
    player.speedMeter += next((s[1] for s in item.type_ if isinstance(s, list) and s[0] == SPEED), 0)
item_charge_small = Item("Charge S. Potion", "Gain Boost II. Raise Speed Meter by 20.", [STATUS_I, [SPEED, 20]], 99, useType="Battle", status=[BoostII], target="player", extraEffect=speed_meter_effect, coinCost=70, gpCost=140)

item_charge_medium = Item("Charge M. Potion", "Gain Boost III. Raise Speed Meter by 30.", [STATUS_I, [SPEED, 30]], 99, useType="Battle", status=[BoostIII], target="player", extraEffect=speed_meter_effect, coinCost=90, gpCost=180)

item_iron_small = Item("Iron S. Potion", "Gain Tough I. Raise Speed Meter by 15.", [STATUS_I, [SPEED, 15]], 99, useType="Battle", status=[ToughI], target="player", extraEffect=speed_meter_effect, coinCost=60, gpCost=120)

item_iron_medium = Item("Iron M. Potion", "Gain Tough II. Raise Speed Meter by 25.", [STATUS_I, [SPEED, 25]], 99, useType="Battle", status=[ToughII], target="player", extraEffect=speed_meter_effect, coinCost=85, gpCost=170)

item_full_power = Item("Charge Max Potion", "Gain Full Power. Raise Speed Meter by 25.", [STATUS_I, [SPEED, 25]], 5, useType="Battle", status=[FullPower], target="player", extraEffect=speed_meter_effect, coinCost=110, gpCost=220)

##--Debuff--##

item_wrangler_lasso = Item("Wrangler Lasso", "Will inflict SpD~Down/HiT~Down.", [STATUS_I], 99, useType="Battle", status=[SpDDown, HiTDown], coinCost=55, gpCost=110)

item_clover_bind = Item("Clover Bind", "Remove 1 Negative status present on the opposer. Will inflict LcK~Down.", [STATUS_I, CLEANSE], 99, useType="Battle", removeAmount=1, removeTarget=["Negative"], status=[LcKDown], coinCost=65, gpCost=130)

##--Sanity--##

def sanity_familiy_special(self, player: Player, enemy: Enemy):
    player.sanity += self.heal
    if self.heal > 0:
        say(f"{Color['blue']}{player.name} Gained {self.heal} Sanity!{Color['reset']}")
    elif self.heal < 0:
        say(f"{Color['magenta']}{player.name} Lost {abs(self.heal)} Sanity!{Color['reset']}")
item_white_small_sanity = Item("White S.Sanity Potion", "Gain 5 sanity.", [SPECIAL], 99, useType="Battle", heal=5, coinCost=23, gpCost=26)
item_white_small_sanity.special = types.MethodType(sanity_familiy_special, item_white_small_sanity)

item_white_medium_sanity = Item("White M.Sanity Potion", "Gain 15 sanity.", [SPECIAL], 99, useType="Battle", heal=15, coinCost=26, gpCost=52)
item_white_medium_sanity.special = types.MethodType(sanity_familiy_special, item_white_medium_sanity)

item_black_small_sanity = Item("Black S.Sanity Potion", "Lose 5 sanity.", [SPECIAL], 99, useType="Battle", heal=-5, coinCost=23, gpCost=25)
item_black_small_sanity.special = types.MethodType(sanity_familiy_special, item_black_small_sanity)

item_black_medium_sanity = Item("Black M.Sanity Potion", "Lose 15 sanity.", [SPECIAL], 99, useType="Battle", heal=-15, coinCost=26, gpCost=52)
item_black_medium_sanity.special = types.MethodType(sanity_familiy_special, item_black_medium_sanity)

def positive_balm_special(self, player: Player, enemy: Enemy):
    for battler in [player, enemy]:
        san = random.randint(3,6)
        battler.sanity += san
        say(f"{Color['blue']}{battler.name} Gained {san} Sanity!{Color['reset']}")
item_positive_balm = Item("Positive Balm", "Both battlers gain 3-6 sanity.", [SPECIAL], 99, useType="Battle", coinCost=30, gpCost=60)
item_positive_balm.special = types.MethodType(positive_balm_special, item_positive_balm)

def turn_over_special(self, player: Player, enemy: Enemy):
    if player.sanity < 0:
        player.sanity = abs(player.sanity)
        say(f"{Color['yellow']}{player.name} Sanity Is Now {player.sanity}!{Color['reset']}")
    
    elif player.sanity > 0:
        player.sanity -= player.sanity * 2
        say(f"{Color['magenta']}{player.name} Sanity Is Now {player.sanity}!{Color['reset']}")
    
    else:
        say("Nothing Happened!")
item_turn_over = Item("Turn Over Potion", "Turn sanity Positive/Negative if sanity is Negative/Positive.", [SPECIAL], 99, useType="Battle", coinCost=60, gpCost=120)
item_turn_over.special = types.MethodType(turn_over_special, item_turn_over)

##--Damage--##

item_whip = Item("Whip", "Deals (10 + 15% of Strength) Physical damage. Remove 1 Negative status from the opposer. Chance to inflict StR~Down/MgC~Down.", [DAMAGE, STATUS_I], 99, status=[StRDown, MgCDown], damage=(10, 1, [["strength", 0.15]]), hit=30, element="physical", coinCost=15, gpCost=25)

item_fire_tome = Item("Fire Tome", "Deals (10 + 15% of Magic) Fire damage. Chance to inflict 2 stacks of Burn.", [DAMAGE, STATUS_I], 99, status=[Burn], stacks=2, damage=(10, 1, [["magic", 0.15]]), hit=25, element="fire", coinCost=20, gpCost=30)

item_thunder_tome = Item("Thunder Tome", "Deals (20 + 10% of Magic) Thunder damage x 1-2. Chance to inflict 3 stacks of Spark.", [DAMAGE, STATUS_I], 99, status=[Spark], stacks=3, damage=(20, HITS(1,2), [["magic", 0.1]]), hit=35, element="thunder", coinCost=25, gpCost=45)

item_frost_book = Item("Frost Book", "Deals (10 + 15% of Magic) Ice damage. Chance to inflict 2 stacks of Glint/Freeze.", [DAMAGE, STATUS_I], 99, status=[Glint, Freeze], stacks=2, damage=(10, 1, [["magic", 0.15]]), hit=25, element="ice", coinCost=20, gpCost=30)

item_breeze_book = Item("Breeze Book", "Deals (15 + 20% of Magic) Wind damage x 1-3. Chance to gain 2 stacks of Keen.", [DAMAGE, STATUS_I], 99, status=[Keen], stacks=2, target="player", damage=(15, HITS(1,3), [["magic", 0.20]]), hit=35, element="wind", coinCost=25, gpCost=40)

item_nasty_bomb = Item("Nasty Bomb", "Deals (20 + 10% of Luck) Mighty damage x 2. Chance to inflict 2 stacks of Deadly Poison.", [DAMAGE, STATUS_I], 99, status=[DeadlyPoison], stacks=2, damage=(20, 2, [["luck", 0.15]]), hit=30, element="mighty", coinCost=25, gpCost=40)

##--##

item_brass_lamp = Item("Brass Lamp", "Deals (30 + 25% of Magic) Fire damage x 1-2. Chance to inflict 5 stacks of Willow Wisp/ReS~Down.", [DAMAGE, STATUS_I], 99, status=[WillowWisp, ReSDown], stacks=5, damage=(30, HITS(1,2), [["magic", 0.25]]), hit=40, element="fire", coinCost=45, gpCost=60)

item_charge_coil = Item("Charged Coil", "Deals (25 + 20% of Magic) Thunder damage x 1-3. Chance to gain 2 stacks of Charge.", [DAMAGE, STATUS_I], 99, status=[Charge], stacks=2, target="player", damage=(25, HITS(1,3), [["magic", 0.20]]), hit=35, element="thunder", coinCost=45, gpCost=60)

item_electro_trap = Item("Electro Trap", "Deals (23 + 22% of Strength) Thunder damage. Chance to inflict 5 stacks of Spark/Rupture.", [DAMAGE, STATUS_I], 99, status=[Spark, Rupture], stacks=5, count=5, damage=(23, 1, [["strength", 0.22]]), hit=50, element="thunder", coinCost=50, gpCost=70)

item_snow_globe = Item("Snow Globe", "Deals (20 + 25% of Magic) Ice damage x 1-4. Chance to inflict 2 stacks of Frostbite/Frigid.", [DAMAGE, STATUS_I], 99, status=[Frostbite, Frigid], stacks=2, damage=(20, HITS(1,4), [["magic", 0.25]]), hit=40, element="ice", coinCost=40, gpCost=80)

item_caltrops = Item("Caltrops", "Deals (15 + 20% of Strength) Physical damage x 1-6. Chance to inflict 2 stacks of Hemorrhage/Gash.", [DAMAGE, STATUS_I], 99, status=[Hemorrhage, Gash], stacks=2, damage=(15, HITS(1,6), [["strength", 0.2]]), hit=40, element="physical", coinCost=50, gpCost=70)

def daggers_effect(item: Item, player: Player, enemy: Enemy):
    if enemy.health <= round(enemy.maxHealth * 0.5):
        return 50
item_daggers = Item("Daggers", "Deals (25 + 30% of Strength) Physical damage x 1-2. If opposers health is below 50%, increase damage (50). Chance to inflict 5 stacks of Hemorrhage/Puncture.", [DAMAGE, STATUS_I], 99, status=[Hemorrhage, Puncture], stacks=2, damage=(25, HITS(1, 2), [["strength", 0.25]]), hit=50, element="physical", extraEffect=daggers_effect, coinCost=80, gpCost=130)

item_razor_knives = Item("Razor Knives", "Deals (20 + 25% of Strength) Physical damage x 1-4. Chance to inflict Puncture/Bleed.", [DAMAGE, STATUS_I], 99, status=[Puncture, Bleed], damage=(20, HITS(1,4), [["strength", 0.25]]), hit=35, element="physical", coinCost=75, gpCost=120)

item_hair_dryer = Item("Hair Dryer", "Deals (30 + 30% of Magic) Wind damage x 2-3. Chance to gain 1 Poise/Boon.", [DAMAGE, STATUS_I], 99, status=[Poise, Boon], target="player", damage=(30, HITS(2,3), [["magic", 0.3]]), hit=40, element="wind", coinCost=60, gpCost=90)

item_rubberball = Item("Rubberball", "Deals (30 + 20% of Strength) Mighty damage x 2-5. Chance to inflict Infection/Sinking.", [DAMAGE, STATUS_I], 99, status=[Infection, Sinking], damage=(30, HITS(2,5), [["strength", 0.20]]), hit=45, element="mighty", coinCost=65, gpCost=100)

item_acid_bomb = Item("Acid Bomb.", "Deals (10 + 20% of Luck) Mighty damage. Chance to inflict Poise/DeF~Down/ReS~Down.", [DAMAGE, STATUS_I], 99, status=[Poison, DeFDown, ReSDown], damage=(10, 1, [[["luck", 0.2]]]), hit=45, element="physical", coinCost=65, gpCost=100)

##--##

item_soul_lantern = Item("Soul Lantern", "Deals (15 + 25% of Magic) Mighty damage. Chance to inflict 2 stacks of Sinking/ReS~Down.", [DAMAGE, STATUS_I], 99, status=[Sinking, ReSDown], stacks=2, damage=(15, 1, [["magic", 0.25]]), hit=55, element="mighty", coinCost=105, gpCost=140)

item_boulder_sling = Item("Boulder Sling", "Deals (30 + 40% of Strength) Mighty damage. Chance to inflict Stun.", [DAMAGE, STATUS_I], 99, status=[Stun], damage=(30, 1, [["strength", 0.3]]), hit=25, element="physical", coinCost=150, gpCost=230)