from Utility import *
from gameData.Skills import *

##------------Basic Enemies------------##
# 0-Fire | 1-Ice | 2-Thunder | 3-Wind | 4-Mighty | 5-Physical

enemy_dummy = Enemy("Dummy", "Cowardly", 9999, 10, 10, 10, 10, 100, 100, 15, [eskill_recharge], eskill_recharge, uskill_charge_ii, ["Neutral", "Neutral", "Neutral", "Neutral", "Neutral", "Neutral"], 0, 0)

enemy_ice_slime = Enemy("Ice Slime", "Cowardly", 225, 2, 7, 4, 5, 85, 60, 10, [eskill_mana_leech, eskill_ice_shard, eskill_icy_aura], eskill_icy_aura, uskill_soul_piercing_stare, ["Super Weak", "Resist", "Neutral", "Weak", "Neutral", "Resist"], 2, 3)

enemy_poison_slime = Enemy("Poison Slime", "Sadistic", 195, 2, 8, 3, 4, 70, 75, 15, [eskill_mana_leech, eskill_serration, eskill_surprise_gift], eskill_surprise_gift, uskill_great_chrysalis, ["Neutral", "Weak", "Neutral", "Weak", "Resist", "Resist"], 3, 5)

enemy_geo_slime = Enemy("Geo Slime", "Aggressive", 235, 7, 6, 6, 6, 50, 50, 10, [eskill_rough_housing, eskill_harden_i, eskill_rundown], eskill_rundown, uskill_charge_ii, ["Neutral", "Weak", "Neutral", "Neutral", "Weak", "Resist"], 3, 5)

enemy_fire_skeleton = Enemy("Fire Skeleton", "Aggressive", 210, 3, 9, 3, 8, 90, 70, 15, [eskill_mana_leech, eskill_chant_of_fire, eskill_burning_whirl], eskill_burning_whirl, uskill_soul_piercing_stare, ["Resist", "Resist", "Neutral", "Neutral", "Weak", "Weak"], 5, 7)

enemy_red_knight = Enemy("Red Knight", "Honorable", 250, 9, 7, 8, 5, 75, 80, 10, [eskill_serration, eskill_harden_i, eskill_burning_whirl], eskill_serration, uskill_charge_ii, ["Weak", "Resist", "Neutral", "Weak", "Neutral", "Resist"], 6, 8)

enemy_yellow_samurai = Enemy("Yellow Samurai", "Honorable", 300, 11, 6, 9, 8, 80, 80, 20, [eskill_exhaust, eskill_prideful_slash, eskill_counter_stance], eskill_prideful_slash, uskill_aerial_collide, ["Resist", "Neutral", "Neutral", "Resist", "Neutral", "Resist"], 12, 16)

enemy_serious_slime = Enemy("Serious Slime", "Tactical", 330, 8, 9, 6, 8, 50, 85, 15, [eskill_icy_aura, eskill_snow_storm, eskill_health_leech], eskill_health_leech, uskill_soul_piercing_stare, ["Weak", "Resist", "Neutral", "Weak", "Neutral", "Resist"], 11, 14)

enemy_playful_slime = Enemy("Playful Slime", "Cowardly", 325, 7, 10, 6, 8, 90, 60, 15, [eskill_warm_up, eskill_rough_housing, eskill_health_leech], eskill_rough_housing, uskill_festering_ripple, ["Weak", "Neutral", "Weak", "Weak", "Neutral", "Resist"], 10, 12)

enemy_zappy_spirit = Enemy("Zappy Spirit", "Aggressive", 375, 0, 13, 7, 10, 75, 75, 20, [eskill_exhaust, eskill_warm_up, eskill_wild_storm], eskill_wild_storm, uskill_charge_ii, ["Neutral", "Neutral", "Reflect", "Absorb", "Weak", "Resist"], 15, 15)

enemy_frigid_spirit = Enemy("Frigid Spirit", "Sadistic", 380, 0, 11, 8, 11, 80, 65, 15, [eskill_snow_storm, eskill_ice_shard, eskill_harden_i], eskill_harden_i, uskill_soul_piercing_stare, ["Weak", "Absorb", "Neutral", "Weak", "Neutral", "Resist"], 14, 16)

enemy_negative_revenant = Enemy("Negative Revenant", "Opportunist", 390, 11, 11, 5, 6, 80, 65, 20, [eskill_health_leech, eskill_serration, eskill_power_charge_I], eskill_power_charge_I, uskill_survival, ["Neutral", "Neutral", "Resist", "Weak", "Resist", "Weak"], 15, 17)

enemy_mountain_slime = Enemy("Mountain Slime", "Cowardly", 455, 13, 14, 11, 10, 70, 95, 15, [eskill_snow_storm, eskill_earthen_chains, eskill_recharge], eskill_earthen_chains, uskill_survival, ["Weak", "Resist", "Null", "Neutral", "Neutral", "Neutral"], 30, 30)

enemy_aura_deimon = Enemy("Aura Deimon", "Sadistic", 435, 11, 15, 8, 12, 90, 90, 20, [eskill_power_charge_I, eskill_consume, eskill_aura_strike], eskill_aura_strike, uskill_soul_piercing_stare, ["Reflect", "Resist", "Neutral", "Neutral", "Weak", "Reflect"], 32, 34)

enemy_howling_spirit = Enemy("Howling Spirit", "Aggressive", 450, 3, 17, 13, 8, 65, 75, 20, [eskill_wild_thungerga, eskill_thunderous_roar, eskill_recharge], eskill_thunderous_roar, uskill_high_surge, ["Resist", "Weak", "Absorb", "Neutral", "Neutral", "Null"], 32, 30)

enemy_incessant_doctor = Enemy("Incessant Doctor", "Opportunist", 500, 9, 20, 12, 15, 80, 90, 20, [eskill_mana_leech, eskill_moon_blade, eskill_esuna], eskill_moon_blade, uskill_soul_drain, ["Neutral", "Absorb", "Weak", "Weak", "Absorb", "Neutral"], 40, 38)

enemy_titan = Enemy("Titan", "Tactical", 600, 19, 4, 16, 14, 65, 75, 15, [eskill_upheaval, eskill_reckless_assault, eskill_warm_up], eskill_reckless_assault, uskill_survival, ["Weak", "Neutral", "Super Weak", "Neutral", "Null", "Null"], 45, 30)

enemy_wild_cotton = Enemy("Wild Cotton", "Sadistic", 480, 10, 16, 16, 16, 80, 80, 25, [eskill_air_stasis, eskill_punishing_blade, eskill_consume, eskill_haste, epassive_lucky_play], eskill_haste, uskill_setback, ["Weak", "Weak", "Resist", "Absorb", "Neutral", "Weak"], 35, 35)

enemy_the_melded_faces = Enemy("The Melded Faces", "Aggressive", 540, 16, 16, 12, 12, 90, 100, 15, [eskill_punishing_blade, eskill_cataclysm, eskill_voiding_beam, epassive_lucky_play], eskill_voiding_beam, uskill_wound_play, ["Resist", "Resist", "Resist", "Resist", "Weak", "Weak"], 20, 40)

enemy_the_jailer = Enemy("The Jailer", "Aggressive", 540, 20, 5, 14, 11, 75, 80, 15, [eskill_earthen_chains, eskill_reckless_assault, eskill_red_cyclone, epassive_experience], eskill_earthen_chains, uskill_lockout_chains, ["Weak", "Weak", "Reflect", "Neutral", "Neutral", "Reflect"], 45, 30)

enemy_evil_slime = Enemy("Evil Slime", "Honorable", 350, 10, 17, 12, 14, 100, 70, 25, [eskill_head_hunter, eskill_falling_hail, eskill_cataclysm, eskill_haste, epassive_experience], eskill_haste, uskill_devils_bell, ["Resist", "Weak", "Resist", "Neutral", "Absorb", "Null"], 50, 45)

enemy_silver_slime = Enemy("Silver Slime", "Cowardly", 450, 16, 10, 15, 12, 80, 80, 10, [eskill_harden_ii, eskill_power_charge_II, eskill_rough_housing], eskill_rough_housing, uskill_great_chrysalis, ["Super Weak", "Resist", "Resist", "Neutral", "Neutral", "Reflect"], 00, 00, 
                           canTransform=True, transformTo=enemy_evil_slime, transTrigger=lambda self, target: self.health <= round(self.maxHealth * 0.25))

enemy_dimension_wisp = Enemy("Dimension Wisp", "Aggressive", 725, 22, 16, 15, 15, 60, 110, 25, [eskill_red_cyclone, eskill_molten_cobble, epassive_rift_espers], eskill_molten_cobble, uskill_soul_piercing_stare, ["Reflect", "Weak", "Absorb", "Neutral", "Resist", "Null"], 100, 90)

enemy_knight_slime = Enemy("Knight Slime", "Honorable", 850, 24, 13, 20, 14, 70, 70, 20, [eskill_spliting_slash, eskill_reckless_assault, epassive_lock_down], eskill_spliting_slash, uskill_wound_play, ["Weak", "Resist", "Weak", "Neutral", "Reflect", "Reflect"], 95, 110)

enemy_calico_slime = Enemy("Calico Slime", "Sadistic", 700, 20, 15, 18, 16, 90, 90, 25, [eskill_head_shot, eskill_haste, epassive_lucky_play], eskill_head_shot, uskill_setback, ["Reflect", "Neutral", "Reflect", "Weak", "Neutral", "Weak"], 90, 95)

##------------Raid Enemies------------##

raid_gold_blur = Enemy("Golden Blur", "Aggressive", 1305, 32, 30, 24, 23, 130, 90, 35, [spskill_blue_cyclone, spskill_spin, spskill_blurring_rush, spassive_infinite_speed], spskill_spin, uskill_charge_ii, ["Resist", "Neutral", "Resist", "Resist", "Reflect", "Neutral"], 00, 00)

raid_blue_blur = Enemy("Blue Blur", "Honorable", 1200, 24, 20, 28, 26, 100, 80, 30, [eskill_power_charge_ex, spskill_blue_cyclone, spskill_spin, spassive_jewel_collector], eskill_power_charge_ex, uspskill_seven_jewels, ["Resist", "Neutral", "Resist", "Resist", "Weak", "Neutral"], 00, 00,
                       True, raid_gold_blur, lambda self, target: self.lastAction and self.lastAction == "Ultimate" and self.lastSkill.name == "Seven Jewels of Power")

raid_rookie_cop = Enemy("Rookie S. Cop", "Tactical", 1235, 33, 21, 32, 24, 80, 85, 25, [eskill_head_hunter, spskill_herbal_remedy, spskill_rapid_fire, spassives_survivalist], eskill_head_hunter, uskill_survival, ["Resist", "Neutral", "Weak", "Neuetral", "Weak", "Resist"], 00, 00)

raid_green_dino = Enemy("Green Dino", "Aggressive", 1115, 30, 13, 31, 30, 80, 70, 25, [spskill_tongue_attach, spskill_bottom_bash, eskill_consume, epassive_lock_down], spskill_tongue_attach, uskill_spirit_stare, ["Weak", "Resist", "Neutral", "Neutral", "Resist", "Resist"], 00, 00)

##------------Raid Special Enemies------------##

special_energy_wisp = Enemy("Energy Wisp", "Aggressive", 2300, 22, 28, 31, 38, 90, 90, 30, [spskill_chakra_rupture, spskill_wind_lashes, eskill_falling_hail, epassive_rift_espers], spskill_chakra_rupture, uspskill_world_fracture, ["Resist", "Resist", "Weak", "Null", "Resist", "Neutral"], 00, 00)

special_orchid_swan = Enemy("Orchid Swan", "Cowardly", 2545, 21, 30, 29, 40, 100, 70, 20, [spskill_swan_song, spskill_wind_lashes, eskill_consume, epassive_experience], spskill_swan_song, uskill_great_chrysalis, ["Resist", "Absorb", "Weak", "Reflect", "Neutral", "Neutral"], 00, 00)

special_undead_phoenix = Enemy("Undead Phoenix", "Sadistic", 2855, 5, 32, 36, 36, 90, 75, 30, [eskill_mana_leech, eskill_earthen_chains, eskill_air_stasis, epassive_lock_down], eskill_mana_leech, uspskill_rebirth, ["Absorb", "Weak", "Neutral", "Resist", "Weak", "Neutral"], 00, 00)

special_pale_clad_soldier = Enemy("Pale Clad Soldier", "Tactical", 3000, 37, 26, 44, 38, 75, 80, 25, [eskill_molten_cobble, eskill_punishing_blade, spskill_soul_snare, epassive_experience], spskill_soul_snare, uspskill_vital_squeeze, ["Resist", "Neutral", "Weak", "Neutral", "Resist", "Resist"], 00, 00)

##------------Raid Boss Enemies------------##

raid_boss_meliane = Enemy("Meliane, the Singing Gale", "Honorable", 5525, 26, 34, 35, 40, 100, 80, 25, [bskill_passionate_hymn, bskill_feeble_song, bskill_skys_wrath, bpassive_winds_guidance], bskill_feeble_song, ubskill_soothing_aria, ["Resist", "Weak", "Neutral", "Reflect", "Weak", "Neutral"], 00, 00)

raid_boss_hanbo = Enemy("Hanbo, the Uncarring Phoenix Lord", "Sadistic", 6115, 31, 40, 40, 45, 85, 90, 30, [bskill_ghost_flame, bskill_heartless_flames, bskill_rebirth_anchor, bpassive_lord_nether], bskill_rebirth_anchor, ubskill_ghastly_rebirth, ["Absorb", "Super Weak", "Neutral", "Neutral", "Resist", "Resist"], 00, 00)

##------------Seasson Boss Enemies------------##

boss_sol = Enemy("Sol", "Opportunist", 435, 6, 11, 11, 12, 70, 70, 10, [bskill_light_ray, bskill_yellow_gleam], bskill_self_bath, ubskill_solar_eclipse, ["Resist", "Neutral", "Neutral", "Weak", "Neutral", "Neutral"], 0, 0, theme="summer")

boss_sol_x = Enemy("Sol X", "Opportunist", 700, 14, 23, 19, 22, 80, 80, 20, [bskill_light_ray, bskill_yellow_gleam, bskill_self_bath], bskill_self_bath, ubskill_solar_eclipse, ["Absorb", "Neutral", "Neutral", "Weak", "Neutral", "Neutral"], 0, 0, theme="summer")

boss_sol_ex = Enemy("Sol EX", "Opportunist", 1005, 18, 27, 23, 26, 80, 90, 25, [bskill_light_ray, bskill_yellow_gleam, bskill_self_bath, bpassive_great_sol], bskill_self_bath, ubskill_solar_eclipse, ["Absorb", "Null", "Neutral", "Reflect", "Neutral", "Neutral"], 0, 0, theme="summer")

##--##

boss_white_silence = Enemy("White Silence", "Tactical", 415, 12, 6, 9, 8, 40, 70, 15, [bskill_imobilize, bskill_white_echo], bskill_imobilize, ubskill_lacrimosa_crescendo, ["Weak", "Resist", "Weak", "Neutral", "Resist", "Neutral"], 0, 0, theme="winter")

boss_white_silence_x = Enemy("White Silence X", "Tactical", 665, 22, 15, 18, 17, 75, 80, 25, [bskill_imobilize, bskill_white_echo, bskill_snowy_mist], bskill_imobilize, ubskill_lacrimosa_crescendo, ["Weak", "Resist", "Resist", "Neutral", "Resist", "Neutral"], 0, 0, theme="winter")

boss_white_silence_ex = Enemy("White Silence EX", "Tactical", 965, 26, 19, 22, 21, 90, 85, 30, [bskill_imobilize, bskill_white_echo, bskill_snowy_mist, bpassive_soundless_echo], bskill_imobilize, ubskill_lacrimosa_crescendo, ["Weak", "Reflect", "Resist", "Neutral", "Resist", "Neutral"], 0, 0, theme="winter")

##--##

boss_super_slime = Enemy("Super Charged Slime", "Cowardly", 695, 9, 13, 9, 10, 70, 65, 10, [bskill_wild_thungerga_strikes, bskill_mass_discharge], bskill_mass_discharge, ubskill_catastrophic_overload, ["Neutral", "Neutral", "Neutral", "Absorb", "Weak", "Neutral"], 0, 0, theme="fall")

boss_super_slime_x = Enemy("Super Charged Slime X", "Cowardly", 845, 18, 22, 17, 19, 80, 75, 20, [bskill_wild_thungerga_strikes, bskill_mass_discharge, bskill_super_charge], bskill_super_charge, ubskill_catastrophic_overload, ["Neutral", "Neutral", "Resist", "Absorb", "Weak", "Resist"], 0, 0, theme="fall")

boss_super_slime_ex = Enemy("Super Charged Slime EX", "Cowardly", 1145, 22, 26, 21, 23, 90, 75, 25, [bskill_wild_thungerga_strikes, bskill_mass_discharge, bskill_super_charge, bpassive_lightning_rod], bskill_super_charge, ubskill_catastrophic_overload, ["Resist", "Neutral", "Resist", "Absorb", "Weak", "Reflect"], 0, 0, theme="fall")

##--##

boss_syzoth = Enemy("Syzoth", "Aggressive", 500, 13, 9, 10, 4, 60, 80, 15, [bskill_force_ball, bskill_tongue_lash,], bskill_tongue_lash, ubskill_beast_unleashed, ["Neutral", "Super Weak", "Neutral", "Neutral", "Resist", "Resist"], 0, 0, theme="spring")

boss_syzoth_x = Enemy("Syzoth X", "Aggressive", 750, 21, 17, 18, 13, 80, 90, 25, [bskill_force_ball, bskill_tongue_lash, bskill_dirty_claw], bskill_dirty_claw, ubskill_beast_unleashed, ["Resist", "Super Weak", "Neutral", "Neutral", "Resist", "Resist"], 0, 0, theme="spring")

boss_syzoth_ex = Enemy("Syzoth EX", "Aggressive", 1050, 25, 21, 22, 17, 90, 115, 30, [bskill_force_ball, bskill_tongue_lash, bskill_dirty_claw, bpassive_kombatent], bskill_dirty_claw, ubskill_beast_unleashed, ["Resist", "Super Weak", "Neutral", "Neutral", "Null", "Resist"], 0, 0, theme="spring")

##------------Boss Enemies------------##

boss_nameless_king = Enemy("Nameless King", "Aggressive", 825, 18, 20, 10, 12, 90, 115, 25, [bskill_spear_charge, bskill_lightning_stake, bskill_expanding_lightning, bpassive_first_born], bskill_spear_charge, ubskill_kings_shockwave, ["Resist", "Neutral", "Null", "Reflect", "Weak", "Resist"], 120, 84)

boss_king_storms = Enemy("King of the Storms", "Tactical", 655, 17, 18, 9, 11, 75, 100, 20, [bskill_dragons_breath, bskill_air_line, bskill_push_back], bskill_air_line, ubskill_kings_storm, ["Resist", "Neutral", "Weak", "Reflect", "Weak", "Neutral"], 000, 000, True, boss_nameless_king, lambda self, target: self.health <= round(self.maxHealth * 0.1))

boss_fire_lord = Enemy("Fire Lord", "Tactical", 480, 8, 14, 5, 9, 70, 90, 15, [eskill_chant_of_fire, bskill_flare_wave, eskill_warm_up], bskill_flare_wave, ubskill_magnis_flame, ["Resist", "Weak", "Resist", "Neutral", "Neutral", "Neutral"], 28, 45)
                    
boss_armored_knight = Enemy("Armored Knight", "Honorable", 470, 15, 5, 10, 8, 90, 90, 10, [bskill_heavy_slash, bskill_timed_stab, bskill_charge_i], bskill_heavy_slash, ubskill_double_heavy_slash, ["Weak", "Neutral", "Resist", "Neutral", "Neutral", "Resist"], 28, 45)

boss_elden_beast = Enemy("Elden Beast", "Tactical", 525, 7, 14, 9, 11, 80, 90, 20, [bskill_golden_breath, bskill_retreating_swing, bskill_flying_flame_sword], bskill_retreating_swing, ubskill_elden_stars, ["Neutral", "Neutral", "Weak", "Resist", "Resist", "Weak"], 75, 48)

boss_radagon = Enemy("Radagon, the King Consort", "Aggressive", 405, 11, 12, 7, 8, 50, 100, 15, [bskill_radagons_spear, bskill_holy_spear_fan, bskill_parry_stance], bskill_radagons_spear, ubskill_gold_breaker, ["Neutral", "Resist", "Weak", "Resist", "Resist", "Neutral"], 0, 0, 
               True, boss_elden_beast, lambda self, target: self.health <= round(self.maxHealth * 0.20))

boss_goku_rose = Enemy("Goku Black (Rose)", "Sadistic", 320, 13, 12, 6, 5, 90, 110, 25, [bskill_black_wave, bskill_god_slicer, bskill_work_of_gods], bskill_work_of_gods, ubskill_sickle_of_sorrow, ["Neutral", "Neutral", "Weak", "Neutral", "Resist", "Resist"], 80, 52)

boss_goku_black = Enemy("Goku Black", "Tactical", 415, 13, 11, 8, 7, 65, 100, 15, [bskill_god_slicer, bskill_work_of_gods, bskill_kai_healing], bskill_kai_healing, ubskill_godly_severence, ["Neutral", "Neutral", "Weak", "Neutral", "Resist", "Neutral"], 0, 0, 
               True, boss_goku_rose, lambda self, target: self.health <= round(self.maxHealth * 0.20))

boss_mohg = Enemy("Mohg, Lord of Blood", "Opportunist", 560, 7, 15, 7, 10, 110, 65, 10, [bskill_blood_flame_talons, bskill_bloodboon, bskill_blood_offer], bskill_blood_offer, ubskill_bloodboon_ritual, ["Resist", "Weak", "Neutral", "Weak", "Resist", "Resist"], 70, 45)

boss_mohg_consort = Enemy("Mohg, the Failed Consort", "Sadistic", 1300, 19, 24, 20, 23, 100, 90, 25, [bskill_blood_tax, bskill_blood_flame_explosion, bskill_omen_claw, bpassive_greatest_child], bskill_blood_tax, ubskill_ritual_countdown, ["Absorb", "Weak", "Neutral", "Neutral", "Null", "Resist"], 190, 165)

boss_deus_motus = Enemy("Deus Motus", "Opportunist", 825, 12, 18, 12, 14, 65, 80, 25, [bskill_kinetic_intake, bskill_onero_intake, bskill_deus_discharge], bskill_onero_intake, ubskill_divine_motus, ["Neutral", "Neutral", "Resist", "Resist", "Weak", "Weak"], 88, 56)

boss_kratos = Enemy("Kratos, God of Sparta", "Aggressive", 725, 18, 13, 11, 10, 50, 100, 15, [bskill_gauntlets_of_zeus, bskill_atlas_quake, bskill_power_absorption], bskill_power_absorption, ubskill_blade_of_olympus, ["Neutral", "Neutral", "Neutral", "Neutral", "Resist", "Resist"], 88, 56)

boss_mortal_hate = Enemy("Mortal Hating God", "Cowardly", 955, 1, 30, 20, 22, 100, 90, 25, [bskill_extinction, bskill_light_of_doom, bskill_cloning, bpassive_immortality], bskill_cloning, ubskill_zamasus_justice, ["Weak", "Null", "Reflect", "Null", "Absorb", "Weak"], 380, 335)

boss_fused_zamasu = Enemy("Fused Zamasu", "Sadistic", 1650, 17, 28, 23, 26, 90, 85, 20, [bskill_absolute_lightning, bskill_blades_of_judgment, bskill_energy_charge, bpassive_purity], bskill_energy_charge, ubskill_light_divine, ["Neutral", "Resist", "Resist", "Null", "Reflect", "Weak"], 00, 00, 
                          True, boss_mortal_hate, lambda self, target: self.health <= round(self.maxHealth * 0.15))

boss_unhearing_child = Enemy("Unhearing Child", "Cowardly", 550, 1, 14, 13, 8, 50, 75, 20, [bskill_inconsolable_grief, bskill_victimize, bskill_restrain], bskill_victimize, ubskill_isolate, ["Absorb", "Weak", "Neutral", "Neutral", "Reflect", "Weak"], 99, 78)

boss_unseeing_child = Enemy("Unseeing Child", "Aggressive", 500, 3, 13, 12, 10, 70, 80, 30, [bskill_distored_illusion, bskill_bygone_illusion, bskill_facade_impact], bskill_distored_illusion, ubskill_isolate, ["Absorb", "Weak", "Neutral", "Neutral", "Reflect", "Resist"], 0, 0,
                              True, boss_unhearing_child, lambda self, target: self.health <= round(self.maxHealth * 0.15) or self.sanity >= 20 or self.sanity <= -20)

boss_unspeaking_child = Enemy("Unspeaking Child", "Opportunist", 450, 5, 11, 12, 11, 90, 90, 20, [bskill_unhearing_murmur, bskill_unseeing_murmur, bskill_unspeaking_murmur], bskill_unseeing_murmur, ubskill_isolate, ["Absorb", "Weak", "Neutral", "Neutral", "Resist", "Resist"], 0, 0,
                              True, boss_unseeing_child, lambda self, target: self.health <= round(self.maxHealth * 0.25) or self.sanity >= 25 or self.sanity <= -15)

boss_midra = Enemy("Midra, Lord of Frenzied Flame", "Tactical", 955, 15, 14, 15, 14, 70, 80, 20, [bskill_flame_frenzy, bskill_sweeping_frenzy, bskill_barbed_thrust, bpassive_vassal], bskill_sweeping_frenzy, ubskill_midras_frenzy, ["Absorb", "Weak", "Neutral", "Resist", "Weak", "Resist"], 99, 78)

boss_time_ripper = Enemy("Time Ripper", "Opportunist", 900, 18, 10, 14, 12, 80, 90, 25, [bskill_you_afraid, bskill_extraction, bskill_time_steal, bpassive_resentment], bskill_you_afraid, ubskill_time_save, ["Neutral", "Resist", "Resist", "Absorb", "Neutral", "Weak"], 99, 78 )

boss_the_father = Enemy("The Father", "Sadistic", 1410, 20, 5, 15, 15, 50, 80, 20, [bskill_harsh_glare, bskill_harsh_lecture, bskill_frigid_lesson, bpassive_observation], bskill_harsh_glare, ubskill_final_lesson, ["Weak", "Null", "Resist", "Weak", "Neutral", "Resist"], 99, 80)

boss_phillip = Enemy("Phillip, the Waxen Pinion", "Honorable", 2100, 32, 30, 28, 27, 110, 75, 25, [bskill_torrid_sword, bskill_scorching_strike, bskill_wax_winged, bpassive_shimmering, bpassive_heros_passion], bskill_torrid_sword, ubskill_melting_star, ["Absorb", "Weak", "Neutral", "Absorb", "Resist", "Resist"], 760, 670, theme="sea")

boss_salax = Enemy("Salax the Lustful Harpy", "Sadistic", 930, 13, 19, 12, 15, 95, 85, 25, [bskill_aroma_spread, bskill_feather_shot, bskill_wind_slam, bpassive_display_love], bskill_feather_shot, ubskill_desire_moon, ["Reflect", "Neutral", "Weak", "Resist", "Neutral", "Resist"], 111, 106)

boss_dolor = Enemy("Dolor the Sorrowful Man", "Cowardly", 1120, 8, 18, 15, 17, 65, 80, 15, [bskill_panic_attack, bskill_brood, bskill_shared_pain, bpassive_waning_moon], bskill_panic_attack, ubskill_tears_moon, ["Weak", "Absorb", "Weak", "Neutral", "Absorb", "Resist"], 111, 106)

boss_egenus = Enemy("Egenus the Lacking Snake", "Opportunist", 980, 14, 18, 13, 15, 90, 85, 20, [bskill_oozing_envy, bskill_mine, bskill_underhanded_tactics, bpassive_abysmal_greed], bskill_mine, ubskill_yearning_moon, ["Absorb", "Weak", "Resist", "Neutral", "Null", "Resist"], 111, 106)

boss_mamzer = Enemy("Mamzer the Bastard Lycon", "Aggressive", 1085, 21, 10, 16, 12, 75, 90, 20, [bskill_moons_sanatio, bskill_pillage, bskill_cruentos_amor, bpassive_living_remnant], bskill_pillage, ubskill_scorn_moon, ["Resist", "Resist", "Neutral", "Neutral", "Resist", "Reflect"], 111, 106)

boss_dionus = Enemy("Dionus, Lord of the Twin Moons", "Tactical", 1165, 16, 24, 18, 21, 80, 100, 20, [eskill_cleanse, bskill_finest_wine, bskill_lords_friaja, bskill_lords_aura, bpassive_lord_moons], bskill_lords_friaja, ubskill_detachment_moon, ["Reflect", "Weak", "Resist", "Neutral", "Resist", "Neutral"], 135, 146)

boss_chionizei = Enemy("Chionizei, Bringer of Snow", "Sadistic", 2455, 20, 33, 28, 31, 110, 85, 30, [bskill_eight_cage, bskill_moons_blessing, bskill_hibernate, bpassive_freezing_eye], bskill_hibernate, ubskill_lunar_tear, ["Weak", "Absorb", "Weak", "Resist", "Null", "Resist"], 500, 335)

boss_kataigida = Enemy("Kataigida, Bringer of Storms", "Honorable", 2500, 32, 24, 28, 28, 100, 85, 30, [bskill_seven_charged, bskill_lightning_dance, bskill_thunderous_drums, bpassive_roaring_laughter], bskill_lightning_dance, ubskill_casting, ["Resist", "Resist", "Absorb", "Weak", "Resist", "Weak"], 500, 335)

boss_vilis = Enemy("Vilis, the Vile One", "Opportunist", 1355, 25, 17, 18, 15, 80, 80, 25, [bskill_infinite_defect, bskill_undae_ventae, bskill_globus_luti, bpassive_one_corruption], bskill_undae_ventae, ubskill_corrupted_transit, ["Weak", "Resist", "Neutral", "Resist", "Null", "Resist"], 130, 125)

boss_solumn_lament = Enemy("Solumn Lament", "Tactical", 1380, 26, 12, 19, 21, 65, 85, 30, [bskill_butterfly_flight, bskill_celebration_departed, bskill_lament_living, bpassive_hand_salvation], bskill_celebration_departed, ubskill_goodbye_now, ["Resist", "Absorb", "Weak", "Neutral", "Resist", "Neutral"], 135, 130)

boss_court_jester = Enemy("Court Jester, God of Magic", "Sadistic", 1300, 10, 27, 14, 19, 60, 90, 30, [bskill_luck_cards, bskill_ball_juggle, bskill_contagious_laughter, bpassive_laughing_matter], bskill_contagious_laughter, ubskill_five_spade, ["Resist", "Resist", "Resist", "Resist", "Null", "Weak"], 130, 128)

boss_lone_delusion = Enemy("The Lone Delusion", "Tactical", 775, 10, 28, 20, 20, 100, 70, 25, [bskill_confusing_fake, bskill_world_isolate, bskill_consumption_self, bpassive_acceptance_self, bpassive_blank_mask], bskill_world_isolate, ubskill_worldly_denial, ["Neutral", "Absorb", "Neutral", "Neutral", "Weak", "Weak"], 165, 175)

boss_cracked_delusion = Enemy("The Cracked Delusion", "Cowardly", 900, 10, 26, 14, 16, 55, 75, 15, [bskill_shattering_outburst, bskill_facade_break, bskill_piece_together, bpassive_blank_mask], bskill_facade_break, ubskill_nobodys_heartbeat, ["Weak", "Absorb", "Neutral", "Neutral", "Resist", "Resist"], 0, 0,
                              True, boss_lone_delusion, lambda self, target: self.health <= round(self.maxHealth * 0.2) or self.sanity <= -20)

boss_mask_delusion = Enemy("Mask of Delusion", "Aggressive", 1125, 10, 24, 16, 18, 80, 85, 25, [bskill_jolly_giggle, bskill_laugh_mock, bskill_mask_slip], bskill_jolly_giggle, ubskill_world_delusions, ["Weak", "Resist", "Neutral", "Neutral", "Absorb", "Absorb"], 0, 0, 
                           True, boss_cracked_delusion, lambda self, target: self.health <= round(self.maxHealth * 0.1) or self.sanity <= -20)

boss_orion_knight = Enemy("The Knight of Orion", "Tactical", 1999, 26, 27, 21, 22, 99, 99, 35, [bskill_sword_tunnel, bskill_star_fury, bskill_nebulizer, bpassive_arrogant_boasting], bskill_nebulizer, ubskill_roaring, ["Reflect", "Super Weak", "Resist", "Null", "Absorb", "Neutral"], 166, 199)

boss_three_drag_king = Enemy("Three-Headed Dragon King", "Honorable", 2125, 32, 30, 24, 26, 75, 80, 30, [bskill_waking_avalanche, bskill_icy_barrier, bskill_flare_impact, bskill_blazing_heart, bskill_primaeval_rupture, bpassive_planning_king], None, [ubskill_diamond_dust, ubskill_giga_impact, ubskill_imposing_aura], ["Weak", "Weak", "Reflect", "Reflect", "Super Weak", "Reflect"], 200, 235,
                             theme="thdk")

boss_hoarah_loux = Enemy("Hoarah Loux", "Sadistic", 1500, 40, 15, 28, 20, 70, 80, 25, [bskill_earth_stomp, bskill_power_bomb, bskill_claw_barrage, bpassive_lord_badlands], bskill_power_bomb, ubskill_earthshaker, ["Neutral", "Reflect", "Weak", "Resist", "Super Weak", "Null"], 175, 200,
                         theme="hoarah")

boss_godfrey = Enemy("Godfrey", "Honorable", 1850, 35, 20, 32, 24, 65, 55, 20, [bskill_plunging_axe, bskill_overhead_smash, bskill_beastial_sacrifice, bpassive_tarnished_lord], bskill_plunging_axe, ubskill_regal_roar, ["Neutral", "Resist", "Neutral", "Resist", "Weak", "Resist"], 000, 000, 
                     True, boss_hoarah_loux, lambda self, target: self.health <= round(self.maxHealth * 0.25), "hoarah")

boss_wayward_passenger = Enemy("Wayward Passenger", "Aggressive", 1750, 34, 15, 26, 25, 80, 85, 30, [bskill_rip_space, bskill_dimensional_slice, bskill_hideaway_rift, bpassive_dimensional_escape], bskill_rip_space, ubskill_high_rip, ["Super Weak", "Neutral", "Absorb", "Absorb", "Null", "Neutral"], 155, 190)

boss_shadow_daemon = Enemy("Shadow Daemon", "Sadistic", 3150, 1, 40, 28, 35, 100, 100, 35, [bskill_pareidolia, bskill_anti_mystic, bskill_volatile_ember, bpassive_gossamer], bskill_pareidolia, ubskill_nightshade_flashover, ["Absorb", "Reflect", "Resist", "Neutral", "Weak", "Null"], 250, 350, theme="hazey")