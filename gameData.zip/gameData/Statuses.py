from Utility import *
from Class import *

##--Other Family--##

##--Dev Only--##
Fix = Status("Fix", "Other", 0, ["Buff"], "Neutral",
             "Fixes Stat Mutations.",
             mutate=[["strength", 0]])

##--Misc--##
def muddySpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.statMutation(afflicted)
    for status in afflicted.statusList:
        if status.name in ("Gash", "Venom"):
            status.special(afflicted, damage, opposer)
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By 5!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 20!{Color['reset']}")
Muddy = Status("Muddy", "Other", 3, ["Special"], "Negative",
               "Lower Speed/Hit by 5/20. If Gash or Venom are present, retrigger them. Last 3 actions.",
               mutate=[["speed", -5], ["hit", -20]])
Muddy.special = types.MethodType(muddySpecial, Muddy)

def breakSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.lastAction == "Skill" and "Damage" in afflicted.lastSkill.type_ and isinstance(damage, int):
        damage = round(damage * 0.30) + 30
        afflicted.health -= damage
        say(f"{Color['red']}Break Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
    
    self.simple(afflicted)
Break = Status("Break", "Other", 3, ["Special", "Debuff"], "Negative",
               "Lower Speed/Defense by 5. If afflicted's last action a damaging skill was used, deal damage (30 + 30% of damage). Last 3 actions.",
               mutate=[["speed", -5], ["defense", -5]])
Break.special = types.MethodType(breakSpecial, Break)

def superBreakSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.lastAction == "Skill" and "Damage" in afflicted.lastSkill.type_ and isinstance(damage, int):
        damage = round(damage * 0.5) + 50
        afflicted.health -= damage
        say(f"{Color['red']}Super Break Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
    
    self.simple(afflicted)
SuperBreak = Status("Super Break", "Other", 3, ["Special", "Debuff"], "Negative",
               "Lower Speed/Defense by 10/8. If last action a damaging skill was used, deal damage (50 + 50% of damage). Last 3 actions.",
               mutate=[["speed", -10], ["defense", -8]])
SuperBreak.special = types.MethodType(superBreakSpecial, SuperBreak)

def staggerSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if not hasattr(self, "immunity"):
        self.immunity = 0
        
    if self.immunity > 0:
        self.immunity -= 1
        return
    
    if damage and damage > 0:
        gained = min(30, max(0, round(damage * 0.05)))
        self.stacks = min(self.maxStack, self.stacks + gained)
        say(f"{Color['magenta']}{afflicted.name} Gained {gained} Stacks Of Stagger!{Color['reset']}")
    
    if self.stacks > 0:
        afflicted.speedMeter += 25
        say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By 25!{Color['reset']}")
        
    if self.stacks >= self.maxStack:
        self.stacks = 0
        self.immunity = 3
        Burnout.inflict(afflicted) 
        FrailII.inflict(afflicted)
Stagger = Status("Stagger", "Other", 0, ["Special"], "Neutral",
                 "If the opposer uses a damaging skill or attacked, gain stacks proportional to damage taken (Max 30/Min 0). Raise Speed Meter by 25 each action.  At max stacks, inflict Burnout/Frail II and enter immunity. While in immunity, all effects of Stagger will no longer happen for 3 actions, and then they will resume.",
                 canStack=True, maxStack=80, forever=True)
Stagger.special = types.MethodType(staggerSpecial, Stagger)

# Rupture Sub-Family #

def ruptureSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.wasHit:
        hits = opposer.attackHits
        for i in range(hits):
            if self.count <= 0:
                break
            damage = self.stacks * 3
            afflicted.health -= damage
            say(f"{Color['red']}Rupture Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
            self.remove(afflicted)
            if self.stacks <= 0: self.stacks = 1
            self.count -= 1
    
    if self.count <= 0 and self in afflicted.statusList or self.stacks <= 0 and self in afflicted.statusList:
        self.remove(afflicted, full=True)
Rupture = Status("Rupture", "Other", 0, ["Special"], "Negative",
                 "If the opposer used a damaging skill or attacked, deal damage (Rupture stacks x 3). Trigger for the amount of hits taken. When triggered, lose 1 count/stack (Stack will always be at least 1) per times triggered. When count reaches 0, remove self.",
                 canStack=True, maxStack=99, forever=True)
Rupture.special = types.MethodType(ruptureSpecial, Rupture); Rupture.count = 0

def deathriteBSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    
    if self.duration == 0 and not hasattr(self, "changed"):
        self.maxStack = self.stacks
        self.changed = True
    
    if opposer.lastAction == "Skill" and opposer.lastSkill.element and opposer.lastSkill.element in ["fire", "thunder"]:
        self.remove(afflicted)
        Burn.inflict(afflicted)
        Rupture.inflict(afflicted, 1, 1)
    
    burn = next((s for s in afflicted.statusList if s.name == "Burn"), None)
    if burn and burn.stacks >= 3:
        burn.remove(afflicted)
        Rupture.inflict(afflicted, 2, 2)
    
    if self.stacks <= 0:
        self.remove(afflicted, full=True)
        Burn.inflict(afflicted, 2)
        Rupture.inflict(afflicted, 2, 3)
        
        damage = 15 * self.count
        afflicted.health -= damage
        say(f"{Color['red']}Deathrite-Blaze Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
DeathriteBlaze = Status("Deathrite-Blaze", "Other", 1, ["Special"], "Neutral",
                        "Once active, this status cannot gain any stacks. If the opposer used a Fire/Thunder element skill, lose 1 stack and gain 1 stack of Burn/Rupture (with 2 count). If Burn is present and at 3+ stacks, remove 1 stack of Burn and gain 2 stacks of Rupture (with 2 count). At 0 stacks, remove self, inflict 2 stacks of Burn/Rupture (with 3 count), amd deal damage (15 x count (turns active)). Last forever and stacks up to 4.",
                        forever=True, canStack=True, maxStack=4)
DeathriteBlaze.special = types.MethodType(deathriteBSpecial, DeathriteBlaze); DeathriteBlaze.count = 0

def deathriteFSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    
    if self.duration == 0 and not hasattr(self, "changed"):
        self.maxStack = self.stacks
        self.changed = True
    
    if opposer.lastAction == "Skill" and opposer.lastSkill.element and opposer.lastSkill.element in ["physical", "wind"]:
        self.remove(afflicted)
        Slug.inflict(afflicted)
        Rupture.inflict(afflicted)
    
    if any(s.name == "Rupture" and s.stacks >= 10 for s in afflicted.statusList):
        Rupture.inflict(afflicted, self.stacks, self.stacks)
DeathriteFissure = Status("Deathrite-Fissure", "Other", 1, ["Special"], "Neutral",
                        "Once active, this status cannot gain any stacks. If the opposer used a Physical/Wind element skill, lose 1 stack and gain 1 stack of Slug/Rupture (with 1 count). If Rupture is present and at 10+ stacks, gain 1 per stack of Deathrite-Fissure stacks of Rupture (with 1 per stack of Deathrite-Fissure count) and lose 1 stack. Last forever and stacks up to 5.",
                        forever=True, canStack=True, maxStack=5)
DeathriteFissure.special = types.MethodType(deathriteFSpecial, DeathriteFissure); DeathriteFissure.count = 0

##--Counters--##
Counter = Status("Counter", "Other", 2, ["Counter"], "Positive",
                 "If damaged by a Physical skill, deal damage to the attacker (damage dealt x 4). Last 2 actions.",
                 counter=[4, 0], counterDamage="physical")

SuperCounter = Status("Super Counter", "Other", 2, ["Counter"], "Positive",
                 "If Player Enemy, makes opposer more likely to use damaging skills. If damaged by a damaging skill, deal damage to the attacker (damage dealt x 6). Last 2 actions.",
                 counter=[6, 0], taunt=7)

##--Reward--## 
Golden = Status("Golden", "Other", 1, ["Buff", "Debuff"], "Neutral",
                "Raise Luck by 25 + 1 per stack. Lower Hit by 20 + 1 per stack. If battle is a Map battle, increase Coin and Game Points rewarded by 1% per stack. Last forever and stacks up to 50.",
                forever=True, canStack=True, maxStack=50, mutate=[["luck", 25], ["hit", -20]])

Diamond = Status("Diamond", "Other", 1, ["Buff", "Debuff"], "Neutral",
                 "Raise Luck by 20. Lower Hit by 15. If battle is a Map battle, increase Coin and Game Points rewarded by 35%. Last forever.",
                 forever=True, mutate=[["luck", 20], ["hit", -15]])

##--Small Stat Alters--##
StRUp = Status("StR~Up", "Other", 5, ["Buff"], "Positive",
               "Raise Strength by 3. Last 5 actions.",
               mutate=[["strength", 3]])

MgCUp = Status("MgC~Up", "Other", 5, ["Buff"], "Positive",
               "Raise Magic by 3. Last 5 actions.",
               mutate=[["magic", 3]])

DeFUp = Status("DeF~Up", "Other", 5, ["Buff"], "Positive",
               "Raise Defense by 3. Last 5 actions.",
               mutate=[["defense", 3]])

ReSUp = Status("ReS~Up", "Other", 5, ["Buff"], "Positive",
               "Raise Resistance by 3. Last 5 actions.",
               mutate=[["resistance", 3]])

StRDown = Status("StR~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Strength by 3. Last 5 actions.",
               mutate=[["strength", -3]])

MgCDown = Status("MgC~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Magic by 3. Last 5 actions.",
               mutate=[["magic", -3]])

DeFDown = Status("DeF~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Defense by 3. Last 5 actions.",
               mutate=[["defense", -3]])

ReSDown = Status("ReS~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Resistance by 3. Last 5 actions.",
               mutate=[["resistance", -3]])

LcKDown = Status("LcK~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Luck by 15. Last 5 actions.",
               mutate=[["luck", -15]])

HiTDown = Status("HiT~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Hit by 15. Last 5 actions.",
               mutate=[["hit", -15]])

SpDDown = Status("SpD~Down", "Other", 5, ["Debuff"], "Negative",
               "Lower Speed by 5. Last 5 actions.",
               mutate=[["speed", -5]])

##--Buffs--##
Haze = Status("Haze", "Other", 3, ["Buff", "Debuff"], "Positive",
              "Raise Luck by 50. Lower Strength/Magic by 5. Last 3 actions.",
              mutate=[["luck", 50], ["strength", -5], ["magic", -5]])

Keen = Status("Keen", "Other", 3, ["Buff", "Debuff"], "Positive",
              "Raise Hit by 20 + 1 per stack. Lower Luck by 5 + 1 per stack. Last 3 actions and stacks up to 10.",
              canStack=True, maxStack=10, mutate=[["hit", 20], ["luck", -5]])

def poiseSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if any(s.name == "Keen" for s in afflicted.statusList):
        next(s for s in afflicted.statusList if s.name == "Keen").remove(afflicted)
        Poise.inflict(afflicted, 1)
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {15 + (5 * self.stacks)}!{Color['reset']}")
Poise = Status("Poise", "Other", 3, ["Special"], "Positive",
               "Raise Hit/Luck by 15 + 5 per stack. If Keen is present, remove 1 stack of Keen and gain 1 stack of Poise. Last 2 actions and stacks up to 12.",
               canStack=True, maxStack=12, mutate=[["hit", 15], ["luck", 15]], stackScale=5)
Poise.special = types.MethodType(poiseSpecial, Poise)

Boon = Status("Boon", "Other", 3, ["Buff"], "Positive",
              "Raise Luck by 10 + 10 per stack. Last 3 actions and stacks up to 6.",
              canStack=True, maxStack=6, mutate=[["luck", 10]], stackScale=10)

# Boost Sub-Family
BoostI = Status("Boost I", "Other", 3, ["Buff"], "Positive",
                "Raise Strength/Magic by 4. Last 3 actions.",
                mutate=[["strength", 4], ["magic", 4]])

BoostII = Status("Boost II", "Other", 3, ["Buff"], "Positive",
                "Raise Strength/Magic by 8. Last 3 actions.",
                mutate=[["strength", 8], ["magic", 8]], noCoexist=["Boost I"])

BoostIII = Status("Boost III", "Other", 5, ["Buff"], "Positive",
                "Raise Strength/Magic by 12. Last 5 actions.",
                mutate=[["strength", 12], ["magic", 12]], noCoexist=["Boost I", "Boost II"])

def powerInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        percent = 0.02 * self.stacks
        damage += round(damage * percent)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['yellow']}{afflicted.name}s Power Triggered! Damage Was Increased By {round(percent * 100)}%!{Color['reset']}")
    return damage
Power = Status("Power", "Other", 1, ["Special"], "Positive",
               "Increase next damaging skills damage (2% per stack) and lose 1 stack. Last forever and stacks up to 25.",
               forever=True, canStack=True, maxStack=25)
Power.damageInterupt = types.MethodType(powerInterupt, Power)

def mightInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        percent = 0.1 * self.stacks
        damage += round(damage * percent)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['yellow']}{afflicted.name}s Might Triggered! Damage Was Increased By {round(percent * 100)}%!{Color['reset']}")
    return damage
Might = Status("Might", "Other", 1, ["Special"], "Positive",
               "Increase next damaging skills damage (10% per stack) and lose 1 stack. Last forever and stacks up to 10.",
               forever=True, canStack=True, maxStack=10)
Might.damageInterupt = types.MethodType(mightInterupt, Might)

def overflowInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        if afflicted.lastAction == "Skill" and "Damage" in afflicted.lastSkill.type_:
            percent = 0.25
            if afflicted.lastSkill.recoil: percent = 0.5
            damage += round(damage * percent)
            dam = round(damage * 0.15)
            afflicted.user -= dam
            say(f"{Color['red']}Overflow Triggered! Damage Was Increased By {int(percent * 100)}% and {afflicted.name} Took Health {dam} Damage!{Color['reset']}")
Overflow = Status("Overflow", "Other", 3, ["Special"], "Positive",
                  "Increase next damaging skills damage (25%!) and lose health (15% of damage). If a recoil skill is used, increase damage (2x!). Last 3 actions.")
Overflow.damageInterupt = types.MethodType(overflowInterupt, Overflow)

def fullPowerInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        damage *= 2
        self.remove(afflicted, full=True)
        say(f"{Color['yellow']}Full Power Triggered! Damage Was Increased By 2x!{Color['reset']}")
    return damage
FullPower = Status("Full Power", "Other", 1, ["Special"], "Positive",
                   "Increase next attack or damaging skills damage (2x!) and remove self. Last forever.",
                   forever=True)
FullPower.damageInterupt = types.MethodType(fullPowerInterupt, FullPower)

# Tough Sub-Family
ToughI = Status("Tough I", "Other", 3, ["Buff"], "Positive",
                     "Raise Defense/Resistance by 3 + stack. Last 3 actions and stacks up to 3.",
                    canStack=True, maxStack=3, mutate=[["defense", 3], ["resistance", 3]])

ToughII = Status("Tough II", "Other", 3, ["Buff"], "Positive",
                     "Raise Defense/Resistance by 8 + stack. Last 3 actions and stacks up to 5.",
                    canStack=True, maxStack=5, mutate=[["defense", 8], ["resistance", 8]], noCoexist=["Tough I"])

def protectionInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        reduce = (0.3 + 0.05 * self.stacks)
        damage -= round(damage * reduce)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['magenta']}{afflicted.name}s Protection Triggered! Damage Was Reduced By {round(reduce * 100)}%!{Color['reset']}")
    return damage
def profraSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks <= 0:
        self.remove(afflicted, full=True)
Protection = Status("Protection", "Other", 1, ["Special"], "Positive",
                    "Reduce damage taken by the next attack or damaging skill used by the opposer by 30% + 5% per stack. If the opposer used an attack or damaging skill, lose 1 stack. Last forever and stacks up to 5.",
                    forever=True, canStack=True, maxStack=5)
Protection.special = types.MethodType(profraSpecial, Protection)
Protection.damageInterupt = types.MethodType(protectionInterupt, Protection)

def shellInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        reduce = (0.05 + 0.01 * self.stacks)
        damage -= round(damage * reduce)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['magenta']}{afflicted.name}s Shell Triggered! Damage Was Reduced By {round(reduce * 100)}%!{Color['reset']}")
    return damage
def profraSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks <= 0:
        self.remove(afflicted, full=True)
Shell = Status("Shell", "Other", 2, ["Special"], "Positive",
               "Reduce damage taken by the next attack or damaging skill used by the opposer by 5% + 1% per stack and lose 1 stack. Last 2 actions and stacks up to 25.",
               canStack=True, maxStack=25)
Shell.special = types.MethodType(profraSpecial, Shell)
Shell.damageInterupt = types.MethodType(shellInterupt, Shell)

def vitalityInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        if damage > afflicted.maxHealth // 2:
            damage = afflicted.maxHealth // 2
            self.remove(afflicted, full=True)
            say(f"{Color['red']}{afflicted.name}s Vitality Triggered! Damage Was Set To 15% Of {afflicted.name}s Max Health!{Color['reset']}")
    return damage
Vitality = Status("Vitality", "Other", 4, ["Special"], "Positive",
                  "If damage taken by the next attack or damaging skill used by the opposer is more than 15% of health, remove self and set damage taken to 15% of Max Health. Last 4 actions.")
Vitality.damageInterupt = types.MethodType(vitalityInterupt, Vitality)

def antiMagicInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        if opposer.lastAction == "Skill" and opposer.lastSkill.statsUsed[0] in ["magic", "resistance"]:
            damage = round(damage * 0.3)
            self.remove(afflicted, full=True)
            say(f"{Color['red']}{afflicted.name}s Magic Shield Triggered! Damage Was Reduced By 30%{Color['reset']}")
    return damage
MagicShield = Status("Magic Shield", "Other", 3, ["Special", "Debuff"], "Positive",
                     "Reduce damage taken by the next Magic damaging skill used by the opposer by 30% and remove self. Last 3 actions.")
MagicShield.damageInterupt = types.MethodType(antiMagicInterupt, MagicShield)

def healthSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks > 0:
        heal = round(afflicted.maxHealth * 0.02)
        afflicted.health += min(heal, afflicted.maxHealth - afflicted.health)
        say(f"{Color['green']}{afflicted.name}s Health Was Restored By {heal} From {self.name}!{Color['reset']}")
    else:
        self.remove(afflicted, full=True)
HealthShield = Status("Health Shield", "Other", 1, ["Special"], "Positive",
                      "While present, all damage to health will be nullified (excluding status effects). If opposer uses an attack or damaging skill (direct only), lose 1 stack per hit. Restore health (2% of Max Health). Last forever and stacks up to 25.",
                      canStack=True, maxStack=25, forever=True)
HealthShield.special = types.MethodType(healthSpecial, HealthShield)

# Guards Sub-Family
GuardP = Status("Guard. P", "Other", 2, ["Buff"], "Positive",
                "Raise Defense by 10. Last 2 actions.",
                mutate=[["defense", 10]], noCoexist=["Guard. U", "Guard. M"])

GuardM = Status("Guard. M", "Other", 2, ["Buff"], "Positive",
                "Raise Resistance by 10. Last 2 actions.",
                mutate=[["resistance", 10]], noCoexist=["Guard. P", "Guard. U"])

GuardU = Status("Guard. U", "Other", 2, ["Buff"], "Positive",
                "Raise Defense/Resistance by 10. Last 2 actions.",
                mutate=[["resistance", 10], ["defense", 10]], noCoexist=["Guard. P", "Guard. M"])

# Regen Sub-Family
Regen = Status("Regen", "Other", 3, ["Heal"], "Positive",
               "Restore health (5% of Max Health + 1-5). Last 3 actions.",
                healWho="afflicted", damage=[[["maxHealth", 5]], lambda: random.randint(1,5), 1])

ManaRegen = Status("Mana Regen", "Other", 3, ["Heal"], "Positive",
               "Restore mana (4% of Max Mana + 1-3). Last 3 actions.",
                healWho="afflicted", meter="mana", damage=[[["maxMana", 4]], lambda: random.randint(1,3), 1])

def rejuvenateSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    heal = round(afflicted.maxHealth * 0.01) + self.stacks * 2
    afflicted.health = min(afflicted.maxHealth, afflicted.health + heal)
    say(f"{Color['green']}{afflicted.name}s Health Was Restored By {heal} From {self.name}!{Color['reset']}")
Rejuvenate = Status("Rejuvenate", "Other", 2, ["Special"], "Positive",
                    "Restore health (stacks x 2 + 1% of Max Health). Last 2 actions and stacks up to 99.",
                    canStack=True, maxStack=99)
Rejuvenate.special = types.MethodType(rejuvenateSpecial, Rejuvenate)

def phoenixSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.lastAction == "Revive":
        say(f"{Color['yellow']}Phoenix Blessing Triggered! {afflicted.name} Lost All Of Their Negative Statuses!{Color['reset']}")
        self.remove(afflicted, full=True)
        for status in afflicted.statusList[:]:
            if status.align == "Negative":
                status.remove(afflicted, full=True)
        heal = round(afflicted.maxHealth * 0.75)
        afflicted.health = heal
        say(f"{Color['green']}{afflicted.name}s Health Was Set To {heal} Due {self.name}!{Color['reset']}")
Phoenix = Status("Phoenix Blessing", "Other", 1, ["Special"], "Neutral",
                 "If health reaches 0, cannot act that action, remove self, remove all Negative statuses, and restore health (75% of Max Health). Last forever.",
                 forever=True)
Phoenix.special = types.MethodType(phoenixSpecial, Phoenix)

##--Debuffs--##
Husk = Status("Husk", "Other", 3, ["Damage"], "Negative",
                  "Drains mana (2% of Max Mana + 1-3). Last 3 actions.",
                  meter="mana", damage=[[["maxMana", 2]], lambda: random.randint(1,3), 1])

CollapsingHusk = Status("Collapsing Husk", "Other", 3, ["Damage", "Debuff"], "Negative",
                        "Lower Resistance/Speed by 10/5. Drains mana (5% of Max Mana + 25% of Magic). Last 3 actions.",
                        mutate=[["resistance", -10], ["speed", -5]], meter="mana", damage=[[["maxMana", 5], ["magic", 25]], 0, 1])

def weakSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if hasattr(afflicted, "ultimateMeter"):
        afflicted.ultimateMeter = max(0, afflicted.ultimateMeter - 15)
        say(f"{Color['magenta']}{afflicted.name}s Ultimate Meter Was Reduced By 15!{Color['reset']}")

    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By 5!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 15!{Color['reset']}")
Weak = Status("Weak", "Other", 3, ["Special"], "Negative",
              "Lower Speed/Hit by 5/15. Drain Ultimate Meter (15 points!). Last 3 actions",
              mutate=[["speed", -5], ["hit", -15]])
Weak.special = types.MethodType(weakSpecial, Weak)

def illSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    for status in afflicted.statusList:
        if status.align == "Negative" and status.name != "Ill" and random.randint(1,100) >= 50:
                status.duration -= 1
                if status.duration < 0:
                    status.duration = 0
                say(f"{Color['magenta']}{status.name} Had Its Duration Extended By {self.prolong}!{Color['reset']}")
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By 3!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Resistance Was Reduced By 3!{Color['reset']}")
    
    if self.stacks == self.maxStack:
        self.remove(afflicted, full=True)
        for status in afflicted.statusList:
            if status.align == "Negative":
                status.duration = 0
                say(f"{Color['magenta']}{status.name} Had Its Duration Set To 0!{Color['reset']}")
Ill = Status("Ill", "Other", 3, ["Special"], "Negative",
             "Lowers Defense/Resistance by 3. Chance to extend the duration of all Negative statuses by 1. At max stacks, remove self and reset all Negative statuses duration to 0. Last 3 actions and stacks up to 5.",
             canStack=True, maxStack=5, scaleWithStacks=False, mutate=[["defense", -3], ["resistance", -3]])
Ill.special = types.MethodType(illSpecial, Ill)

Stun = Status("Stun", "Other", 2, ["Special", "Stun"], "Negative",
              "Cannot act while this status is present. Last 2 actions.")

# Frail Sub-Family
FrailI = Status("Frail I", "Other", 2, ["Debuff"], "Negative",
                "Lower Defense/Resistance by 3. Last 2 actions.",
                mutate=[["defense", -3], ["resistance", -3]])

FrailII = Status("Frail II", "Other", 2, ["Debuff"], "Negative",
                "Lower Defense/Resistance by 6. Last 2 actions.",
                mutate=[["defense", -6], ["resistance", -6]], noCoexist=["Frail I"])

FrailIII = Status("Frail III", "Other", 4, ["Debuff"], "Negative",
                "Lower Defense/Resistance by 9. Last 4 actions.",
                mutate=[["defense", -9], ["resistance", -9]], noCoexist=["Frail I", "Frail II"])

def fragileInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        increase = (0.3 + 0.05 * self.stacks)
        damage += round(damage * increase)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['yellow']}{afflicted.name}s Fragile Triggered! Damage Was Increased By {round(increase * 100)}%!{Color['reset']}")
    return damage
Fragile = Status("Fragile", "Other", 1, ["Special"], "Negative",
                    "Increase damage taken by the next attack or damaging skill used by the opposer by 30% + 5% per stack. If the opposer used an attack or damaging skill, lose 1 stack. Last forever and stacks up to 5.",
                    forever=True, canStack=True, maxStack=5)
Fragile.special = types.MethodType(profraSpecial, Fragile)
Fragile.damageInterupt = types.MethodType(fragileInterupt, Fragile)

# Cripple Sub-Family
CrippleI = Status("Cripple I", "Other", 3, ["Debuff"], "Negative",
                "Lower Strength/Magic by 3. Last 3 actions.",
                mutate=[["strength", -3], ["magic", -3]])

CrippleII = Status("Cripple II", "Other", 3, ["Debuff"], "Negative",
                "Lower Strength/Magic by 6. Last 3 actions.",
                mutate=[["strength", -6], ["magic", -6]], noCoexist=["Cripple I"])

CrippleIII = Status("Cripple III", "Other", 4, ["Debuff"], "Negative",
                "Lower Strength/Magic by 9. Last 4 actions.",
                mutate=[["strength", -9], ["magic", -9]], noCoexist=["Cripple I", "Cripple II"])

# Slow Sub-Family
SlowI = Status("Slow I", "Other", 3, ("Debuff",), "Negative",
              "Lowers Speed by 10. Last 3 actions.",
              mutate=[["speed", -10]])

SlowII = Status("Slow II", "Other", 2, ["Debuff"], "Negative",
              "Lowers Speed by 15. Last 2 actions.", 
              mutate=[["speed", -15]], noCoexist=["Slow I"])

# Bind Sub-Family 
BindI = Status("Bind I", "Other", 3, ("Debuff",), "Negative",
              "Lowers Hit/Speed by 15/5. Last 3 actions.",
              mutate=[["hit", -15], ["speed", -5]])

BindII = Status("Bind II", "Other", 3, ("Debuff",), "Negative",
              "Lowers Hit/Speed by 30/10. Last 3 actions.",
              mutate=[["hit", -30], ["speed", -10]], noCoexist=["Bind I"])

# Shift Sub-Family
shiftNoCoexist = [
    "Wind Shift", "Thunder Shift", "Fire Shift",
    "Ice Shift", "Mighty Shift", "Physical Shift"]

WindShift = Status("Wind Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Wind Resist/Reflect/Absorb into Neutral.",
                   shift=[["wind", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Wind Shift"])

ThunderShift = Status("Thunder Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Thunder Resist/Reflect/Absorb into Neutral.",
                   shift=[["thunder", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Thunder Shift"])

FireShift = Status("Fire Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Fire Resist/Reflect/Absorb into Neutral.",
                   shift=[["fire", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Fire Shift"])

IceShift = Status("Ice Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Ice Resist/Reflect/Absorb into Neutral.",
                   shift=[["ice", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Ice Shift"])

MightyShift = Status("Mighty Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Mighty Resist/Reflect/Absorb into Neutral.",
                   shift=[["mighty", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Mighty Shift"])

PhysicalShift = Status("Physical Shift", "Other", 3, ["Shift"], "Negative",
                   "Change Physical Resist/Reflect/Absorb into Neutral.",
                   shift=[["physical", ["Resist", "Reflect", "Absorb"], "Neutral"]],
                   noCoexist=[s for s in shiftNoCoexist if s != "Physical Shift"])

# Prone Sub-Family
def proneInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        if opposer.lastAction == "Skill" and opposer.lastSkill.element in self.shift[0]:
            damage += round(damage * 0.15)
            say(f"{Color[self.shift[1]]}{afflicted.name}s {self.name} Triggered! Damage Was Increased By 15%!{Color['reset']}")
    return damage

WindProne = Status("Wind Prone", "Other", 3, ["Special"], "Negative",
                   "If opposer uses a Wind element skill, increase damage by 15%. Last 3 actions",
                   shift=[["wind"], "green"])
WindProne.damageInterupt = types.MethodType(proneInterupt, WindProne)

IceProne = Status("Ice Prone", "Other", 3, ["Special"], "Negative",
                   "If opposer uses a Ice element skill, increase damage by 15%. Last 3 actions",
                   shift=[["ice"], "cyan"])
IceProne.damageInterupt = types.MethodType(proneInterupt, IceProne)

FireProne = Status("Fire Prone", "Other", 3, ["Special"], "Negative",
                   "If opposer uses a Fire element skill, increase damage by 15%. Last 3 actions",
                   shift=[["fire"], "red"])
FireProne.damageInterupt = types.MethodType(proneInterupt, FireProne)

ThunderProne = Status("Thunder Prone", "Other", 3, ["Special"], "Negative",
                   "If opposer uses a Thunder element skill, increase damage by 15%. Last 3 actions",
                   shift=[["thunder"], "yellow"])
ThunderProne.damageInterupt = types.MethodType(proneInterupt, ThunderProne)

##--Burn Family--##
Burn = Status("Burn", "Burn", 3, ["Damage"], "Negative",
              "Deals damage (3% of Max Health + 1-3 x stack). Last 3 actions and stacks up to 5.",
              canStack=True, maxStack=5, damage=[[["maxHealth", 3]], lambda: random.randint(1,3), 1])

Scorch = Status("Scorch", "Burn", 5, ["Prolonger"], "Negative",
                "Chance (65%) to extend other Burn statuses duration by 2. Last 5 actions.",
                chanceToProlong=65, prolong=2)

Volcanic = Status("Volcanic", "Burn", 2, ["Damage"], "Negative",
                  "Deals damage (10% of Max Health + 6-9). Lowers Defense by 6.",
                  damage=[[["maxHealth", 10]], lambda: random.randint(6, 9), 1], mutate=[["defense", -6]])

Heated = Status("Heated", "Burn", 2, ["Damage", "Debuff"], "Negative",
                "Deals damage (2% of Max Health + 25% of Strength + 1-4 x stack). Lowers Defense by 3 + 1 per stack. Transforms into Volcanic at max stacks. Last 2 actions and stacks up to 3.",
                canStack=True, maxStack=3, damage=[[["maxHealth", 2], ["strength", 25]], lambda: random.randint(1,4), 1], mutate=[["defense", -3]], transform=Volcanic) 

def searSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = 0
    
    burn = False
    bleed = False
    for status in afflicted.statusList:
        if status.family == "Burn":
            burn = True
        
        elif status.family == "Bleed":
            bleed = True

    if burn and bleed:
        damage = round(afflicted.maxHealth * 0.03 + random.randint(1, 3)) * 3
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    else:
        damage = round(afflicted.maxHealth * 0.03 + random.randint(1, 3))
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Sear = Status("Sear", "Burn", 3, ["Special", "Damage"], "Negative",
                "Deals daamge (3% of Max Health + 1-3). If a Burn and Bleed status are present, increase damage (3x!). Last 3 actions.")
Sear.special = types.MethodType(searSpecial, Sear)

def moltenSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.04 + random.randint(1, 3) + afflicted.strength * 0.75)
    if any("Volcanic" == s.name for s in afflicted.statusList):
        damage *= 2
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Molten = Status("Molten", "Burn", 3, ["Special", "Damage"], "Negative",
                "Deals damage (75% of Strength + 4% of Max Health). Increased damage (2x!) if Volcanic is present. Last 3 actions",)
Molten.special = types.MethodType(moltenSpecial, Molten)

def radiantSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.02 + afflicted.baseStrength * 0.25) * self.stacks
    if sum(1 for s in afflicted.statusList if "Burn" == s.family and s.name != "Radiant") >= 2:
        damage *= 2
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Strength Was Reduced By {4 + self.stacks}!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Magic Was Reduced By {4 + self.stacks}!{Color['reset']}")
    
    if self.stacks >= 2:
        for status in afflicted.statusList:
            if status.family == "Burn":
                if not "Special" in status.type_:
                    status.simple(opposer, damage, afflicted)
                else:
                    status.special(opposer, damage, afflicted)
    
    return damage
Radiant = Status("Radiant", "Burn", 2, ["Special", "Damage"], "Negative", 
                 "Deals damage (2% of Max Health + 25% of Base Strength) x stacks. If 2+ Burn statuses are present (excluding Radiant), increase damage (2x!). Lowers Strength/Magic by 4 + 1 per stack. At 2+ stacks, chance to retrigger 2 Burn statuses. Last 2 actions and stacks up to 4.",
                 canStack=True, maxStack=4, mutate=[["strength", -4], ["magic", -4]])
Radiant.special = types.MethodType(radiantSpecial, Radiant)

def frenziedSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.strength * 0.25 + afflicted.magic * 0.40)
    for status in afflicted.statusList:
        if status.name == "Madness":
            damage *= 2
            status.remove(afflicted)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} Health Damage From {self.name}!{Color['reset']}")
    
    return damage
FrenziedFlames = Status("Frenzied Flames", "Burn", 3, ["Special", "Damage"], "Negative",
                        "Deal damage (25% of Strength + 40% of Magic). If Madness is present, increase damage (2x!) and remove 1 stack of Madness. Last 3 actions.",
                        mutate=[["strength", -5]])
FrenziedFlames.special = types.MethodType(frenziedSpecial, FrenziedFlames)

def scaldSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    for status in afflicted.statusList[:]:
        if status.name in ["Burn", "Heated", "Hemorrhage"]:
            Status.allStatuses[status.name].inflict(afflicted)
            
            if random.randint(1, 100) >= 68:
                retrigger = next(s for s in afflicted.statusList if s.name in ["Burn", "Heated", "Hemorrhage"])
                if "Special" in retrigger.type_:
                    retrigger.special(afflicted, damage, opposer)
                else:
                    retrigger.simple(afflicted)
Scald = Status("Scald", "Burn", 3, ["Special"], "Negative", 
               "While present, Burn/Heated/Hemorrhage gain 1 stack (if already present). Chance to retrigger 1 of Burn/Heated/Hemorrhage.")
Scald.special = types.MethodType(scaldSpecial, Scald)

def willowSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(self.stacks * 2 + afflicted.magic * 0.1)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} Health Damage From {self.name}!{Color['reset']}")
WillowWisp = Status("Willow Wisp", "Burn", 2, ["Special"], "Negative",
                    "Deal damage (stacks x 2 + 10% of Magic). Last 2 actions and stacks up to 99.",
                    canStack=True, maxStack=99)
WillowWisp.special = types.MethodType(willowSpecial, WillowWisp)

##--Chill Family--##
def freezeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if hasattr(afflicted, "ultimateMeter"):
        afflicted.ultimateMeter = max(0, afflicted.ultimateMeter - 5)
        say(f"{Color['magenta']}{afflicted.name}s Ultimate Meter Was Reduced By 5!{Color['reset']}")
    else:
        skills = afflicted.skills[:]
        random.shuffle(skills)
        for skill in skills:
            if skill.usable == False and not "Passive" in skill.type_:
                skill.cooldownProgress = max(0, skill.cooldownProgress - 1)
                say(f"{Color['magenta']}{afflicted.name}s {skill.name} Had Its Cooldown Extended By 1!{Color['reset']}")
                break
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Magic Was Reduced By 2!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Resistance Was Reduced By 3!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By 5!{Color['reset']}")
Freeze = Status("Freeze", "Chill", 3, ["Special"], "Negative",
    "Lower Magic/Resistance/Speed by 2/3/5. If Enemy; Lower Ultimate Meter by 5. If Player; Extend the cooldown of 1 unusable skill by 1 action. Last 3 actions.",
    mutate=[["magic", -2], ["resistance", -3], ["speed", -5]])
Freeze.special = types.MethodType(freezeSpecial, Freeze)

def deepFreezeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if (opposer.lastSkill and "Damage" in opposer.lastSkill.type_ and opposer.lastSkill.element in ["thunder", "fire"]) and (opposer.lastAction and opposer.lastAction == "Skill"):
        damage = round(afflicted.resistance * 0.60 + random.randint(1,4))
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
        
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Resistance Was Reduced By 6!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By 5!{Color['reset']}")
DeepFreeze = Status("Deep Freeze", "Chill", 1, ["Special", "Stun"], "Negative",
    "Lower Resistance/Speed by 6/5. Cannot act while this status is present. If opposer used a Fire or Thunder skill, deal damage (60% of Resistance + 1-4). Last 1 action.",
    mutate=[["resistance", -6], ["speed", -5]])
DeepFreeze.special = types.MethodType(deepFreezeSpecial, DeepFreeze)

def absolouteZeroSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.resistance * 0.5) * random.randint(1,3)
    bonus = 0
    for status in afflicted.statusList:
        if status.family == "Chill":
            bonus += 0.15
    if bonus:
        damage += round(damage * bonus)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
AbsoluteZero = Status("Absolute Zero", "Chill", 3, ["Special", "Damage"], "Negative",
    "Deals damage (50% of Resistance  x 1-3). Increased damage (15% for each Chill status present). Last 3 actions.")
AbsoluteZero.special = types.MethodType(absolouteZeroSpecial, AbsoluteZero)

def frostbiteSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if hasattr(afflicted, "ultimateMeter"):
        afflicted.ultimateMeter = max(0, afflicted.ultimateMeter - (5 + self.stacks))
        say(f"{Color['magenta']}{afflicted.name}s Ultimate Meter Was Reduced By {5 + self.stacks}!{Color['reset']}")
    else:
        skills = afflicted.skills[:]
        random.shuffle(skills)
        for skill in skills:
            if skill.usable == False and not "Passive" in skill.type_:
                skill.cooldownProgress = max(0, skill.cooldownProgress - (1 + self.stacks))
                say(f"{Color['magenta']}{afflicted.name}s {skill.name} Had Its Cooldown Extended By {1 + self.stacks}!{Color['reset']}")
                break

    damage = round((afflicted.resistance * 0.25 + afflicted.magic * 0.25) * self.stacks)
    if sum(1 for status in afflicted.statusList if status.name != "Frostbite" and status.family == "Chill") >= 2:
        damage += round(damage * 0.5)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Frostbite = Status("Frostbite", "Chill", 2, ["Special", "Damage"], "Negative",
    "Deals damage (25% of Resistance + 25% of Magic) x stacks. If 2+ Chill statuses (excluding Frostbite), increase damage (50%!). If Enemy; Lower Ultimate Meter by 5 + stacks. If Player; Extend 1 unusable skill's cooldown by 1 + stacks. Last 2 actions and stacks up to 5.",
    canStack=True, maxStack=5)
Frostbite.special = types.MethodType(frostbiteSpecial, Frostbite)

def iceVeinsSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.lastAction and afflicted.lastAction == "Skill":
        for skill in afflicted.skills:
            if skill.onCooldown: skill.cooldownProgress -= 1
IceVeins = Status("Ice Veins", "Chill", 3, ["Special"], "Negative",
    "Lower Magic by 8. If a skill is used, extend cooldown for each skill on cooldown by 1. Last 3 actions.",
    mutate=[["magic", -8]])
IceVeins.special = types.MethodType(iceVeinsSpecial, IceVeins)

def frigidSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By {5 + (self.stacks * 2)}!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By {5 + (self.stacks * 2)}!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Resistance Was Reduced By {7 + (self.stacks * 2)}!{Color['reset']}")
    
    if self.stacks == self.maxStack:
        self.remove(afflicted, full=True)
        Frostbite.inflict(afflicted, 3)
        Freeze.inflict(afflicted)
Frigid = Status("Frigid", "Chill", 2, ["Special"], "Negative",
                "Lowers Speed/Defense/Resistance by 5/5/7 + 2 per stack. Transforms into max stacks of Frostbite/Freeze at max stacks. Last 2 actions and stacks up to 6.",
                canStack=True, maxStack=6, stackScale=2, mutate=[["speed", -5], ["defense", -5], ["resistance", -7]])
Frigid.special = types.MethodType(frigidSpecial, Frigid)

def glintSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(self.stacks + afflicted.magic) * round(self.stacks * 0.5)
    if any(s.name in ["Freeze", "Deep Freeze", "Lunar Bind"] for s in afflicted.statusList):
        damage += round(damage * 0.35)
        self.inflict(afflicted)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.simple(afflicted)
Glint = Status("Glint", "Chill", 2, ["Special", "Damage", "Debuff"], "Negative",
               "Deal damage (stacks + Magic) x half of stacks. Lowers Hit/Speed by 10/5 + 2 per stack. If Freeze/Deep Freeze/Lunar Bind are present, gain 1 stack and increase damage (35%!). Last 2 actions and stacks up to 8.",
               canStack= True, maxStack=8, stackScale=2, mutate=[["hit", -10], ["speed", -5]])
Glint.special = types.MethodType(glintSpecial, Glint)

##--Shock Family--##
Shock = Status("Shock", "Shock", 2, ["Buff"], "Positive",
               "Raise Speed by 5 + 2 per stack. Last 2 actions and stacks up to 4.",
               canStack=True, maxStack=4, stackScale=2, mutate=[["speed", 5]])

Overload = Status("Overload", "Shock", 4, ["Damage", "Buff"], "Positive",
                  "Deals damage (30% of Speed + 1-3 x stack). Raise Speed by 10 + 2 per stack. Last 4 actions and stacks up to 5.",
                  canStack=True, maxStack=5, stackScale=2, mutate=[["speed", 10]], damage=[[["speed", 30]], lambda: random.randint(1,3), 1])

def energeticSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    number = 1
    for status in afflicted.statusList:
        if status.family == "Shock" and status.name != "Energetic":
            number += 1
    
    damage = round(afflicted.speed * 0.40) * number
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By 20!{Color['reset']}")
    
    return damage
Energetic = Status("Energetic", "Shock", 4, ["Special"], "Positive",
                   f"Deals damage (40% of Speed * number of Shock statuses present). Raise Hit/Speed by 20. Transforms into Slow I on end.",
                   mutate=[["hit", 20], ["speed", 20]], transform=SlowI)
Energetic.special = types.MethodType(energeticSpecial, Energetic)

ShortCircuit = Status("Short Circuit", "Shock", 2, ["Buff"], "Positive",
               "Raise Speed by 10 + 2 per stack. Lowers Strength/Magic by 2 + 2 per stack. Last 2 actions and stacks up to 5.",
               canStack=True, maxStack=5, stackScale=2, mutate=[["speed", 10], ["strength", -2], ["magic", -2]])

def chargeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks >= 11:
        over = self.stacks - 11
        speedBoost = 0
        for i in range(0, over):
            speedBoost += 5
        afflicted.speedMeter += speedBoost
        say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By {speedBoost}!{Color['reset']}")
    
    if self.stacks >= 15:
        shock = sum(1 for s in afflicted.statusList if s.family == "Shock")
        if shock:
            speedBoost = 0
            for i in range(0, shock):
                speedBoost += 3
            afflicted.speedMeter += speedBoost
            say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By {speedBoost}!{Color['reset']}")
            
            damage = round(afflicted.speed * 0.25 * shock)
            afflicted.health -= damage
            say(f"{Color['red']}Took {damage} From {self.name}!{Color['reset']}")
        
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {setS[1] + (2 * self.stacks)}!{Color['reset']}")
Charge = Status("Charge", "Shock", 2, ["Special", "Buff"], "Positive",
                "Raise Strength/Speed/Luck by 2/2/10 + 1 per stack. If stack is at 11+, raise Speed Meter (5 per stack per over 11). If stack is at 15+, for every Shock status present, raise Speed Meter by 3 and deal damage (25% of Speed x number of Shock statuses). Last 2 actions and stacks up to 20.",
                canStack=True, maxStack=20, mutate=[["strength", 2], ["speed", 2], ["luck", 10]])
Charge.special = types.MethodType(chargeSpecial, Charge)

def staticSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    for status in afflicted.statusList:
        if status.family == "Shock":
            status.duration -= 1
            say(f"{Color['magenta']}{status.name} Had Its Duration Extended By 1!{Color['reset']}")
            if status.canStack:
                status.stacks += 1
    
    damage = round(afflicted.speed * 0.35 * 2)
    afflicted.health -= damage
    say(f"{Color['red']}Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Static = Status("Static", "Shock", 4, ["Special", "Damage"], "Positive",
                "Deal damage (35% of Speed x 2). Extend other Shock statuses duration by 1 and gain 2 stacks if possiable. Last 4 actions.")
Static.special = types.MethodType(staticSpecial, Static)

def sparkSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = 10 + 2 * self.stacks + round(afflicted.speed * 0.15)
    shocks = sum(1 for s in afflicted.statusList if s.family == "Shock")
    damage *= shocks
    afflicted.health -= damage
    say(f"{Color['red']}Took {damage} From {self.name}!{Color['reset']}")
    
    Spark.inflict(afflicted, shocks)
    if any(s.name == "Static" for s in afflicted.statusList):
        Spark.inflict(afflicted, 3)
Spark = Status("Spark", "Shock", 2, ["Special", "Damage"], "Negative",
               "Deal damage (10 + 2 per stack + 15% of Speed) x number of Shock statuses. For each Shock status present, gain 1 stack of Spark. If Static is present, gain 3 stacks of Spark. Last 2 actions and stacks up to 30.",
               canStack=True, maxStack=30)
Spark.special = types.MethodType(sparkSpecial, Spark)

def hasteInterupt(self, afflicted: Player | Enemy, speed=1):
    remain = 0.15 + 0.05 * self.stacks
    speed += round(speed * remain)
    return speed
Haste = Status("Haste", "Shock", 1, ["Special"], "Positive",
              "Increase amount of Speed Meter gained each tick by  each tick by 15% + 5% per stack. Last 1 action and stacks up to 5.",
              canStack=True, maxStack=5)
Haste.speedInterupt = types.MethodType(hasteInterupt, Haste)

def electricSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if any(s.name == "Arc" for s in afflicted.statusList):
        shock_one = next((s for s in afflicted.statusList if s.family == "Shock" and not s.name in ["Arc", "Electric Bridge"]), None)
        shock_two = next((s for s in afflicted.statusList if s.family == "Shock" and (shock_one and s.name != shock_one.name) and not s.name in ["Arc", "Electric Bridge"]), None)
        
        if shock_one and shock_two:
            for status in [shock_one, shock_two]:
                if "Damage" in status.type_:
                    if "Special" not in status.type_:
                        status.simple(afflicted)
                    else:
                        status.special(afflicted, 0, opposer)

                else:
                    afflicted.speedMeter -= 15
                    say(f"{Color['magenta']}{afflicted.name}s Speed Meter Was Reduced By 15!{Color['reset']}")
                
                status.duration -= 1
                say(f"{Color['magenta']}{status.name} Had Its Duration Extended By 1!{Color['reset']}")
    else:
        self.remove(afflicted, full=True)
ElectricBridge = Status("Electric Bridge", "Shock", 1, ["Special"], "Negative",
                        "Based on the 2 oldest Shock statuses present (excluding Arc/Electric Bridge); if status deals non-conditional damage, retrigger status, and if status does not, lower Speed Meter by 15. For 2 oldest Shock statuses present (excluding Arc/Electric Bridge), extend duration by 1. If Arc is not present, remove self. Last forever.")
ElectricBridge.special = types.MethodType(electricSpecial, ElectricBridge)

def arcSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if sum(1 for s in afflicted.statusList if s.family == "Shock" and not s.name in ["Arc", "Electric Bridge"]) >= 2:
        Spark.inflict(afflicted, 2)
        ElectricBridge.inflict(afflicted)
        
        self.simple(afflicted)
    else:
        Spark.inflict(afflicted, 3)
        self.remove(afflicted, full=True)
Arc = Status("Arc", "Shock", 3, ["Special", "Debuff"], "Negative",
             "Lower Speed by 15. If 2+ Shock statuses are not present (excluding Arc/Electric Bridge), remove self and gain 3 stacks of Spark. If 2+ Shock statuses are present (excluding Arc/Electric Bridge), gain 2 stacks of Spark/Electric Bridge. Last 3 actions",
             mutate=[["speed", -15]])
Arc.special = types.MethodType(arcSpecial, Arc)

def loveHateSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    charge = next((s for s in afflicted.statusList if s.name == "Charge"), None)

    if not charge:
        self.remove(afflicted, full=True)
    
    if charge:

        if self.stacks >= 6:
            self.inflict(afflicted)

        if self.stacks >= 10:
            stacks = self.stacks - 10
            self.mutate = [["strength", 12 + stacks], ["magic", 12 + stacks], ["luck", -30 + (stacks * -1)], ["hit", -30 + (stacks * -1)]]
            self.statMutation
            
            charge.remove(afflicted)
            
            if charge.stacks >= 6:
                charge.remove(afflicted)
                self.inflict(afflicted)
LoveHate = Status("Love~Hate", "Shock", 4, ["Special", "Buff", "Debuff"], "Positive",
                  "If Charge is not present, remove self. At 6+ stacks, gain 1 stack. At 10+ stacks, raise Strength/Magic by 12 + 2 per stack above 10, lower Luck/Hit by 30 + 5 per stack above 10, and if Charge is present, lose 1 stack of Charge and if Charge is at 6+ stacks, lose 1 stack of Charge and gain 1 stack of Love~Hate. Last 4 actions and stacks up to 12.",
                  canStack=True, maxStack=12, scaleWithStacks=False)
LoveHate.special = types.MethodType(loveHateSpecial, LoveHate)

##--Bleed Family--##
Bleed = Status("Bleed", "Bleed", 5, ["Damage"], "Negative",
               "Deals damage (5% of Max Health + 1-4). Last 5 actions.",
               damage=[[["maxHealth", 5]], lambda: random.randint(1,4), 1])

def gashSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.05 + random.randint(1,2))
    for status in afflicted.statusList:
        if status.family == "Bleed" and status.name != "Gash":
            damage += round(damage * 0.45)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Gash = Status("Gash", "Bleed", 5, ["Special", "Damage"], "Negative",
              "Deals damage (5% of Max Health + 1-2). Deals an extra 45% of damage for each Bleed status (excluding self). Last 5 actions.")
Gash.special = types.MethodType(gashSpecial, Gash)

def woundSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = 0
    amount = 0
    removeList = []
    for status in afflicted.statusList[:]:
        if status.family == "Bleed" and status.name != "Wound":
            amount += 1
            removeList.append(status)
        
    if amount > 0:
        damage = (round(afflicted.maxHealth * 0.1) + 5) * amount
        say(f"{Color['red']}Wound Was Triggered! {afflicted.name} Took {damage}!{Color['reset']}")
        afflicted.health -= damage
        FrailII.inflict(afflicted)
        
        for status in removeList:
            status.remove(afflicted, full=True)
        
    return damage
Wound = Status("Wound", "Bleed", 1, ["Special", "Damage"], "Negative",
                 "If 1+ Bleed statuses are present, consume them and deal damage (10% of Max Health + 5) x number of Bleed statuses and inflict Frail II. Last 1 action.")
Wound.special = types.MethodType(woundSpecial, Wound)

def clotSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = 0
    if self.duration == 0:
        self.count = 0
    
    self.count += round(afflicted.maxHealth * 0.03) + 15

    if self.duration == self.maxDuration - 1:
        afflicted.health -= self.count
        say(f"{Color['red']}{afflicted.name} Took {self.count} From {self.name}!{Color['reset']}")
        self.remove(afflicted, full=True)
    
    return damage
Clot = Status("Clot", "Bleed", 3, ["Special"], "Negative",
              "Builds up damage (3% of Max Health + 15) per action. On status end, deal built up damage. Last 3 actions",)
Clot.special = types.MethodType(clotSpecial, Clot); Clot.count = 0

def punctureSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    number =0 
    for status in afflicted.statusList:
        if status.family == "Bleed" and status.name != "Puncture" and random.randint(1,100) >= 50:
            status.duration = 0
            number += 1

    damage = (number + random.randint(1,3)) * number
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By 5!{Color['reset']}")
    
    return damage
Puncture = Status("Puncture", "Bleed", 3, ["Special", "Damage"], "Negative",
              "Deals damage (number of Bleed statuses (including self) + 1-3) x number of Bleed statuses (including self). Lowers Defense by 5. Chance to reset Bleed statuses (15% for each status). Last 3 actions.",
              mutate=[["defense", 5]])
Puncture.special = types.MethodType(punctureSpecial, Puncture)

def splitSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.01 + afflicted.speed * 0.5)
    if any("Hemorrhage" == s.name and s.stacks >= 5 for s in afflicted.statusList):
        damage *= 2
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Speed Was Reduced By 5!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By 2!{Color['reset']}")
Split = Status("Split", "Bleed", 3, ["Special", "Damage"], "Negative",
               "Deals damage (1% of Max Health + 50% of Speed). Lowers Speed/Defense by 5/2. If Hemorrhage is present and it is at 5+ stacks, extend Split's duration by 1 and increase damage (2x!). Last 3 actions.",
                mutate=[["speed", 5], ["defense", 3]])
Split.special = types.MethodType(splitSpecial, Split)

def hemorrhageSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.01 + random.randint(2,4)) * self.stacks
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")

    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By {3 + self.stacks}!{Color['reset']}")
    
    return damage
Hemorrhage = Status("Hemorrhage", "Bleed", 3, ["Special", "Damage"], "Negative",
               "Deals damage (1% of Max Health + 2-4) x stack. Lowers Defense by 5 + 1 per stack. Last 3 actions and stacks up to 10.",
               canStack=True, maxStack=10, mutate=[["defense", -10]])
Hemorrhage.special = types.MethodType(hemorrhageSpecial, Hemorrhage)

##--Poison Family--##
def poisonSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    damage = round(afflicted.maxHealth * 0.03 + random.randint(1, 3) + (self.count * 2))
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Poison = Status("Poison", "Poison", 5, ["Special", "Damage"], "Negative",
                "Deals damage (3% of Max Health + 1-3 + count (turns active) x 2). Last 5 actions.")
Poison.special = types.MethodType(poisonSpecial, Poison); Poison.count = 0

def deadlyPoisonSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    damage = round(afflicted.maxHealth * 0.01 + random.randint(1, 2) + self.count + self.stacks) * 2
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(setS[1] + (1 * self.stacks))}!{Color['reset']}")
DeadlyPoison = Status("Deadly Poison", "Poison", 3, ["Special", "Damage"], "Negative",
                      "Deal damage (1% of Max Health + 1-2 + count (turns active) + stacks) x 2. Lowers Speed/Hit by 5/15 + 1 per stack. Lst 3 actions and stacks up to 20.",
                      canStack=True, maxStack=20, mutate=[["speed", -5], ["hit", -15]])
DeadlyPoison.special = types.MethodType(deadlyPoisonSpecial, DeadlyPoison); DeadlyPoison.count = 0

def maggotsSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    if any(s for s in afflicted.statusList if s.family == "Poison"):
        counts = sum(s.count for s in afflicted.statusList if s.family == "Poison" and s.name != "Deadly Poison")
        damage = (5 + counts) * self.stacks
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
        
        restore = (20 + counts )* self.stacks
        opposer.health += min(restore, opposer.maxHealth - opposer.health)
        say(f"{Color['green']}{opposer.name}s Health Was Restored By {restore} From {self.name}!{Color['reset']}")
    else:
        self.remove(afflicted, full=True)
Maggots = Status("Maggots", "Poison", 1, ["Special"], "Negative",
                 "Deals damage (5 + count (turns active) of all Poison statuses) x stacks. Restore health (20 + count of all Poison statuses) x stacks to the opposer. if no other Poison statuses are present, remove self. Last forever and stacks up to 5.",
                 forever=True, canStack=True, maxStack=5)
Maggots.special = types.MethodType(maggotsSpecial, Maggots); Maggots.count = 0

def venomSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    counts = 0
    for status in afflicted.statusList:
        if status.family == "Poison" and status.name != "Venom":
            counts += status.count

    damage = round(afflicted.maxHealth * 0.03 + random.randint(1, 2) + (self.count * 2) + counts)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Venom = Status("Venom", "Poison", 3, ["Special", "Damage"], "Negative",
                "Deals damage (3% of Max Health + 1-2 + count (turns active) x 2 + other Poison statuses count). Last 3 actions.")
Venom.special = types.MethodType(venomSpecial, Venom); Venom.count = 0

def plagueSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    for status in afflicted.statusList:
        if status.family == "Poison" and status.name != "Plague":
            status.count += 2
            say(f"{Color['magenta']}{status.name}s Count Was Increased By 2 Due To {self.name}!{Color['reset']}")
Plague = Status("Plague", "Poison", 3, ["Special"], "Negative",
                "Increase other Poison statuses count (turns active) by 2 each turn (excluding self). Last 3 actions.")
Plague.special = types.MethodType(plagueSpecial, Plague); Plague.count = 0

def infectionSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    for status in afflicted.statusList:
        if status.align == "Negative" and status.family == "Poison" and status.name != "Infection":
            status.count += 1
            say(f"{Color['magenta']}{status.name}s Count Was Increased By 1 Due To {self.name}!{Color['reset']}")
        
        elif status.align == "Negative" and not status.family == "Poison" and status.name != "Infection":
            status.duration -= 1
            if status.duration < 0:
                status.duration = 0
            say(f"{Color['magenta']}{status.name} Had Its Duration Extended By {self.prolong}!{Color['reset']}")
Infection = Status("Infection", "Poison", 2, ["Special"], "Negative",
                   "Extend Negative statuses duration by 1. Increase other Poison statuses count (turns active) by 1 (excluding self). Last 2 actions.",)
Infection.special = types.MethodType(infectionSpecial, Infection); Infection.count = 0

def rotSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    amount = 0
    self.count += 1
    for status in afflicted.statusList:
        if status.family == "Poison" and status.name != "Rot":
            status.count += 1
            amount += 1
    
    damage = abs((self.count + amount) * self.duration)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
# Rot Gets Stronger The Closer Rot Is To Finishing | Don't know if it should use others counts
Rot = Status("Rot", "Poison", 5, ["Special", "Damage"], "Negative",
             "Deal damage (count (turns active)  +  number of other Poison statuses) x duration. Increase other Poison statuses count by 1 (excluding self). Last 5 actions.",)
Rot.special = types.MethodType(rotSpecial, Rot); Rot.count = 0

def blightSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = round(afflicted.maxHealth * 0.02 + random.randint(1,3)) * ((1 + sum(status.count for status in afflicted.statusList if hasattr(status, "count") and status.family == "Poison")) // 2)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    for status in afflicted.statusList:
        if status.family == "Poison" and status.name != "Blight":
            status.count = 0
            say(f"{Color['magenta']}{status.name}s Count Was Set To 0 Due To {self.name}!{Color['reset']}")
    
    return damage
Blight = Status("Blight", "Poison", 1, ["Special", "Damage"], "Negative",
                "Deals damage (2% of Max Health + 1-3) x (count (turns active) of all Poison statuses (including Blight) / 2). Sets other Poison statuses count to 0. Transforms into Plague on end. Last 1 action.",
                transform=Plague)
Blight.special = types.MethodType(blightSpecial, Blight); Blight.count = 0

def corruptionSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    
    if self.count >= 10:
        afflicted.health -= 100
        say(f"{Color['red']}{afflicted.name} Took 100 From {self.name}!{Color['reset']}")
        self.remove(afflicted, full=True)
        return 
    
    damage = (self.count + random.randint(1,3)) * self.count 
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(setS[1])}!{Color['reset']}")
Corruption = Status("Corruption", "Poison", 3, ["Special", "Damage"], "Negative",
                    "Deals damage (count (turns active) + 1-3) x count. Lowers Defense/Resistance/Speed by 5. At 10+ count, remove self and deal 100 damage. Last 3 actions.",
                    mutate=[["defense", -5], ["resistance", -5], ["speed", -5]])
Corruption.special = types.MethodType(corruptionSpecial, Corruption); Corruption.count = 0

##--Mental Family--##
Tranquil = Status("Tranquil", "Mental", 3, ["Buff", "Sanity"], "Positive",
                  "Raise Hit/Luck/Speed by 10/15/5. Gain 4 sanity each aciton. Last 3 actions",
                  mutate=[["hit", 10], ["luck", 15], ["speed", 5]], sanity=4, sanityCondition=True)

Serenity = Status("Serenity", "Mental", 2, ["Buff", "Sanity"], "Positive",
                  "Raise Luck/Hit by 10 + 5 per stack. Gain 2 + 2 per stack sanity. Last 2 actions and stacks up to 10.",
                  canStack=True, maxStack=10, stackScale=5, mutate=[["luck", 10], ["hit", 10]], sanity=2)

def damageSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = 20 + self.stacks + abs(self.sanity)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")

    afflicted.sanity -= self.stacks
    say(f"{Color['magenta']}{afflicted.name} Lost {self.stacks} Sanity!{Color['reset']}")

    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By {10 + (self.stacks * 2)}!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Luck Was Reduced By {10 + (self.stacks * 2)}!{Color['reset']}")
Down = Status("Down", "Mental", 2, ["Special"], "Negative",
                "Deal damage (20 + stacks + sanity (Positive if Negative)). Lower Hit/Luck by 10 + 2 per stack. Lose stacks sanity. If sanity is below -10, inflict 1 stack of Fragile. Last 2 actions and stacks up to 20.",
                canStack=True, maxStack=20, stackScale=2, mutate=[["hit", -10], ["luck", -10]])

def slugInterupt(self, afflicted: Player | Enemy, speed=1):
    remain = 0.2 + 0.05 * self.stacks
    speed -= round(speed * remain)
    return speed
Slug = Status("Slug", "Mental", 1, ["Special"], "Negative",
              "Decrease amount of Speed Meter gained each tick by 20% + 5% per stack. Last 1 action and stacks up to 5.",
              canStack=True, maxStack=5)
Slug.speedInterupt = types.MethodType(slugInterupt, Slug)

def cloudedCondtion(self, afflicted, damage, opposer):
    if opposer is None:
        return False
    
    if afflicted.hit < opposer.hit:
        return True
    return False
CloudedI = Status("Clouded I", "Mental", 3, ["Debuff", "Sanity"], "Negative",
                  "Lower Hit by 10. If Hit lower than opposers Hit, lose 1 sanity. Last 3 actions.",
                  mutate=[["hit", -10]], sanity=-1, sanityCondition=cloudedCondtion)

CloudedII = Status("Clouded II", "Mental", 3, ["Debuff", "Sanity"], "Negative",
                  "Lower Hit by 20. If Hit lower than opposers Hit, lose 3 sanity. Last 3 actions.",
                  mutate=[["hit", -20]], sanity=-3, sanityCondition=cloudedCondtion, noCoexist=["Clouded I"])

def consumedCondtion(self, afflicted, damage, opposer):
    if afflicted.lastAction == "Miss":
        return True
    return False
Consumed = Status("Consumed", "Mental", 3, ["Debuff", "Sanity"], "Negative",
                  "Raise Luck/Strength/Magic by 15/3/3. Lower Hit by 15. If an attack or skill is used and misses, lose 3 sanity. Last 3 actions.",
                  mutate=[["luck", 15], ["strength", 3], ["magic", 3], ["hit", 15]], sanity=-3, sanityCondition=consumedCondtion)

def burnoutSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    afflicted.speedMeter -= 25
    say(f"{Color['magenta']}{afflicted.name}s Speed Meter Was Reduced By 25!{Color['reset']}")
Burnout = Status("Burnout", "Mental", 2, ["Special", "Stun"], "Negative",
    "Reduce Speed Meter by 25. Cannot act while this status is present. Last 2 actions.")
Burnout.special = types.MethodType(burnoutSpecial, Burnout)

def madnessSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    instance = next(s for s in afflicted.statusList if s.name == self.name)

    afflicted.sanity -= 1 + instance.stacks
    say(f"{Color['magenta']}{afflicted.name} Lost {abs(self.sanity) + instance.stacks} Sanity!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        number = abs(setS[1]) + instance.stacks
        say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(number)}!{Color['reset']}")
    
    if hasattr(afflicted, "mana"):
        damage = round(afflicted.magic * 0.25 + random.randint(1,6))
        afflicted.mana -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} Mana Damage From {self.name}!{Color['reset']}")

    if instance.stacks >= 8 and not any("Frenzied Flames" == s.name for s in afflicted.statusList):
        FrenziedFlames.inflict(afflicted)
Madness = Status("Madness", "Mental", 2, ["Special", "Damage"], "Negative", 
                 "Drains mana (25% of Magic + 1-6). Lower Magic by 3 + 1 per stack. Lose 2 + 1 per stack sanity. If Madness is at 8+ stacks, inflict Frenzied Flames. Last 2 actions and stacks up to 12.",
                 canStack=True, maxStack=12, mutate=[["magic", -3]])
Madness.special = types.MethodType(madnessSpecial, Madness)

Lust = Status("Lust", "Mental", 2, ["Debuff"], "Negative",
              "Lowers Hit/Luck/Strength/Magic by 30/25/3/3. Last 2 actions.",
              mutate=[["hit", -30], ["luck", -25], ["strength", -3], ["magic", -3]], noCoexist=["Charm"])

def charmSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if (afflicted.lastSkill and "Damage" in afflicted.lastSkill.type_) and (afflicted.lastAction and afflicted.lastAction == "Skill") or afflicted.lastAction and afflicted.lastAction == "Attack":
        Charm.inflict(afflicted)
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 20!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Luck Was Reduced By 20!{Color['reset']}")
Charm = Status("Charm", "Mental", 2, ["Special"], "Negative",
               "Lowers Hit/Luck by 20. After attacking/using a damaging skill, gain 1 stack of Charm. At max stacks of Charm, remove self and gain Lust. Last 2 actions and stacks up to 5.",
               canStack=True, maxStack=5, scaleWithStacks=False, mutate=[["hit", -20], ["luck", -20]], transform=Lust)
Charm.special = types.MethodType(charmSpecial, Charm)

def devoidSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.sanity > 0:
        say(f"{Color['yellow']}{afflicted.name} Gained {abs(afflicted.sanity)} Sanity!{Color['reset']}")
        afflicted.sanity -= afflicted.sanity
    elif afflicted.sanity < 0:
        say(f"{Color['magenta']}{afflicted.name} Lost {afflicted.sanity} Sanity!{Color['reset']}")
        afflicted.sanity += afflicted.sanity
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 10!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Luck Was Reduced By 10!{Color['reset']}")
Devoid = Status("Devoid", "Mental", 2, ["Special"], "Negative", 
                "Lowers Hit/Luck by 10. Sanity is reset to 0 each turn. Last 2 actions.",
                mutate=[["hit", -10], ["luck", -10]])
Devoid.special = types.MethodType(devoidSpecial, Devoid)

def avariceSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    say(f"{Color['magenta']}{afflicted.name} Lost 6 Sanity!{Color['reset']}")
    afflicted.sanity -= 6
    
    if (afflicted.health / afflicted.maxHealth) * 100 < (opposer.health / opposer.maxHealth) * 100: 
        afflicted.speedMeter -= 20
        say(f"{Color['magenta']}{afflicted.name}s Speed Meter Was Reduced By 20!{Color['reset']}")
Avarice = Status("Avarice", "Mental", 3, ["Special"], "Negative",
                 "Lose 6 sanity. If health percent is lower than opposers health perccent, lose 20 Speed Meter. Last 3 actions.")
Avarice.special = types.MethodType(avariceSpecial, Avarice)

def engulfedSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    afflicted.sanity -= 2
    say(f"{Color['magenta']}{afflicted.name} Lost 2 Sanity!{Color['reset']}")
    
    if afflicted.sanity >= 5:
        afflicted.sanity -= 5
        say(f"{Color['magenta']}{afflicted.name} Lost 5 Sanity!{Color['reset']}")
    
    if sum(1 for s in afflicted.statusList if s.align == "Negative" and s.family == "Mental") >= 3:
        damage = round(afflicted.magic * 0.4) + abs(afflicted.sanity)
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(setS[1])}!{Color['reset']}")
Engulfed = Status("Engulfed", "Mental", 3, ["Special", "Debuff", "Damage"], "Negative",
                  "Lowers Strength/Magic/Hit by 5/5/25. Lose 2 sanity. If sanity is at 5+, lose 5 sanity. If 3+ Negative Mental statuses are present, deal damage (40% of Magic + sanity (Positive if Negative)). Last 3 actions.",
                  mutate=[["strength", -5], ["magic", -5], ["luck", -25]])
Engulfed.special = types.MethodType(engulfedSpecial, Engulfed)

def moveInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        if opposer.lastAction == "Skill" and opposer.lastSkill.element == "mighty":
            damage += round(damage * 0.15)
            LoveHate.inflict(opposer)
            say(f"{Color['yellow']}{afflicted.name}s Mark of Villaniy Triggered! Damage Was Increased By 15%!{Color['reset']}")
    return damage
MarkOfVillainy = Status("Mark of Villainy", "Mental", 3, ["Sanity"], "Negative",
                        "Lose 2 sanity. If opposer uses a Mighty element skill, inflict 1 stack of Love~Hate and increase damage taken by 15%. Last 3 actions.",
                        sanity=2)
MarkOfVillainy.damageInterupt = types.MethodType(moveInterupt, MarkOfVillainy)

# Sinking Sub-Family
def butterflySpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = (20 + abs(afflicted.sanity)) * self.stacks
    afflicted.health -= damage
    if any(s.name == "Swimmer" for s in afflicted.skills):
        damage -= round(damage * 0.35)
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    if opposer and (opposer.lastAction and opposer.lastAction == "Attack" or opposer.lastAction and opposer.lastAction == "Skill" and opposer.lastSkill and "Damage" in opposer.lastSkill.type_):
        if opposer.lastAction == "Attack" or opposer.lastSkill.sanLean == "Positive":
            opposer.sanity += 1 + self.stacks
            say(f"{Color['yellow']}{opposer.name} Gained {1 + self.stacks} Sanity!{Color['reset']}")
        else: 
            opposer.sanity -= 1 + self.stacks
            say(f"{Color['magenta']}{opposer.name} Lost {1 + self.stacks} Sanity!{Color['reset']}")
    
    afflicted.sanity -= 1 + self.stacks * 2
    say(f"{Color['magenta']}{afflicted.name} Lost {1 + self.stacks * 2} Sanity!{Color['reset']}")
    
    if any(s.name == "Sinking" and s.stacks >= 1 for s in afflicted.statusList):
        next(s for s in afflicted.statusList if s.name == "Sinking").remove(afflicted)
        self.inflict(afflicted)
        if not self.maxStack >= 12:
            self.maxStack += 1
Butterfly = Status("Butterfly", "Mental", 3, ["Special", "Damage"], "Negative",
                   "Deals damage (20 + sanity (Positive if Negative)) x stacks. If opposer attacked or used a damaging skill last action, depending on if it was an attack or a Positive/Negative skill, opposer gains/loses 1 + 1 per stack sanity. Lose 1 + 2 per stack sanity each action. For each stack of Sinking present (once per stack), lose 1 stack of Sinking, increase max stack size by 1 (max of 12), and gain 1 stack. Last 3 actions and stacks up to 5.",
                   canStack=True, maxStack=5)
Butterfly.special = types.MethodType(butterflySpecial, Butterfly)

def delugeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    percent = 0
    for i in range(0, afflicted.sanity, -2):
        if i % -2 == 0:
            percent += 0.1
    for status in afflicted.statusList:
        if status.family == "Mental":
            percent += 0.1
    damage = 30 + round(afflicted.magic * 0.55) 
    if percent > 0:
        damage += round(damage * percent)
    if any(s.name == "Swimmer" for s in afflicted.skills):
        damage -= round(damage * 0.35)
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Deluge = Status("Deluge", "Mental", 3, ["Special", "Damage"], "Negative",
                 "Deal damage (30 + 55% of Magic). Increase damage (10% for -5 sanity) the lower sanity is and for each Mental status. Last 3 actions.",)
Deluge.special = types.MethodType(delugeSpecial, Deluge)

def sinkingSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    afflicted.sanity -= 2 + self.stacks
    percent = 0
    for i in range(0, afflicted.sanity, -5):
        if i % -5 == 0:
            percent += 0.05
        
        if percent >= 0.5:
            percent = 0.5
            break
        
    damage = 15 + round(afflicted.magic * 0.25) * self.stacks
    if percent > 0:
        damage += round(damage * percent)
    if any(s.name == "Swimmer" for s in afflicted.skills):
        damage -= round(damage * 0.35)
    afflicted.health -= damage
    say(f"{Color['magenta']}{afflicted.name} Lost {self.sanity + self.stacks} Sanity!{Color['reset']}")
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    return damage
Sinking = Status("Sinking", "Mental", 6, ["Special", "Damage", "Sanity"], "Negative",
                 "Deal damage (15 + 25% of Magic x stacks). Increase damage (5% for -5 sanity, max 50%). Lose 2 + 1 per stack sanity. Transforms into Deluge at max stacks. Last 6 actions and stacks up to 5.",
                canStack=True, maxStack=5, transform=Deluge, sanity=2)
Sinking.special = types.MethodType(sinkingSpecial, Sinking)

def gloomSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    for status in afflicted.statusList[:]:
        if status.name == "Deluge":
            status.remove(afflicted, full=True)
            Gloom.inflict(afflicted)
        
        elif status.name in ["Sinking", "Butterfly"]:
            status.remove(afflicted)
            if status.stacks <= 0:
                status.remove(afflicted, full=True)
            Gloom.inflict(afflicted)
    
    if opposer.lastAction and opposer.lastAction == "Skill" and opposer.lastSkill and "Damage" in opposer.lastSkill.type_:
        damage = round((damage * 0.5 + abs(afflicted.sanity)) * 1.5)
        if any(s.name == "Swimmer" for s in afflicted.skills):
            damage -= round(damage * 0.35)
        afflicted.health -= damage
        
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
        
    loss = 1 + (2 * self.stacks)
    afflicted.sanity -= loss
    say(f"{Color['magenta']}{afflicted.name} Lost {loss} Sanity!{Color['reset']}")
    
    if self.stacks >= self.maxStack:
        self.remove(afflicted, full=True)
        FrailII.inflict(afflicted)
        CrippleII.inflict(afflicted)
Gloom = Status("Gloom", "Mental", 0, ["Special", "Damage"], "Negative",
               "If Sinking (or any Adjacent statuses) are present, remove that status/lose 1 stack of that status and gain 1 stack of Gloom. If a damaging skill is used by the opposer, deal damage (50% of damage + sanity (turned positive)) x 1.5. Lose 1 + 2 per stack sanity. At max stacks, transform into Frail II/Cripple II. Last foreveer and stacks up to 10.",
               canStack=True, maxStack=10, forever=True)
Gloom.special = types.MethodType(gloomSpecial, Gloom)

##--Class Specific--##

## Lancer Sub-Family 
def stanceMSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    preDamage = 0
    
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Resistance Was Reduced By 6!{Color['reset']}")

    if self.duration == 0:
        return
    
    if damage and damage > 0 and opposer.lastAction == "Skill" and opposer.lastSkill and "Damage" in opposer.lastSkill.type_ and opposer.lastSkill.statsUsed[0] in ["magic", "resistance"]:
        damage = round(damage * 1.5 + afflicted.magic * 0.5)
        opposer.health -= damage
        say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")
        self.remove(afflicted, full=True)
    
    else:
        if opposer.lastAction in ["Skill", "Attack"]:
            afflicted.speedMeter = max(0, afflicted.speedMeter - 20)
            say(f"{Color['magenta']}{afflicted.name}s Speed Meter Was Reduced By 20!{Color['reset']}")
    
    if not preDamage == damage: return damage
StanceM = Status("Stance. M", "Other", 2, ["Special"], "Positive",
                 "Lower Resistance by 6. If opposer uses a Magic skill, remove Stance. M and deal damage (150% of damage taken + 50% of Magic). If damage was not taken, lower Speed Meter by 20. Last 2 actions.",
                 mutate=[["resistance", -6]])
StanceM.special = types.MethodType(stanceMSpecial, StanceM)

def stancePSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    preDamage = damage

    if self.duration == 0:
        return
    
    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Defense Was Reduced By 6!{Color['reset']}")
        
    if damage and damage > 0 and opposer.lastAction == "Skill" and opposer.lastSkill and "Damage" in opposer.lastSkill.type_ and opposer.lastSkill.statsUsed[0] in ["strength", "speed", "defense"]:
        damage = round(damage * 1.5 + afflicted.strength * 0.5)
        opposer.health -= damage
        say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")
        self.remove(afflicted, full=True)
    
    else:
        if opposer.lastAction in ["Skill", "Attack"]:
            afflicted.speedMeter = max(0, afflicted.speedMeter - 20)
            say(f"{Color['magenta']}{afflicted.name}s Speed Meter Was Reduced By 20!{Color['reset']}")
    
    if not preDamage == damage: return damage
StanceP = Status("Stance. P", "Other", 2, ["Special"], "Positive",
                 "Lower Defense by 6. If opposer uses a Physical skill, remove Stance. P and deal damage (150% of damage taken + 50% of Strength). If damage was not taken, lower Speed Meter by 20. Last 2 actions.",
                 mutate=[["defense", -6]])
StanceP.special = types.MethodType(stancePSpecial, StanceP)

Steadfast =  Status("Steadfast", "Other", 5, ["Buff", "Debuff"], "Positive",
                    "Raise Strength/Luck/Hit by 8/30/30. Lowers Defense/Resistance by 5. last 5 actions.",
                    mutate=[["strength", 8], ["luck", 30], ["hit", 30], ["defense", -5], ["resistance", -5]])

# Monk Mental Sub-Family
Peace = Status("Peace", "Mental", 3, ["Buff", "Sanity"], "Positive",
               "Raise Hit/Luck/Magic by 15/10/5 + 1 per stack. Gain 1 + 1 per stack sanity. Last 3 actions and stacks up to 8",
               canStack=True, maxStack=8, sanity=1, mutate=[["hit", 15], ["luck", 10], ["magic", 5]], sanityCondition=True)

# Forlorn Mental Sub-Family
def maniaSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    afflicted.sanity -= self.sanity
    say(f"{Color['magenta']}{afflicted.name} Lost {self.sanity} Sanity!{Color['reset']}")

    damage = round(afflicted.strength * 0.5 + afflicted.magic * 0.5 + abs(afflicted.sanity))
    opposer.health -= damage
    say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")

    self.statMutation(afflicted)
    say(f"{Color['yellow']}{afflicted.name}s Hit Was Increased By 20!{Color['reset']}")
    say(f"{Color['yellow']}{afflicted.name}s Magic Was Increased By 7!{Color['reset']}")
    say(f"{Color['yellow']}{afflicted.name}s Strength Was Increased By 7!{Color['reset']}")
    say(f"{Color['yellow']}{afflicted.name}s Speed Was Increased By 5!{Color['reset']}")
Mania = Status("Mania", "Mental", 3, ["Special"], "Positive",
               "Deal damage (50% of Strength + 50% of Magic + sanity (Positive if Negative)) to opposer. Raise Hit/Strength/Magic/Speed by 20/7/6/5. Lose 5 sanity. Last 3 actions.",
               mutate=[["hit", 20], ["magic", 7], ["strength", 7], ["speed", 5]], noCoexist=["Fear"], sanity=5)
Mania.special = types.MethodType(maniaSpecial, Mania)

def fearSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks >= 5:
        Power.inflict(afflicted)
        Protection.inflict(afflicted)

    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 10!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Luck Was Reduced By 10!{Color['reset']}")
Fear = Status("Fear", "Mental", 3, ["Debuff", "Sanity"], "Negative",
               "Lower Hit/Luck by 10. Lose 2 + 1 per stack sanity. At 5+ stacks, gain 1 stack of Power/Protection. Transforms into Mania at max stacks. Last 3 actions and stacks up to 8.",
               canStack=True, maxStack=8, scaleWithStacks=False, sanity=-2, mutate=[["luck", -10], ["hit", -10]], transform=Mania)
Fear.special = types.MethodType(fearSpecial, Fear)

# Equinox Mental Sub-Family
def equilibriumSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.sanity > 0:
        afflicted.sanity += 1 + self.stacks
        say(f"{Color['yellow']}{afflicted.name} Gained {self.stacks + 1} Sanity!{Color['reset']}")
    elif afflicted.sanity < 0:
        afflicted.sanity -= 1 + self.stacks
        say(f"{Color['magenta']}{afflicted.name} Lost {self.stacks + 1} Sanity!{Color['reset']}")        
    
    self.statMutation(afflicted)
    say(f"{Color['yellow']}{afflicted.name}s Magic Was Increased By {2 + self.stacks}!{Color['reset']}")
Equilibrium = Status("Equilibrium", "Mental", 2, ["Special"], "Positive",
                     "Raise Magic by 2 + 1 per stack. Lose/Gain 1 + 1 per stack sanity depending on if sanity is Negative/Positive. Last 2 actions and stacks up to 10.",
                     canStack=True, maxStack=10, mutate=[["magic", 2]])
Equilibrium.special = types.MethodType(equilibriumSpecial, Equilibrium)

# Daredevil Sub-Family

def riskInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "user":
        increase = 0.1 + (0.05 * self.stacks)
        if afflicted.health <= round(afflicted.maxHealth * 0.3):
            increase += 0.2
        increase = float(str(increase)[:3])
        damage += round(damage * increase)
        self.remove(afflicted)
        say(f"{Color['yellow']}{afflicted.name}s Risk Triggered! Damage Was Increased By {round(increase * 100)}%!{Color['reset']}")
    return damage
def riskSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks > 0:
        afflicted.sanity -= 1 + self.stacks

        if self.stacks >= 4 and afflicted.sanity <= -15:
            afflicted.speedMeter += 25
            say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By 25!{Color['reset']}")
            for status in afflicted.statusList[:]:
                if status.align == "Negative" and random.randint(1, 100) >= 45:
                    status.duration = status.maxDuration 
                    say(f"{Color['green']}{afflicted.name} No Longer Has {status.name}!{Color['reset']}")
                    break

        if afflicted.health <= round(afflicted.maxHealth * 0.30):
            afflicted.speedMeter += 15
            say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By 15!{Color['reset']}")
    else:
        self.remove(afflicted, full=True)
Risk = Status("Risk", "Mental", 3, ["Special", "Debuff", "Buff", "Damage"], "Positive",
              "Increase next damaging skills damage (10% + 5% stack) and lose 1 stack. If Risk is at 4+ stacks and sanity is below -15, raise Speed Meter by 25 and chance to remove 1 Negative status. If health is below 30%, raise Speed Meter by 15 and increase next damaging skills damage (20%!). Lose 2 + 1 per stack sanity. Last forever and stacks up to 12.",
              forever=True, canStack=True, maxStack=12)
Risk.special = types.MethodType(riskSpecial, Risk)
Risk.damageInterupt = types.MethodType(riskInterupt, Risk)

# Tamer Sub-Family

def bondSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    affinity = afflicted.buddy.affinity
    if affinity == "Power":
        self.mutate = [["strength", 4], ["magic", 4]]
        self.stackScale = 2
    elif affinity == "Support":
        self.mutate = [["defense", 6], ["resistance", 6]]
        self.stackScale = 1
    elif affinity == "Utility":
        self.mutate = [["luck", 5], ["hit", 5]]
        self.stackScale = 5
        
    afflicted.buddy.buddyMeter += 10
    say(f"{Color['cyan']}{afflicted.buddy.name} Gained 10 Buddy Meter!{Color['reset']}")
    self.simple(afflicted, damage, opposer)
Bond = Status("Bond", "Other", 1, ["Special", "Buff"], "Neutral",
              "If Power Buddy is equipped, raise Strength/Magic by 4 + 2 per stack. If Support Buddy is equipped, raise Defense/Resistance by 6 + 1 per stack. If Utility Buddy is equipped, raise Luck/Hit by 5 + 5 per stack. If a Buddy is equipped, Buddy gains 10 Buddy Meter. Last forever and stacks up to 5.",
              forever=True, canStack=True, maxStack=5)
Bond.special = types.MethodType(bondSpecial, Bond)

# Thief Sub-Family

StolenGoods = Status("Stolen Goods", "Other", 1, ["Special"], "Neutral",
                     "If battle is a Map battle, increase Coin and Game Points rewarded by 5% per stack and, at a chance of 10% + 2% per 10 points of Luck, gain 1 random item (from a pool) per stack (max 3). Last forever and stacks up to 5.",
                     forever=True, canStack=True, maxStack=5)

##--Boss Only Statuses--##

def windSheerSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if opposer.lastAction == "Skill" and "wind" == opposer.lastSkill.element:
        for i in range (3):
            if self.count == 0:
                self.remove(afflicted, full=True)
                break
            damage = self.stacks * 4
            afflicted.health -= damage
            say(f"{Color['red']}Wind Sheer Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")

            self.count -= 1
            self.stacks = max(1, self.stacks - 1)
def windSheerRemoval(self, target, stacks=1, count=0, full=False):
    if full:
        existing = next((s for s in target.statusList if s.name == self.name), None)
        if existing:
            if existing.canStack and not full:
                removed = min(stacks, existing.stacks)
                existing.stacks = max(0, existing.stacks - stacks)

                if existing.stacks <= 0:
                    target.statusList.remove(existing)

                if "Debuff" in existing.type_ or "Buff" in existing.type_:
                    existing.statMutation(target)

                if removed > 0:
                    say(f"{Color['green']}{target.name} Lost {removed} {'Stacks' if removed > 1 else 'Stack'} Of {self.name}!{Color['reset']}")

                if hasattr(self, "count") and count > 0:
                    say(f"{Color['green']}{target.name} Lost {count} Count Of {self.name}!{Color['reset']}")
                    existing.count -= count
                    if existing.count <= 0:
                        existing.count = 0

            else:
                say(f"{Color['green']}{target.name} Lost {self.name}!{Color['reset']}")
                target.statusList.remove(existing)

                BindII.inflict(target)
                damage = (20 + existing.stacks) * 2
                print(f"{target.name} Took {damage} Damage!{Color['reset']}")
WindSheer = Status("Wind Sheer", "Other", 1, ["Special", "Damage"], "Negative",
                   "If the opposer uses a Wind element skill, deal damage (Wind Sheer stacks x 4). Trigger for the amount of hits taken (triggers up to 3 times, can only be triggered up to amount of count). When triggered, lose 1 count/stack (stack will always be at least 1) per time triggered. When count reaches 0, remove self. On removal, inflict Bind II and deal damage (20 + Wind Sheer stacks) x 2. Last forever and stacks up to 20.",
                   forever=True, canStack=True, maxStack=20)
WindSheer.special = types.MethodType(windSheerSpecial, WindSheer)
WindSheer.remove = types.MethodType(windSheerRemoval, WindSheer)
WindSheer.count = 0

def rawEmbersSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.count += 1
    percent = random.randint(1, 4) / 10
    damage = round(afflicted.maxHealth * percent) + (random.randint(5,10) * self.stacks)

    if self.count % 2 == 0:
        afflicted.health -= damage
        say(f"{Color['red']}Raw Embers Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
RawEmbers = Status("Raw Embers", "Burn", 2, ["Special", "Damage"], "Negative",
                   "Every 2 actions present, deal damage (1-4% of Max Health + (5-10 x stacks)). Last 2 actions and stacks up to 15.",
                   canStack=True, maxStack=15)
RawEmbers.special = types.MethodType(rawEmbersSpecial, RawEmbers); RawEmbers.count = 0

def soulBindSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if opposer.health <= 0:
        afflicted.health = 0
        say(f"{Color['red']}{afflicted.name}s Health Was Set To 0 Due {self.name}!{Color['reset']}")
    self.statMutation(afflicted)
SoulBind = Status("Soul Bind", "Other", 4, ["Special", "Debuff"], "Neutral",
                  "Lowers Luck/Hit/Speed by 15/15/5. While active, after acting, if opposers health is at 0, set health to 0. Last 4 actions.",
                  mutate=[["luck", -15], ["hit", -15], ["speed", -5]])
SoulBind.special = types.MethodType(soulBindSpecial, SoulBind)

def boonSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    amount = 0
    for status in opposer.statusList:
        if status.family == "Bleed" or status.name == "Sear" and opposer:
            if "Damage" in status.type_ and not "Special" in status.type_:
                status.simple(opposer, damage, afflicted)
            else:
                status.special(opposer, damage, afflicted)
            amount += 1
        
        if amount >= self.stacks:
            break
Bloodboon = Status("Bloodboon", "Bleed", 2, ["Special"], "Positive",
                   "For each stack, chance to retrigger 1 Bleed status present on the opposer. Last 2 actions and stacks up to 4.",
                   canStack=True, maxStack=4)
Bloodboon.special = types.MethodType(boonSpecial, Bloodboon)

def bloodGeyserSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.wasHit:
        for i in range (0, opposer.attackHits):
            self.inflict(afflicted, random.randint(1,8))

    damage = self.stacks
    afflicted.health -= damage
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")

    if self.stacks >= self.maxStack:
        self.remove(afflicted, self.maxStack)
        damage = 50 + round(afflicted.maxHealth * 0.1)
        afflicted.health -= damage
        say(f"{Color['red']}Blood Geyser Was Triggered! {afflicted.name} Took {damage} Damage!{Color['reset']}")
BloodGeyser = Status("Blood Geyser", "Bleed", 1, ["Special", "Damage"], "Negative",
                     "Deal damage (stacks). If attack or a damaging skill is used by the opposer, gain 1-8 stacks per hit. At max stacks, lose all stacks and deal damage (50 + 10% of Max Health). Last forever and stacks to 100.",
                     forever=True, canStack=True, maxStack=100)
BloodGeyser.special = types.MethodType(bloodGeyserSpecial, BloodGeyser)

Devotion = Status("Devotion", "Other", 2, ["Damage", "Buff"], "Neutral",
                  "Drains mana (10% of Max Mana x 2 + 1-4 x stack). Raise Magic/Luck by (3/10) + stack. Last 2 actions and stacks up to 5.",
                  meter="mana", canStack=True, maxStack= 5, damage=[[["maxMana", 10]], lambda: random.randint(1,4), 2], mutate=[["magic", 3], ["luck", 10]])

Parry = Status("Parry", "Other", 2, ["Counter"], "Positive",
               "If damaged by an attack or skill, deal damage to the opposer (Strength x 2). Last 2 actions.",
               counter=[2, "strength"], counterType="self")

Zealotry = Status("Zealotry", "Other", 3, ["Damage", "Buff"], "Neutral",
                  "Drains mana (6% of Max Mana x 2 + 3-6 x stack). Lower Magic/Luck by 7/24. Last 3 actions.",
                  meter="mana", damage=[[["maxMana", 6]], lambda: random.randint(3,6), 2], mutate=[["magic", -7], ["luck", -24]])

def vestigeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    instance = next(s for s in afflicted.statusList if s.name == self.name)

    damage = round(afflicted.strength * 0.25 + afflicted.magic * 0.25 + self.stacks) * 2
    opposer.health -= damage
    say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")

    self.statMutation(afflicted)
    for setS in self.mutate:
        number = abs(setS[1]) + instance.stacks
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {abs(number)}!{Color['reset']}")
    
    return damage
Vestige = Status("Vestige", "Other", 2, ["Special"], "Positive",
                 "Raise Speed by 4 + 1 per stack. Deal damage to opposer (25% of Strength + 25% of Magic + stack) x 2. Last 2 actions and stacks up to 5.",
                 canStack=True, maxStack=10, mutate=[["speed", 4]])
Vestige.special = types.MethodType(vestigeSpecial, Vestige)

Warrior = Status("Warrior", "Other", 2, ["Buff"], "Positive",
                 "Raise Strength/Defense/Hit by 5/5/15. Last 2 actions and stacks up to 5.",
                 canStack=True, maxStack=5, mutate=[["strength", 5], ["defense", 5], ["hit", 15]])

def waxSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    afflicted.sanity += 1 + self.stacks
    instance = next(s for s in afflicted.statusList if s.name == self.name)
    self.statMutation(afflicted)
    for setS in self.mutate:
        number = abs(setS[1]) + instance.stacks
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {abs(number)}!{Color['reset']}")
        
    if (opposer.lastSkill and "Damage" in opposer.lastSkill.type_ and opposer.lastSkill.statsUsed[0] == "magic") and (opposer.lastAction and opposer.lastAction == "Skill"):
        for status in afflicted.statusList:
            if status.name == "Wax":
                status.stacks = max(0, status.stacks - 2)

    damage = 0
    if any("Burn" == s.family for s in opposer.statusList):
            damage = round(opposer.magic * 0.50)
            say(f"{Color['red']}Wax Was Triggered! {opposer.name} Took {damage}!{Color['reset']}")
            opposer.health -= damage
    
    return damage
Wax = Status("Wax", "Other", 3, ["Special", "Sanity"], "Positive",
             "Raise Defense/Resistance by 3 + 1 per stack. Gain 1 + stack sanity each action. If any Burn statuses are present on the opposer, deal damage to the opposer (50% of Magic). If opposers last skill used was Magic, remove 2 stacks of Wax. Last 3 actions and stacks up to 8.",
             canStack=True, maxStack=8, sanity=1, mutate=[["defense", 3], ["resistance", 3]], sanityCondition=True)
Wax.special = types.MethodType(waxSpecial, Wax)

def lightSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.sanity >= 15:
        Power.inflict(afflicted)
        Protection.inflict(afflicted)

    if afflicted.sanity <= -12:
        Fragile.inflict(afflicted)
        Slug.inflict(afflicted)

    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {abs(setS[1]) + self.stacks * 2}!{Color['reset']}")
Light = Status("Light", "Other", 3, ["Special", "Buff"], "Neutral",
               "Raise Strength/Luck by 8/20 + 2 per stack. If sanity is at 15+, gain 1 stack of Power/Protection. If sanity is below -12, gain 1 stack of Fragile/Slug. Last 3 actions and stacks up to 10.",
               canStack=True, maxStack=10, stackScale=2, mutate=[["strength", 8], ["luck", 20]])
Light.special = types.MethodType(lightSpecial, Light)

def meltingSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if not any(s.name == "Light" for s in afflicted.statusList):
        self.remove(afflicted, full=True)
        afflicted.sanity -= 10

    if self.stacks >= 15:
        afflicted.sanity += 8
        Boon.inflict(afflicted, 2)
        afflicted.speedMeter += 25
        say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By 25!{Color['reset']}")

    self.statMutation(afflicted)
    for setS in self.mutate:
        if setS[1] > 0:
            say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {abs(setS[1]) + self.stacks}!{Color['reset']}")

        elif setS[1] > 0:
            say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(setS[1]) + self.stacks}!{Color['reset']}")
Melting = Status("Melting", "Burn", 2, ["Special", "Debuff"], "Neutral",
               "If Light is not present, remove self and lose 10 sanity. Raise Speed/Hit by 1 + 1 per stack. Lower Defense/Resistance by 1 + 1 per stack. If at 15+ stacks, gain 8 sanity, gain 2 stacks of Boon, and raise Speed Meter by 25. Last 2 actions and stacks up to 30.",
               canStack=True, maxStack=30, mutate=[["speed", 1], ["hit", 1], ["defense", -1], ["resistance", -1]])
Melting.special = types.MethodType(meltingSpecial, Melting)

def silenceSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if afflicted.lastAction == "Skill":
        CrippleII.inflict(afflicted)
        FrailII.inflict(afflicted)

    self.statMutation(afflicted)
    say(f"{Color['magenta']}{afflicted.name}s Hit Was Reduced By 29!{Color['reset']}")
    say(f"{Color['magenta']}{afflicted.name}s Luck Was Reduced By 20!{Color['reset']}")
Silence = Status("Silence", "Other", 3, ["Special"], "Negative", 
                 "Lowers Hit/Luck by 20. If a skill is used, gain Cripple II/Frail II. Last 3 actions.",
                 mutate=[["strength", -20], ["magic", -20]])
Silence.special = types.MethodType(silenceSpecial, Silence)

def stolenTimeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if hasattr(afflicted, "ultimateMeter"):
        amount = 10 + sum(10 for i in range(0, self.stacks, 100))
        afflicted.ultimateMeter = afflicted.ultimateMeter + amount
        say(f"{Color['yellow']}{afflicted.name}s Ultimate Meter Was Increased By {amount}!{Color['reset']}")

    self.statMutation(afflicted)
    say(f"{Color['yellow']}{afflicted.name}s Speed Was Increased By 6!{Color['reset']}")

    if self.stacks >= 300:
        afflicted.sanity -= 3
StolenTime = Status("Stolen Time", "Shock", 1, ["Special"], "Positive",
                    "Raise Speed by 6. Increase Ultimate Meter by 10 + 10 per 100 stacks of Stolen Time. If Stolen Time is at 300+ stacks, lose 3 sanity. Last 1 action and stacks up to 500.",
                    canStack=True, maxStack=500, mutate=[["speed", 6]], scaleWithStacks=False)
StolenTime.special = types.MethodType(stolenTimeSpecial, StolenTime)

CrimsonMoonsBlessing = Status("Crimson Moon's Blessing", "Other", 3, ["Buff", "Sanity"], "Positive",
                              "Raise Strength/Speed by 7/5. Gain 3 sanity. Last 3 actions",
                              sanity=3, mutate=[["strength", 7], ["speed", 5]], sanityCondition=True); CrimsonMoonsBlessing.count = 0

def lunarBindSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    bind = next((s for s in afflicted.statusList if s.name == "Bind II"), None)
    if bind:
        bind.remove(afflicted, full=True)
        self.duration -= 1
        say(f"{Color['magenta']}{self.name} Had Its Duration Extended By 1!{Color['reset']}")
        
    deep = next((s for s in afflicted.statusList if s.name == "Deep Freeze"), None)
    if deep:
        deep.remove(afflicted, full=True)
        afflicted.sanity -= 5
        say(f"{Color['magenta']}{afflicted.name} Lost 5 Sanity!{Color['reset']}")
    
    self.simple(afflicted)
LunarBind = Status("Lunar Bind", "Chill", 2, ["Special", "Stun", "Debuff"], "Negative",
                   "Lower Resistance/Speed by 10. Cannot act while this status is present. If Bind II is present, remove Bind II and extend duration by 1. If Deep Freeze is present, remove Deep Freeze and lose 5 sanity. Last 2 actions.",
                   mutate=[["resistance", -10], ["speed", -10]])
LunarBind.special = types.MethodType(lunarBindSpecial, LunarBind)

def coffinSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if opposer and opposer.lastAction and opposer.lastAction == "Skill" and opposer.lastSkill:
        Burnout.inflict(opposer)
        damage = round(afflicted.strength * 0.75 * 2)
        opposer.health -= damage
        say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")
        self.remove(afflicted, full=True)
        return
    
    afflicted.ultimateMeter += 5 + afflicted.sanity
    say(f"{Color['yellow']}{afflicted.name}s Ultimate Meter Was Increased By {5 + afflicted.sanity}!{Color['reset']}")
    
    afflicted.sanity += 1
    say(f"{Color['yellow']}{afflicted.name} Gained 1 Sanity!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {abs(setS[1])}!{Color['reset']}")
Coffin = Status("Coffin", "Other", 2, ["Special"], "Positive",
                 "Raise Strength/Luck by 5/20. Raise Ultimate Meter by 5 + sanity. Gain 1 sanity. If opposer used any skill on their previous action, remove self, inflict Burnout, and deal damage (75% of Strength x 2) to the opposer. Last 2 actions.",
                 mutate=[["strength", 5], ["luck", 20]])
Coffin.special = types.MethodType(coffinSpecial, Coffin)

def oopsieSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    damage = (random.randint(1, 3) + sum(1 for s in afflicted.statusList if s.align == "Negative")) * sum(1 for s in afflicted.statusList if s.align == "Negative")
    say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
    
    self.statMutation(afflicted)
    for setS in self.mutate:
        setS[1] = random.randint(-10, -1)
        say(f"{Color['magenta']}{afflicted.name}s {setS[0].capitalize()} Was Reduced By {abs(setS[1])}!{Color['reset']}")
Oopsie = Status("Oopsie", "Other", 3, ["Special", "Damage"], "Negative",
                "Deals damage (1-3 + number of Negative statuses present) x number of Negative statuses present. Lowers Defense/Resistance/Luck by 1-10. Last 3 actions.",
                mutate=[["defense", 0], ["resistance", 0], ["luck", 0]])
Oopsie.special = types.MethodType(oopsieSpecial, Oopsie)

DelusionsOfGrandeur = Status("Delusions of Grandeur", "Mental", 5, ["Buff"], "Positive",
                             "Raise Magic/Speed by 5/10 + 2 per stack. Transforms into Engulfed on end. Last 5 actions and stacks up to 10.",
                             maxStack=10, mutate=[["magic", 5], ["speed", 10]], stackScale=2, transform=Engulfed)

BrokenFacade = Status("Broken Facade", "Mental", 4, ["Debuff", "Shift"], "Positive",
                "Lowers Magic by 4. Change all elemental affinities into Resist. Transforms into Regen on end. Last 4 actions.",
                mutate=[["magic", -4]], transform=Regen,
                shift=[["fire", "Resist"], ["ice", "Resist"], ["thunder", "Resist"], ["wind", "Resist"], ["mighty", "Resist"], ["physical", "Resist"]])

Isolation = Status("Isolation", "Mental", 3, ["Shift"], "Positive",
                "Change all elemental affinities into Null. Last 3 actions.",
                shift=[["fire", "Null"], ["ice", "Null"], ["thunder", "Null"], ["wind", "Null"], ["mighty", "Null"], ["physical", "Null"]])

Nebulize = Status("Nebulize", "Other", 3, ["Buff", "Sanity"], "Positive",
                 "Raise Strength/Magic/Luck/Speed by 6/6/15/5 + 3 per stack. Gain 3 + 1 per stack sanity. Last 3 actions and stacks up to 6.",
                 canStack=True, maxStack=6, mutate=[["strength", 6], ["magic", 6], ["luck", 15], ["speed", 5]], stackScale=3, sanity=3)

def sapienSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.count <= 0:
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Waking Avalanche"))
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Icy Barrier"))
        afflicted.ultimateSkill.remove(next(s for s in afflicted.ultimateSkill if s.name == "Diamond Dust"))
        self.remove(afflicted, full=True)
        return
    
    if self.duration % 2 == 0 and self.duration != 0:
        damage = round(abs(afflicted.magic * 0.65 - opposer.resistance * 0.5)) * 2
        say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")
        opposer.health -= damage
        
    if self.duration % 3 == 0 and self.duration != 0:
        afflicted.baseMagic += 3
        say(f"{Color['yellow']}{afflicted.name}s Magic Was Permanetly Increased By 3!{Color['reset']}")
    
    count = 0
    for status in afflicted.statusList:
        if "Chill" == status.family:
            self.count -= 1
            say(f"{Color['red']}{self.name} Lost 1 Count!{Color['reset']}")
            count += 1
        
        if count >= 2:
            break
    # Count damage & Status lost handled in Three Headed Dragon King theme in Battle.py
Sapien = Status("Sapien Head", "Other", 0, ["Special"], "Neutral",
                "Every 2 actions active, deal damage to opposer ((65% of Magic - 50% of opposers Resistance) x 2). Every 3 actions active, permanently raise Magic by 3. When the opposer uses a skill with the Ice element, lose 3 count. If any Chill statuses are present, lose 1 count per status (Max 2). When count reaches 0,  lose the skills Waking Avalanche/Icy Barrier/Diamond Dust. Last foreveer.",
                forever=True); Sapien.count = 9
Sapien.special = types.MethodType(sapienSpecial, Sapien)

def temerariosSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.count <= 0:
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Mega Flare Impact"))
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Blazing Heart"))
        afflicted.ultimateSkill.remove(next(s for s in afflicted.ultimateSkill if s.name == "Giga Flare Impact"))
        self.remove(afflicted, full=True)
        return
    
    if self.duration % 2 == 0 and self.duration != 0:
        damage = round(abs(afflicted.strength * 0.5 - opposer.defense * 0.5)) * 2
        say(f"{Color['red']}{opposer.name} Took {damage} From {self.name}!{Color['reset']}")
        opposer.health -= damage
        
    if self.duration % 3 == 0 and self.duration != 0:
        afflicted.baseStrength += 2
        afflicted.baseHit += 5
        say(f"{Color['yellow']}{afflicted.name}s Strength Was Permanetly Increased By 2!{Color['reset']}")
        say(f"{Color['yellow']}{afflicted.name}s Hit Was Permanetly Increased By 5!{Color['reset']}")
    
    count = 0
    for status in afflicted.statusList:
        if "Burn" == status.family:
            self.count -= 1
            say(f"{Color['red']}{self.name} Lost 1 Count!{Color['reset']}")
            count += 1
        
        if count >= 2:
            break
    # Count damage & Status lost handled in Three Headed Dragon King theme in Battle.py
Temerarios = Status("Temerarios Head", "Other", 0, ["Special"], "Neutral",
                    "Every 2 actions active, deal damage to opposer ((50% of Strength - 50% of opposers Defense) x 2). Every 3 actions active, permanently raise Strength/Hit by 2/5. When the opposer uses a skill with the Fire element, lose 3 count. If any Burn statuses are present, lose 1 count per status (Max 2). When count reaches 0,  lose the skills Mega Flare Impact/Blazing Heart/Giga Flare Impact. Last foreveer.",
                    forever=True); Temerarios.count = 9
Temerarios.special = types.MethodType(temerariosSpecial, Temerarios)

def fomesSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.count <= 0:
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Primaeval Rupture"))
        afflicted.skills.remove(next(s for s in afflicted.skills if s.name == "Planning King"))
        afflicted.ultimateSkill.remove(next(s for s in afflicted.ultimateSkill if s.name == "Imposing Aura"))
        self.remove(afflicted, full=True)
        return
    
    if self.duration % 3 == 0 and self.duration != 0:
        afflicted.ultimateMeter += 25
        afflicted.speedMeter += 30
        say(f"{Color['yellow']}{afflicted.name}s Ultimate Meter Was Raised By 25!{Color['reset']}")
        say(f"{Color['yellow']}{afflicted.name}s Speed Meter Was Raised By 30!{Color['reset']}")
        
    if self.duration % 4 == 0 and self.duration != 0:
        afflicted.baseSpeed += 2
        say(f"{Color['yellow']}{afflicted.name}s Speed Was Permanetly Increased By 2!{Color['reset']}")
    # Count damage & Status lost handled in Three Headed Dragon King theme in Battle.py
Fomes = Status("Fomes Head", "Other", 0, ["Special"], "Neutral",
                "Every 3 actions, raise Ultimate/Speed Meter by 25/30. Every 4 actions active, permanently raise Speed by 2. When the opposer uses a skill with the Mighty element, lose 3 count. When count reaches 0,  lose the skills Primaeval Rupture/Planning Aura/Imposing Aura. Last foreveer.",
                forever=True); Fomes.count = 12
Fomes.special = types.MethodType(fomesSpecial, Fomes)

def purpleHazeInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        damage = 0
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['magenta']}{afflicted.name}s Purple Haze Triggered! Damage Was Nullified!{Color['reset']}")
    return damage
def purpleHazeSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    self.statMutation(afflicted)
    for setS in self.mutate:
        say(f"{Color['yellow']}{afflicted.name}s {setS[0].capitalize()} Was Increased By {setS[1]}!{Color['reset']}")
PurpleHaze = Status("Purple Haze", "Other", 0, ["Special"], "Neutral",
                    "Nullify damage from the next attack or damaging skill used by the opposer and lose 1 stack. Raise Luck/Speed by 50/15. Last forever and stacks up to 6.",
                    forever=True, canStack=True, maxStack=6, mutate=[["luck", 50], ["speed", 15]])
PurpleHaze.special = types.MethodType(purpleHazeSpecial, PurpleHaze)
PurpleHaze.damageInterupt = types.MethodType(purpleHazeInterupt, PurpleHaze)

def flameShieldsInterupt(self, afflicted: Player | Enemy, opposer: Player | Enemy, damage: int = 0, side: str = "user"):
    if side == "target":
        reduce = (0.35 + 0.03 * self.stacks)
        damage -= round(damage * reduce)
        self.remove(afflicted)
        if self.stacks <= 0:
            self.remove(afflicted, full=True)
        say(f"{Color['magenta']}{afflicted.name}s Flame Shields Triggered! Damage Was Reduced By {round(reduce * 100)}%!{Color['reset']}")
    return damage
def flameShieldsSpecial(self, afflicted: Player | Enemy, damage: int = 0, opposer: Player | Enemy = None):
    if self.stacks >= 10:
        damage = round(afflicted.maxHealth * 0.05)
        afflicted.health -= damage
        say(f"{Color['red']}{afflicted.name} Took {damage} From {self.name}!{Color['reset']}")
FlameShields = Status("Flame Shields", "Burn", 2, ["Special"], "Positive", 
                      "Reduce damage taken by the next attack or damaging skill used by the opposer by 35% + 3% per stack. At 10+ stacks, deal damage (5% of Max Health). Last 2 actions and stacks up to 30.",
                      canStack=True, maxStack=30)
FlameShields.special = types.MethodType(flameShieldsSpecial, FlameShields)
FlameShields.damageInterupt = types.MethodType(flameShieldsInterupt, FlameShields)