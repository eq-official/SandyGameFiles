from Utility import *
from gameData.RaidMaps import *
from Battle import *

##--Player Classes--##
class_nobody = Player(None, "Nobody - Dev", 230, 75, 6, 6, 4, 4, 70, 80, 15, [skill_cure, skill_clean_piercer, skill_bliz, skill_fira, skill_thunger, skill_wind])

class_lancer = Player(None, "Lancer", 250, 75, 8, 3, 7, 5, 65, 75, 15, [lancer_ready_stance, lancer_morstalis_thrust, lancer_defensive_whirl])
class_magi = Player(None, "Magi", 240, 80, 3, 8, 2, 6, 55, 65, 10, [magi_weather_ball, magi_thunger_alter, magi_mana_rupture, passive_attune])
class_ferkin = Player(None, "Ferkin", 220, 60, 7, 5, 5, 5, 75, 70, 15, [ferkin_munch, ferkin_beast_swipe, ferkin_familial_instinct])
class_accursed = Player(None, "Accursed", 250, 90, 5, 7, 4, 5, 85, 75, 10, [accursed_malfira, accursed_malwind, accursed_malremolio])
class_monk = Player(None, "Monk", 215, 75, 6, 7, 3, 4, 70, 75, 15, [monk_chi_palm, monk_soul_search, monk_chi_blast])
class_forlorn = Player(None, "Forlorn", 275, 70, 8, 5, 3, 3, 50, 90, 15, [forlorn_dwell, forlorn_panic_attack, forlorn_trauma_break, passive_experience])
class_scout = Player(None, "Scout", 200, 75, 6, 3, 3, 2, 80, 85, 20, [scout_tri_blade, scout_quick_glance, scout_myriad_rush])
class_equinox= Player(None, "Equinox", 225, 70, 5, 8, 3, 3, 70, 75, 15, [equinox_emission, equinox_sarn, equinox_pendulum, passive_metamorphosis])
class_cleric = Player(None, "Cleric", 210, 100, 2, 6, 2, 4, 85, 70, 15, [cleric_sutura, cleric_divine_protection, cleric_smite, passive_confessions])
class_daredevil = Player(None, "Daredevil", 250, 65, 7, 3, 3, 2, 70, 80, 20, [daredevil_test_run, daredevil_freestyle_danger, daredevil_triple_axel, passive_fearless])
class_tamer = Player(None, "Tamer", 275, 100, 5, 5, 4, 4, 90, 75, 15, [tamer_tackle, tamer_whistle, tamer_buddy_trick, passive_kindred])
class_thief = Player(None, "Thief", 250, 80, 6, 3, 5, 3, 75, 85, 20, [thief_coin_shot, thief_swipe, thief_sleight_hand, passive_sticy_fingers])

# Growth Tables
growthTables = {
    "Nobody - Dev": {
        "maxHealth": 14,
        "maxMana": 8,
        "strength": 2,
        "magic": 2,
        "defense": 1,
        "resistance": 2,
    },
    
    "Lancer": {
        "maxHealth": 15,
        "maxMana": 6,
        "strength": 2,
        "magic": 1,
        "defense": 2,
        "resistance": 1,
    },
    "Magi": {
        "maxHealth": 12,
        "maxMana": 10,
        "strength": 1,
        "magic": 2,
        "defense": 1,
        "resistance": 2,
    },
    "Ferkin": {
        "maxHealth": 18,
        "maxMana": 8,
        "strength": 2,
        "magic": 1,
        "defense": 2,
        "resistance": 2,
    },
    "Accursed": {
        "maxHealth": 12,
        "maxMana": 10,
        "strength": 1,
        "magic": 2,
        "defense": 1,
        "resistance": 2,
    },
    "Monk": {
        "maxHealth": 14,
        "maxMana": 9,
        "strength": 1,
        "magic": 2,
        "defense": 1,
        "resistance": 2,
    },
    "Forlorn": {
        "maxHealth": 20,
        "maxMana": 7,
        "strength": 2,
        "magic": 2,
        "defense": 1,
        "resistance": 1,
    },
    "Scout": {
        "maxHealth": 10,
        "maxMana": 8,
        "strength": 2,
        "magic": 1,
        "defense": 1,
        "resistance": 1,
    },
    "Equinox": {
        "maxHealth": 11,
        "maxMana": 6,
        "strength": 2,
        "magic": 2,
        "defense": 1,
        "resistance": 1,
    },
    "Cleric": {
        "maxHealth": 11,
        "maxMana": 9,
        "strength": 1,
        "magic": 2,
        "defense": 1,
        "resistance": 2,
    },
    "Daredevil": {
        "maxHealth": 18,
        "maxMana": 6,
        "strength": 2,
        "magic": 1,
        "defense": 2,
        "resistance": 1,
    },
    "Tamer": {
        "maxHealth": 15,
        "maxMana": 10,
        "strength": 1,
        "magic": 1,
        "defense": 1,
        "resistance": 1,
    },
    "Thief": {
        "maxHealth": 12,
        "maxMana": 12,
        "strength": 2,
        "magic": 1,
        "defense": 2,
        "resistance": 1,
    }
}